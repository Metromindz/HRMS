import { useState, useEffect, useMemo } from 'react';
import api from '@/config/api';
import ApexChartClient from '@/components/client-wrapper/ApexChartClient';
import { useNotifications } from '@/context/NotificationContext';
import { useAuth } from '@/context/AuthContext';
import {
    LuCircleCheck,
    LuClock,
    LuListTodo,
    LuPause,
    LuCircleAlert,
    LuTrendingUp,
    LuRefreshCw
} from 'react-icons/lu';

const TaskStatusChartWidget = () => {
    const { socket } = useNotifications();
    const { user } = useAuth();
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);
    const [hoveredSegment, setHoveredSegment] = useState(null);

    const fetchStats = async () => {
        try {
            const res = await api.get('/dashboard/task-status');
            if (res.data.success) {
                setStats(res.data.data);
            }
        } catch (err) {
            console.error('Failed to fetch task status:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchStats();
    }, []);

    useEffect(() => {
        if (!socket) return;

        const handleTaskChange = (payload) => {
            const role = user?.role?.toLowerCase();
            const isPrivileged = role === 'superadmin' || role === 'admin' || role === 'hr';
            if (isPrivileged || (payload?.affectedUserIds && payload.affectedUserIds.includes(user?._id))) {
                fetchStats();
            }
        };

        socket.on('task-changed', handleTaskChange);
        socket.on('task-board-refresh', fetchStats);

        return () => {
            socket.off('task-changed', handleTaskChange);
            socket.off('task-board-refresh', fetchStats);
        };
    }, [socket, user]);

    const statusConfig = useMemo(() => ({
        completed: {
            label: 'Completed',
            color: '#10b981',
            bgColor: 'bg-emerald-500',
            lightColor: 'bg-emerald-50',
            textColor: 'text-emerald-700',
            icon: LuCircleCheck,
            description: 'Finished tasks'
        },
        in_progress: {
            label: 'In Progress',
            color: '#6366f1',
            bgColor: 'bg-indigo-500',
            lightColor: 'bg-indigo-50',
            textColor: 'text-indigo-700',
            icon: LuClock,
            description: 'Active work'
        },
        todo: {
            label: 'To Do',
            color: '#8b5cf6',
            bgColor: 'bg-violet-500',
            lightColor: 'bg-violet-50',
            textColor: 'text-violet-700',
            icon: LuListTodo,
            description: 'Queued tasks'
        },
        pending: {
            label: 'Pending',
            color: '#f59e0b',
            bgColor: 'bg-amber-500',
            lightColor: 'bg-amber-50',
            textColor: 'text-amber-700',
            icon: LuPause,
            description: 'On hold'
        },
        overdue: {
            label: 'Overdue',
            color: '#ef4444',
            bgColor: 'bg-rose-500',
            lightColor: 'bg-rose-50',
            textColor: 'text-rose-700',
            icon: LuCircleAlert,
            description: 'Past due date'
        }
    }), []);

    const chartData = useMemo(() => {
        if (!stats) return null;

        const data = [
            { key: 'completed', value: stats.completed || 0 },
            { key: 'in_progress', value: stats.in_progress || 0 },
            { key: 'todo', value: stats.todo || 0 },
            { key: 'pending', value: stats.pending || 0 },
            { key: 'overdue', value: stats.overdue || 0 }
        ];

        const total = data.reduce((sum, item) => sum + item.value, 0);

        return {
            series: data.map(d => d.value),
            labels: data.map(d => statusConfig[d.key].label),
            colors: data.map(d => statusConfig[d.key].color),
            data,
            total
        };
    }, [stats, statusConfig]);

    const chartOptions = useMemo(() => {
        if (!chartData) return null;

        return {
            series: chartData.series,
            options: {
                chart: {
                    type: 'donut',
                    fontFamily: 'Inter, system-ui, sans-serif',
                    toolbar: { show: false },
                    animations: {
                        enabled: true,
                        easing: 'easeinout',
                        speed: 800,
                        animateGradually: { enabled: true, delay: 150 },
                        dynamicAnimation: { enabled: true, speed: 350 }
                    },
                    events: {
                        dataPointSelection: (event, chartContext, config) => {
                            setHoveredSegment(config.dataPointIndex);
                        },
                        mouseLeave: () => setHoveredSegment(null)
                    }
                },
                labels: chartData.labels,
                colors: chartData.colors,
                dataLabels: {
                    enabled: false
                },
                legend: {
                    show: false
                },
                plotOptions: {
                    pie: {
                        donut: {
                            size: '75%',
                            background: 'transparent',
                            labels: {
                                show: true,
                                name: {
                                    show: true,
                                    fontSize: '14px',
                                    fontWeight: 600,
                                    color: '#64748b',
                                    offsetY: -10
                                },
                                value: {
                                    show: true,
                                    fontSize: '28px',
                                    fontWeight: 700,
                                    color: '#1e293b',
                                    offsetY: 5,
                                    formatter: (val) => val
                                },
                                total: {
                                    show: true,
                                    showAlways: true,
                                    label: 'Total Tasks',
                                    fontSize: '12px',
                                    fontWeight: 500,
                                    color: '#94a3b8',
                                    formatter: () => chartData.total
                                }
                            }
                        }
                    }
                },
                stroke: {
                    show: true,
                    width: 2,
                    colors: ['#ffffff']
                },
                tooltip: {
                    enabled: true,
                    theme: 'light',
                    y: {
                        formatter: (val) => `${val} tasks`
                    },
                    style: {
                        fontSize: '12px',
                        fontFamily: 'Inter, system-ui, sans-serif'
                    },
                    fillSeriesColor: false,
                    marker: { show: true }
                },
                states: {
                    hover: {
                        filter: {
                            type: 'darken',
                            value: 0.8
                        }
                    },
                    active: {
                        filter: {
                            type: 'darken',
                            value: 0.8
                        }
                    }
                }
            }
        };
    }, [chartData]);

    if (loading) {
        return (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm h-full flex items-center justify-center p-8">
                <div className="flex flex-col items-center gap-3">
                    <div className="w-10 h-10 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin" />
                    <span className="text-sm font-medium text-slate-500">Loading analytics...</span>
                </div>
            </div>
        );
    }

    if (!stats || !chartOptions) return null;

    const totalTasks = chartData.total;
    const completionRate = totalTasks > 0 ? Math.round((stats.completed / totalTasks) * 100) : 0;

    return (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden h-full flex flex-col">
            {/* Header */}
            <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-50/50 to-white">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                        <LuTrendingUp className="w-5 h-5" />
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-slate-900">Task Overview</h3>
                        <p className="text-sm text-slate-500">Real-time status distribution</p>
                    </div>
                </div>
                <button
                    onClick={fetchStats}
                    className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all active:scale-95"
                    title="Refresh data"
                >
                    <LuRefreshCw className="w-5 h-5" />
                </button>
            </div>

            <div className="flex-1 flex flex-col xl:flex-row">
                {/* Chart Section */}
                <div className="flex-1 p-6 flex items-center justify-center bg-gradient-to-br from-slate-50/30 to-white min-h-[300px]">
                    <div className="w-full max-w-[280px] sm:max-w-sm flex justify-center flex-col items-center">
                        <ApexChartClient
                            getOptions={() => chartOptions.options}
                            series={chartOptions.series}
                            type="donut"
                            height={320}
                        />
                    </div>
                </div>

                {/* Stats Grid */}
                <div className="w-full xl:w-80 p-6 bg-slate-50/50 xl:border-l border-t xl:border-t-0 border-slate-100 flex flex-col justify-center">
                    <div className="mb-6 pb-6 border-b border-slate-200">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium text-slate-600">Completion Rate</span>
                            <span className="text-2xl font-bold text-emerald-600">{completionRate}%</span>
                        </div>
                        <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                            <div
                                className="h-full bg-emerald-500 rounded-full transition-all duration-1000 ease-out"
                                style={{ width: `${completionRate}%` }}
                            />
                        </div>
                        <p className="text-xs text-slate-500 mt-2">
                            {stats.completed} of {totalTasks} tasks completed
                        </p>
                    </div>

                    <div className="space-y-3">
                        {chartData.data.map((item, index) => {
                            const config = statusConfig[item.key];
                            const Icon = config.icon;
                            const percentage = totalTasks > 0 ? Math.round((item.value / totalTasks) * 100) : 0;
                            const isHovered = hoveredSegment === index;

                            return (
                                <div
                                    key={item.key}
                                    className={`group flex items-center gap-3 p-3 rounded-xl transition-all cursor-pointer ${isHovered
                                        ? 'bg-white shadow-md scale-105 border border-slate-200'
                                        : 'hover:bg-white hover:shadow-sm border border-transparent'
                                        }`}
                                    onMouseEnter={() => setHoveredSegment(index)}
                                    onMouseLeave={() => setHoveredSegment(null)}
                                >
                                    <div className={`w-10 h-10 rounded-lg ${config.lightColor} flex items-center justify-center ${config.textColor} transition-transform group-hover:scale-110`}>
                                        <Icon className="w-5 h-5" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center justify-between mb-0.5">
                                            <span className="text-sm font-semibold text-slate-900 truncate">
                                                {config.label}
                                            </span>
                                            <span className="text-sm font-bold text-slate-700">
                                                {item.value}
                                            </span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <div className="flex-1 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                                                <div
                                                    className={`h-full ${config.bgColor} rounded-full transition-all duration-500`}
                                                    style={{ width: `${percentage}%` }}
                                                />
                                            </div>
                                            <span className="text-xs font-medium text-slate-500 w-8 text-right">
                                                {percentage}%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TaskStatusChartWidget;