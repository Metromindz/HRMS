import { useState, useEffect, useMemo } from 'react';
import api from '@/config/api';
import ApexChartClient from '@/components/client-wrapper/ApexChartClient';
import { 
  PieChart, 
  RefreshCw, 
  MoreHorizontal,
  TrendingUp,
  Users,
  Target,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

const LeadsBySourceWidget = () => {
  const [leadsSources, setLeadsSources] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [hoveredSegment, setHoveredSegment] = useState(null);

  const fetchLeadsSources = async () => {
    if (!isRefreshing) setLoading(true);
    try {
      const res = await api.get('/dashboard/leads-sources');
      if (res.data.success) {
        setLeadsSources(res.data.data);
      }
    } catch (err) {
      console.error('Failed to fetch leads sources:', err);
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    fetchLeadsSources();
  };

  useEffect(() => {
    fetchLeadsSources();
  }, []);

  // Enhanced color palette with gradients
  const colorPalette = [
    { solid: '#6366f1', gradient: 'from-indigo-500 to-violet-600', bg: 'bg-indigo-50', text: 'text-indigo-600', border: 'border-indigo-200' },
    { solid: '#10b981', gradient: 'from-emerald-500 to-teal-600', bg: 'bg-emerald-50', text: 'text-emerald-600', border: 'border-emerald-200' },
    { solid: '#f59e0b', gradient: 'from-amber-500 to-orange-600', bg: 'bg-amber-50', text: 'text-amber-600', border: 'border-amber-200' },
    { solid: '#ef4444', gradient: 'from-rose-500 to-pink-600', bg: 'bg-rose-50', text: 'text-rose-600', border: 'border-rose-200' },
    { solid: '#22c55e', gradient: 'from-green-500 to-emerald-600', bg: 'bg-green-50', text: 'text-green-600', border: 'border-green-200' },
    { solid: '#a855f7', gradient: 'from-purple-500 to-fuchsia-600', bg: 'bg-purple-50', text: 'text-purple-600', border: 'border-purple-200' },
    { solid: '#3b82f6', gradient: 'from-blue-500 to-indigo-600', bg: 'bg-blue-50', text: 'text-blue-600', border: 'border-blue-200' },
    { solid: '#f97316', gradient: 'from-orange-500 to-red-600', bg: 'bg-orange-50', text: 'text-orange-600', border: 'border-orange-200' },
  ];

  const chartOptions = useMemo(() => {
    if (!leadsSources) return null;
    
    const sourceData = (leadsSources.bySource || []);
    const labels = sourceData.map(i => i._id || 'Others');
    const series = sourceData.map(i => i.count);
    const total = series.reduce((a, b) => a + b, 0);

    return {
      series,
      options: {
        chart: {
          type: 'donut',
          height: 260,
          toolbar: { show: false },
          parentHeightOffset: 0,
          fontFamily: 'inherit',
          events: {
            dataPointSelection: (event, chartContext, config) => {
              setHoveredSegment(config.dataPointIndex);
            }
          },
          animations: {
            enabled: true,
            easing: 'easeinout',
            speed: 800,
            animateGradually: { enabled: true, delay: 150 },
            dynamicAnimation: { enabled: true, speed: 350 }
          }
        },
        labels,
        colors: colorPalette.map(c => c.solid),
        legend: { 
          show: false // Custom legend built below
        },
        dataLabels: { 
          enabled: false 
        },
        stroke: { 
          show: true,
          width: 2,
          colors: ['#ffffff']
        },
        plotOptions: {
          pie: {
            donut: {
              size: '65%',
              labels: {
                show: true,
                total: {
                  show: true,
                  label: 'Total Leads',
                  fontSize: '12px',
                  fontWeight: 600,
                  color: '#94a3b8',
                  formatter: () => total,
                },
                value: {
                  fontSize: '28px',
                  fontWeight: 700,
                  color: '#1e293b',
                }
              }
            },
            expandOnClick: true,
          }
        },
        tooltip: {
          enabled: true,
          y: {
            formatter: (val) => `${val} leads (${Math.round((val/total)*100)}%)`
          }
        }
      }
    };
  }, [leadsSources]);

  // Build custom legend with stats
  const legendItems = useMemo(() => {
    if (!leadsSources) return [];
    
    const sourceData = (leadsSources.bySource || []);
    const total = sourceData.reduce((acc, item) => acc + item.count, 0);
    
    return sourceData.map((item, index) => {
      const colors = colorPalette[index % colorPalette.length];
      const percent = total > 0 ? Math.round((item.count / total) * 100) : 0;
      
      // Mock trend data (replace with actual data from API)
      const trend = Math.random() > 0.5 ? 'up' : 'down';
      const trendValue = Math.floor(Math.random() * 20) + 5;
      
      return {
        label: item._id || 'Others',
        value: item.count,
        percent,
        trend,
        trendValue,
        ...colors
      };
    });
  }, [leadsSources]);

  // Calculate top performing source
  const topSource = useMemo(() => {
    if (!legendItems.length) return null;
    return legendItems.reduce((max, item) => item.value > max.value ? item : max, legendItems[0]);
  }, [legendItems]);

  if (loading) {
    return (
      <div className="relative w-full h-full">
        <div className="absolute -inset-1 bg-gradient-to-br from-indigo-100/50 to-purple-50/30 rounded-3xl blur-2xl opacity-40" />
        <div className="relative h-full bg-white/80 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 p-6 animate-pulse">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-200" />
              <div className="space-y-2">
                <div className="h-4 w-32 bg-slate-200 rounded" />
                <div className="h-3 w-24 bg-slate-100 rounded" />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-center py-8">
            <div className="w-48 h-48 rounded-full bg-slate-100 border-8 border-slate-50" />
          </div>
        </div>
      </div>
    );
  }

  if (!leadsSources || !chartOptions) return null;

  return (
    <div className="relative w-full h-full">
      {/* Ambient glow */}
      <div className="absolute -inset-1 bg-gradient-to-br from-indigo-100/50 via-violet-50/30 to-purple-50/20 rounded-3xl blur-2xl opacity-60" />
      
      <div className="relative h-full bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-white to-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-500/25">
              <PieChart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">Leads by Source</h3>
              <p className="text-[11px] text-slate-500 font-medium">Acquisition channels</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {topSource && (
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 rounded-lg border border-emerald-100">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-xs font-bold text-emerald-700">{topSource.label}</span>
              </div>
            )}
            <button 
              onClick={handleRefresh}
              className={`p-2 hover:bg-slate-100 rounded-lg transition-all text-slate-400 hover:text-slate-600 ${isRefreshing ? 'animate-spin' : ''}`}
              disabled={isRefreshing}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-400 hover:text-slate-600">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 flex flex-col">
          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-100">
              <div className="flex items-center gap-2 mb-1">
                <Users className="w-3.5 h-3.5 text-indigo-600" />
                <span className="text-[10px] font-bold text-indigo-600 uppercase">Total</span>
              </div>
              <p className="text-lg font-bold text-indigo-900">
                {legendItems.reduce((acc, item) => acc + item.value, 0)}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-violet-50 border border-violet-100">
              <div className="flex items-center gap-2 mb-1">
                <Target className="w-3.5 h-3.5 text-violet-600" />
                <span className="text-[10px] font-bold text-violet-600 uppercase">Sources</span>
              </div>
              <p className="text-lg font-bold text-violet-900">{legendItems.length}</p>
            </div>
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-[10px] font-bold text-emerald-600 uppercase">Top</span>
              </div>
              <p className="text-lg font-bold text-emerald-900 truncate">
                {topSource?.percent || 0}%
              </p>
            </div>
          </div>

          {/* Donut Chart */}
          <div className="flex-1 min-h-[200px] relative">
            <ApexChartClient
              getOptions={() => chartOptions.options}
              series={chartOptions.series}
              type="donut"
              height={260}
            />
          </div>

          {/* Custom Legend */}
          <div className="mt-4 space-y-2 max-h-[160px] overflow-y-auto custom-scrollbar pr-1">
            {legendItems.map((item, index) => (
              <div 
                key={item.label}
                className={`flex items-center justify-between p-3 rounded-xl border transition-all duration-300 cursor-pointer group ${
                  hoveredSegment === index 
                    ? 'bg-slate-50 border-slate-300 shadow-sm' 
                    : `${item.bg} ${item.border} hover:shadow-sm`
                }`}
                onMouseEnter={() => setHoveredSegment(index)}
                onMouseLeave={() => setHoveredSegment(null)}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full bg-gradient-to-br ${item.gradient}`} />
                  <div>
                    <p className={`text-sm font-semibold ${item.text}`}>{item.label}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      {item.trend === 'up' ? (
                        <ArrowUpRight className="w-3 h-3 text-emerald-500" />
                      ) : (
                        <ArrowDownRight className="w-3 h-3 text-rose-500" />
                      )}
                      <span className={`text-[10px] font-medium ${item.trend === 'up' ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {item.trendValue}%
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-slate-700">{item.value}</p>
                  <p className="text-[10px] font-medium text-slate-400">{item.percent}%</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeadsBySourceWidget;