import { useMemo, useCallback } from 'react';
import ApexChartClient from '@/components/client-wrapper/ApexChartClient';
import { 
  FolderKanban, 
  TrendingUp, 
  CheckCircle2, 
  Clock, 
  PauseCircle,
  MoreHorizontal 
} from 'lucide-react';

const ProjectStatusWidget = ({ projectStatus }) => {
  const projectStatusOptions = useMemo(() => {
    if (!projectStatus) return null;
    const labels = ['In Progress', 'Completed', 'Pending', 'On Hold'];
    const series = [
      projectStatus.in_progress || 0,
      projectStatus.completed || 0,
      projectStatus.pending || 0,
      projectStatus.on_hold || 0,
    ];
    const total = series.reduce((a, b) => a + b, 0);

    return {
      series,
      chart: { 
        type: 'donut', 
        height: 220, 
        toolbar: { show: false }, 
        parentHeightOffset: 0, 
        fontFamily: 'inherit',
        animations: {
          enabled: true,
          easing: 'easeinout',
          speed: 800,
          animateGradually: { enabled: true, delay: 150 },
          dynamicAnimation: { enabled: true, speed: 350 }
        }
      },
      labels,
      colors: ['#8b5cf6', '#22c55e', '#94a3b8', '#f59e0b'],
      legend: { 
        position: 'bottom', 
        fontWeight: 600, 
        labels: { colors: '#64748b' },
        itemMargin: { horizontal: 8, vertical: 4 }
      },
      dataLabels: { enabled: false },
      stroke: { show: true, width: 0, colors: ['transparent'] },
      plotOptions: {
        pie: {
          donut: {
            size: '70%',
            labels: {
              show: true,
              total: {
                show: true,
                label: 'Projects',
                fontSize: '12px',
                fontWeight: 600,
                color: '#94a3b8',
                formatter: () => total,
              },
              value: {
                fontSize: '24px',
                fontWeight: 700,
                color: '#1e293b',
              }
            },
          },
          expandOnClick: true,
        },
      },
      tooltip: {
        enabled: true,
        y: {
          formatter: (val) => `${val} projects`
        }
      }
    };
  }, [projectStatus]);

  const getChartOptions = useCallback((options) => () => options, []);

  // Calculate percentages for mini stats
  const stats = useMemo(() => {
    if (!projectStatus) return [];
    const total = Object.values(projectStatus).reduce((a, b) => a + b, 0) || 1;
    
    return [
      { 
        label: 'In Progress', 
        value: projectStatus.in_progress || 0,
        percent: Math.round(((projectStatus.in_progress || 0) / total) * 100),
        color: 'text-violet-600', 
        bgColor: 'bg-violet-50',
        borderColor: 'border-violet-200',
        icon: Clock
      },
      { 
        label: 'Completed', 
        value: projectStatus.completed || 0,
        percent: Math.round(((projectStatus.completed || 0) / total) * 100),
        color: 'text-emerald-600', 
        bgColor: 'bg-emerald-50',
        borderColor: 'border-emerald-200',
        icon: CheckCircle2
      },
      { 
        label: 'Pending', 
        value: projectStatus.pending || 0,
        percent: Math.round(((projectStatus.pending || 0) / total) * 100),
        color: 'text-slate-600', 
        bgColor: 'bg-slate-50',
        borderColor: 'border-slate-200',
        icon: FolderKanban
      },
      { 
        label: 'On Hold', 
        value: projectStatus.on_hold || 0,
        percent: Math.round(((projectStatus.on_hold || 0) / total) * 100),
        color: 'text-amber-600', 
        bgColor: 'bg-amber-50',
        borderColor: 'border-amber-200',
        icon: PauseCircle
      },
    ];
  }, [projectStatus]);

  if (!projectStatusOptions) return null;

  return (
    <div className="relative w-full h-full">
      {/* Ambient glow */}
      <div className="absolute -inset-1 bg-gradient-to-br from-violet-100/50 via-emerald-50/30 to-amber-50/20 rounded-3xl blur-2xl opacity-60" />
      
      <div className="relative h-full bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-white to-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg shadow-violet-500/25">
              <FolderKanban className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">Project Status</h3>
              <p className="text-[11px] text-slate-500 font-medium">Distribution overview</p>
            </div>
          </div>
          <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-400 hover:text-slate-600">
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>

        {/* Chart */}
        <div className="p-6 flex-1 flex flex-col">
          <div className="flex-1 min-h-[220px]">
            <ApexChartClient
              getOptions={getChartOptions(projectStatusOptions)}
              series={projectStatusOptions.series}
              type="donut"
              height={220}
            />
          </div>

          {/* Mini Stats Grid */}
          <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-slate-100">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <div 
                  key={stat.label} 
                  className={`p-3 rounded-xl border ${stat.borderColor} ${stat.bgColor} transition-all duration-300 hover:shadow-sm group`}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <Icon className={`w-3.5 h-3.5 ${stat.color}`} />
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{stat.label}</span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className={`text-lg font-bold ${stat.color}`}>{stat.value}</span>
                    <span className="text-[10px] font-medium text-slate-400">{stat.percent}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectStatusWidget;