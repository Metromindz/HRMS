import { useState, useEffect } from 'react';
import api from '@/config/api';
import { 
  Activity, 
  RefreshCw, 
  MoreHorizontal,
  Clock,
  User,
  FileText,
  CheckCircle2,
  AlertCircle,
  Edit3,
  Trash2,
  Plus,
  LogIn,
  LogOut,
  Settings,
  Bell,
  Calendar,
  Filter,
  ChevronDown
} from 'lucide-react';

const ActivityLogsWidget = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [filter, setFilter] = useState('all');
  const [expandedId, setExpandedId] = useState(null);

  useEffect(() => {
    fetchActivityLogs();
  }, []);

  const fetchActivityLogs = async () => {
    if (!isRefreshing) setLoading(true);
    try {
      const response = await api.get('/activity-logs/recent?limit=20', {
        withCredentials: true
      });
      if (response.data.success) {
        setEvents(response.data.logs);
      }
    } catch (error) {
      console.error('Error fetching activity logs:', error);
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    fetchActivityLogs();
  };

  // Get icon based on activity type
  const getActivityIcon = (type, action) => {
    const typeStr = String(type || '').toLowerCase();
    const actionStr = String(action || '').toLowerCase();

    if (actionStr.includes('create') || actionStr.includes('add')) return Plus;
    if (actionStr.includes('update') || actionStr.includes('edit')) return Edit3;
    if (actionStr.includes('delete') || actionStr.includes('remove')) return Trash2;
    if (actionStr.includes('login')) return LogIn;
    if (actionStr.includes('logout')) return LogOut;
    if (typeStr.includes('task')) return CheckCircle2;
    if (typeStr.includes('project')) return FileText;
    if (typeStr.includes('user') || typeStr.includes('employee')) return User;
    if (typeStr.includes('setting')) return Settings;
    if (typeStr.includes('notification')) return Bell;
    if (typeStr.includes('leave')) return Calendar;
    
    return Activity;
  };

  // Get color based on activity action
  const getActivityColor = (action) => {
    const actionStr = String(action || '').toLowerCase();
    
    if (actionStr.includes('create') || actionStr.includes('add')) {
      return {
        bg: 'bg-emerald-50',
        border: 'border-emerald-200',
        text: 'text-emerald-600',
        icon: 'text-emerald-500',
        gradient: 'from-emerald-500 to-teal-600'
      };
    }
    if (actionStr.includes('update') || actionStr.includes('edit')) {
      return {
        bg: 'bg-blue-50',
        border: 'border-blue-200',
        text: 'text-blue-600',
        icon: 'text-blue-500',
        gradient: 'from-blue-500 to-indigo-600'
      };
    }
    if (actionStr.includes('delete') || actionStr.includes('remove')) {
      return {
        bg: 'bg-rose-50',
        border: 'border-rose-200',
        text: 'text-rose-600',
        icon: 'text-rose-500',
        gradient: 'from-rose-500 to-pink-600'
      };
    }
    if (actionStr.includes('login') || actionStr.includes('logout')) {
      return {
        bg: 'bg-violet-50',
        border: 'border-violet-200',
        text: 'text-violet-600',
        icon: 'text-violet-500',
        gradient: 'from-violet-500 to-purple-600'
      };
    }
    
    return {
      bg: 'bg-slate-50',
      border: 'border-slate-200',
      text: 'text-slate-600',
      icon: 'text-slate-500',
      gradient: 'from-slate-500 to-slate-600'
    };
  };

  // Format relative time
  const getRelativeTime = (dateStr) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  // Group events by date
  const groupedEvents = events.reduce((acc, event) => {
    const dateKey = event.date || event.createdAt?.split('T')[0] || 'Unknown';
    if (!acc[dateKey]) acc[dateKey] = [];
    acc[dateKey].push(event);
    return acc;
  }, {});

  const filteredEvents = filter === 'all' 
    ? events 
    : events.filter(e => String(e.action || '').toLowerCase().includes(filter));

  if (loading) {
    return (
      <div className="relative w-full h-[500px]">
        <div className="absolute -inset-1 bg-gradient-to-br from-blue-100/50 via-indigo-50/30 to-violet-50/20 rounded-3xl blur-2xl opacity-40" />
        <div className="relative h-full bg-white/80 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 p-6 animate-pulse">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-200" />
              <div className="space-y-2">
                <div className="h-4 w-32 bg-slate-200 rounded" />
                <div className="h-3 w-24 bg-slate-100 rounded" />
              </div>
            </div>
          </div>
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex gap-4">
                <div className="w-12 h-12 rounded-2xl bg-slate-100" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 w-3/4 bg-slate-100 rounded" />
                  <div className="h-3 w-1/2 bg-slate-50 rounded" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-[500px]">
      {/* Ambient glow */}
      <div className="absolute -inset-1 bg-gradient-to-br from-blue-100/40 via-indigo-50/30 to-violet-50/20 rounded-3xl blur-2xl opacity-60" />
      
      <div className="relative h-full bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-white to-slate-50/50 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/25">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">Activity Logs</h3>
              <p className="text-[11px] text-slate-500 font-medium">
                {events.length} recent activities
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Filter Dropdown */}
            <div className="relative group">
              <button className="flex items-center gap-2 px-3 py-2 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 text-xs font-medium text-slate-600 transition-colors">
                <Filter className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Filter</span>
                <ChevronDown className="w-3 h-3" />
              </button>
              <div className="absolute right-0 top-full mt-2 w-40 bg-white rounded-xl shadow-lg shadow-slate-200/50 border border-slate-100 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                {['all', 'create', 'update', 'delete', 'login'].map((f) => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`w-full px-4 py-2 text-xs font-medium text-left capitalize transition-colors first:rounded-t-xl last:rounded-b-xl ${
                      filter === f ? 'bg-blue-50 text-blue-600' : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {f === 'all' ? 'All Activities' : `${f}d`}
                  </button>
                ))}
              </div>
            </div>

            <button 
              onClick={handleRefresh}
              className={`p-2 hover:bg-slate-100 rounded-lg transition-all text-slate-400 hover:text-slate-600 ${isRefreshing ? 'animate-spin' : ''}`}
              disabled={isRefreshing}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-400 hover:text-slate-600">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Activity List */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
          {filteredEvents.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="w-16 h-16 rounded-2xl bg-slate-50 flex items-center justify-center mb-3">
                <Activity className="w-8 h-8 text-slate-300" />
              </div>
              <p className="text-sm font-semibold text-slate-600">No activities found</p>
              <p className="text-xs text-slate-400 mt-1">Try adjusting your filters</p>
            </div>
          ) : (
            <div className="relative space-y-6 before:absolute before:top-0 before:bottom-0 before:left-6 before:w-px before:bg-gradient-to-b before:from-slate-200 before:via-slate-300 before:to-slate-200">
              {filteredEvents.map((event, idx) => {
                const Icon = getActivityIcon(event.type, event.action);
                const colors = getActivityColor(event.action);
                const isExpanded = expandedId === event._id;
                
                return (
                  <div 
                    key={event._id || idx} 
                    className="relative flex items-start gap-4 group cursor-pointer"
                    onClick={() => setExpandedId(isExpanded ? null : event._id)}
                  >
                    {/* Timeline dot with icon */}
                    <div className={`z-10 shrink-0 w-12 h-12 rounded-2xl border-2 flex items-center justify-center transition-all duration-300 ${
                      colors.bg
                    } ${colors.border} ${colors.icon} group-hover:scale-110 group-hover:shadow-md`}>
                      <Icon className="w-5 h-5" />
                    </div>

                    {/* Content */}
                    <div className={`flex-1 min-w-0 p-4 rounded-xl border transition-all duration-300 ${
                      isExpanded 
                        ? 'bg-slate-50 border-slate-200 shadow-sm' 
                        : 'bg-white border-transparent hover:bg-slate-50/50 hover:border-slate-100'
                    }`}>
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex-1 min-w-0">
                          <h6 className={`text-sm font-semibold truncate transition-colors ${
                            colors.text
                          }`}>
                            {event.title || 'Untitled Activity'}
                          </h6>
                          <div className="flex items-center gap-2 mt-1">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${colors.bg} ${colors.text} ${colors.border}`}>
                              {event.action || 'Action'}
                            </span>
                            {event.type && (
                              <span className="text-[10px] text-slate-400 font-medium">
                                {event.type}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <div className="flex items-center gap-1 text-[11px] text-slate-400 font-medium">
                            <Clock className="w-3 h-3" />
                            {getRelativeTime(event.createdAt || event.date)}
                          </div>
                        </div>
                      </div>
                      
                      {/* <p className={`text-xs text-slate-500 leading-relaxed transition-all ${
                        isExpanded ? '' : 'line-clamp-2'
                      }`}>
                        {event.description || 'No description available'}
                      </p> */}

                      {/* Expanded details */}
                      {isExpanded && event.metadata && (
                        <div className="mt-3 pt-3 border-t border-slate-100">
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            {Object.entries(event.metadata).map(([key, value]) => (
                              <div key={key} className="flex flex-col">
                                <span className="text-[10px] font-bold text-slate-400 uppercase">{key}</span>
                                <span className="text-slate-600 font-medium truncate">{String(value)}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* User info if available */}
                      {event.user && (
                        <div className="mt-3 flex items-center gap-2">
                          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-slate-400 to-slate-600 flex items-center justify-center text-white text-[10px] font-bold">
                            {event.user.name?.charAt(0) || 'U'}
                          </div>
                          <span className="text-[11px] text-slate-500 font-medium">{event.user.name || 'Unknown User'}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50/50 shrink-0 flex items-center justify-between">
          <span className="text-xs text-slate-400 font-medium">
            Showing {filteredEvents.length} of {events.length} activities
          </span>
          <button className="text-xs font-semibold text-blue-600 hover:text-blue-700 transition-colors">
            View all logs
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActivityLogsWidget;