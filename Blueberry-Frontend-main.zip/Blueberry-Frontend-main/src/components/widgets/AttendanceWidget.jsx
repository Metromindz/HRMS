import { useState, useEffect } from 'react';
import api from '@/config/api';
import toast from 'react-hot-toast';
import {
  LogIn as LuLogIn,
  LogOut as LuLogOut,
  Clock as LuClock,
  MapPin as LuMapPin,
  Coffee as LuCoffee,
  CheckCircle as LuCheckCircle,
  Timer as LuTimer,
  MoreHorizontal as LuMoreHorizontal
} from 'lucide-react';

const AttendanceWidget = () => {
  const [loading, setLoading] = useState(true);
  const [attendance, setAttendance] = useState(null);
  const [elapsedTime, setElapsedTime] = useState('00:00:00');
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(new Date());

  const STANDARD_WORK_HOURS = 8;

  useEffect(() => {
    fetchTodayAttendance();
    const timeTimer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timeTimer);
  }, []);

  useEffect(() => {
    let timer;
    if (attendance?.inTime && !attendance?.outTime) {
      timer = setInterval(() => {
        const now = new Date();
        const [h, m] = attendance.inTime.split(':').map(Number);
        const checkIn = new Date();
        checkIn.setHours(h, m, 0, 0);
        if (checkIn > now) checkIn.setDate(checkIn.getDate() - 1);

        const diff = now - checkIn;
        const hrs = Math.floor(diff / (1000 * 60 * 60));
        const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const secs = Math.floor((diff % (1000 * 60)) / 1000);

        setElapsedTime(
          `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
        );

        const totalMinutes = (diff / (1000 * 60));
        const progressPercent = Math.min((totalMinutes / (STANDARD_WORK_HOURS * 60)) * 100, 100);
        setProgress(progressPercent);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [attendance]);

  const fetchTodayAttendance = async () => {
    try {
      setLoading(true);
      const res = await api.get('/attendance/today');
      setAttendance(res.data.attendance || null);
      if (res.data.attendance?.workingMinutes) {
        const mins = res.data.attendance.workingMinutes;
        setProgress(Math.min((mins / (STANDARD_WORK_HOURS * 60)) * 100, 100));
      }
    } catch (err) {
      if (err.response?.status !== 404) {
        toast.error('Failed to fetch attendance');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCheckIn = async () => {
    try {
      setLoading(true);
      const res = await api.post('/attendance/check-in');
      setAttendance(res.data.attendance);
      toast.success('Welcome! Checked in successfully 👋');
    } catch {
      toast.error('Check-in failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckOut = async () => {
    try {
      setLoading(true);
      const res = await api.post('/attendance/check-out');
      setAttendance(res.data.attendance);
      toast.success('Great work! Checked out successfully 🎉');
    } catch {
      toast.error('Check-out failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const formatHours = (mins) => {
    if (!mins) return '0h 0m';
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h}h ${m}m`;
  };

  const isCheckedIn = attendance && !attendance.outTime;
  const isCheckedOut = attendance && attendance.outTime;
  const isNotStarted = !attendance;

  const statusConfig = {
    notStarted: {
      color: 'slate',
      bg: 'bg-slate-100',
      text: 'text-slate-600',
      label: 'Ready to Start',
      icon: LuCoffee,
      gradient: 'from-slate-100 to-slate-50'
    },
    working: {
      color: 'emerald',
      bg: 'bg-emerald-100',
      text: 'text-emerald-600',
      label: 'Currently Working',
      icon: LuTimer,
      gradient: 'from-emerald-50 to-teal-50'
    },
    completed: {
      color: 'blue',
      bg: 'bg-blue-100',
      text: 'text-blue-600',
      label: 'Day Completed',
      icon: LuCheckCircle,  // ✅ FIXED
      gradient: 'from-blue-50 to-indigo-50'
    }
  };

  const currentStatus = isCheckedOut ? statusConfig.completed :
    isCheckedIn ? statusConfig.working :
      statusConfig.notStarted;

  const StatusIcon = currentStatus.icon;

  return (
    <div className="relative w-full h-full">
      <div className={`absolute -inset-1 bg-gradient-to-r ${currentStatus.gradient} rounded-[2rem] blur-xl opacity-60 transition-all duration-1000`} />

      <div className="relative h-full flex flex-col bg-white rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100 overflow-hidden">

        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl ${currentStatus.bg} ${currentStatus.text} transition-colors duration-500`}>
              <StatusIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 tracking-tight">Attendance</h3>
              <p className="text-[10px] text-slate-500 font-medium uppercase tracking-wider">
                {currentTime.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
              </p>
            </div>
          </div>

          <button className="p-2 hover:bg-slate-50 rounded-lg transition-colors text-slate-400 hover:text-slate-600">
            <LuMoreHorizontal className="w-5 h-5" />
          </button>
        </div>

        {/* Main Content */}
        <div className="p-6 flex-1 flex flex-col">

          {/* Radial Progress Timer */}
          <div className="flex flex-col items-center mb-6">
            <div className="relative w-48 h-48">
              <svg className="absolute inset-0 w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
                {/* Background Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="46"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="4"
                  className="text-slate-100"
                />

                {/* Progress Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="46"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 46}`}
                  strokeDashoffset={`${2 * Math.PI * 46 * (1 - progress / 100)}`}
                  className={`transition-all duration-1000 ${isCheckedIn ? 'text-emerald-500' : isCheckedOut ? 'text-blue-500' : 'text-slate-300'}`}
                />
              </svg>

              <div className="absolute inset-4 rounded-full bg-gradient-to-br from-slate-50 to-white shadow-inner flex flex-col items-center justify-center">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1.5 mb-1">
                    <LuClock className={`w-3.5 h-3.5 ${currentStatus.text}`} />
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      {isCheckedIn ? 'Elapsed' : isCheckedOut ? 'Total' : 'Ready'}
                    </span>
                  </div>

                  <div className={`text-4xl font-black tabular-nums tracking-tight ${currentStatus.text} transition-colors duration-500`}>
                    {isCheckedIn ? elapsedTime.split(':').slice(0, 2).join(':') :
                      isCheckedOut ? formatHours(attendance.workingMinutes) :
                        '--:--'}
                  </div>

                  {isCheckedIn && (
                    <div className="text-xs font-medium text-slate-400 mt-1">
                      {elapsedTime.split(':')[2]}s
                    </div>
                  )}
                </div>
              </div>

              <div className={`absolute -bottom-1 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${currentStatus.bg} ${currentStatus.text} shadow-sm border border-white`}>
                {currentStatus.label}
              </div>
            </div>
          </div>

          {/* Timeline Info */}
          <div className="grid grid-cols-2 gap-3 mb-6">
            <div className={`p-3 rounded-2xl border transition-all duration-300 ${isCheckedIn || isCheckedOut ? 'bg-emerald-50/50 border-emerald-100' : 'bg-slate-50 border-slate-100'}`}>
              <div className="flex items-center gap-2 mb-1">
                <div className={`w-6 h-6 rounded-lg flex items-center justify-center ${isCheckedIn || isCheckedOut ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-400'}`}>
                  <LuLogIn className="w-3.5 h-3.5" />
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">Check In</span>
              </div>
              <p className="text-lg font-bold text-slate-800">
                {attendance?.inTime || '--:--'}
              </p>
            </div>

            <div className={`p-3 rounded-2xl border transition-all duration-300 ${isCheckedOut ? 'bg-blue-50/50 border-blue-100' : isCheckedIn ? 'bg-amber-50/50 border-amber-100' : 'bg-slate-50 border-slate-100'}`}>
              <div className="flex items-center gap-2 mb-1">
                <div className={`w-6 h-6 rounded-lg flex items-center justify-center ${isCheckedOut ? 'bg-blue-500 text-white' : isCheckedIn ? 'bg-amber-400 text-white animate-pulse' : 'bg-slate-200 text-slate-400'}`}>
                  <LuLogOut className="w-3.5 h-3.5" />
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">Check Out</span>
              </div>
              <p className="text-lg font-bold text-slate-800">
                {attendance?.outTime || (isCheckedIn ? 'Pending...' : '--:--')}
              </p>
            </div>
          </div>

          {/* Location hint */}
          <div className="flex items-center gap-2 mb-5 px-1">
            <LuMapPin className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-[11px] text-slate-500 font-medium">Office Location • Auto-detected</span>
          </div>

          {/* Action Button */}
          <div className="relative mt-auto pt-6">
            {isNotStarted && (
              <button
                onClick={handleCheckIn}
                disabled={loading}
                className="group w-full relative overflow-hidden bg-slate-900 hover:bg-slate-800 text-white py-4 rounded-2xl font-bold text-sm transition-all duration-300 shadow-lg shadow-slate-900/20 hover:shadow-xl hover:shadow-slate-900/30 hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
                <span className="relative flex items-center justify-center gap-2">
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <LuLogIn className="w-4 h-4" />
                      Check In Now
                    </>
                  )}
                </span>
              </button>
            )}

            {isCheckedIn && (
              <button
                onClick={handleCheckOut}
                disabled={loading}
                className="group w-full relative overflow-hidden bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white py-4 rounded-2xl font-bold text-sm transition-all duration-300 shadow-lg shadow-rose-500/20 hover:shadow-xl hover:shadow-rose-500/30 hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <span className="relative flex items-center justify-center gap-2">
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <LuLogOut className="w-4 h-4" />
                      Check Out
                    </>
                  )}
                </span>
              </button>
            )}

            {isCheckedOut && (
              <div className="w-full bg-slate-100 text-slate-500 py-4 rounded-2xl text-center font-bold text-sm flex items-center justify-center gap-2">
                <LuCheckCircle className="w-4 h-4 text-emerald-500" />  {/* ✅ FIXED */}
                Shift Completed • {formatHours(attendance.workingMinutes)}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AttendanceWidget;
