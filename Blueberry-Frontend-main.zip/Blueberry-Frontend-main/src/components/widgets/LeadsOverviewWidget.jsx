import { useState, useEffect, useMemo, useCallback } from 'react';
import api from '@/config/api';
import ApexChartClient from '@/components/client-wrapper/ApexChartClient';
import { 
  TrendingUp, 
  TrendingDown,
  RefreshCw, 
  Calendar,
  Target,
  Users,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

const LeadsOverviewWidget = ({ range = '7' }) => {
  const [leadsTrend, setLeadsTrend] = useState({ labels: [], series: [] });
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdatedAt, setLastUpdatedAt] = useState(null);

  const fetchLeadsTrend = useCallback(async ({ showLoader = false } = {}) => {
    if (showLoader) setLoading(true);
    try {
      const res = await api.get('/dashboard/leads-trend', { params: { range } });
      if (res.data.success) {
        const labelsRaw = Array.isArray(res.data?.data?.labels) ? res.data.data.labels : [];
        const seriesRaw = Array.isArray(res.data?.data?.series) ? res.data.data.series : [];

        // Keep only valid points returned by API; drop unavailable/invalid values.
        const points = labelsRaw
          .map((label, index) => ({
            label,
            value: Number(seriesRaw[index]),
          }))
          .filter((p) => p.label && Number.isFinite(p.value));

        setLeadsTrend({
          labels: points.map((p) => p.label),
          series: points.map((p) => p.value),
        });
        setLastUpdatedAt(new Date());
      }
    } catch (err) {
      console.error('Failed to fetch leads trend:', err);
      setLeadsTrend({ labels: [], series: [] });
    } finally {
      setLoading(false);
    }
  }, [range]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchLeadsTrend();
    setIsRefreshing(false);
  };

  useEffect(() => {
    fetchLeadsTrend({ showLoader: true });

    // Refresh every 30s for near real-time dashboard updates.
    const intervalId = setInterval(() => {
      fetchLeadsTrend();
    }, 30000);

    return () => clearInterval(intervalId);
  }, [fetchLeadsTrend]);

  // Calculate statistics
  const stats = useMemo(() => {
    if (!leadsTrend?.series?.length) return null;
    
    const series = leadsTrend.series;
    const total = series.reduce((a, b) => a + b, 0);
    const avg = Math.round(total / series.length);
    const max = Math.max(...series);
    const min = Math.min(...series);
    
    // Calculate trend (compare first half vs second half)
    const half = Math.floor(series.length / 2);
    const firstHalf = series.slice(0, half).reduce((a, b) => a + b, 0);
    const secondHalf = series.slice(half).reduce((a, b) => a + b, 0);
    const trend = secondHalf - firstHalf;
    const trendPercent = firstHalf > 0 ? Math.round((trend / firstHalf) * 100) : 0;
    
    return { total, avg, max, min, trend, trendPercent };
  }, [leadsTrend]);

  const chartOptions = useMemo(() => {
    if (!leadsTrend) return null;
    
    const categories = (leadsTrend.labels || []).map(d =>
      new Date(d).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
    );

    return {
      series: [{ name: 'Leads', data: leadsTrend.series }],
      options: {
        chart: {
          type: 'area',
          height: 240,
          toolbar: { show: false },
          parentHeightOffset: 0,
          fontFamily: 'inherit',
          animations: {
            enabled: true,
            easing: 'easeinout',
            speed: 800,
            animateGradually: { enabled: true, delay: 150 },
            dynamicAnimation: { enabled: true, speed: 350 }
          },
        },
        dataLabels: { enabled: false },
        stroke: { 
          curve: 'smooth', 
          width: 3,
          colors: ['#3b82f6'],
          lineCap: 'round'
        },
        xaxis: {
          categories,
          tickAmount: 6,
          axisBorder: { show: false },
          axisTicks: { show: false },
          labels: { 
            style: { colors: '#94a3b8', fontWeight: 500, fontSize: '11px' },
            rotate: 0
          },
          crosshairs: {
            show: true,
            position: 'back',
            stroke: { color: '#e2e8f0', width: 1, dashArray: 4 }
          }
        },
        yaxis: { 
          labels: { 
            style: { colors: '#94a3b8', fontWeight: 500, fontSize: '11px' },
            formatter: (val) => Math.round(val)
          },
          tickAmount: 5
        },
        colors: ['#3b82f6'],
        fill: {
          type: 'gradient',
          gradient: { 
            shadeIntensity: 1, 
            opacityFrom: 0.5, 
            opacityTo: 0.05, 
            stops: [0, 90, 100],
            colorStops: [
              { offset: 0, color: '#3b82f6', opacity: 0.5 },
              { offset: 100, color: '#3b82f6', opacity: 0.05 }
            ]
          }
        },
        grid: { 
          borderColor: '#f1f5f9', 
          strokeDashArray: 4, 
          padding: { left: 10, right: 10, top: 0, bottom: 0 },
          xaxis: { lines: { show: false } }
        },
        tooltip: {
          theme: 'light',
          x: { format: 'dd MMM' },
          y: { formatter: (val) => `${val} leads` },
          style: { fontSize: '12px' },
          marker: { show: true },
          custom: function({ series, seriesIndex, dataPointIndex, w }) {
            const val = series[seriesIndex][dataPointIndex];
            const date = w.globals.labels[dataPointIndex];
            return `
              <div class="px-3 py-2 bg-white rounded-lg shadow-lg shadow-slate-200/50 border border-slate-100">
                <div class="text-[10px] font-bold text-slate-400 uppercase mb-1">${date}</div>
                <div class="text-sm font-bold text-blue-600">${val} leads</div>
              </div>
            `;
          }
        },
        markers: {
          size: 4,
          colors: ['#ffffff'],
          strokeColors: '#3b82f6',
          strokeWidth: 2,
          hover: { size: 6, sizeOffset: 2 }
        }
      }
    };
  }, [leadsTrend]);

  const getRangeLabel = (r) => {
    const map = { '7': 'Last 7 days', '30': 'Last 30 days', '90': 'Last 90 days' };
    return map[r] || `Last ${r} days`;
  };

  if (loading) {
    return (
      <div className="relative w-full h-full">
        <div className="absolute -inset-1 bg-gradient-to-br from-blue-100/50 via-indigo-50/30 to-cyan-50/20 rounded-3xl blur-2xl opacity-40" />
        <div className="relative h-full bg-white/80 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 p-6 animate-pulse">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-200" />
              <div className="space-y-2">
                <div className="h-4 w-32 bg-slate-200 rounded" />
                <div className="h-3 w-24 bg-slate-100 rounded" />
              </div>
            </div>
          </div>
          <div className="h-48 w-full bg-slate-100 rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!chartOptions) return null;

  const hasData = leadsTrend.series.some((value) => value > 0);

  const isPositiveTrend = stats?.trend >= 0;

  return (
    <div className="relative w-full h-full">
      {/* Ambient glow */}
      <div className="absolute -inset-1 bg-gradient-to-br from-blue-100/50 via-indigo-50/30 to-cyan-50/20 rounded-3xl blur-2xl opacity-60" />
      
      <div className="relative h-full bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-white to-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/25">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">Leads Overview</h3>
              <p className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {getRangeLabel(range)}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {stats && (
              <div className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg border ${
                isPositiveTrend 
                  ? 'bg-emerald-50 border-emerald-100 text-emerald-700' 
                  : 'bg-rose-50 border-rose-100 text-rose-700'
              }`}>
                {isPositiveTrend ? (
                  <ArrowUpRight className="w-3.5 h-3.5" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5" />
                )}
                <span className="text-xs font-bold">{Math.abs(stats.trendPercent)}%</span>
              </div>
            )}
            <button 
              onClick={handleRefresh}
              className={`p-2 hover:bg-slate-100 rounded-lg transition-all text-slate-400 hover:text-slate-600 ${isRefreshing ? 'animate-spin' : ''}`}
              disabled={isRefreshing}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stats Row */}
        {stats && (
          <div className="px-6 py-4 grid grid-cols-4 gap-3 border-b border-slate-100 bg-slate-50/30">
            <div className="p-3 rounded-xl bg-white border border-slate-100 shadow-sm">
              <div className="flex items-center gap-2 mb-1">
                <Target className="w-3.5 h-3.5 text-blue-500" />
                <span className="text-[10px] font-bold text-slate-400 uppercase">Total</span>
              </div>
              <p className="text-lg font-bold text-slate-800">{stats.total}</p>
            </div>
            <div className="p-3 rounded-xl bg-white border border-slate-100 shadow-sm">
              <div className="flex items-center gap-2 mb-1">
                <Users className="w-3.5 h-3.5 text-violet-500" />
                <span className="text-[10px] font-bold text-slate-400 uppercase">Daily Avg</span>
              </div>
              <p className="text-lg font-bold text-slate-800">{stats.avg}</p>
            </div>
            <div className="p-3 rounded-xl bg-white border border-slate-100 shadow-sm">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                <span className="text-[10px] font-bold text-slate-400 uppercase">Peak</span>
              </div>
              <p className="text-lg font-bold text-slate-800">{stats.max}</p>
            </div>
            <div className="p-3 rounded-xl bg-white border border-slate-100 shadow-sm">
              <div className="flex items-center gap-2 mb-1">
                <TrendingDown className="w-3.5 h-3.5 text-rose-500" />
                <span className="text-[10px] font-bold text-slate-400 uppercase">Lowest</span>
              </div>
              <p className="text-lg font-bold text-slate-800">{stats.min}</p>
            </div>
          </div>
        )}

        {/* Chart */}
        <div className="flex-1 p-6 min-h-[240px]">
          {hasData ? (
            <ApexChartClient
              getOptions={() => chartOptions.options}
              series={chartOptions.series}
              type="area"
              height={240}
            />
          ) : (
            <div className="h-[240px] rounded-2xl border border-dashed border-slate-200 bg-slate-50/40 flex items-center justify-center">
              <p className="text-sm font-semibold text-slate-500">No lead trend data available for this period</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
          <div className="flex items-center gap-4 text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-blue-500" />
              New Leads
            </span>
            <span className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-blue-200" />
              Trend
            </span>
          </div>
          <span className="text-xs font-medium text-slate-400">
            Updated {lastUpdatedAt ? lastUpdatedAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--:--'}
          </span>
        </div>
      </div>
    </div>
  );
};

export default LeadsOverviewWidget;
