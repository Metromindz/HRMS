import { useState, useEffect, useCallback, useRef } from 'react';
import {
    CheckCircle2,
    Clock,
    ArrowRight,
    AlertCircle,
    Zap,
    Calendar,
    Flag,
    Timer,
    Circle,
    AlertTriangle,
    TrendingUp,
    Target
} from 'lucide-react';
import { Link } from 'react-router';
import api from '@/config/api';
import { useNotifications } from '@/context/NotificationContext';
import { useAuth } from '@/context/AuthContext';

const TodayPrioritiesWidget = () => {
    const { socket } = useNotifications();
    const { user } = useAuth();
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [hoveredTask, setHoveredTask] = useState(null);
    const refreshTimerRef = useRef(null);

    const fetchTasks = useCallback(async () => {
        try {
            const res = await api.get('/tasks', {
                params: { page: 1, limit: 20, sort: 'priority', order: 'asc' }
            });

            const allTasks = res.data.items || [];
            const today = new Date().setHours(0, 0, 0, 0);

            // Categorize tasks
            const actionable = allTasks.filter(
                t => t.status !== 'done' && t.status !== 'Completed' && t.status !== 'completed'
            );

            const completedToday = allTasks.filter(
                t => (t.status === 'done' || t.status === 'Completed' || t.status === 'completed') &&
                    new Date(t.updatedAt).getTime() >= today
            );

            // Sort actionable by urgency
            const sortedActionable = actionable.sort((a, b) => {
                const priorityOrder = { urgent: 0, high: 1, medium: 2, low: 3 };
                const aP = priorityOrder[a.priority?.toLowerCase()] || 4;
                const bP = priorityOrder[b.priority?.toLowerCase()] || 4;
                return aP - bP;
            });

            const combined = [...sortedActionable, ...completedToday];
            setTasks(combined.slice(0, 5));
        } catch (err) {
            console.error('Failed to fetch priorities:', err);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchTasks();
    }, [fetchTasks]);

    useEffect(() => {
        if (!socket) return;

        const handleTaskChanged = (payload) => {
            const role = user?.role?.toLowerCase();
            const isPrivileged = role === 'superadmin' || role === 'admin' || role === 'hr';
            const affected = payload?.affectedUserIds;

            if (!isPrivileged && Array.isArray(affected) && user?._id) {
                if (!affected.some((id) => String(id) === String(user._id))) return;
            }

            if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
            refreshTimerRef.current = setTimeout(() => {
                fetchTasks();
            }, 250);
        };

        socket.on('task-changed', handleTaskChanged);
        socket.on('task-board-refresh', fetchTasks);

        return () => {
            socket.off('task-changed', handleTaskChanged);
            socket.off('task-board-refresh', fetchTasks);
            if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
        };
    }, [socket, fetchTasks, user?._id, user?.role]);

    const getTaskConfig = (task) => {
        const status = task.status?.toLowerCase() || '';
        const priority = task.priority?.toLowerCase() || '';

        // Completed tasks
        if (status === 'done' || status === 'completed') {
            return {
                icon: CheckCircle2,
                gradient: 'from-emerald-500 to-teal-600',
                bgColor: 'bg-emerald-50',
                borderColor: 'border-emerald-200',
                textColor: 'text-emerald-700',
                accentColor: 'text-emerald-600',
                label: 'Completed',
                pulse: false
            };
        }

        // Urgent/High priority
        if (priority === 'urgent' || priority === 'high') {
            return {
                icon: AlertTriangle,
                gradient: 'from-rose-500 to-pink-600',
                bgColor: 'bg-rose-50',
                borderColor: 'border-rose-200',
                textColor: 'text-rose-700',
                accentColor: 'text-rose-600',
                label: 'High Priority',
                pulse: true
            };
        }

        // In Progress
        if (status === 'in_progress' || status === 'in progress') {
            return {
                icon: Timer,
                gradient: 'from-violet-500 to-purple-600',
                bgColor: 'bg-violet-50',
                borderColor: 'border-violet-200',
                textColor: 'text-violet-700',
                accentColor: 'text-violet-600',
                label: 'In Progress',
                pulse: true
            };
        }

        // Blocked
        if (status === 'blocked') {
            return {
                icon: AlertCircle,
                gradient: 'from-amber-500 to-orange-600',
                bgColor: 'bg-amber-50',
                borderColor: 'border-amber-200',
                textColor: 'text-amber-700',
                accentColor: 'text-amber-600',
                label: 'Blocked',
                pulse: false
            };
        }

        // Default Todo
        return {
            icon: Circle,
            gradient: 'from-blue-500 to-indigo-600',
            bgColor: 'bg-blue-50',
            borderColor: 'border-blue-200',
            textColor: 'text-blue-700',
            accentColor: 'text-blue-600',
            label: 'To Do',
            pulse: false
        };
    };

    const formatDueDate = (date) => {
        if (!date) return null;
        const d = new Date(date);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        if (d < today) return { text: 'Overdue', color: 'text-rose-600 bg-rose-50 border-rose-200' };
        if (d.getTime() === today.getTime()) return { text: 'Today', color: 'text-amber-600 bg-amber-50 border-amber-200' };
        if (d.getTime() === tomorrow.getTime()) return { text: 'Tomorrow', color: 'text-blue-600 bg-blue-50 border-blue-200' };

        return {
            text: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            color: 'text-slate-600 bg-slate-100 border-slate-200'
        };
    };

    const pendingCount = tasks.filter(t =>
        t.status !== 'done' && t.status !== 'Completed' && t.status !== 'completed'
    ).length;

    const completedCount = tasks.filter(t =>
        t.status === 'done' || t.status === 'Completed' || t.status === 'completed'
    ).length;

    if (loading) {
        return (
            <div className="relative w-full">
                <div className="absolute -inset-1 bg-gradient-to-br from-amber-100/50 to-orange-50/30 rounded-3xl blur-2xl opacity-60" />
                <div className="relative bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 p-6 min-h-[400px] flex items-center justify-center">
                    <div className="flex flex-col items-center gap-4">
                        <div className="relative">
                            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center animate-pulse shadow-lg shadow-amber-500/25">
                                <Zap className="w-7 h-7 text-white" />
                            </div>
                            <div className="absolute inset-0 rounded-2xl border-2 border-white/30 animate-ping" />
                        </div>
                        <div className="space-y-2 text-center">
                            <div className="h-4 w-32 bg-slate-200 rounded animate-pulse" />
                            <div className="h-3 w-24 bg-slate-100 rounded animate-pulse" />
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="relative w-full h-full">
            {/* Ambient glow */}
            <div className={`absolute -inset-2 rounded-[2rem] blur-3xl opacity-40 transition-all duration-1000 ${pendingCount > 0 ? 'bg-gradient-to-br from-amber-200/50 to-rose-100/50' : 'bg-gradient-to-br from-emerald-200/50 to-teal-100/50'
                }`} />

            <div className="relative h-full bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 overflow-hidden flex flex-col">

                {/* Header */}
                <div className="px-6 py-5 border-b border-slate-100 bg-gradient-to-r from-white via-slate-50/50 to-white flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="relative">
                            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-amber-500/25">
                                <Zap className="w-6 h-6 text-white fill-white/20" />
                            </div>
                            {pendingCount > 0 && (
                                <div className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white animate-pulse">
                                    {pendingCount}
                                </div>
                            )}
                        </div>
                        <div>
                            <h3 className="text-lg font-bold text-slate-900 tracking-tight">Today's Priorities</h3>
                            <p className="text-xs text-slate-500 font-medium mt-0.5 flex items-center gap-2">
                                {pendingCount > 0 ? (
                                    <>
                                        <Target className="w-3 h-3 text-rose-500" />
                                        <span className="text-rose-600 font-semibold">{pendingCount} urgent</span>
                                        <span className="text-slate-300">•</span>
                                        <span>{completedCount} done</span>
                                    </>
                                ) : (
                                    <>
                                        <TrendingUp className="w-3 h-3 text-emerald-500" />
                                        <span className="text-emerald-600 font-semibold">All caught up!</span>
                                    </>
                                )}
                            </p>
                        </div>
                    </div>

                    <div className="flex items-center gap-2">
                        <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 rounded-lg">
                            <Calendar className="w-3.5 h-3.5 text-slate-500" />
                            <span className="text-[11px] font-semibold text-slate-600">
                                {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                            </span>
                        </div>
                        <Link
                            to="/tasks"
                            className="flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 text-slate-500 hover:bg-amber-50 hover:text-amber-600 hover:border-amber-200 transition-all duration-300 group"
                        >
                            <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-0.5" />
                        </Link>
                    </div>
                </div>

                {/* Task List */}
                <div className="flex-1 overflow-y-auto custom-scrollbar">
                    {tasks.length > 0 ? (
                        <div className="divide-y divide-slate-100/70">
                            {tasks.map((task, index) => {
                                const config = getTaskConfig(task);
                                const TaskIcon = config.icon;
                                const due = formatDueDate(task.dueDate);
                                const isHovered = hoveredTask === task._id;

                                return (
                                    <div
                                        key={task._id}
                                        className={`relative p-5 transition-all duration-300 cursor-pointer group ${isHovered ? 'bg-slate-50/80' : ''
                                            }`}
                                        onMouseEnter={() => setHoveredTask(task._id)}
                                        onMouseLeave={() => setHoveredTask(null)}
                                        style={{ animationDelay: `${index * 50}ms` }}
                                    >
                                        {/* Left accent bar */}
                                        <div className={`absolute left-0 top-4 bottom-4 w-1 rounded-full bg-gradient-to-b ${config.gradient} transition-all duration-300 ${isHovered ? 'opacity-100 scale-y-100' : 'opacity-0 scale-y-0'
                                            }`} />

                                        <div className="flex items-start gap-4 pl-2">
                                            {/* Icon */}
                                            <div className={`relative shrink-0 w-10 h-10 rounded-xl ${config.bgColor} ${config.borderColor} border flex items-center justify-center transition-all duration-300 ${isHovered ? 'scale-110 shadow-md' : ''
                                                }`}>
                                                <TaskIcon className={`w-5 h-5 ${config.accentColor} ${config.pulse && !task.completed ? 'animate-pulse' : ''}`} />
                                                {config.pulse && !task.completed && (
                                                    <div className={`absolute inset-0 rounded-xl bg-gradient-to-r ${config.gradient} opacity-20 animate-ping`} />
                                                )}
                                            </div>

                                            {/* Content */}
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-start justify-between gap-3 mb-2">
                                                    <h4 className={`text-sm font-semibold leading-snug transition-colors ${isHovered ? 'text-slate-900' : 'text-slate-700'
                                                        } ${task.status?.toLowerCase() === 'done' || task.status?.toLowerCase() === 'completed' ? 'line-through text-slate-400' : ''}`}>
                                                        {task.title}
                                                    </h4>
                                                    {isHovered && (
                                                        <ArrowRight className="w-4 h-4 text-slate-400 shrink-0 transition-transform group-hover:translate-x-1" />
                                                    )}
                                                </div>

                                                {/* Meta row */}
                                                <div className="flex items-center gap-2 flex-wrap">
                                                    {/* Status badge */}
                                                    <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border ${config.bgColor} ${config.textColor} ${config.borderColor}`}>
                                                        {config.label}
                                                    </span>

                                                    {/* Priority badge */}
                                                    {task.priority && task.priority.toLowerCase() !== 'low' && (
                                                        <span className={`flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-bold border ${task.priority.toLowerCase() === 'urgent' ? 'bg-rose-100 text-rose-700 border-rose-200' :
                                                                task.priority.toLowerCase() === 'high' ? 'bg-orange-100 text-orange-700 border-orange-200' :
                                                                    'bg-blue-100 text-blue-700 border-blue-200'
                                                            }`}>
                                                            <Flag className="w-3 h-3" />
                                                            {task.priority}
                                                        </span>
                                                    )}

                                                    {/* Due date */}
                                                    {due && (
                                                        <span className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-[10px] font-semibold border ${due.color}`}>
                                                            <Clock className="w-3 h-3" />
                                                            {due.text}
                                                        </span>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                        /* Empty State */
                        <div className="flex flex-col items-center justify-center h-full min-h-[300px] p-8 text-center">
                            <div className="relative mb-4">
                                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-emerald-100 to-teal-50 flex items-center justify-center">
                                    <CheckCircle2 className="w-10 h-10 text-emerald-500" />
                                </div>
                                <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md">
                                    <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                                </div>
                            </div>
                            <h5 className="text-base font-bold text-slate-800 mb-1">All caught up!</h5>
                            <p className="text-sm text-slate-500 max-w-[200px] leading-relaxed">
                                You have no pending high-priority tasks. Enjoy your productive day!
                            </p>
                            <Link
                                to="/tasks"
                                className="mt-4 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
                            >
                                View all tasks
                            </Link>
                        </div>
                    )}
                </div>

                {/* Footer */}
                {tasks.length > 0 && (
                    <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
                        <div className="flex items-center gap-4 text-xs text-slate-500">
                            <div className="flex items-center gap-1.5">
                                <div className="w-2 h-2 rounded-full bg-rose-500" />
                                <span>{pendingCount} pending</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                                <span>{completedCount} done today</span>
                            </div>
                        </div>
                        <Link
                            to="/tasks"
                            className="text-xs font-semibold text-amber-600 hover:text-amber-700 flex items-center gap-1 group"
                        >
                            View all tasks
                            <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
                        </Link>
                    </div>
                )}
            </div>
        </div>
    );
};

export default TodayPrioritiesWidget;