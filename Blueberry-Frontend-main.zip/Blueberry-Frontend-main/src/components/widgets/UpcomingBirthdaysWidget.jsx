// Upcoming birthdays
import User1 from '@/assets/images/user/avatar-11.png';
import { useState, useEffect } from 'react';
import SimplebarClient from '@/components/client-wrapper/SimplebarClient';
import { Link } from 'react-router';
import { LuCalendar } from 'react-icons/lu';
import api from '@/config/api';
import { getUploadUrl } from '@/utils/uploadUrl';

const UpcomingBirthdaysWidget = () => {
  const [birthdays, setBirthdays] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBirthdays = async () => {
      try {
        const response = await api.get('/dashboard/upcoming-birthdays');
        if (response.data.success) {
          setBirthdays(response.data.data);
        }
      } catch (error) {
        console.error('Error fetching birthdays:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchBirthdays();
  }, []);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return <div className="h-[500px]">
    <div className="card border border-default-200 flex flex-col h-full">
      <div className="card-header border-b border-default-200">
        <h6 className="card-title text-base font-semibold">Upcoming Birthdays</h6>
      </div>

      <SimplebarClient className="flex-1 min-h-0">
        <div className="card-body">
          <div className="flex flex-col gap-4">
            {loading ? (
              <div className="text-center py-4">
                <div className="animate-spin inline-block size-6 border-[3px] border-current border-t-transparent text-primary rounded-full" role="status" aria-label="loading">
                  <span className="sr-only">Loading...</span>
                </div>
              </div>
            ) : birthdays.length === 0 ? (
              <div className="text-center py-8 bg-default-50 rounded-lg border border-dashed border-default-300">
                <p className="text-default-500 font-medium">No upcoming birthdays</p>
              </div>
            ) : (
              birthdays.map((person, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-2xl border border-default-200 hover:border-primary/30 hover:bg-primary/5 transition-all duration-300 group">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <img src={getUploadUrl(person.profilePhoto) || User1} alt={person.fullName} className="size-11 rounded-full object-cover ring-2 ring-default-100" />
                      <div className="absolute -bottom-0.5 -right-0.5 size-3.5 bg-success border-2 border-white rounded-full"></div>
                    </div>
                    <div>
                      <h6 className="text-sm font-bold text-default-900 group-hover:text-primary transition-colors">
                        <Link to="#">{person.fullName}</Link>
                      </h6>
                      <p className="text-xs text-default-500 font-medium">{person.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1.5 text-primary bg-primary/10 px-2.5 py-1 rounded-full">
                      <LuCalendar className="size-3.5" />
                      <span className="text-xs font-bold">{formatDate(person.birthday)}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </SimplebarClient>
    </div>
  </div>;
};

export default UpcomingBirthdaysWidget;
