import { useState, useEffect, useCallback, useRef } from 'react';
import { Link } from 'react-router';
import {
    FileText,
    Paperclip,
    Clock,
    ArrowRight,
    Plus,
    MoreHorizontal,
    Calendar,
    Flag,
    UserCircle2,
    CheckCircle2,
    Circle,
    AlertCircle,
    Timer,
    Layers
} from 'lucide-react';
import api from '@/config/api';
import { useNotifications } from '@/context/NotificationContext';
import { useAuth } from '@/context/AuthContext';

const TaskBoardWidget = () => {
    const { socket } = useNotifications();
    const { user } = useAuth();
    const [tasks, setTasks] = useState({
        todo: [],
        inProgress: [],
        completed: [],
        incomplete: []
    });
    const [loading, setLoading] = useState(true);
    const [hoveredColumn, setHoveredColumn] = useState(null);
    const refreshTimerRef = useRef(null);

    const normalizeStatus = useCallback((status) => {
        const raw = String(status || '').trim().toLowerCase();
        return raw.replace(/\s+/g, '_');
    }, []);

    const fetchBoardTasks = useCallback(async () => {
        try {
            const res = await api.get('/tasks', {
                params: { page: 1, limit: 50, sort: 'createdAt', order: 'desc' }
            });

            const allTasks = res.data.items || [];

            const grouped = {
                todo: [],
                inProgress: [],
                completed: [],
                incomplete: []
            };

            for (const t of allTasks) {
                const s = normalizeStatus(t.status);
                if (s === 'todo' || s === 'to_do' || s === 'open') grouped.todo.push(t);
                else if (s === 'in_progress' || s === 'inprogress') grouped.inProgress.push(t);
                else if (s === 'done' || s === 'completed') grouped.completed.push(t);
                else if (s === 'incomplete' || s === 'pending' || s === 'overdue' || s === 'paused') grouped.incomplete.push(t);
                else grouped.todo.push(t);
            }

            setTasks(grouped);
        } catch (err) {
            console.error('Failed to fetch tasks for board:', err);
        } finally {
            setLoading(false);
        }
    }, [normalizeStatus]);

    useEffect(() => {
        fetchBoardTasks();
    }, [fetchBoardTasks]);

    useEffect(() => {
        if (!socket) return;

        const handleTaskChanged = (payload) => {
            const role = user?.role?.toLowerCase();
            const isPrivileged = role === 'superadmin' || role === 'admin' || role === 'hr';
            const affected = payload?.affectedUserIds;

            if (!isPrivileged && Array.isArray(affected) && user?._id) {
                if (!affected.some((id) => String(id) === String(user._id))) return;
            }

            if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
            refreshTimerRef.current = setTimeout(() => {
                fetchBoardTasks();
            }, 250);
        };

        socket.on('task-changed', handleTaskChanged);

        return () => {
            socket.off('task-changed', handleTaskChanged);
            if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
        };
    }, [socket, fetchBoardTasks, user?._id, user?.role]);

    const columns = [
        {
            id: 'todo',
            title: 'To Do',
            subtitle: 'Upcoming',
            data: tasks.todo,
            icon: Circle,
            gradient: 'from-amber-500 to-orange-500',
            bgColor: 'bg-amber-50',
            borderColor: 'border-amber-200',
            badgeColor: 'bg-amber-100 text-amber-700',
            accentColor: 'text-amber-600'
        },
        {
            id: 'inProgress',
            title: 'In Progress',
            subtitle: 'Active now',
            data: tasks.inProgress,
            icon: Timer,
            gradient: 'from-violet-500 to-purple-600',
            bgColor: 'bg-violet-50',
            borderColor: 'border-violet-200',
            badgeColor: 'bg-violet-100 text-violet-700',
            accentColor: 'text-violet-600'
        },
        {
            id: 'completed',
            title: 'Completed',
            subtitle: 'Done',
            data: tasks.completed,
            icon: CheckCircle2,
            gradient: 'from-emerald-500 to-teal-600',
            bgColor: 'bg-emerald-50',
            borderColor: 'border-emerald-200',
            badgeColor: 'bg-emerald-100 text-emerald-700',
            accentColor: 'text-emerald-600'
        },
        {
            id: 'incomplete',
            title: 'Incomplete',
            subtitle: 'Needs attention',
            data: tasks.incomplete,
            icon: AlertCircle,
            gradient: 'from-rose-500 to-pink-600',
            bgColor: 'bg-rose-50',
            borderColor: 'border-rose-200',
            badgeColor: 'bg-rose-100 text-rose-700',
            accentColor: 'text-rose-600'
        }
    ];

    const getInitials = (name) => {
        const cleaned = String(name || '').trim();
        if (!cleaned) return '?';
        const parts = cleaned.split(/\s+/).filter(Boolean);
        const initials = parts.slice(0, 2).map(p => p[0]).join('');
        return initials.toUpperCase();
    };

    const getPriorityColor = (priority) => {
        const p = String(priority || '').toLowerCase();
        if (p === 'high' || p === 'urgent') return 'bg-rose-500 text-white';
        if (p === 'medium') return 'bg-amber-500 text-white';
        return 'bg-slate-400 text-white';
    };

    const formatDueDate = (date) => {
        if (!date) return null;
        const d = new Date(date);
        const today = new Date();
        const diff = Math.ceil((d - today) / (1000 * 60 * 60 * 24));

        if (diff < 0) return { text: 'Overdue', color: 'text-rose-600 bg-rose-50' };
        if (diff === 0) return { text: 'Today', color: 'text-amber-600 bg-amber-50' };
        if (diff === 1) return { text: 'Tomorrow', color: 'text-blue-600 bg-blue-50' };
        return {
            text: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
            color: 'text-slate-600 bg-slate-100'
        };
    };

    if (loading) {
        return (
            <div className="w-full bg-white rounded-3xl border border-slate-200 p-8 shadow-sm min-h-[400px] flex items-center justify-center">
                <div className="flex flex-col items-center gap-3">
                    <div className="relative">
                        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center animate-pulse">
                            <Layers className="w-6 h-6 text-white" />
                        </div>
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center">
                            <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" />
                        </div>
                    </div>
                    <span className="text-sm font-medium text-slate-500">Loading tasks...</span>
                </div>
            </div>
        );
    }

    const totalTasks = Object.values(tasks).flat().length;

    return (
        <div className="relative w-full">
            {/* Ambient background */}
            <div className="absolute -inset-4 bg-gradient-to-br from-blue-50/50 via-purple-50/30 to-slate-100/50 rounded-[2rem] blur-3xl opacity-60" />

            <div className="relative bg-white/80 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 overflow-hidden">

                {/* Header */}
                <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-white to-slate-50/50">
                    <div className="flex items-center gap-4">
                        <div className="relative">
                            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/25">
                                <Layers className="w-6 h-6 text-white" />
                            </div>
                            {totalTasks > 0 && (
                                <div className="absolute -top-2 -right-2 w-6 h-6 bg-slate-900 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">
                                    {totalTasks > 99 ? '99+' : totalTasks}
                                </div>
                            )}
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-slate-900 tracking-tight">Task Board</h3>
                            <p className="text-xs text-slate-500 font-medium mt-0.5">
                                {totalTasks} active task{totalTasks !== 1 ? 's' : ''} across all columns
                            </p>
                        </div>
                    </div>

                    <div className="flex items-center gap-2">
                        <button className="hidden sm:flex items-center gap-2 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold rounded-xl transition-all shadow-lg shadow-slate-900/20 hover:shadow-xl hover:-translate-y-0.5">
                            <Plus className="w-4 h-4" />
                            New Task
                        </button>
                        <Link
                            to="/tasks"
                            className="flex items-center justify-center w-10 h-10 rounded-xl border border-slate-200 text-slate-500 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition-all"
                        >
                            <ArrowRight className="w-5 h-5" />
                        </Link>
                    </div>
                </div>

                {/* Kanban Columns */}
                <div className="p-6 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
                    {columns.map((col) => {
                        const ColumnIcon = col.icon;
                        const isHovered = hoveredColumn === col.id;

                        return (
                            <div
                                key={col.id}
                                className="flex flex-col min-w-0"
                                onMouseEnter={() => setHoveredColumn(col.id)}
                                onMouseLeave={() => setHoveredColumn(null)}
                            >
                                {/* Column Header */}
                                <div className="flex items-center justify-between mb-4 px-1">
                                    <div className="flex items-center gap-3">
                                        <div className={`p-2 rounded-lg bg-gradient-to-br ${col.gradient} shadow-md`}>
                                            <ColumnIcon className="w-4 h-4 text-white" />
                                        </div>
                                        <div>
                                            <h4 className="text-sm font-bold text-slate-900">{col.title}</h4>
                                            <p className="text-[10px] text-slate-500 font-medium">{col.subtitle}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${col.badgeColor}`}>
                                            {col.data.length}
                                        </span>
                                        <button className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors text-slate-400 hover:text-slate-600">
                                            <MoreHorizontal className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>

                                {/* Task Cards */}
                                <div className={`flex-1 space-y-3 min-h-[200px] rounded-2xl p-3 transition-all duration-300 ${isHovered ? col.bgColor : 'bg-slate-50/50'}`}>
                                    {col.data.slice(0, 2).map((task, index) => {
                                        const due = formatDueDate(task.dueDate);
                                        const hasAttachments = (task.documents || []).length > 0;

                                        return (
                                            <div
                                                key={task._id}
                                                className="group bg-white rounded-xl border border-slate-200 p-4 shadow-sm hover:shadow-md hover:border-blue-300 transition-all duration-300 cursor-pointer hover:-translate-y-0.5"
                                                style={{ animationDelay: `${index * 50}ms` }}
                                            >
                                                {/* Card Header */}
                                                <div className="flex items-start justify-between gap-3 mb-3">
                                                    <div className="flex items-center gap-2 flex-1 min-w-0">
                                                        <span className="shrink-0 px-2 py-1 bg-slate-100 text-slate-600 text-[10px] font-bold rounded-md border border-slate-200">
                                                            #{task.taskNumber || String(task._id || '').slice(-6).toUpperCase()}
                                                        </span>
                                                        {task.priority && (
                                                            <span className={`shrink-0 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${getPriorityColor(task.priority)}`}>
                                                                {task.priority}
                                                            </span>
                                                        )}
                                                    </div>
                                                    {hasAttachments && (
                                                        <div className="flex items-center gap-1 text-slate-400">
                                                            <Paperclip className="w-3.5 h-3.5" />
                                                            <span className="text-[10px] font-medium">{(task.documents || []).length}</span>
                                                        </div>
                                                    )}
                                                </div>

                                                {/* Title */}
                                                <h5 className="text-sm font-semibold text-slate-800 mb-3 line-clamp-2 leading-snug group-hover:text-blue-700 transition-colors">
                                                    {task.title || 'Untitled task'}
                                                </h5>

                                                {/* Meta Row */}
                                                <div className="flex items-center gap-2 flex-wrap mb-3">
                                                    {task.project?.name && (
                                                        <span className="px-2 py-1 bg-blue-50 text-blue-700 text-[10px] font-semibold rounded-md border border-blue-100 truncate max-w-[120px]">
                                                            {task.project.name}
                                                        </span>
                                                    )}
                                                    {due && (
                                                        <span className={`flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold ${due.color}`}>
                                                            <Clock className="w-3 h-3" />
                                                            {due.text}
                                                        </span>
                                                    )}
                                                </div>

                                                {/* Footer */}
                                                <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                                                    {/* Assignees */}
                                                    <div className="flex items-center -space-x-2">
                                                        {(task.assignees || []).slice(0, 3).map((a, i) => (
                                                            <div
                                                                key={a?._id || i}
                                                                className="w-7 h-7 rounded-full bg-gradient-to-br from-slate-100 to-slate-200 border-2 border-white flex items-center justify-center text-[10px] font-bold text-slate-600 shadow-sm"
                                                                title={a?.name || ''}
                                                            >
                                                                {getInitials(a?.name)}
                                                            </div>
                                                        ))}
                                                        {(task.assignees || []).length === 0 && (
                                                            <div className="flex items-center gap-1.5 text-slate-400">
                                                                <UserCircle2 className="w-4 h-4" />
                                                                <span className="text-[10px] font-medium">Unassigned</span>
                                                            </div>
                                                        )}
                                                        {(task.assignees || []).length > 3 && (
                                                            <div className="w-7 h-7 rounded-full bg-slate-800 text-white border-2 border-white flex items-center justify-center text-[9px] font-bold shadow-sm">
                                                                +{(task.assignees || []).length - 3}
                                                            </div>
                                                        )}
                                                    </div>

                                                    {/* Status Indicator */}
                                                    <div className={`flex items-center gap-1.5 text-[10px] font-semibold ${col.accentColor}`}>
                                                        <div className={`w-1.5 h-1.5 rounded-full ${col.gradient.replace('from-', 'bg-').split(' ')[0]}`} />
                                                        {col.title}
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}

                                    {/* Empty State */}
                                    {col.data.length === 0 && (
                                        <div className={`h-full min-h-[160px] rounded-xl border-2 border-dashed ${col.borderColor} ${col.bgColor} flex flex-col items-center justify-center text-center p-4`}>
                                            <div className={`w-10 h-10 rounded-full ${col.bgColor} flex items-center justify-center mb-2`}>
                                                <ColumnIcon className={`w-5 h-5 ${col.accentColor}`} />
                                            </div>
                                            <p className="text-xs font-semibold text-slate-500">No {col.title.toLowerCase()}</p>
                                            <p className="text-[10px] text-slate-400 mt-0.5">Tasks will appear here</p>
                                        </div>
                                    )}

                                    {/* View More */}
                                    {col.data.length > 2 && (
                                        <Link
                                            to="/tasks"
                                            className={`flex items-center justify-center gap-2 py-3 rounded-xl border border-dashed ${col.borderColor} ${col.bgColor} hover:bg-white hover:shadow-sm transition-all group`}
                                        >
                                            <span className={`text-xs font-semibold ${col.accentColor}`}>
                                                +{col.data.length - 2} more tasks
                                            </span>
                                            <ArrowRight className={`w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 ${col.accentColor}`} />
                                        </Link>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>

                {/* Footer Stats */}
                <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
                    <div className="flex items-center gap-6">
                        <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-amber-500" />
                            <span className="text-xs text-slate-600 font-medium">{tasks.todo.length} pending</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-violet-500" />
                            <span className="text-xs text-slate-600 font-medium">{tasks.inProgress.length} active</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-emerald-500" />
                            <span className="text-xs text-slate-600 font-medium">{tasks.completed.length} done</span>
                        </div>
                    </div>
                    <div className="text-xs text-slate-400 font-medium">
                        Last updated: {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TaskBoardWidget;