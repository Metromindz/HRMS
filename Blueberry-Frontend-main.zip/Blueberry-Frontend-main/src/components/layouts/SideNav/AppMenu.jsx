import { Link, useLocation } from 'react-router-dom';
import { menuItemsData } from './menu';
import { useAuth } from '@/context/AuthContext';

// Normalize paths to avoid trailing slash mismatch
const normalizePath = path => path.replace(/\/+$/, '');

// Check if a menu item (or its children) is active
const isItemActive = (item, pathname) => {
  const currentPath = normalizePath(pathname);
  if (item.href && normalizePath(item.href) === currentPath) return true;
  if (item.children) {
    return item.children.some(child => isItemActive(child, currentPath));
  }
  return false;
};

// Recursively filter menu based on permissions
const filterMenu = (items, user) => {
  if (!user) return [];
  
  return items
    .map(item => ({
      ...item,
      children: item.children ? filterMenu(item.children, user) : undefined,
    }))
    .filter(item => {
      if (item.excludeRoles && item.excludeRoles.includes(user.role)) return false;

      if (user.role === 'superadmin') return true;

      // If item has children, show parent if any child is visible (no parent permission check)
      if (item.children) {
        return item.children.length > 0;
      }

      // For items without children, check permissions
      if (!item.permissions || item.permissions.length === 0) return true;
      return item.permissions.some(p => user.permissions?.includes(p));
    });
};

// Single menu item
const MenuItem = ({ item, pathname }) => {
  const Icon = item.icon;
  const active = isItemActive(item, pathname);

  return (
    <li className={`menu-item ${active ? 'active' : ''}`}>
      <Link 
        to={item.href ?? '#'} 
        className={`menu-link group relative transition-all duration-200 ${
          active 
            ? 'active bg-primary/10 text-primary' 
            : 'hover:bg-default-100 hover:text-primary'
        } py-2`}
      >
        {active && (
          <span className="absolute left-0 top-1/2 -translate-y-1/2 h-8 w-1 bg-primary rounded-r-full" />
        )}
        {Icon && (
          <span className={`menu-icon transition-colors duration-200 ${active ? 'text-primary' : 'group-hover:text-primary'}`}>
            <Icon size={20} />
          </span>
        )}
        <div className={`menu-text transition-all duration-200 ${active ? 'font-bold' : 'font-semibold'}`}>
          {item.label}
        </div>
      </Link>
    </li>
  );
};

// Main App Menu
const AppMenu = () => {
  const { user } = useAuth();
  const { pathname } = useLocation();
  const filteredMenu = filterMenu(menuItemsData, user);

  return (
    <ul className="side-nav px-4 py-4 space-y-0.5">
      {filteredMenu.map(item => (
        <MenuItem key={item.key} item={item} pathname={pathname} />
      ))}
    </ul>
  );
};

export default AppMenu;
