import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';
import api from '../config/api';

const AuthContext = createContext();
export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState(
    localStorage.getItem('token') || sessionStorage.getItem('token')
  );

  useEffect(() => {
    const token = localStorage.getItem('token') || sessionStorage.getItem('token');
    if (token) {
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      fetchProfile(token);
    } else {
      setLoading(false);
    }
  }, []);

  const fetchProfile = async () => {
    try {
      const response = await api.get('/auth/profile');
      setUser(response.data.user);
    } catch (error) {
      if (error.response?.status === 401 || error.response?.status === 404) {
        localStorage.removeItem('token');
        sessionStorage.removeItem('token');
        delete axios.defaults.headers.common['Authorization'];
        delete api.defaults.headers.common['Authorization'];
        setToken(null);
      } else {
        console.warn('Profile fetch failed:', error.message);
      }
    }
    setLoading(false);
  };

  const login = async credentials => {
    try {
      const response = await api.post('/auth/login', credentials);
      const { token, user } = response.data;

      if (credentials.rememberMe) {
        localStorage.setItem('token', token);
      } else {
        sessionStorage.setItem('token', token);
      }

      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;

      setToken(token);
      setUser(user);

      let landingPage = '/dashboard';
      if (user.role === 'superadmin' || user.permissions?.includes('dashboard.view')) {
        landingPage = '/';
      }

      return { token, user, landingPage };
    } catch (err) {
      console.error('Login error', err.response?.data || err.message);
      throw err;
    }
  };

  const logout = async () => {
    try {
      await api.patch('/tasks/timer/pause-all');
    } catch {
      // ignore network errors during logout
    }
    localStorage.removeItem('token');
    sessionStorage.removeItem('token');
    delete axios.defaults.headers.common['Authorization'];
    delete api.defaults.headers.common['Authorization'];
    setToken(null);
    setUser(null);
  };

  const hasPermission = permission => {
    if (!user) return false;
    if (user.role === 'superadmin') return true;
    return user.permissions?.includes(permission) || false;
  };

  useEffect(() => {
    if (token) {
      const decoded = jwtDecode(token);
      const expTime = decoded.exp * 1000 - Date.now();

      const timeout = setTimeout(() => logout(), expTime);
      return () => clearTimeout(timeout);
    }
  }, [token]);

  return (
    <AuthContext.Provider value={{ user, setUser, login, logout, hasPermission, loading }}>
      {children}
    </AuthContext.Provider>
  );
};
