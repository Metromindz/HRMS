/**
 * Converts a relative upload path (e.g., "uploads/documents/photo.png")
 * into a fully qualified URL pointing to the backend server.
 *
 * @param {string} relativePath - The path stored in the database (e.g., "uploads/documents/logo.png")
 * @returns {string|null} Full URL like "http://localhost:5002/uploads/documents/logo.png", or null if input is falsy
 */
export const getUploadUrl = (relativePath) => {
    if (!relativePath) return null;

    // If it's already a full URL (http/https or data URI), return as-is
    if (relativePath.startsWith('http') || relativePath.startsWith('data:')) {
        return relativePath;
    }

    const base = import.meta.env.VITE_API_BASE_URL?.replace('/api', '') || '';
    // Ensure no double slashes
    const cleanPath = relativePath.startsWith('/') ? relativePath : `/${relativePath}`;
    return `${base}${cleanPath}`;
};
