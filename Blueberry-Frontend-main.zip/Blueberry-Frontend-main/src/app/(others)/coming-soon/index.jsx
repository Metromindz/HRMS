import PageMeta from '@/components/PageMeta';
import CommingSoon from './components/CommingSoon';
const Index = () => {
  return <>
      <PageMeta title="Coming Soon" />
      <CommingSoon />;
    </>;
};
export default Index;