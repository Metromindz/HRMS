import PageMeta from '@/components/PageMeta';
import SmallNav from './components/SmallNav';
const Index = () => {
  return <>
      <PageMeta title="Small Sidenav" />
      <main>
        <SmallNav />
      </main>
    </>;
};
export default Index;