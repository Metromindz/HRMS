import PageMeta from '@/components/PageMeta';
import SideOffcanvase from './components/SideOffcanvase';
const Index = () => {
  return <>
      <PageMeta title="Offcanvas Sidenav" />
      <main>
        <SideOffcanvase />
      </main>
    </>;
};
export default Index;