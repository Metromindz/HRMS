import ApexChartClient from '@/components/client-wrapper/ApexChartClient';
import {
  getRjectedCandidates,
  getTotalEmployee,
} from './data';
import { useEffect, useState } from 'react';
import api from '../../../../../config/api';


const EmployeeCard = ({ title, value, percentage, percentageType, chartOptions }) => {
 return (
    <div className="card border border-default-200 transition-all duration-300">
      <div className="card-body">
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <p className="text-sm text-default-500 font-semibold uppercase tracking-wider mb-2">{title}</p>
            <div className="flex items-baseline gap-2">
              <h5 className="text-3xl font-bold text-default-900">{value}</h5>
              <span className={`text-xs font-bold px-1.5 py-0.5 rounded-full ${percentageType === 'success' ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger'}`}>
                {percentageType === 'success' ? '↑' : '↓'} {percentage}
              </span>
            </div>
          </div>

          <div className="shrink-0 -me-4">
            <ApexChartClient
              getOptions={chartOptions}
              series={chartOptions().series}
              type="radialBar"
              height={120}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
const EmployeDetails = () => {
   const [statistics,setStatistics] = useState([]);
   
  const fetchCount =async () =>{
    try{
      const res = await api.get('/statistics/counts');
      setStatistics(res.data.data);
    }
    catch(error){
      console.error("Fetching error",error);
    }
  }
  useEffect(()=>{
    fetchCount();
  }, []);
  return (
    <div className="col-span-1 mb-5">
      <div className="grid md:grid-cols-2 lg:grid-cols-3 grid-cols-1 gap-5">
        <EmployeeCard
          title="Total Employees"
          value={statistics.totalEmployees - 1}
          percentage="15%"
          percentageType="success"
          chartOptions={getTotalEmployee}
        />

        {/* <EmployeeCard
          title="Probation Employees"
          value={174}
          percentage="26%"
          percentageType="success"
          chartOptions={getTotalApplication}
        /> */}

        {/* <EmployeeCard
          title="Contract Employees"
          value={64}
          percentage="0.5%"
          percentageType="danger"
          chartOptions={getHiredCandidates}
        /> */}

        <EmployeeCard
          title="Total Designations"
          value={statistics.totalDesignations}
          percentage="16%"
          percentageType="danger"
          chartOptions={getRjectedCandidates}
        />

        <EmployeeCard
          title="Total Departments"
          value={statistics.totalDepartments}
          percentage="16%"
          percentageType="danger"
          chartOptions={getRjectedCandidates}
        />

        <EmployeeCard
          title="Total Holidays"
          value={statistics.totalHolidays}
          percentage="16%"
          percentageType="danger"
          chartOptions={getRjectedCandidates}
        />

          <EmployeeCard
          title="Notice Period Employees"
          value={statistics.totalNotice}
          percentage="15%"
          percentageType="success"
          chartOptions={getTotalEmployee}
        />
        <EmployeeCard
          title="Probation Employees"
          value={statistics.totalProbation}
          percentage="15%"
          percentageType="success"
          chartOptions={getTotalEmployee}
        />
      </div>
    </div>
  );
};

export default EmployeDetails;
