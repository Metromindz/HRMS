import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import {
  LuPencil,
  LuMail,
  LuPhone,
  LuMapPin,
  LuCalendar,
  LuBuilding2,
  LuBadgeCheck,
  LuBriefcase,
  LuSettings,
  LuCamera
} from 'react-icons/lu';
import EditProfileModal from './EditProfileModal';
import { getUploadUrl } from '@/utils/uploadUrl';

const EmployeeProfileCard = () => {
  const { user, setUser } = useAuth();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [isHoveringAvatar, setIsHoveringAvatar] = useState(false);

  if (!user) return null;

  // Data mapping with fallbacks
  const profile = {
    name: user.employeePersonal?.fullName || user.name || 'Employee',
    designation: user.employmentDetails?.designation?.name || user.role || 'Employee',
    department: user.employmentDetails?.department?.name || 'General',
    employeeId: user.employmentDetails?.employeeId || user.employeeId || 'N/A',
    email: user.email || 'N/A',
    phone: user.employeePersonal?.contactNumber || 'N/A',
    location: user.employmentDetails?.workLocation || 'N/A',
    joiningDate: user.employmentDetails?.dateOfJoining
      ? new Date(user.employmentDetails.dateOfJoining).toLocaleDateString('en-GB', {
        day: '2-digit', month: 'long', year: 'numeric'
      })
      : 'N/A',
    avatar: user.employeePersonal?.profilePhoto,
    status: user.status || 'Active'
  };

  const handleUpdateSuccess = (updatedUser) => {
    if (updatedUser) {
      setUser(updatedUser);
      setImageError(false);
    }
  };

  const getInitials = (name) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  return (
    <>
      <div className="relative w-full h-full">
        {/* Background decorative elements */}
        <div className="absolute -top-4 -left-4 w-24 h-24 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full blur-3xl opacity-20 animate-pulse" />
        <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-emerald-400 to-cyan-500 rounded-full blur-3xl opacity-20 animate-pulse delay-1000" />

        {/* Main Card */}
        <div className="relative h-full flex flex-col bg-white/80 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 overflow-hidden transition-all duration-500 hover:shadow-2xl hover:shadow-slate-200/60 hover:-translate-y-1">

          {/* Header Banner */}
          <div className="h-36 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden">
            {/* Animated mesh gradient overlay */}
            <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.03%22%3E%3Cpath%20d%3D%22M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-50" />

            {/* Top Actions */}
            <div className="absolute top-4 right-4 flex gap-2">
              <button
                onClick={() => setIsEditModalOpen(true)}
                className="group flex items-center gap-2 px-3 py-1.5 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full border border-white/10 transition-all duration-300"
              >
                <LuPencil className="w-3.5 h-3.5 text-white/80 group-hover:text-white" />
                <span className="text-[10px] font-medium text-white/80 group-hover:text-white">Edit</span>
              </button>
              <button className="p-2 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-full border border-white/10 transition-all duration-300">
                <LuSettings className="w-4 h-4 text-white/80" />
              </button>
            </div>

            {/* Status Badge */}
            <div className="absolute top-4 left-4">
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/20 backdrop-blur-md rounded-full border border-emerald-400/30">
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                <span className="text-[10px] font-semibold text-emerald-100 uppercase tracking-wider">{profile.status}</span>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="px-6 pb-6 -mt-16 relative flex-1 flex flex-col">

            {/* Avatar with hover effect */}
            <div className="flex justify-center mb-4">
              <div
                className="relative group"
                onMouseEnter={() => setIsHoveringAvatar(true)}
                onMouseLeave={() => setIsHoveringAvatar(false)}
              >
                <div className="w-32 h-32 rounded-2xl overflow-hidden ring-4 ring-white shadow-lg shadow-slate-200/50 bg-gradient-to-br from-slate-100 to-slate-200 transform transition-transform duration-300 group-hover:scale-105">
                  {!imageError && profile.avatar ? (
                    <img
                      src={getUploadUrl(profile.avatar)}
                      alt={profile.name}
                      className="w-full h-full object-cover"
                      onError={() => setImageError(true)}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                      <span className="text-3xl font-bold">{getInitials(profile.name)}</span>
                    </div>
                  )}
                </div>

                {/* Hover overlay for photo change */}
                <div className={`absolute inset-0 bg-black/40 rounded-2xl flex items-center justify-center transition-opacity duration-300 ${isHoveringAvatar ? 'opacity-100' : 'opacity-0'}`}>
                  <LuCamera className="w-6 h-6 text-white" />
                </div>

                {/* Verification Badge */}
                <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-white rounded-xl shadow-md flex items-center justify-center">
                  <LuBadgeCheck className="w-5 h-5 text-blue-500" />
                </div>
              </div>
            </div>

            {/* Identity */}
            <div className="text-center mb-6">
              <h2 className="text-xl font-bold text-slate-900 mb-1 tracking-tight">{profile.name}</h2>
              <div className="flex items-center justify-center gap-2 mb-3">
                <span className="px-2.5 py-0.5 bg-blue-50 text-blue-600 text-[10px] font-bold uppercase tracking-wider rounded-full border border-blue-100">
                  {profile.designation}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium flex items-center justify-center gap-1">
                <LuBuilding2 className="w-3 h-3" />
                {profile.department}
              </p>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 hover:border-blue-200 hover:bg-blue-50/30 transition-colors group">
                <div className="flex items-center gap-2 mb-1">
                  <LuBriefcase className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-500" />
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">ID</span>
                </div>
                <p className="text-sm font-bold text-slate-700 group-hover:text-blue-700">{profile.employeeId}</p>
              </div>
              <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 hover:border-purple-200 hover:bg-purple-50/30 transition-colors group">
                <div className="flex items-center gap-2 mb-1">
                  <LuCalendar className="w-3.5 h-3.5 text-slate-400 group-hover:text-purple-500" />
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Joined</span>
                </div>
                <p className="text-sm font-bold text-slate-700 group-hover:text-purple-700">{profile.joiningDate}</p>
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-2.5">
              <div className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-slate-50 transition-colors group">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-500 flex items-center justify-center group-hover:bg-blue-500 group-hover:text-white transition-colors">
                  <LuMail className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Email</p>
                  <p className="text-xs font-medium text-slate-700 truncate">{profile.email}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-slate-50 transition-colors group">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-500 flex items-center justify-center group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                  <LuPhone className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Phone</p>
                  <p className="text-xs font-medium text-slate-700">{profile.phone}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-slate-50 transition-colors group">
                <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-500 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-white transition-colors">
                  <LuMapPin className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Location</p>
                  <p className="text-xs font-medium text-slate-700">{profile.location}</p>
                </div>
              </div>
            </div>

            {/* Action Footer */}
            {/* <div className="mt-auto pt-4 border-t border-slate-100 flex gap-2">
              <button className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-2">
                <LuMail className="w-3.5 h-3.5" />
                Message
              </button>
              <button className="flex-1 py-2.5 bg-white border border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-2">
                <LuCalendar className="w-3.5 h-3.5" />
                Schedule
              </button>
            </div> */}
          </div>
        </div>
      </div>

      <EditProfileModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        user={user}
        onUpdateSuccess={handleUpdateSuccess}
      />
    </>
  );
};

export default EmployeeProfileCard;
