import PageBreadcrumb from '@/components/PageBreadcrumb';
import AttendanceWidget from '@/components/widgets/AttendanceWidget';
import EmployeeProfileCard from './components/EmployeeProfileCard';
import NotificationPanel from './components/NotificationPanel';
import AnnouncementsWidget from '@/components/widgets/AnnouncementsWidget';
import EmployeeTaskSummary from './components/EmployeeTaskSummary';
import TaskBoardWidget from '@/components/widgets/TaskBoardWidget';
import TodayPrioritiesWidget from '@/components/widgets/TodayPrioritiesWidget';
import TaskStatusChartWidget from '@/components/widgets/TaskStatusChartWidget';
import LeadsOverviewWidget from '@/components/widgets/LeadsOverviewWidget';
import LeadsBySourceWidget from '@/components/widgets/LeadsBySourceWidget';
import WorkforceOverviewWidget from '@/components/widgets/WorkforceOverviewWidget';
import ProjectStatusWidget from '@/components/widgets/ProjectStatusWidget';
import TaskStatusDistributionWidget from '@/components/widgets/TaskStatusDistributionWidget';
import ActivityLogsWidget from '@/components/widgets/ActivityLogsWidget';
import UpcomingBirthdaysWidget from '@/components/widgets/UpcomingBirthdaysWidget';
import EmployeePerformance from './components/EmployeePerformance';
import PageMeta from '@/components/PageMeta';
import { useEffect, useMemo, useState, useCallback } from 'react';
import api from '@/config/api';
import ApexChartClient from '@/components/client-wrapper/ApexChartClient';
import { Link } from 'react-router';
import {
  LuBuilding2, LuBriefcase, LuListChecks, LuUserPlus,
  LuPlay, LuCircleCheck, LuTrendingUp, LuTrendingDown, LuUsers,
  LuAward, LuBuilding, LuCalendar, LuCircleAlert, LuTimer,
  LuFileSpreadsheet, LuArrowRight, LuWallet
} from 'react-icons/lu';
import { useAuth } from '@/context/AuthContext';
import { toast } from 'react-hot-toast';

const Index = () => {
  const [summary, setSummary] = useState(null);
  const [projectStatus, setProjectStatus] = useState(null);
  const [taskStatus, setTaskStatus] = useState(null);
  const [range, setRange] = useState('30');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [statistics, setStatistics] = useState(null);
  const [taskTrend, setTaskTrend] = useState(null);
  const [employeeLeave, setEmployeeLeave] = useState(null);
  const [employeeLeaveBalance, setEmployeeLeaveBalance] = useState(null);
  const [employeeLeaveLoading, setEmployeeLeaveLoading] = useState(true);
  const [permittedWidgets, setPermittedWidgets] = useState([]);
  const [widgetsLoading, setWidgetsLoading] = useState(true);
  const { hasPermission, user } = useAuth();

  const handleRangeChange = (e) => {
    const val = e.target.value;
    if (!['7', '30', '90'].includes(val)) {
      toast.error('Invalid range');
      return;
    }
    setRange(val);
  };

  const canCompany = hasPermission('company.view');
  const canProject = hasPermission('project.view');
  const canTask = hasPermission('task.view');
  const canLead = hasPermission('lead.view');
  const canEmployee = hasPermission('employee.view');

  const isAdmin = user?.role === 'superadmin' || user?.role === 'admin';
  const isEmployee = user?.role === 'employee';

  const isWidgetVisible = useCallback((key) => {
    const visible = permittedWidgets.includes(key);
    console.log(`[DEBUG] Widget "${key}" visibility: ${visible}`);
    return visible;
  }, [permittedWidgets]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    if (isEmployee) setEmployeeLeaveLoading(true);
    setWidgetsLoading(true);

    const run = async () => {
      try {
        // First, fetch permissions to know what else to fetch
        const widgetRes = await api.get('/widgets/my');
        if (widgetRes.data.success && !cancelled) {
          const keys = widgetRes.data.widgets.map(w => w.key);
          setPermittedWidgets(keys);
        }
        setWidgetsLoading(false);

        if (isEmployee) {
          const requests = [];
          const labels = [];

          if (canProject || canTask) {
            requests.push(api.get('/dashboard/summary', { params: { range } }));
            labels.push('summary');
          } else {
            setSummary(null);
          }

          requests.push(api.get('/leave-requests/employee', { params: { page: 1, limit: 20 } }));
          labels.push('leave');

          if (user?.employeeId) {
            requests.push(api.get(`/leave-balance/${user.employeeId}`));
            labels.push('balance');
          } else {
            setEmployeeLeaveBalance(null);
          }

          const responses = await Promise.all(requests);
          if (cancelled) return;

          responses.forEach((res, i) => {
            const label = labels[i];
            if (label === 'summary') setSummary(res.data.data);
            if (label === 'leave') setEmployeeLeave(res.data?.data || null);
            if (label === 'balance') setEmployeeLeaveBalance(res.data?.data || null);
          });

          // Fetch employee-scoped analytics (backend filters by employee role)
          if (canProject) {
            const psRes = await api.get('/dashboard/project-status');
            if (!cancelled) setProjectStatus(psRes.data.data);
          } else {
            setProjectStatus(null);
          }

          if (canTask) {
            const [tsRes, ttRes] = await Promise.all([
              api.get('/dashboard/task-status'),
              api.get('/dashboard/task-completion-trend', { params: { range } }),
            ]);
            if (!cancelled) {
              setTaskStatus(tsRes.data.data);
              setTaskTrend(ttRes.data.data);
            }
          } else {
            setTaskStatus(null);
            setTaskTrend(null);
          }

          // Leads widgets fetch their own data internally
          // Leads widgets and Workforce widget fetch their own data internally
          setStatistics(null);
        } else {
          const [s, ps, ts, stats, tt] = await Promise.all([
            api.get('/dashboard/summary', { params: { range } }),
            api.get('/dashboard/project-status'),
            api.get('/dashboard/task-status'),
            api.get('/statistics/counts'),
            api.get('/dashboard/task-completion-trend', { params: { range } }),
          ]);

          if (cancelled) return;

          setSummary(s.data.data);
          setProjectStatus(ps.data.data);
          setTaskStatus(ts.data.data);
          setStatistics(stats.data.data);
          setTaskTrend(tt.data.data);
        }
      } catch (e) {
        if (!cancelled) {
          setError(e.message || 'Failed to load dashboard data');
          console.error(e);
        }
      } finally {
        if (!cancelled) {
          console.log('[DEBUG] Dashboard loading finished. Permitted widgets:', permittedWidgets);
          console.log('[DEBUG] Current User Role:', user?.role);
          setLoading(false);
          setWidgetsLoading(false);
          if (isEmployee) setEmployeeLeaveLoading(false);
        }
      }
    };

    run();
    return () => { cancelled = true; };
  }, [range, isEmployee, canProject, canTask, user?.employeeId]);

  const getDeltaInfo = useCallback((key) => {
    const d = summary?.delta?.[key];
    if (!d) return null;
    const current = Number(d.current || 0);
    const prev = Number(d.prev || 0);
    const diff = current - prev;
    const pct = prev === 0 ? (current > 0 ? 100 : 0) : Math.round((diff / prev) * 100);
    return { pct, up: diff >= 0 };
  }, [summary]);

  const kpis = useMemo(() => {
    if (!summary) return [];

    const createKpi = (label, value, icon, color, textColor, bgColor, key) => ({
      label, value, icon, color, textColor, bgColor, key
    });

    if (isEmployee) {
      const empArr = [];
      if (canProject) {
        empArr.push(createKpi('My Projects', summary.projects, LuBriefcase, 'bg-blue-500', 'text-blue-500', 'bg-blue-500/10', 'projects'));
        empArr.push(createKpi('My Active Projects', summary.activeProjects, LuPlay, 'bg-primary', 'text-primary', 'bg-primary/10', 'activeProjects'));
      }
      if (canTask) {
        empArr.push(createKpi('My Tasks', summary.tasks, LuListChecks, 'bg-emerald-500', 'text-emerald-500', 'bg-emerald-500/10', 'tasks'));
        empArr.push(createKpi('My Completed Tasks', summary.completedTasks, LuCircleCheck, 'bg-success', 'text-success', 'bg-success/10', 'completedTasks'));
      }
      return empArr;
    }

    const arr = [];
    if (canCompany) arr.push(createKpi('Total Companies', summary.companies, LuBuilding2, 'bg-violet-500', 'text-violet-500', 'bg-violet-500/10', 'companies'));
    if (canProject) {
      arr.push(createKpi('Total Projects', summary.projects, LuBriefcase, 'bg-blue-500', 'text-blue-500', 'bg-blue-500/10', 'projects'));
      arr.push(createKpi('Active Projects', summary.activeProjects, LuPlay, 'bg-primary', 'text-primary', 'bg-primary/10', 'activeProjects'));
    }
    if (canTask) {
      arr.push(createKpi('Total Tasks', summary.tasks, LuListChecks, 'bg-emerald-500', 'text-emerald-500', 'bg-emerald-500/10', 'tasks'));
      arr.push(createKpi('Completed Tasks', summary.completedTasks, LuCircleCheck, 'bg-success', 'text-success', 'bg-success/10', 'completedTasks'));
    }
    if (canLead) arr.push(createKpi('Total Leads', summary.leads, LuUserPlus, 'bg-orange-500', 'text-orange-500', 'bg-orange-500/10', 'leads'));

    return arr;
  }, [summary, canCompany, canProject, canTask, canLead, isEmployee]);

  const employeeLeaveStats = useMemo(() => {
    const applications = employeeLeave?.applications || [];
    const pending = applications.filter(a => a.status === 'pending').length;
    const approved = applications.filter(a => a.status === 'approved').length;
    const rejected = applications.filter(a => a.status === 'rejected').length;
    const recentApps = [...applications]
      .sort((a, b) => new Date(b.createdAt || b.fromDate) - new Date(a.createdAt || a.fromDate))
      .slice(0, 6);

    const balances = employeeLeaveBalance?.leaveBalances || [];
    const totalRemaining = balances.reduce((acc, b) => acc + (Number(b.yearlyRemaining) || 0), 0);
    const topBalances = balances
      .slice()
      .sort((a, b) => (Number(b.yearlyRemaining) || 0) - (Number(a.yearlyRemaining) || 0))
      .slice(0, 6);

    return { pending, approved, rejected, recentApps, totalRemaining, topBalances };
  }, [employeeLeave, employeeLeaveBalance]);

  const taskTrendOptions = useMemo(() => {
    if (!taskTrend) return null;
    const categories = (taskTrend.labels || []).map(d =>
      new Date(d).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
    );

    return {
      series: [{ name: 'Tasks Completed', data: taskTrend.series }],
      chart: { type: 'area', height: 240, toolbar: { show: false }, parentHeightOffset: 0, fontFamily: 'inherit' },
      dataLabels: { enabled: false },
      stroke: { curve: 'smooth', width: 3 },
      xaxis: {
        categories,
        tickAmount: 6,
        axisBorder: { show: false },
        axisTicks: { show: false },
        labels: { style: { colors: '#94a3b8', fontWeight: 500 } }
      },
      yaxis: { labels: { style: { colors: '#94a3b8', fontWeight: 500 } } },
      colors: ['#22c55e'],
      fill: { type: 'gradient', gradient: { shadeIntensity: 1, opacityFrom: 0.4, opacityTo: 0.05, stops: [0, 90, 100] } },
      grid: { borderColor: '#f1f5f9', strokeDashArray: 4, padding: { left: 10, right: 0 } },
    };
  }, [taskTrend]);





  // Stable callback for chart options to prevent re-renders
  const getChartOptions = useCallback((options) => () => options, []);

  const adminStats = [
    { label: 'Total Employees', value: statistics?.totalEmployees || 0, icon: LuUsers, textColor: 'text-blue-500', bgColor: 'bg-blue-500/10' },
    { label: 'Total Designations', value: statistics?.totalDesignations || 0, icon: LuAward, textColor: 'text-orange-500', bgColor: 'bg-orange-500/10' },
    { label: 'Total Departments', value: statistics?.totalDepartments || 0, icon: LuBuilding, textColor: 'text-violet-500', bgColor: 'bg-violet-500/10' },
    { label: 'Total Holidays', value: statistics?.totalHolidays || 0, icon: LuCalendar, textColor: 'text-pink-500', bgColor: 'bg-pink-500/10' },
    { label: 'Notice Period Employees', value: statistics?.totalNotice || 0, icon: LuCircleAlert, textColor: 'text-amber-500', bgColor: 'bg-amber-500/10' },
    { label: 'Probation Employees', value: statistics?.totalProbation || 0, icon: LuTimer, textColor: 'text-emerald-500', bgColor: 'bg-emerald-500/10' },
  ];

  if (error) {
    return (
      <>
        <PageMeta title="Dashboard" />
        <main>
          <PageBreadcrumb title="Dashboard" subtitle="Overview" />
          <div className="card border border-red-200 bg-red-50">
            <div className="card-body text-center py-12">
              <LuCircleAlert className="size-12 text-red-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-red-700 mb-2">Failed to load dashboard</h3>
              <p className="text-red-600 mb-4">{error}</p>
              <button
                onClick={() => window.location.reload()}
                className="btn btn-primary"
              >
                Retry
              </button>
            </div>
          </div>
        </main>
      </>
    );
  }

  if (isEmployee) {
    const name = user?.employeePersonal?.fullName || user?.name || 'Employee';
    const subtitle = user?.employmentDetails?.designation?.name || 'Employee';

    const statusStyles = (status) => {
      if (status === 'approved') return 'bg-success/10 text-success border-success/20';
      if (status === 'rejected') return 'bg-danger/10 text-danger border-danger/20';
      return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
    };

    return (
      <>
        <PageMeta title="Dashboard" />
        <main className="w-full space-y-6">
          <PageBreadcrumb title="Dashboard" subtitle="Employee" />

          <div className="grid lg:grid-cols-12 grid-cols-1 gap-6 items-stretch">
            <div className="lg:col-span-8 space-y-6">
              <div className="bg-white border border-default-200 rounded-3xl overflow-hidden shadow-sm relative">
                {/* Decorative Elements */}
                <div className="absolute top-0 right-0 -mr-16 -mt-16 size-64 bg-primary/10 rounded-full blur-3xl pointer-events-none"></div>

                <div className="p-8 border-b border-default-200">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 relative z-10">
                    <div className="flex items-center gap-5">
                      <div className="p-4 bg-gradient-to-br from-primary/20 to-primary/5 text-primary rounded-2xl shadow-inner border border-primary/10 hidden sm:flex">
                        <span className="text-3xl">👋</span>
                      </div>
                      <div className="space-y-1">
                        <div className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">
                          {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}
                        </div>
                        <div className="text-3xl font-black text-default-900 tracking-tight">
                          Welcome back, {name}
                        </div>
                        <div className="text-sm font-semibold text-primary">
                          {subtitle}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      <Link
                        to="/apply-leave"
                        className="h-11 px-6 rounded-xl bg-gradient-to-r from-primary to-primary-600 text-white font-black text-[11px] uppercase tracking-widest flex items-center justify-center hover:shadow-lg hover:shadow-primary/30 hover:-translate-y-0.5 transition-all duration-300"
                      >
                        Apply Leave
                      </Link>
                      <Link
                        to="/payslip"
                        className="h-11 px-6 rounded-xl bg-white border border-default-200 text-default-700 font-black text-[11px] uppercase tracking-widest flex items-center justify-center hover:border-default-300 hover:bg-default-50 transition-colors"
                      >
                        Payslip
                      </Link>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  {isWidgetVisible('employee_performance') && (
                    <div className="mb-6">
                      <EmployeePerformance />
                    </div>
                  )}
                  <div className="grid sm:grid-cols-4 grid-cols-2 gap-4">
                    <div className="rounded-2xl border border-default-200 bg-white p-5">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <div className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Pending</div>
                          <div className="text-2xl font-black text-default-900">{employeeLeaveLoading ? '—' : employeeLeaveStats.pending}</div>
                        </div>
                        <div className="size-12 rounded-2xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
                          <LuFileSpreadsheet className="size-6" />
                        </div>
                      </div>
                      <div className="mt-3 text-xs font-bold text-default-500">
                        Leave requests awaiting action
                      </div>
                    </div>

                    <div className="rounded-2xl border border-default-200 bg-white p-5">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <div className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Approved</div>
                          <div className="text-2xl font-black text-default-900">{employeeLeaveLoading ? '—' : employeeLeaveStats.approved}</div>
                        </div>
                        <div className="size-12 rounded-2xl bg-success/10 text-success flex items-center justify-center">
                          <LuCircleCheck className="size-6" />
                        </div>
                      </div>
                      <div className="mt-3 text-xs font-bold text-default-500">
                        Approved requests
                      </div>
                    </div>

                    <div className="rounded-2xl border border-default-200 bg-white p-5">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <div className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Rejected</div>
                          <div className="text-2xl font-black text-default-900">{employeeLeaveLoading ? '—' : employeeLeaveStats.rejected}</div>
                        </div>
                        <div className="size-12 rounded-2xl bg-danger/10 text-danger flex items-center justify-center">
                          <LuCircleAlert className="size-6" />
                        </div>
                      </div>
                      <div className="mt-3 text-xs font-bold text-default-500">
                        Requests rejected
                      </div>
                    </div>

                    <div className="rounded-2xl border border-default-200 bg-white p-5">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <div className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Remaining</div>
                          <div className="text-2xl font-black text-default-900">{employeeLeaveLoading ? '—' : employeeLeaveStats.totalRemaining}</div>
                        </div>
                        <div className="size-12 rounded-2xl bg-violet-500/10 text-violet-500 flex items-center justify-center">
                          <LuWallet className="size-6" />
                        </div>
                      </div>
                      <div className="mt-3 text-xs font-bold text-default-500">
                        Total leave days available
                      </div>
                    </div>
                  </div>

                  {isWidgetVisible('employee_task_summary') && (canProject || canTask) && (
                    <div className="mt-6">
                      <EmployeeTaskSummary stats={summary} loading={loading} />
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-white border border-default-200 rounded-2xl overflow-hidden shadow-sm flex flex-col">
                  <div className="p-5 border-b border-default-200 bg-white flex items-center justify-between">
                    <div>
                      <h4 className="text-lg font-black text-default-900 flex items-center gap-2 tracking-tight">
                        🏖️ Time Off Overview
                      </h4>
                      <p className="text-xs font-bold text-default-400 mt-0.5 uppercase tracking-widest">
                        Your leave balances and requests
                      </p>
                    </div>
                    <Link
                      to="/applied-leave"
                      className="size-8 rounded-full bg-default-100 flex items-center justify-center text-default-500 hover:bg-primary hover:text-white transition-colors"
                    >
                      <LuArrowRight size={16} />
                    </Link>
                  </div>

                  <div className="p-5 flex-grow overflow-y-auto max-h-[400px]">
                    <div className="mb-6">
                      <h5 className="text-[10px] font-black text-default-500 uppercase tracking-widest mb-3">Available Balances</h5>
                      {employeeLeaveLoading ? (
                        <div className="space-y-3">
                          {Array.from({ length: 2 }).map((_, i) => (
                            <div key={i} className="h-10 rounded-xl bg-default-100 animate-pulse" />
                          ))}
                        </div>
                      ) : employeeLeaveStats.topBalances.length === 0 ? (
                        <p className="text-sm text-default-400 italic">No balance data available.</p>
                      ) : (
                        <div className="space-y-2">
                          {employeeLeaveStats.topBalances.slice(0, 3).map((b) => (
                            <div key={b._id || `${b.leaveId}-${b.leaveName}`} className="flex items-center justify-between p-3 rounded-xl border border-default-200 hover:border-primary/20 hover:bg-primary/5 transition-colors">
                              <span className="text-sm font-bold text-default-700">{b.leaveName || 'Leave'}</span>
                              <span className="text-sm font-black text-primary bg-primary/10 px-3 py-1 rounded-md">{Number(b.yearlyRemaining) || 0} days</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div>
                      <h5 className="text-[10px] font-black text-default-500 uppercase tracking-widest mb-3">Recent Requests</h5>
                      {employeeLeaveLoading ? (
                        <div className="space-y-3">
                          {Array.from({ length: 2 }).map((_, i) => (
                            <div key={i} className="h-12 rounded-xl bg-default-100 animate-pulse" />
                          ))}
                        </div>
                      ) : employeeLeaveStats.recentApps.length === 0 ? (
                        <p className="text-sm text-default-400 italic">No recent leave requests.</p>
                      ) : (
                        <div className="space-y-2">
                          {employeeLeaveStats.recentApps.slice(0, 3).map((app) => (
                            <div key={app._id} className="flex items-center justify-between p-3 flex-wrap gap-2 rounded-xl border border-default-200">
                              <div>
                                <div className="text-sm font-bold text-default-900">{app.leaveName || 'Leave'}</div>
                                <div className="text-[11px] font-bold text-default-500">
                                  {new Date(app.fromDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} - {new Date(app.toDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                                </div>
                              </div>
                              <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest border ${statusStyles(app.status)}`}>
                                {app.status || 'pending'}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {isWidgetVisible('employee_task_summary') && (canProject || canTask) && (
                  <div className="mb-6">
                    <EmployeeTaskSummary stats={summary} loading={loading} />
                  </div>
                )}

                {isWidgetVisible('today_priorities_widget') && <TodayPrioritiesWidget />}
                {isWidgetVisible('task_board_widget') && <TaskBoardWidget />}
              </div>
            </div>

            <div className="lg:col-span-4 space-y-6">
              {isWidgetVisible('profile_card') && <EmployeeProfileCard />}
              {isWidgetVisible('attendance_widget') && <AttendanceWidget />}
              {isWidgetVisible('announcements_widget') && <AnnouncementsWidget />}
              {isWidgetVisible('notifications_panel') && <NotificationPanel />}
            </div>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <PageMeta title="Dashboard" />

      <main>
        <PageBreadcrumb title="Dashboard" subtitle="Overview" />

        {(loading || widgetsLoading) && (
          <div className="flex flex-col items-center justify-center min-h-[400px]">
            <div className="size-12 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-default-500 font-medium animate-pulse">Loading dashboard widgets...</p>
          </div>
        )}

        {!(loading || widgetsLoading) && (
          <>
            {isAdmin && (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 grid-cols-1 gap-4 mb-6">
                {adminStats.map((s) => (
                  <div key={s.label} className="card border border-default-200 group transition-all duration-300 hover:shadow-sm">
                    <div className="card-body">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-default-600 mb-1">{s.label}</p>
                          <h4 className="text-2xl font-bold text-default-900">{loading ? '—' : s.value}</h4>
                        </div>
                        <div className={`size-12 rounded-2xl ${s.bgColor} ${s.textColor} flex items-center justify-center transition-all duration-300 group-hover:scale-110`}>
                          <s.icon className="size-6" />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center justify-between mb-5">
              <div className="text-sm text-default-600">Filters</div>
              <select
                className="form-input form-input-sm bg-default-100"
                value={range}
                onChange={handleRangeChange}
              >
                <option value="7">Last 7 days</option>
                <option value="30">Last 30 days</option>
                <option value="90">Last 90 days</option>
              </select>
            </div>

            {!isAdmin && (
              <div className="grid lg:grid-cols-12 grid-cols-1 gap-6 mb-6 items-stretch">
                {isWidgetVisible('profile_card') && (
                  <div className="lg:col-span-4">
                    <EmployeeProfileCard />
                  </div>
                )}

                {isWidgetVisible('attendance_widget') && (
                  <div className="lg:col-span-4">
                    <AttendanceWidget />
                  </div>
                )}

                {isWidgetVisible('notifications_panel') && (
                  <div className="lg:col-span-4">
                    <NotificationPanel />
                  </div>
                )}
              </div>
            )}

            {isWidgetVisible('employee_task_summary') && (
              <div className="grid grid-cols-1 gap-6 mb-6">
                <div className="w-full">
                  <div className={`grid gap-4 ${!isAdmin ? "lg:grid-cols-4 sm:grid-cols-2 grid-cols-1" : "lg:grid-cols-3 sm:grid-cols-2 grid-cols-1"}`}>
                    {kpis.map((k) => (
                      <div key={k.label} className="card border border-default-200 group transition-all duration-300 hover:shadow-sm">
                        <div className="card-body">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="text-sm font-medium text-default-600 mb-1">{k.label}</p>
                              <div className="flex items-baseline gap-2">
                                <h4 className="text-2xl font-bold text-default-900">{loading ? '—' : k.value}</h4>
                                {!loading && (() => {
                                  const info = getDeltaInfo(k.key);
                                  if (!info) return null;
                                  const cls = info.up ? 'text-success' : 'text-danger';
                                  const Icon = info.up ? LuTrendingUp : LuTrendingDown;
                                  return (
                                    <span className={`text-xs font-medium ${cls} flex items-center gap-0.5`}>
                                      <Icon className="size-3" />
                                      {`${info.up ? '+' : ''}${info.pct}%`}
                                    </span>
                                  );
                                })()}
                              </div>
                            </div>
                            <div className={`size-12 rounded-2xl ${k.bgColor} ${k.textColor} flex items-center justify-center transition-all duration-300 group-hover:scale-110`}>
                              <k.icon className="size-6" />
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="grid lg:grid-cols-12 grid-cols-1 gap-5 mb-5 items-stretch">
              {isWidgetVisible('employee_performance') && (
                <div className="lg:col-span-12">
                  <EmployeePerformance />
                </div>
              )}

              {isWidgetVisible('task_board_widget') && (
                <div className="lg:col-span-12">
                  <TaskBoardWidget />
                </div>
              )}

              {isWidgetVisible('announcements_widget') && (
                <div className="lg:col-span-12">
                  <AnnouncementsWidget />
                </div>
              )}

              {/* Priorities + Task Status Distribution — own isolated row */}
              {(isWidgetVisible('today_priorities_widget') || (isWidgetVisible('task_status_overview') && canTask && taskStatus)) && (
                <div className="lg:col-span-6">
                  <div className="grid lg:col-span-6 grid-cols-1 gap-5 items-stretch">
                    {isWidgetVisible('today_priorities_widget') && (
                      <div className="lg:col-span-6 ">
                        <TodayPrioritiesWidget />
                      </div>
                    )}
                    {isWidgetVisible('task_status_overview') && canTask && taskStatus && (
                      <div className="lg:col-span-6">
                        <TaskStatusDistributionWidget taskStatus={taskStatus} />
                      </div>
                    )}
                  </div>
                </div>
              )}



              {isWidgetVisible('task_status_chart_widget') && canTask && (
                <div className="lg:col-span-6 h-full">
                  <TaskStatusChartWidget />
                </div>
              )}
              {isWidgetVisible('project_status') && canProject && projectStatus && (
                <div className="lg:col-span-6 h-full">
                  <ProjectStatusWidget projectStatus={projectStatus} />
                </div>
              )}

              <div className="grid lg:col-span-6 gap-5 mb-5 items-stretch">
                {isWidgetVisible('leads_overview') && canLead && (
                  <div className="lg:col-span-6 h-full">
                    <LeadsOverviewWidget range={range} />
                  </div>
                )}

                {isWidgetVisible('task_completion_trend') && canTask && taskTrendOptions && (
                  <div className="lg:col-span-">
                    <div className="card border border-default-200">
                      <div className="card-header border-b border-default-200">
                        <h6 className="card-title text-base font-semibold">Task Completion Trend</h6>
                      </div>
                      <div className="card-body">
                        <ApexChartClient
                          getOptions={getChartOptions(taskTrendOptions)}
                          series={taskTrendOptions.series}
                          type="area"
                          height={240}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>


              {isWidgetVisible('leads_overview') && canLead && (
                <div className="lg:col-span-6 h-full">
                  <LeadsBySourceWidget />
                </div>
              )}

              {isWidgetVisible('workforce_overview') && canEmployee && !isEmployee && (
                <div className="lg:col-span-6 h-full">
                  <WorkforceOverviewWidget />
                </div>
              )}
            </div>

            <div className="grid lg:grid-cols-2 grid-cols-1 gap-5 items-stretch">
              {isWidgetVisible('upcoming_birthdays') && (
                <div className="h-full">
                  <UpcomingBirthdaysWidget />
                </div>
              )}
              {isWidgetVisible('activity_logs') && (
                <div className="h-full">
                  <ActivityLogsWidget />
                </div>
              )}
            </div>
          </>
        )}
      </main>
    </>
  );
};

export default Index;
