import { useState, useEffect, useMemo } from 'react';
import { LuSearch, LuCheck, LuX, LuEye, LuMessageSquare, LuList, LuClock, LuCircleX, LuPlus, LuUpload } from 'react-icons/lu';
import { FiCheckCircle, FiXCircle, FiClock } from 'react-icons/fi';
import api from '@/config/api';
import { toast } from 'react-hot-toast';

const ApprovalList = () => {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [rejectionModal, setRejectionModal] = useState({ isOpen: false, expenseId: null, reason: '' });
  const [rejectionError, setRejectionError] = useState('');
  const [generateModalOpen, setGenerateModalOpen] = useState(false);
  const [employeesLoading, setEmployeesLoading] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [generateFormData, setGenerateFormData] = useState({
    employeeUserId: '',
    title: '',
    category: 'Travel',
    amount: '',
    date: new Date().toISOString().split('T')[0],
    description: '',
  });
  const [generateFile, setGenerateFile] = useState(null);
  const [generateSubmitting, setGenerateSubmitting] = useState(false);
  const [generateFieldErrors, setGenerateFieldErrors] = useState({});

  const categories = ['Travel', 'Food', 'Accommodation', 'Office Supplies', 'Communication', 'Others'];

  const stats = useMemo(() => {
    const totalRequests = expenses.length;
    const approved = expenses.filter(e => e.status === 'Approved').length;
    const pending = expenses.filter(e => e.status === 'Pending').length;
    const rejected = expenses.filter(e => e.status === 'Rejected').length;
    return { totalRequests, approved, pending, rejected };
  }, [expenses]);

  const fetchAllExpenses = async () => {
    try {
      setLoading(true);
      const response = await api.get('/expenses');
      if (response.data.success) {
        setExpenses(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching all expenses:', error);
      toast.error('Failed to load expenses for approval');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllExpenses();
  }, []);

  const loadEmployees = async () => {
    try {
      setEmployeesLoading(true);
      const resp = await api.get('/hr/employees', { params: { page: 1, limit: 200 } });
      if (resp.data?.success) {
        setEmployees(resp.data.employees || []);
      } else {
        setEmployees([]);
      }
    } catch (e) {
      setEmployees([]);
      toast.error(e.response?.data?.message || 'Failed to load employees');
    } finally {
      setEmployeesLoading(false);
    }
  };

  const openGenerateModal = async () => {
    setGenerateModalOpen(true);
    setGenerateFieldErrors({});
    setGenerateFile(null);
    setGenerateFormData({
      employeeUserId: '',
      title: '',
      category: 'Travel',
      amount: '',
      date: new Date().toISOString().split('T')[0],
      description: '',
    });
    if (!employees.length) await loadEmployees();
  };

  const clearGenerateFieldError = (field) => {
    if (!generateFieldErrors[field]) return;
    setGenerateFieldErrors((prev) => {
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };

  const selectedEmployee = useMemo(() => {
    const id = generateFormData.employeeUserId;
    if (!id) return null;
    return employees.find((e) => e._id === id) || null;
  }, [employees, generateFormData.employeeUserId]);

  const validateGenerate = () => {
    const errors = {};

    if (!generateFormData.employeeUserId) errors.employeeUserId = 'Employee is required';

    const title = generateFormData.title?.trim() || '';
    if (!title) errors.title = 'Title is required';
    else if (title.length < 3) errors.title = 'Title must be at least 3 characters';
    else if (title.length > 120) errors.title = 'Title must be at most 120 characters';

    if (!categories.includes(generateFormData.category)) errors.category = 'Invalid category';

    const amountNumber = Number(generateFormData.amount);
    if (generateFormData.amount === '' || generateFormData.amount === null || generateFormData.amount === undefined) errors.amount = 'Amount is required';
    else if (!Number.isFinite(amountNumber)) errors.amount = 'Amount must be a number';
    else if (amountNumber <= 0) errors.amount = 'Amount must be greater than 0';
    else if (amountNumber > 1000000000) errors.amount = 'Amount is too large';

    const date = generateFormData.date ? new Date(`${generateFormData.date}T00:00:00`) : null;
    if (!date || Number.isNaN(date.getTime())) errors.date = 'Date is required';
    else {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (date > today) errors.date = 'Date cannot be in the future';
    }

    const description = generateFormData.description?.trim() || '';
    if (description.length > 2000) errors.description = 'Description is too long';

    if (generateFile) {
      const maxSizeBytes = 5 * 1024 * 1024;
      const isPdf = generateFile.type === 'application/pdf';
      const isImage = generateFile.type?.startsWith('image/');
      if (!isPdf && !isImage) errors.receipt = 'Receipt must be an image or PDF';
      else if (generateFile.size > maxSizeBytes) errors.receipt = 'Receipt must be 5MB or less';
    }

    setGenerateFieldErrors(errors);
    const firstError = Object.values(errors)[0];
    if (firstError) toast.error(firstError);
    return Object.keys(errors).length === 0;
  };

  const submitGenerateExpense = async (e) => {
    e.preventDefault();
    if (!validateGenerate()) return;
    setGenerateSubmitting(true);
    try {
      const data = new FormData();
      data.append('employeeUserId', generateFormData.employeeUserId);
      data.append('title', String(generateFormData.title || '').trim());
      data.append('category', generateFormData.category);
      data.append('amount', generateFormData.amount);
      data.append('date', generateFormData.date);
      data.append('description', String(generateFormData.description || '').trim());
      if (generateFile) data.append('receipt', generateFile);

      const resp = await api.post('/expenses/admin', data);
      if (resp.data?.success) {
        toast.success('Expense generated successfully');
        setGenerateModalOpen(false);
        fetchAllExpenses();
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to generate expense');
    } finally {
      setGenerateSubmitting(false);
    }
  };

  const handleStatusUpdate = async (id, status, rejectionReason = '') => {
    try {
      const response = await api.patch(`/expenses/${id}/status`, {
        status,
        rejectionReason
      });
      if (response.data.success) {
        toast.success(`Expense ${status.toLowerCase()} successfully`);
        setRejectionModal({ isOpen: false, expenseId: null, reason: '' });
        fetchAllExpenses();
      }
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to update status');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Approved': return 'bg-success/10 text-success';
      case 'Rejected': return 'bg-danger/10 text-danger';
      default: return 'bg-warning/10 text-warning';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Approved': return <FiCheckCircle className="size-3.5 me-1" />;
      case 'Rejected': return <FiXCircle className="size-3.5 me-1" />;
      default: return <FiClock className="size-3.5 me-1" />;
    }
  };

  const filteredExpenses = expenses.filter(exp => 
    (exp.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exp.employee?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exp.employeeId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    exp.category.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (statusFilter ? exp.status === statusFilter : true)
  );

  return (
    <>
      <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5 mb-6">
        <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
              <LuList className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Total Requests</div>
              <div className="text-2xl font-black text-default-900 leading-none">{stats.totalRequests}</div>
            </div>
          </div>
        </div>
        <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-2xl bg-warning/10 flex items-center justify-center text-warning group-hover:scale-110 transition-transform duration-300">
              <LuClock className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Pending</div>
              <div className="text-2xl font-black text-default-900 leading-none">{stats.pending}</div>
            </div>
          </div>
        </div>
        <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-2xl bg-success/10 flex items-center justify-center text-success group-hover:scale-110 transition-transform duration-300">
              <LuCheck className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Approved</div>
              <div className="text-2xl font-black text-default-900 leading-none">{stats.approved}</div>
            </div>
          </div>
        </div>
        <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-2xl bg-danger/10 flex items-center justify-center text-danger group-hover:scale-110 transition-transform duration-300">
              <LuCircleX className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Rejected</div>
              <div className="text-2xl font-black text-danger leading-none">{stats.rejected}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-4 border border-default-200 mb-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3 flex-wrap flex-1 min-w-0">
            <div className="relative flex-1 max-w-xs min-w-[200px]">
              <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-default-400" />
              <input
                type="text"
                className="form-input pl-10 h-11 w-full rounded-2xl border-default-200 focus:border-primary focus:ring-primary bg-default-50/50 text-sm font-medium transition-all"
                placeholder="Search by employee, title..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="w-full sm:w-auto min-w-[150px]">
               <select 
                 className="form-select h-11 w-full rounded-2xl border-default-200 focus:border-primary focus:ring-primary bg-default-50/50 text-sm font-medium transition-all"
                 value={statusFilter}
                 onChange={(e) => setStatusFilter(e.target.value)}
               >
                 <option value="">All Status</option>
                 <option value="Pending">Pending</option>
                 <option value="Approved">Approved</option>
                 <option value="Rejected">Rejected</option>
               </select>
            </div>
          </div>
          <button
            type="button"
            className="btn bg-primary text-white flex items-center gap-2 px-6 h-11 rounded-2xl font-bold uppercase tracking-widest transition-all hover:bg-primary-600 disabled:opacity-50"
            onClick={openGenerateModal}
            disabled={loading}
          >
            <LuPlus className="size-4" />
            Generate Expense
          </button>
        </div>
      </div>

      <div className="card">
        <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-default-200">
          <thead className="bg-default-50">
            <tr>
              <th className="px-6 py-3 text-start text-xs font-bold text-default-500 uppercase">Employee</th>
              <th className="px-6 py-3 text-start text-xs font-bold text-default-500 uppercase">Title/Date</th>
              <th className="px-6 py-3 text-start text-xs font-bold text-default-500 uppercase">Category</th>
              <th className="px-6 py-3 text-start text-xs font-bold text-default-500 uppercase">Amount</th>
              <th className="px-6 py-3 text-start text-xs font-bold text-default-500 uppercase">Status</th>
              <th className="px-6 py-3 text-end text-xs font-bold text-default-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-default-200">
            {loading ? (
              <tr>
                <td colSpan="6" className="px-6 py-4 text-center text-default-500">Loading...</td>
              </tr>
            ) : filteredExpenses.length === 0 ? (
              <tr>
                <td colSpan="6" className="px-6 py-4 text-center text-default-500">No expenses found</td>
              </tr>
            ) : (
              filteredExpenses.map((expense) => (
                <tr key={expense._id} className="hover:bg-default-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex flex-col">
                      <span className="text-sm font-bold text-default-900">{expense.employee?.name}</span>
                      <span className="text-xs text-default-500">{expense.employeeId}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex flex-col">
                      <span className="text-sm text-default-900 font-medium">{expense.title}</span>
                      <span className="text-xs text-default-500">{new Date(expense.date).toLocaleDateString()}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-default-700">
                    <span className="px-2 py-1 rounded-md bg-default-100">{expense.category}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-default-900">
                    ₹{expense.amount.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(expense.status)}`}>
                      {getStatusIcon(expense.status)}
                      {expense.status}
                    </span>
                    {expense.reimbursementStatus === 'Processed' && (
                      <span className="ms-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-info/10 text-info">
                        Reimbursed
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-end text-sm font-medium">
                    <div className="flex justify-end gap-2">
                      {expense.receiptUrl && (
                        <a 
                          href={expense.receiptUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-1.5 text-info hover:bg-info/10 rounded-md transition-all"
                          title="View Receipt"
                        >
                          <LuEye className="size-4" />
                        </a>
                      )}
                      {expense.status === 'Pending' && (
                        <>
                          <button 
                            className="p-1.5 text-success hover:bg-success/10 rounded-md transition-all"
                            onClick={() => handleStatusUpdate(expense._id, 'Approved')}
                            title="Approve"
                          >
                            <LuCheck className="size-4" />
                          </button>
                          <button 
                            className="p-1.5 text-danger hover:bg-danger/10 rounded-md transition-all"
                            onClick={() => setRejectionModal({ isOpen: true, expenseId: expense._id, reason: '' })}
                            title="Reject"
                          >
                            <LuX className="size-4" />
                          </button>
                        </>
                      )}
                      {expense.status === 'Rejected' && expense.rejectionReason && (
                        <button 
                          className="p-1.5 text-warning hover:bg-warning/10 rounded-md transition-all"
                          onClick={() => toast(expense.rejectionReason, { icon: '⚠️' })}
                          title="View Reason"
                        >
                          <LuMessageSquare className="size-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {rejectionModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-default-100 bg-default-50/50">
              <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">Reject Expense</h3>
              <button
                onClick={() => {
                  setRejectionModal({ ...rejectionModal, isOpen: false });
                  setRejectionError('');
                }}
                className="p-2 hover:bg-default-200 rounded-full transition-all"
              >
                <LuX className="size-5 text-default-500" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Reason for Rejection</label>
                <textarea
                  className={`form-input w-full rounded-xl ${rejectionError ? 'border-danger' : ''}`}
                  rows="3"
                  placeholder="Explain why this expense is being rejected..."
                  value={rejectionModal.reason}
                  onChange={(e) => {
                    if (rejectionError) setRejectionError('');
                    setRejectionModal({ ...rejectionModal, reason: e.target.value });
                  }}
                />
                {rejectionError && <div className="mt-1 text-xs font-semibold text-danger">{rejectionError}</div>}
              </div>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setRejectionModal({ ...rejectionModal, isOpen: false });
                    setRejectionError('');
                  }}
                  className="flex-1 px-6 py-3 rounded-xl border border-default-200 text-sm font-black text-default-700 uppercase tracking-widest hover:bg-default-50 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={!rejectionModal.reason?.trim()}
                  className="flex-1 px-6 py-3 rounded-xl bg-danger text-white text-sm font-black uppercase tracking-widest hover:bg-danger-600 transition-all shadow-lg shadow-danger/20 disabled:opacity-50"
                  onClick={() => {
                    const reason = rejectionModal.reason?.trim() || '';
                    if (!reason) {
                      setRejectionError('Rejection reason is required');
                      toast.error('Rejection reason is required');
                      return;
                    }
                    if (reason.length < 10) {
                      setRejectionError('Reason must be at least 10 characters');
                      toast.error('Reason must be at least 10 characters');
                      return;
                    }
                    if (reason.length > 500) {
                      setRejectionError('Reason must be at most 500 characters');
                      toast.error('Reason must be at most 500 characters');
                      return;
                    }
                    handleStatusUpdate(rejectionModal.expenseId, 'Rejected', reason);
                  }}
                >
                  Confirm Rejection
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {generateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-default-100 bg-default-50/50">
              <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">
                Add New Expense
              </h3>
              <button
                onClick={() => setGenerateModalOpen(false)}
                className="p-2 hover:bg-default-200 rounded-full transition-all"
                type="button"
              >
                <LuX className="size-5 text-default-500" />
              </button>
            </div>

            <form onSubmit={submitGenerateExpense} className="p-6 space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Select Employee</label>
                  <select
                    className={`form-select w-full rounded-xl ${generateFieldErrors.employeeUserId ? 'border-danger' : ''}`}
                    value={generateFormData.employeeUserId}
                    onChange={(e) => {
                      clearGenerateFieldError('employeeUserId');
                      setGenerateFormData((p) => ({ ...p, employeeUserId: e.target.value }));
                    }}
                    disabled={employeesLoading}
                  >
                    <option value="">{employeesLoading ? 'Loading...' : 'Select employee'}</option>
                    {employees.map((emp) => (
                      <option key={emp._id} value={emp._id}>
                        {(emp.employeePersonal?.fullName || emp.name) + (emp.employeeId ? ` (${emp.employeeId})` : '')}
                      </option>
                    ))}
                  </select>
                  {generateFieldErrors.employeeUserId && <div className="mt-1 text-xs font-semibold text-danger">{generateFieldErrors.employeeUserId}</div>}
                </div>

                <div>
                  <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Emp - ID</label>
                  <input
                    type="text"
                    className="form-input w-full rounded-xl bg-default-50/50"
                    value={selectedEmployee?.employeeId || ''}
                    readOnly
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Title</label>
                  <input
                    type="text"
                    required
                    className={`form-input w-full rounded-xl ${generateFieldErrors.title ? 'border-danger' : ''}`}
                    placeholder="e.g. Flight to London"
                    value={generateFormData.title}
                    onChange={(e) => {
                      clearGenerateFieldError('title');
                      setGenerateFormData((p) => ({ ...p, title: e.target.value }));
                    }}
                  />
                  {generateFieldErrors.title && <div className="mt-1 text-xs font-semibold text-danger">{generateFieldErrors.title}</div>}
                </div>

                <div>
                  <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Category</label>
                  <select
                    className={`form-select w-full rounded-xl ${generateFieldErrors.category ? 'border-danger' : ''}`}
                    value={generateFormData.category}
                    onChange={(e) => {
                      clearGenerateFieldError('category');
                      setGenerateFormData((p) => ({ ...p, category: e.target.value }));
                    }}
                  >
                    {categories.map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                  {generateFieldErrors.category && <div className="mt-1 text-xs font-semibold text-danger">{generateFieldErrors.category}</div>}
                </div>

                <div>
                  <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Amount</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 start-0 flex items-center ps-3 text-default-500">₹</span>
                    <input
                      type="number"
                      required
                      min="0"
                      step="0.01"
                      className={`form-input w-full ps-7 rounded-xl ${generateFieldErrors.amount ? 'border-danger' : ''}`}
                      placeholder="0.00"
                      value={generateFormData.amount}
                      onChange={(e) => {
                        clearGenerateFieldError('amount');
                        setGenerateFormData((p) => ({ ...p, amount: e.target.value }));
                      }}
                    />
                  </div>
                  {generateFieldErrors.amount && <div className="mt-1 text-xs font-semibold text-danger">{generateFieldErrors.amount}</div>}
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Date</label>
                  <input
                    type="date"
                    required
                    className={`form-input w-full rounded-xl ${generateFieldErrors.date ? 'border-danger' : ''}`}
                    value={generateFormData.date}
                    onChange={(e) => {
                      clearGenerateFieldError('date');
                      setGenerateFormData((p) => ({ ...p, date: e.target.value }));
                    }}
                  />
                  {generateFieldErrors.date && <div className="mt-1 text-xs font-semibold text-danger">{generateFieldErrors.date}</div>}
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Description</label>
                  <textarea
                    className={`form-input w-full rounded-xl ${generateFieldErrors.description ? 'border-danger' : ''}`}
                    rows="3"
                    placeholder="Brief details about the expense..."
                    value={generateFormData.description}
                    onChange={(e) => {
                      clearGenerateFieldError('description');
                      setGenerateFormData((p) => ({ ...p, description: e.target.value }));
                    }}
                  />
                  {generateFieldErrors.description && <div className="mt-1 text-xs font-semibold text-danger">{generateFieldErrors.description}</div>}
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Receipt (Optional)</label>
                  <div className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-2xl hover:border-primary transition-all cursor-pointer group relative ${generateFieldErrors.receipt ? 'border-danger' : 'border-default-200'}`}>
                    <div className="space-y-1 text-center">
                      <LuUpload className="mx-auto size-10 text-default-400 group-hover:text-primary transition-all" />
                      <div className="flex text-sm text-default-600">
                        <label className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary-600">
                          <span>{generateFile ? generateFile.name : 'Upload a file'}</span>
                          <input
                            type="file"
                            className="sr-only"
                            accept="image/*,application/pdf"
                            onChange={(e) => {
                              clearGenerateFieldError('receipt');
                              setGenerateFile(e.target.files?.[0] || null);
                            }}
                          />
                        </label>
                      </div>
                      <p className="text-xs text-default-400">PNG, JPG, PDF up to 5MB</p>
                    </div>
                  </div>
                  {generateFieldErrors.receipt && <div className="mt-1 text-xs font-semibold text-danger">{generateFieldErrors.receipt}</div>}
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setGenerateModalOpen(false)}
                  className="flex-1 px-6 py-3 rounded-xl border border-default-200 text-sm font-black text-default-700 uppercase tracking-widest hover:bg-default-50 transition-all"
                  disabled={generateSubmitting}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-6 py-3 rounded-xl bg-primary text-white text-sm font-black uppercase tracking-widest hover:bg-primary-600 transition-all shadow-lg shadow-primary/20 disabled:opacity-50"
                  disabled={generateSubmitting}
                >
                  {generateSubmitting ? 'Submitting...' : 'Submit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
    </>
  );
};

export default ApprovalList;
