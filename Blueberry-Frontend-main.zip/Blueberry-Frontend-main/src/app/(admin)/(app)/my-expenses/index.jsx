import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import ExpenseList from './components/ExpenseList';

const MyExpenses = () => {
  return (
    <>
      <PageMeta title="My Expenses" />
      <main>
        <PageBreadcrumb title="My Expenses" subtitle="HR" />
        <ExpenseList />
      </main>
    </>
  );
};

export default MyExpenses;
