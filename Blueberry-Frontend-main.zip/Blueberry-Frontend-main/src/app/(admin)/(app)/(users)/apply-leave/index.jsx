import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import ApplyingLeave from './components/ApplyingLeave';

const Index = () => {
  return <>
      <PageMeta title="Apply Leave" />
      <main>
        <PageBreadcrumb title="Apply Leave" subtitle="Menu" />
        <ApplyingLeave />
      </main>
    </>;
};
export default Index;