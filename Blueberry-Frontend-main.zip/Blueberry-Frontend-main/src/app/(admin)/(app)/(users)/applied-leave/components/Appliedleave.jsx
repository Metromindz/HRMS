import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { LuSearch, LuPlus, LuChevronLeft, LuChevronRight, LuCalendar, LuCheck, LuClock, LuX } from 'react-icons/lu';
import api from '../../../../../../config/api.js';

const AppliedLeave = () => {
  const [leaveData, setLeaveData] = useState({
    applications: [],
    leaveTypes: []
  });
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [message, setMessage] = useState('');
  const [pagination, setPagination] = useState({
    page: 1,
    totalPages: 1,
    limit: 10,
    total: 0,
  });

  // Calculate stats for the cards
  const stats = useMemo(() => {
    const apps = leaveData.applications || [];
    const pending = apps.filter(a => a.status?.toLowerCase() === 'pending').length;
    const approved = apps.filter(a => a.status?.toLowerCase() === 'approved').length;
    const rejected = apps.filter(a => a.status?.toLowerCase() === 'rejected').length;
    return {
      total: pagination.total,
      pending,
      approved,
      rejected
    };
  }, [leaveData.applications, pagination.total]);

  // Fetch leave requests from backend with pagination
  const fetchLeaveRequests = async (page = 1, status = statusFilter, search = searchTerm) => {
    try {
      setLoading(true);
      const token = sessionStorage.getItem('token');

      if (!token) {
        setMessage('No authentication token found');
        setLoading(false);
        return;
      }

      // Build query parameters
      const params = new URLSearchParams();
      params.append('page', page);
      params.append('limit', pagination.limit);
      if (status && status !== 'all') {
        params.append('status', status);
      }
      if (search) {
        params.append('search', search);
      }
      // Optional: add date filters if needed
      // params.append('sortBy', 'createdAt');
      // params.append('sortOrder', 'desc');

      const response = await api.get(`/leave-requests/employee?${params.toString()}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });



      if (response.data && response.data.data) {
        // Handle the new response structure from paginated API
        const responseData = response.data.data;

        // Extract applications and other data
        if (responseData.applications) {
          setLeaveData({
            applications: responseData.applications,
            leaveTypes: responseData.leaveTypes || [],
            employeeName: responseData.employeeName,
            employeeId: responseData.employeeId
          });
        } else {
          // Fallback for older API structure
          setLeaveData({
            applications: responseData.leaveRequests?.flatMap(lt =>
              lt.applications?.map(app => ({
                ...app,
                leaveName: lt.leaveName
              })) || []
            ) || [],
            leaveTypes: responseData.leaveRequests || []
          });
        }

        // Update pagination from API response
        if (response.data.pagination) {
          setPagination(prev => ({
            ...prev,
            page: response.data.pagination.page,
            total: response.data.pagination.total,
            totalPages: response.data.pagination.totalPages,
          }));
        }

        setMessage('');
      } else {
        setMessage(response.data?.message || 'Failed to fetch leave requests');
        setLeaveData({ applications: [], leaveTypes: [] });
      }
    } catch (error) {
      console.error('Error fetching leave requests:', error);
      setMessage(error.response?.data?.message || 'Error connecting to server');
      setLeaveData({ applications: [], leaveTypes: [] });
      setPagination(prev => ({ ...prev, page: 1, total: 0, totalPages: 1 }));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Initial fetch
    fetchLeaveRequests(1);

    const intervalId = setInterval(() => {
      fetchLeaveRequests(pagination.page);
    }, 30000);

    return () => clearInterval(intervalId);
  }, [statusFilter, searchTerm]);


  // Handle status filter change
  const handleStatusFilterChange = (e) => {
    const value = e.target.value;
    setStatusFilter(value);
    // Reset to page 1 when filter changes
    fetchLeaveRequests(1, value, searchTerm);
  };

  // Handle search
  const handleSearch = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    // Optionally add debounce here for better performance
    // Reset to page 1 when search changes
    fetchLeaveRequests(1, statusFilter, value);
  };

  // Handle page change
  const handlePageChange = (page) => {
    if (page >= 1 && page <= pagination.totalPages) {
      setPagination(prev => ({ ...prev, page }));
      fetchLeaveRequests(page, statusFilter, searchTerm);
    }
  };

  // Handle previous page
  const handlePrevious = () => {
    if (pagination.page > 1) {
      handlePageChange(pagination.page - 1);
    }
  };

  // Handle next page
  const handleNext = () => {
    if (pagination.page < pagination.totalPages) {
      handlePageChange(pagination.page + 1);
    }
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  // Get status badge style
  const getStatusBadgeClass = (status) => {
    switch (status?.toLowerCase()) {
      case 'approved':
        return 'bg-success/15 text-success';
      case 'rejected':
        return 'bg-danger/10 text-danger';
      case 'pending':
        return 'bg-warning/15 text-warning';
      default:
        return 'bg-default-100 text-default-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5">
        <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
              <LuCalendar className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Total Applied</div>
              <div className="text-2xl font-black text-default-900 leading-none">{stats.total}</div>
            </div>
          </div>
        </div>

        <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-warning/10 flex items-center justify-center text-warning group-hover:scale-110 transition-transform duration-300">
              <LuClock className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Pending Approval</div>
              <div className="text-2xl font-black text-default-900 leading-none">{stats.pending}</div>
            </div>
          </div>
        </div>

        <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-success/10 flex items-center justify-center text-success group-hover:scale-110 transition-transform duration-300">
              <LuCheck className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Approved Leaves</div>
              <div className="text-2xl font-black text-default-900 leading-none">{stats.approved}</div>
            </div>
          </div>
        </div>

        <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-danger/10 flex items-center justify-center text-danger group-hover:scale-110 transition-transform duration-300">
              <LuX className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Rejected Leaves</div>
              <div className="text-2xl font-black text-default-900 leading-none">{stats.rejected}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="card">
        <div className="p-6">
          <div className="flex flex-wrap items-center gap-4 justify-between">
            <div className="flex flex-wrap items-center gap-4">
              <div className="relative">
                <input
                  type="text"
                  className="form-input rounded-xl h-11 ps-10 w-64 border-default-200 focus:border-primary focus:ring-primary/20"
                  placeholder="Search by reason..."
                  value={searchTerm}
                  onChange={handleSearch}
                  disabled={loading}
                />
                <div className="absolute inset-y-0 start-0 flex items-center ps-3.5">
                  <LuSearch className="size-4 text-default-500" />
                </div>
              </div>

              <select
                className="form-input rounded-xl h-11 border-default-200 focus:border-primary focus:ring-primary/20 min-w-[150px]"
                value={statusFilter}
                onChange={handleStatusFilterChange}
                disabled={loading}
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>

            <Link
              to="/apply-leave"
              className="btn h-11 rounded-xl bg-primary text-white flex items-center px-6 hover:bg-primary-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={loading}
            >
              <LuPlus className="size-5 me-2" /> Apply Leave
            </Link>
          </div>
        </div>
      </div>

      {message && (
        <div className={`p-4 rounded-xl border text-sm font-bold ${
          message.toLowerCase().includes('fail') || message.toLowerCase().includes('error') || message.toLowerCase().includes('no ')
            ? 'bg-danger/10 text-danger border-danger/20'
            : 'bg-success/10 text-success border-success/20'
        }`}>
          {message}
        </div>
      )}

      {/* Table Card */}
      <div className="bg-white border border-default-200 rounded-[2rem] overflow-hidden shadow-sm">
        <div className="px-8 py-6 border-b border-default-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h4 className="text-xl font-black text-default-900 uppercase tracking-tight">Applied Leave List</h4>
            <p className="text-[10px] font-black text-default-400 uppercase tracking-widest mt-1">Track and manage your leave applications</p>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-default-500 bg-default-50 px-4 py-2 rounded-xl border border-default-200">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            Showing {pagination.total} Applications
          </div>
        </div>

        <div className="overflow-x-auto custom-scroll">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-default-50/50">
                <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Leave Type</th>
                <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">From Date</th>
                <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">To Date</th>
                <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Days</th>
                <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Reason</th>
                <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Status</th>
                <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Applied On</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-default-100">
              {loading ? (
                <tr>
                  <td colSpan="7" className="px-6 py-12 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <div className="size-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                      <span className="text-sm font-bold text-default-400 uppercase tracking-widest">Loading applications...</span>
                    </div>
                  </td>
                </tr>
              ) : leaveData.applications.length === 0 ? (
                <tr>
                  <td colSpan="7" className="px-6 py-12 text-center">
                    <div className="flex flex-col items-center gap-3 opacity-20">
                      <LuCalendar className="size-16" />
                      <span className="text-sm font-bold uppercase tracking-widest">No leave applications found</span>
                    </div>
                  </td>
                </tr>
              ) : (
                leaveData.applications.map((app) => (
                  <tr key={app._id} className="hover:bg-default-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <span className="text-sm font-bold text-default-900 group-hover:text-primary transition-colors">{app.leaveName}</span>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-default-600">{formatDate(app.fromDate)}</td>
                    <td className="px-6 py-4 text-sm font-medium text-default-600">{formatDate(app.toDate)}</td>
                    <td className="px-6 py-4">
                      <span className="px-2.5 py-1 rounded-lg bg-default-100 text-[10px] font-black text-default-700 uppercase tracking-wider border border-default-200">
                        {app.numberOfDays || app.totalDays} {(app.numberOfDays || app.totalDays) === 1 ? 'Day' : 'Days'}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-default-600 line-clamp-1 max-w-[200px]" title={app.reason}>{app.reason}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-2xl text-[10px] font-black uppercase tracking-widest border ${getStatusBadgeClass(app.status)}`}>
                        {app.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm font-medium text-default-600">{formatDate(app.createdAt)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="px-8 py-6 border-t border-default-200 flex items-center justify-between bg-default-50/30">
            <p className="text-[10px] font-black text-default-400 uppercase tracking-widest">
              Page {pagination.page} of {pagination.totalPages}
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrevious}
                disabled={pagination.page === 1 || loading}
                className="size-10 flex items-center justify-center rounded-xl border border-default-200 bg-white text-default-600 hover:bg-primary hover:text-white hover:border-primary disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                <LuChevronLeft className="size-5" />
              </button>
              <div className="flex items-center gap-1">
                {[...Array(pagination.totalPages)].map((_, i) => (
                  <button
                    key={i + 1}
                    type="button"
                    onClick={() => handlePageChange(i + 1)}
                    className={`size-10 rounded-xl text-xs font-bold transition-all ${pagination.page === i + 1
                        ? 'bg-primary text-white shadow-lg shadow-primary/25'
                        : 'bg-white border border-default-200 text-default-600 hover:bg-default-50'
                      }`}
                  >
                    {i + 1}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={handleNext}
                disabled={pagination.page === pagination.totalPages || loading}
                className="size-10 flex items-center justify-center rounded-xl border border-default-200 bg-white text-default-600 hover:bg-primary hover:text-white hover:border-primary disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                <LuChevronRight className="size-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AppliedLeave;
