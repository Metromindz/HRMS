import { Link } from 'react-router';
import { useState, useEffect, useMemo } from 'react';
import { LuSearch, LuCalendar, LuTrendingUp, LuDollarSign, LuUsers } from 'react-icons/lu';
import api from '../../../../../../config/api.js';

const PayslipDetails = () => {
  const [payslips, setPayslips] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [selectedMonth, setSelectedMonth] = useState(
    new Date().toLocaleString('default', { month: 'long' })
  );
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [searchTerm, setSearchTerm] = useState('');

  // Calculate stats for the individual employee's history
  const stats = useMemo(() => {
    const totalNetPay = payslips.reduce((acc, curr) => acc + (curr.netPay || 0), 0);
    const avgNetPay = payslips.length > 0 ? totalNetPay / payslips.length : 0;
    const latestNetPay = payslips.length > 0 ? payslips[0].netPay : 0;

    return [
      {
        label: 'Latest Net Pay',
        value: `$${latestNetPay.toLocaleString('en-IN')}`,
        icon: LuDollarSign,
        color: 'primary',
        trend: 'Most recent payslip'
      },
      {
        label: 'Total Received',
        value: `$${totalNetPay.toLocaleString('en-IN')}`,
        icon: LuTrendingUp,
        color: 'success',
        trend: 'Lifetime earnings'
      },
      {
        label: 'Avg. Monthly',
        value: `$${Math.round(avgNetPay).toLocaleString('en-IN')}`,
        icon: LuUsers,
        color: 'warning',
        trend: 'Based on records'
      },
      {
        label: 'Total Payslips',
        value: payslips.length,
        icon: LuCalendar,
        color: 'info',
        trend: 'History count'
      }
    ];
  }, [payslips]);

  const fetchPayslips = async () => {
    try {
      setLoading(true);
      setError('');

      const params = new URLSearchParams();
      if (searchTerm.trim()) params.append('search', searchTerm.trim());
      if (selectedMonth && selectedMonth !== 'All Months') params.append('month', selectedMonth);
      if (selectedYear) params.append('year', selectedYear.toString());

      const response = await api.get(`/payslip/byEmp?${params.toString()}`);
      
      if (response.data.success) {
        setPayslips(response.data.data || []);
      } else {
        setError(response.data.message || 'Failed to fetch payslips');
        setPayslips([]);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch payslip records');
      setPayslips([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPayslips();
  }, [searchTerm, selectedMonth, selectedYear]);

  const formatCurrency = amount => {
    return `$${amount.toLocaleString('en-IN')}`;
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="group bg-white rounded-[2rem] p-6 border border-default-200 transition-all duration-300 hover:shadow-lg hover:shadow-default-100 hover:border-primary/20">
            <div className="flex flex-col gap-4">
              <div className={`size-12 rounded-2xl bg-${stat.color}/10 flex items-center justify-center text-${stat.color} group-hover:scale-110 transition-transform duration-500`}>
                <stat.icon className="size-6" />
              </div>
              <div>
                <div className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] mb-1">{stat.label}</div>
                <div className="text-2xl font-black text-default-900 leading-none tracking-tight">{stat.value}</div>
                <div className="text-[9px] font-black text-default-400 uppercase tracking-widest mt-2 flex items-center gap-1.5">
                  <span className="w-1 h-1 rounded-full bg-default-300" />
                  {stat.trend}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white border border-default-200 rounded-[2rem] overflow-hidden shadow-sm">
        {/* Header and Filters */}
        <div className="p-8 border-b border-default-200 bg-white flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex flex-col gap-1">
            <h4 className="text-xl font-black text-default-900 uppercase tracking-tight">Salary History</h4>
            <p className="text-[10px] font-black text-default-400 uppercase tracking-widest mt-1">Your monthly payslips and earning records</p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative group min-w-[240px]">
              <input
                type="text"
                className="w-full bg-default-50 border-default-200 rounded-2xl ps-12 pe-4 py-3 text-sm font-bold focus:border-primary transition-all group-hover:border-default-300 border-2 focus:ring-0"
                placeholder="Search history..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <div className="absolute inset-y-0 start-0 flex items-center ps-5 text-default-400 group-hover:text-primary transition-colors">
                <LuSearch className="size-4" />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <select
                className="appearance-none bg-default-50 border-default-200 rounded-2xl px-5 py-3 pe-12 text-[10px] font-black uppercase tracking-widest focus:border-primary transition-all group-hover:border-default-300 border-2 focus:ring-0 cursor-pointer min-w-[150px]"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
              >
                <option value="All Months">ALL MONTHS</option>
                {Array.from({ length: 12 }, (_, i) => {
                  const monthName = new Date(0, i).toLocaleString('default', { month: 'long' });
                  return (
                    <option key={monthName} value={monthName}>{monthName.toUpperCase()}</option>
                  );
                })}
              </select>

              <select
                className="appearance-none bg-default-50 border-default-200 rounded-2xl px-5 py-3 pe-12 text-[10px] font-black uppercase tracking-widest focus:border-primary transition-all group-hover:border-default-300 border-2 focus:ring-0 cursor-pointer min-w-[120px]"
                value={selectedYear}
                onChange={(e) => setSelectedYear(Number(e.target.value))}
              >
                {Array.from({ length: 5 }, (_, i) => {
                  const year = new Date().getFullYear() - 2 + i;
                  return (
                    <option key={year} value={year}>{year}</option>
                  );
                })}
              </select>
            </div>
          </div>
        </div>

        {/* Table Section */}
        <div className="overflow-x-auto custom-scroll">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-default-50/50">
                <th className="px-8 py-5 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">ID</th>
                <th className="px-8 py-5 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Employee</th>
                <th className="px-8 py-5 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Period</th>
                <th className="px-8 py-5 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Gross</th>
                <th className="px-8 py-5 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Net Pay</th>
                <th className="px-8 py-5 text-right text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-default-100">
              {loading ? (
                <tr>
                  <td colSpan="6" className="py-24 text-center">
                    <div className="flex flex-col items-center gap-4">
                      <div className="size-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Fetching records...</span>
                    </div>
                  </td>
                </tr>
              ) : payslips.length > 0 ? (
                payslips.map(payslip => (
                  <tr key={payslip._id} className="hover:bg-default-50/50 transition-colors group">
                    <td className="px-8 py-5">
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">{payslip.employeeId}</span>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-4">
                        <div className="size-10 rounded-2xl bg-primary/10 flex items-center justify-center text-primary border border-primary/20 group-hover:scale-110 transition-all">
                          <span className="text-xs font-black uppercase">{payslip.employeeName.charAt(0)}</span>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-sm font-bold text-default-900 leading-tight group-hover:text-primary transition-colors">{payslip.employeeName}</span>
                          <span className="text-[9px] font-black text-default-400 uppercase tracking-widest mt-0.5">{payslip.designation}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <div className="inline-flex px-3 py-1.5 rounded-xl bg-default-100 border border-default-200 text-[10px] font-black text-default-600 uppercase tracking-widest">
                        {payslip.payrollMonth} {payslip.payrollYear}
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className="text-sm font-bold text-default-900">{formatCurrency(payslip.totalEarnings)}</span>
                    </td>
                    <td className="px-8 py-5">
                      <span className="text-sm font-black text-primary">{formatCurrency(payslip.netPay)}</span>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <Link
                        to={`/payroll-payslip/${payslip.employeeId}/${payslip.payrollMonth}`}
                        className="h-10 px-6 inline-flex items-center justify-center rounded-2xl bg-primary text-white text-[10px] font-black uppercase tracking-widest hover:bg-primary-600 shadow-lg shadow-primary/20 transition-all active:scale-95"
                      >
                        Download
                      </Link>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="py-24 text-center opacity-30">
                    <div className="flex flex-col items-center">
                      <div className="size-20 bg-default-50 rounded-[2rem] flex items-center justify-center text-default-400 mb-6">
                        <LuCalendar className="size-10" />
                      </div>
                      <h3 className="text-base font-black text-default-900 uppercase tracking-tight mb-1">No Records</h3>
                      <p className="text-[10px] font-black text-default-400 uppercase tracking-widest">No history available</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {error && (
          <div className="mx-8 my-6 p-5 rounded-2xl bg-danger/5 border border-danger/20 text-danger text-[10px] font-black uppercase tracking-widest flex items-center gap-4 animate-in fade-in slide-in-from-top-2">
            <div className="size-10 rounded-xl bg-danger/10 flex items-center justify-center shrink-0">
              <LuTrendingUp className="size-5 rotate-180" />
            </div>
            {error}
          </div>
        )}
      </div>
    </div>
  );
};

export default PayslipDetails;
