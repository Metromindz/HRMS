import PageBreadcrumb from '@/components/PageBreadcrumb';
import PayslipDetails from './components/PayslipDetails';
import PageMeta from '@/components/PageMeta';

const Index = () => {
  return <>
      <PageMeta title="Employee Salary" />
      <main>
        <PageBreadcrumb title="Employees Salary List" subtitle="Menu" />
        {/* <EmployeeTotalSalary /> */}
        <PayslipDetails />
      </main>
    </>;
};
export default Index;