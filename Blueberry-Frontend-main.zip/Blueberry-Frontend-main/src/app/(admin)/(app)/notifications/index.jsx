import { useState, useEffect, useCallback } from 'react';
import {
    LuBell, LuCheckCheck, LuClock, LuFilter, LuSearch,
    LuUser, LuCalendarDays, LuFileText, LuBriefcase,
    LuMegaphone, LuTrendingUp, LuListChecks, LuUsers,
    LuBellOff, LuChevronLeft, LuChevronRight, LuShieldCheck,
    LuRefreshCw, LuLayoutList, LuLayoutGrid
} from 'react-icons/lu';
import { useAuth } from '@/context/AuthContext';
import { useNotifications } from '@/context/NotificationContext';
import api from '@/config/api';
import PageMeta from '@/components/PageMeta';
import PageBreadcrumb from '@/components/PageBreadcrumb';

// Icon and colour mapping per notification type
const TYPE_META = {
    employee_updated: { icon: LuUser, color: 'text-primary', bg: 'bg-primary/10', label: 'Employee' },
    employee_status_update: { icon: LuUsers, color: 'text-warning', bg: 'bg-warning/10', label: 'Status' },
    leave_status: { icon: LuCalendarDays, color: 'text-success', bg: 'bg-success/10', label: 'Leave' },
    payslip_generation: { icon: LuFileText, color: 'text-info', bg: 'bg-info/10', label: 'Payslip' },
    task: { icon: LuListChecks, color: 'text-purple-500', bg: 'bg-purple-50', label: 'Task' },
    lead: { icon: LuTrendingUp, color: 'text-orange-500', bg: 'bg-orange-50', label: 'Lead' },
    project: { icon: LuBriefcase, color: 'text-cyan-500', bg: 'bg-cyan-50', label: 'Project' },
    announcement: { icon: LuMegaphone, color: 'text-pink-500', bg: 'bg-pink-50', label: 'Announcement' },
    general: { icon: LuBell, color: 'text-default-500', bg: 'bg-default-100', label: 'General' },
};

const getTypeMeta = (type) => TYPE_META[type] || TYPE_META.general;

const FILTER_TABS = [
    { key: 'all', label: 'All' },
    { key: 'unread', label: 'Unread' },
    { key: 'read', label: 'Read' },
];

const TYPE_OPTIONS = [
    { value: 'all', label: 'All Types' },
    { value: 'employee_updated', label: 'Employee' },
    { value: 'leave_status', label: 'Leave' },
    { value: 'payslip_generation', label: 'Payslip' },
    { value: 'task', label: 'Task' },
    { value: 'lead', label: 'Lead' },
    { value: 'project', label: 'Project' },
    { value: 'announcement', label: 'Announcement' },
    { value: 'general', label: 'General' },
];

const timeAgo = (dateStr) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    if (days < 7) return `${days}d ago`;
    return new Date(dateStr).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
};

const LIMIT = 20;

const AllNotifications = () => {
    const { user } = useAuth();
    const { markAsRead: ctxMarkAsRead, fetchNotifications } = useNotifications();

    const [notifications, setNotifications] = useState([]);
    const [pagination, setPagination] = useState({ total: 0, pages: 1, page: 1 });
    const [loading, setLoading] = useState(false);
    const [search, setSearch] = useState('');
    const [filter, setFilter] = useState('all');   // all | unread | read
    const [type, setType] = useState('all');
    const [page, setPage] = useState(1);
    const [markingAll, setMarkingAll] = useState(false);
    const [viewMode, setViewMode] = useState('grid');

    const isRead = (n) => n.isRead?.some(r => String(r.userId) === String(user?._id));

    const fetchAll = useCallback(async () => {
        try {
            setLoading(true);
            const params = new URLSearchParams({ page, limit: LIMIT, filter });
            if (type !== 'all') params.append('type', type);
            const res = await api.get(`/notifications/all?${params}`);
            setNotifications(res.data.notifications || []);
            setPagination(res.data.pagination || { total: 0, pages: 1, page: 1 });
        } catch {
            setNotifications([]);
        } finally {
            setLoading(false);
        }
    }, [page, filter, type]);

    useEffect(() => { fetchAll(); }, [fetchAll]);

    // Client-side search filter
    const visible = search.trim()
        ? notifications.filter(n =>
            n.title.toLowerCase().includes(search.toLowerCase()) ||
            n.message.toLowerCase().includes(search.toLowerCase())
        )
        : notifications;

    const handleMarkOne = async (id) => {
        await ctxMarkAsRead(id);
        setNotifications(prev => prev.map(n =>
            n._id === id
                ? { ...n, isRead: [...(n.isRead || []), { userId: user._id }] }
                : n
        ));
    };

    const handleMarkAll = async () => {
        try {
            setMarkingAll(true);
            await api.patch('/notifications/read-all');
            setNotifications(prev =>
                prev.map(n => ({
                    ...n,
                    isRead: isRead(n) ? n.isRead : [...(n.isRead || []), { userId: user._id }]
                }))
            );
            fetchNotifications(); // refresh context / badge
        } catch {
            /* silent */
        } finally {
            setMarkingAll(false);
        }
    };

    const unreadCount = notifications.filter(n => !isRead(n)).length;

    return (
        <>
            <PageMeta title="Notifications" />
            <main>
                <PageBreadcrumb title="All Notifications" subtitle="Menu" />

                {/* ── Summary Stats ── */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                    {[
                        { label: 'Total', value: pagination.total, color: 'text-primary', bg: 'bg-primary/10', icon: LuBell },
                        { label: 'Unread', value: unreadCount, color: 'text-danger', bg: 'bg-danger/10', icon: LuBellOff },
                        { label: 'Read', value: pagination.total - unreadCount, color: 'text-success', bg: 'bg-success/10', icon: LuShieldCheck },
                        { label: 'Types', value: Object.keys(TYPE_META).length - 1, color: 'text-warning', bg: 'bg-warning/10', icon: LuFilter },
                    ].map((s, i) => (
                        <div key={i} className="bg-white border border-default-200 rounded-2xl p-4 flex items-center gap-4">
                            <div className={`size-11 rounded-xl ${s.bg} ${s.color} flex items-center justify-center shrink-0`}>
                                <s.icon className="size-5" />
                            </div>
                            <div>
                                <div className="text-[10px] font-black text-default-400 uppercase tracking-widest">{s.label}</div>
                                <div className="text-xl font-black text-default-900 leading-none">{s.value}</div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* ── Main Card ── */}
                <div className="bg-white border border-default-200 rounded-2xl shadow-sm overflow-hidden">

                    {/* Header */}
                    <div className="p-5 border-b border-default-200 bg-default-50/50">
                        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                            <div>
                                <h4 className="text-xl font-black text-default-900 uppercase tracking-tight flex items-center gap-2">
                                    <LuBell className="text-primary size-5" /> Notifications
                                </h4>
                                <p className="text-xs font-bold text-default-500 uppercase tracking-widest mt-0.5">
                                    {pagination.total} total · {unreadCount} unread
                                </p>
                            </div>

                            <div className="flex flex-wrap items-center gap-3">
                                {/* Search */}
                                <div className="relative group">
                                    <input
                                        type="text"
                                        placeholder="Search notifications…"
                                        value={search}
                                        onChange={e => setSearch(e.target.value)}
                                        className="w-full min-w-[220px] bg-white border-default-200 rounded-xl ps-10 pe-4 py-2.5 text-sm font-bold focus:border-primary focus:ring-primary transition-all shadow-sm"
                                    />
                                    <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-default-400 group-focus-within:text-primary transition-colors" />
                                </div>

                                {/* Type filter */}
                                <select
                                    value={type}
                                    onChange={e => { setType(e.target.value); setPage(1); }}
                                    className="appearance-none bg-white border-default-200 rounded-xl px-4 py-2.5 text-sm font-bold focus:border-primary transition-all shadow-sm cursor-pointer"
                                >
                                    {TYPE_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                                </select>

                                {/* View Mode Toggle */}
                                <div className="flex items-center gap-1 p-1 bg-default-100/80 rounded-xl border border-default-200">
                                    <button
                                        onClick={() => setViewMode('list')}
                                        className={`size-8 flex items-center justify-center rounded-lg transition-all ${viewMode === 'list' ? 'bg-white shadow-sm text-primary font-bold' : 'text-default-500 hover:text-default-700 hover:bg-default-200'}`}
                                        title="List View"
                                    >
                                        <LuLayoutList className="size-4" />
                                    </button>
                                    <button
                                        onClick={() => setViewMode('grid')}
                                        className={`size-8 flex items-center justify-center rounded-lg transition-all ${viewMode === 'grid' ? 'bg-white shadow-sm text-primary font-bold' : 'text-default-500 hover:text-default-700 hover:bg-default-200'}`}
                                        title="Grid View"
                                    >
                                        <LuLayoutGrid className="size-4" />
                                    </button>
                                </div>

                                {/* Mark all read */}
                                {unreadCount > 0 && (
                                    <button
                                        onClick={handleMarkAll}
                                        disabled={markingAll}
                                        className="h-10 px-4 inline-flex items-center gap-2 rounded-xl bg-primary/10 text-primary border border-primary/20 font-black text-[10px] uppercase tracking-widest hover:bg-primary hover:text-white transition-all active:scale-95 disabled:opacity-50"
                                    >
                                        {markingAll
                                            ? <LuRefreshCw className="size-3.5 animate-spin" />
                                            : <LuCheckCheck className="size-3.5" />}
                                        Mark All Read
                                    </button>
                                )}
                            </div>
                        </div>

                        {/* Filter tabs */}
                        <div className="flex gap-1 mt-4">
                            {FILTER_TABS.map(tab => (
                                <button
                                    key={tab.key}
                                    onClick={() => { setFilter(tab.key); setPage(1); }}
                                    className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${filter === tab.key
                                        ? 'bg-primary text-white shadow-sm shadow-primary/20'
                                        : 'bg-default-100 text-default-500 hover:bg-default-200'
                                        }`}
                                >
                                    {tab.label}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Notification List */}
                    <div className={viewMode === 'list' ? "divide-y divide-default-100" : "grid grid-cols-1 md:grid-cols-2 2xl:grid-cols-3 gap-4 p-5 bg-default-50/30"}>
                        {loading ? (
                            Array.from({ length: 9 }).map((_, i) => (
                                <div key={i} className={`p-5 flex gap-4 animate-pulse ${viewMode === 'grid' ? 'bg-white rounded-2xl border border-default-200 shadow-sm' : ''}`}>
                                    <div className="size-11 rounded-xl bg-default-100 shrink-0" />
                                    <div className="flex-1 space-y-2 pt-1">
                                        <div className="h-3.5 bg-default-100 rounded w-1/3" />
                                        <div className="h-3 bg-default-100 rounded w-2/3" />
                                        <div className="h-2.5 bg-default-100 rounded w-1/4" />
                                    </div>
                                </div>
                            ))
                        ) : visible.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-24 gap-4">
                                <div className="size-16 bg-default-50 rounded-2xl flex items-center justify-center">
                                    <LuBellOff className="size-8 text-default-300" />
                                </div>
                                <div className="text-center">
                                    <p className="text-base font-bold text-default-900">No Notifications Found</p>
                                    <p className="text-sm text-default-500 mt-1">
                                        {search ? 'No results for your search.' : 'Nothing here yet.'}
                                    </p>
                                </div>
                            </div>
                        ) : (
                            visible.map(notif => {
                                const meta = getTypeMeta(notif.type);
                                const read = isRead(notif);
                                const Icon = meta.icon;

                                if (viewMode === 'list') {
                                    return (
                                        <div
                                            key={notif._id}
                                            className={`group flex items-start gap-4 p-5 transition-colors hover:bg-default-50/60 ${!read ? 'bg-primary/[0.03]' : ''}`}
                                        >
                                            {/* Unread dot */}
                                            <div className={`mt-1.5 shrink-0 size-2 rounded-full transition-colors ${!read ? 'bg-primary' : 'bg-transparent'}`} />

                                            {/* Icon */}
                                            <div className={`size-11 rounded-xl ${meta.bg} ${meta.color} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                                                <Icon className="size-5" />
                                            </div>

                                            {/* Content */}
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-start justify-between gap-3 mb-1">
                                                    <div className="flex items-center gap-2 flex-wrap">
                                                        <h5 className={`text-sm leading-snug ${!read ? 'font-black text-default-900' : 'font-semibold text-default-700'}`}>
                                                            {notif.title}
                                                        </h5>
                                                        <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-widest ${meta.bg} ${meta.color}`}>
                                                            {meta.label}
                                                        </span>
                                                        {!read && (
                                                            <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-widest bg-primary/10 text-primary">
                                                                New
                                                            </span>
                                                        )}
                                                    </div>
                                                    {!read && (
                                                        <button
                                                            onClick={() => handleMarkOne(notif._id)}
                                                            className="shrink-0 size-7 flex items-center justify-center rounded-lg bg-default-100 text-default-400 hover:bg-primary/10 hover:text-primary transition-all active:scale-90"
                                                            title="Mark as read"
                                                        >
                                                            <LuCheckCheck className="size-3.5" />
                                                        </button>
                                                    )}
                                                </div>

                                                <p className="text-[13px] text-default-600 leading-relaxed mb-2">{notif.message}</p>

                                                <div className="flex flex-wrap items-center gap-3 text-[10px] font-bold text-default-400 uppercase tracking-wider">
                                                    <span className="flex items-center gap-1">
                                                        <LuClock className="size-3" />
                                                        {timeAgo(notif.createdAt)}
                                                    </span>
                                                    <span className="text-default-200">·</span>
                                                    <span className="text-[10px]">
                                                        {new Date(notif.createdAt).toLocaleString('en-IN', {
                                                            day: 'numeric', month: 'short', year: 'numeric',
                                                            hour: '2-digit', minute: '2-digit'
                                                        })}
                                                    </span>
                                                    {notif.createdBy?.name && (
                                                        <>
                                                            <span className="text-default-200">·</span>
                                                            <span>By {notif.createdBy.name}</span>
                                                        </>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    );
                                }

                                return (
                                    <div
                                        key={notif._id}
                                        className={`group relative flex flex-col gap-4 p-5 bg-white rounded-2xl border transition-all hover:-translate-y-0.5 ${!read ? 'border-primary/40 shadow-lg shadow-primary/5' : 'border-default-200 hover:border-default-300 hover:shadow-md'}`}
                                    >
                                        {!read && (
                                            <div className="absolute top-5 right-5 size-2.5 rounded-full bg-primary animate-pulse shadow-[0_0_8px_rgba(var(--color-primary),0.6)]" />
                                        )}

                                        <div className="flex items-center gap-3">
                                            <div className={`size-11 rounded-xl ${meta.bg} ${meta.color} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                                                <Icon className="size-5" />
                                            </div>
                                            <div className="flex-1 min-w-0 pr-6">
                                                <div className="flex items-center gap-2 flex-wrap mb-1">
                                                    <span className={`inline-flex items-center px-1.5 py-0.5 rounded-[5px] text-[9px] font-black uppercase tracking-widest ${meta.bg} ${meta.color}`}>
                                                        {meta.label}
                                                    </span>
                                                    {!read && (
                                                        <span className="inline-flex items-center px-1.5 py-0.5 rounded-[5px] text-[9px] font-black uppercase tracking-widest bg-primary/10 text-primary">
                                                            New
                                                        </span>
                                                    )}
                                                </div>
                                                <h5 className={`text-[14px] leading-snug truncate ${!read ? 'font-black text-default-900' : 'font-bold text-default-700'}`} title={notif.title}>
                                                    {notif.title}
                                                </h5>
                                            </div>
                                        </div>

                                        <div className="flex-1 text-left">
                                            <p className="text-[13px] text-default-600 leading-relaxed line-clamp-3" title={notif.message}>
                                                {notif.message}
                                            </p>
                                        </div>

                                        <div className="mt-auto pt-4 border-t border-default-100 flex flex-wrap items-center justify-between gap-3">
                                            <div className="flex items-center gap-1.5 text-[10px] font-black text-default-400 uppercase tracking-widest">
                                                <LuClock className="size-3.5 text-default-300" />
                                                {timeAgo(notif.createdAt)}

                                                {notif.createdBy?.name && (
                                                    <span className="text-[9px] text-default-300 flex items-center gap-1">
                                                        <span className="text-default-200 block mt-[-1px]">·</span>
                                                        {notif.createdBy.name.split(' ')[0]}
                                                    </span>
                                                )}
                                            </div>

                                            {!read && (
                                                <button
                                                    onClick={() => handleMarkOne(notif._id)}
                                                    className="size-7 flex items-center justify-center rounded-lg bg-default-100 text-default-400 hover:bg-primary/10 hover:text-primary transition-all active:scale-90"
                                                    title="Mark as read"
                                                >
                                                    <LuCheckCheck className="size-3.5" />
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                );
                            })
                        )}
                    </div>

                    {/* Pagination */}
                    {pagination.pages > 1 && (
                        <div className="p-4 border-t border-default-200 bg-default-50/50 flex items-center justify-between">
                            <span className="text-[11px] font-bold text-default-400 uppercase tracking-widest">
                                Page {pagination.page} of {pagination.pages} · {pagination.total} total
                            </span>
                            <div className="flex items-center gap-2">
                                <button
                                    onClick={() => setPage(p => Math.max(1, p - 1))}
                                    disabled={page <= 1}
                                    className="size-9 flex items-center justify-center rounded-xl border border-default-200 bg-white text-default-500 hover:border-primary hover:text-primary disabled:opacity-40 transition-all active:scale-95"
                                >
                                    <LuChevronLeft className="size-4" />
                                </button>

                                {Array.from({ length: Math.min(pagination.pages, 5) }, (_, i) => {
                                    const p = i + 1;
                                    return (
                                        <button
                                            key={p}
                                            onClick={() => setPage(p)}
                                            className={`size-9 flex items-center justify-center rounded-xl border font-black text-xs transition-all active:scale-95 ${page === p
                                                ? 'bg-primary border-primary text-white shadow-sm shadow-primary/20'
                                                : 'border-default-200 bg-white text-default-600 hover:border-primary hover:text-primary'
                                                }`}
                                        >
                                            {p}
                                        </button>
                                    );
                                })}

                                <button
                                    onClick={() => setPage(p => Math.min(pagination.pages, p + 1))}
                                    disabled={page >= pagination.pages}
                                    className="size-9 flex items-center justify-center rounded-xl border border-default-200 bg-white text-default-500 hover:border-primary hover:text-primary disabled:opacity-40 transition-all active:scale-95"
                                >
                                    <LuChevronRight className="size-4" />
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </main>
        </>
    );
};

export default AllNotifications;
