import { useEffect, useMemo, useState } from 'react';
import { toast } from 'react-hot-toast';
import { Link } from 'react-router-dom';
import PageMeta from '@/components/PageMeta';
import PageBreadcrumb from '@/components/PageBreadcrumb';
import api from '@/config/api';
import { useAuth } from '@/context/AuthContext';
import { LuDownload, LuPencil, LuPlus, LuSearch, LuTrash2, LuEye, LuArrowRight, LuBuilding, LuFolderOpen, LuWallet, LuList, LuLayoutGrid } from 'react-icons/lu';

const debounce = (fn, delay = 400) => {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), delay);
  };
};

const Index = () => {
  const { hasPermission } = useAuth();
  const canView = hasPermission('company.view');
  const canCreate = hasPermission('company.create');
  const canEdit = hasPermission('company.edit');
  const canDelete = hasPermission('company.delete');
  const canViewProjects = hasPermission('project.view');
  const canExport = hasPermission('company.export');

  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [viewMode, setViewMode] = useState('list');
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState(null);
  const [companyProjects, setCompanyProjects] = useState([]);
  const [cpTotal, setCpTotal] = useState(0);
  const [cpPage, setCpPage] = useState(1);
  const [cpLimit] = useState(10);
  const [cpLoading, setCpLoading] = useState(false);

  const fetchCompanies = async (params = {}) => {
    setLoading(true);
    try {
      const resp = await api.get('/company', {
        params: { page, limit, search, ...params },
      });
      if (resp.data.success) {
        setItems(resp.data.items);
        setTotal(resp.data.total);
        setTotalRevenue(
          typeof resp.data.totalRevenue === 'number'
            ? resp.data.totalRevenue
            : (resp.data.items || []).reduce((sum, c) => sum + (c.totalCost || 0), 0)
        );
      }
    } finally {
      setLoading(false);
    }
  };

  const debouncedSearch = useMemo(() => debounce((val) => {
    setPage(1);
    fetchCompanies({ search: val });
  }, 500), [page, limit]);

  const stats = useMemo(() => {
    const totalCompanies = total;
    const withProjects = items.filter(i => (i.projectCount || 0) > 0).length;
    return { totalCompanies, withProjects };
  }, [items, total]);

  useEffect(() => {
    if (canView) fetchCompanies();
  }, [page, limit, canView]);



  const exportData = async (format) => {
    const resp = await api.get('/company/export', {
      params: { format, search },
      responseType: 'blob',
    });
    const url = URL.createObjectURL(resp.data);
    const a = document.createElement('a');
    a.href = url;
    a.download = format === 'xlsx' ? 'companies.xlsx' : 'companies.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const [updatingStatus, setUpdatingStatus] = useState(null);
  const [fieldErrors, setFieldErrors] = useState({});

  const clearFieldError = (field) => {
    if (!fieldErrors[field]) return;
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };

  const handleStatusUpdate = async (projectId, newStatus) => {
    try {
      setUpdatingStatus(projectId);
      await api.patch(`/projects/${projectId}/status`, { status: newStatus });
      setCompanyProjects((prev) =>
        prev.map((p) => (p._id === projectId ? { ...p, status: newStatus } : p))
      );
      toast.success('Project status updated');
    } catch (error) {
      console.error(error);
      toast.error('Failed to update status');
    } finally {
      setUpdatingStatus(null);
    }
  };

  const onSubmitCompany = async (e) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);

    // Trim string values in FormData
    for (const [key, value] of Array.from(form.entries())) {
      if (typeof value === 'string') {
        form.set(key, value.trim());
      }
    }

    const payload = {
      name: form.get('name'),
      companyType: form.get('companyType'),
      industry: form.get('industry'),
      email: form.get('email'),
      phone: form.get('phone'),
      alternatePhone: form.get('alternatePhone'),
      website: form.get('website'),
      addressLine1: form.get('addressLine1'),
      addressLine2: form.get('addressLine2'),
      city: form.get('city'),
      state: form.get('state'),
      country: form.get('country'),
      pincode: form.get('pincode'),
      gstNumber: form.get('gstNumber'),
      panNumber: form.get('panNumber'),
      contactPersonName: form.get('contactPersonName'),
      designation: form.get('designation'),
      contactPersonEmail: form.get('contactPersonEmail'),
      contactPersonPhone: form.get('contactPersonPhone'),
    };

    const errors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const normalizePhone = (v) => String(v || '').replace(/[^\d+]/g, '');
    const digitsOnly = (v) => String(v || '').replace(/\D/g, '');

    if (!payload.name) errors.name = 'Company name is required';
    else if (payload.name.length < 2) errors.name = 'Company name must be at least 2 characters';
    else if (payload.name.length > 120) errors.name = 'Company name must be at most 120 characters';

    if (!payload.companyType) errors.companyType = 'Company type is required';
    else if (!['Company', 'Individual'].includes(payload.companyType)) errors.companyType = 'Invalid company type';

    if (!payload.email) errors.email = 'Company email is required';
    else if (!emailRegex.test(payload.email)) errors.email = 'Enter a valid company email';

    const phoneDigits = digitsOnly(payload.phone);
    if (!payload.phone) errors.phone = 'Company phone is required';
    else if (phoneDigits.length < 10 || phoneDigits.length > 15) errors.phone = 'Enter a valid company phone number';
    else payload.phone = normalizePhone(payload.phone);

    if (!payload.addressLine1) errors.addressLine1 = 'Address line 1 is required';
    if (!payload.city) errors.city = 'City is required';
    if (!payload.state) errors.state = 'State is required';
    if (!payload.country) errors.country = 'Country is required';

    const pinDigits = digitsOnly(payload.pincode);
    if (!payload.pincode) errors.pincode = 'Pincode is required';
    else if (pinDigits.length < 4 || pinDigits.length > 10) errors.pincode = 'Enter a valid pincode';

    if (!payload.contactPersonName) errors.contactPersonName = 'Contact person name is required';
    else if (payload.contactPersonName.length < 2) errors.contactPersonName = 'Contact person name must be at least 2 characters';

    if (!payload.contactPersonEmail) errors.contactPersonEmail = 'Contact person email is required';
    else if (!emailRegex.test(payload.contactPersonEmail)) errors.contactPersonEmail = 'Enter a valid contact person email';

    const cpPhoneDigits = digitsOnly(payload.contactPersonPhone);
    if (!payload.contactPersonPhone) errors.contactPersonPhone = 'Contact person phone is required';
    else if (cpPhoneDigits.length < 10 || cpPhoneDigits.length > 15) errors.contactPersonPhone = 'Enter a valid contact person phone number';
    else payload.contactPersonPhone = normalizePhone(payload.contactPersonPhone);

    if (payload.website) {
      const w = String(payload.website).trim();
      const looksLikeUrl = /^(https?:\/\/)?[^\s]+\.[^\s]{2,}.*$/i.test(w);
      if (!looksLikeUrl) errors.website = 'Enter a valid website URL';
    }

    setFieldErrors(errors);
    const firstError = Object.values(errors)[0];
    if (firstError) {
      toast.error(firstError);
      return;
    }

    try {
      if (editItem) {
        await api.put(`/company/${editItem._id}`, form);
        toast.success('Company updated successfully');
      } else {
        await api.post('/company', form);
        toast.success('Company created successfully');
      }
      setFieldErrors({});
      setModalOpen(false);
      setEditItem(null);
      fetchCompanies();
    } catch (error) {
      console.error(error);
      toast.error(error.response?.data?.message || 'Operation failed');
    }
  };

  const confirmDelete = async (id) => {
    if (!canDelete) return;
    if (window.confirm('Delete this company?')) {
      await api.delete(`/company/${id}`);
      fetchCompanies();
    }
  };

  const openCompanyDetails = async (company) => {
    setSelectedCompany(company);
    setDetailOpen(true);
    setCpPage(1);
    await loadCompanyProjects(company._id, 1);
  };

  const loadCompanyProjects = async (id, pageArg = cpPage) => {
    if (!canViewProjects) return;
    setCpLoading(true);
    try {
      const resp = await api.get(`/company/${id}/projects`, { params: { page: pageArg, limit: cpLimit } });
      if (resp.data.success) {
        setCompanyProjects(resp.data.items || []);
        setCpTotal(resp.data.total || 0);
      }
    } finally {
      setCpLoading(false);
    }
  };

  if (!canView) {
    return (
      <>
        <PageMeta title="Company Management" />
        <main>
          <PageBreadcrumb title="Company" subtitle="Company Management" />
          <div className="card">
            <div className="card-body">
              <p className="text-default-500">You do not have permission to view this page.</p>
            </div>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <PageMeta title="Company Management" />
      <main>
        <PageBreadcrumb title="Company" subtitle="Company Management" />

        <div className="grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-6 mb-8">
          <div className="bg-white border border-default-200 rounded-2xl overflow-hidden transition-all duration-300 group">
            <div className="p-6 flex items-center gap-4">
              <div className="size-14 rounded-xl bg-default-100 flex items-center justify-center group-hover:bg-primary/10 transition-colors duration-300">
                <LuBuilding className="size-7 text-default-600 group-hover:text-primary transition-colors duration-300" />
              </div>
              <div>
                <p className="text-[10px] font-black text-default-500 uppercase tracking-[0.2em] mb-1">Total Companies</p>
                <h3 className="text-2xl font-black text-default-900 leading-none">{stats.totalCompanies}</h3>
              </div>
            </div>
          </div>
          <div className="bg-white border border-default-200 rounded-2xl overflow-hidden transition-all duration-300 group">
            <div className="p-6 flex items-center gap-4">
              <div className="size-14 rounded-xl bg-blue-50 flex items-center justify-center group-hover:bg-blue-100 transition-colors duration-300">
                <LuFolderOpen className="size-7 text-blue-600" />
              </div>
              <div>
                <p className="text-[10px] font-black text-default-500 uppercase tracking-[0.2em] mb-1">With Projects</p>
                <h3 className="text-2xl font-black text-default-900 leading-none">{stats.withProjects}</h3>
              </div>
            </div>
          </div>
          <div className="bg-white border border-default-200 rounded-2xl overflow-hidden transition-all duration-300 group">
            <div className="p-6 flex items-center gap-4">
              <div className="size-14 rounded-xl bg-emerald-50 flex items-center justify-center group-hover:bg-emerald-100 transition-colors duration-300">
                <LuWallet className="size-7 text-emerald-600" />
              </div>
              <div>
                <p className="text-[10px] font-black text-default-500 uppercase tracking-[0.2em] mb-1">Total Revenue</p>
                <h3 className="text-2xl font-black text-default-900 leading-none">₹{Number(totalRevenue || 0).toLocaleString()}</h3>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white border border-default-200 rounded-2xl overflow-hidden mb-8">
          <div className="p-6 flex flex-wrap items-center justify-between gap-6">
            <div className="flex flex-wrap items-center gap-4 flex-1">
              <div className="relative flex-1 min-w-[300px] max-w-md group">
                <LuSearch className="absolute left-4 top-1/2 -translate-y-1/2 size-4 text-default-400 group-focus-within:text-primary transition-colors" />
                <input
                  type="text"
                  className="w-full bg-default-50 border-default-200 rounded-xl pl-11 h-12 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                  placeholder="SEARCH COMPANIES..."
                  onChange={(e) => {
                    setSearch(e.target.value);
                    debouncedSearch(e.target.value);
                  }}
                />
              </div>

              {canExport && (
                <div className="flex items-center bg-default-50 border border-default-200 rounded-xl p-1">
                  <button
                    type="button"
                    className="h-10 px-4 flex items-center gap-2 rounded-lg font-black text-[10px] uppercase tracking-widest text-default-600 hover:bg-white hover:text-primary transition-all"
                    onClick={() => exportData('csv')}
                  >
                    <LuDownload className="size-4" /> CSV
                  </button>
                  <div className="w-px h-4 bg-default-200 mx-1" />
                  <button
                    type="button"
                    className="h-10 px-4 flex items-center gap-2 rounded-lg font-black text-[10px] uppercase tracking-widest text-default-600 hover:bg-white hover:text-primary transition-all"
                    onClick={() => exportData('xlsx')}
                  >
                    <LuDownload className="size-4" /> EXCEL
                  </button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center bg-default-50 border border-default-200 rounded-xl p-1">
                <button
                  type="button"
                  className={`size-10 flex items-center justify-center rounded-lg transition-all ${viewMode === 'list' ? 'bg-white text-primary' : 'text-default-500 hover:text-default-900'}`}
                  onClick={() => setViewMode('list')}
                  title="List View"
                >
                  <LuList className="size-5" />
                </button>
                <button
                  type="button"
                  className={`size-10 flex items-center justify-center rounded-lg transition-all ${viewMode === 'grid' ? 'bg-white text-primary' : 'text-default-500 hover:text-default-900'}`}
                  onClick={() => setViewMode('grid')}
                  title="Grid View"
                >
                  <LuLayoutGrid className="size-5" />
                </button>
              </div>

              {canCreate && (
                <button
                  type="button"
                  className="h-12 px-6 flex items-center gap-2 bg-primary text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-primary-600 transition-all active:scale-95"
                  onClick={() => {
                    setEditItem(null);
                    setModalOpen(true);
                  }}
                >
                  <LuPlus className="size-5" /> Add Company
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="bg-white border border-default-200 rounded-2xl overflow-hidden">
          {viewMode === 'list' ? (
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="bg-default-50 border-b border-default-200">
                    <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-widest">Sl No</th>
                    <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-widest">Company ID</th>
                    <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-widest">Company Name</th>
                    <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-widest">Company Email</th>
                    <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-widest">Company Phone</th>
                    <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-widest">Projects</th>
                    <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-widest">Total Revenue</th>
                    <th className="py-4 px-6 text-right text-[10px] font-black text-default-500 uppercase tracking-widest">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td className="py-12 px-6 text-center" colSpan={8}>
                        <div className="flex flex-col items-center gap-2">
                          <div className="size-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                          <p className="text-xs font-bold text-default-400 uppercase tracking-widest">Loading Companies...</p>
                        </div>
                      </td>
                    </tr>
                  ) : items.length === 0 ? (
                    <tr>
                      <td className="py-12 px-6 text-center" colSpan={8}>
                        <p className="text-xs font-bold text-default-400 uppercase tracking-widest">No companies found</p>
                      </td>
                    </tr>
                  ) : (
                    items.map((c, idx) => (
                      <tr key={c._id} className="border-b border-default-100 hover:bg-default-50/50 transition-colors group">
                        <td className="py-4 px-6 text-sm font-bold text-default-600">{(page - 1) * limit + idx + 1}</td>
                        <td className="py-4 px-6 text-sm font-bold text-default-900">
                          <span className="bg-default-100 text-default-600 px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest">
                            {c.companyId}
                          </span>
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-3">
                            {c.logo ? (
                              <img
                                src={`${api.defaults.baseURL?.replace('/api', '')}/${c.logo}`}
                                alt={c.name}
                                className="size-8 rounded-lg object-contain bg-white border border-default-200"
                              />
                            ) : (
                              <div className="size-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center font-black text-xs">
                                {c.name.charAt(0).toUpperCase()}
                              </div>
                            )}
                            <span className="text-sm font-black text-default-900">{c.name}</span>
                          </div>
                        </td>
                        <td className="py-4 px-6 text-sm font-bold text-default-600">{c.email}</td>
                        <td className="py-4 px-6 text-sm font-bold text-default-600">{c.phone}</td>
                        <td className="py-4 px-6 text-sm font-bold text-default-600">
                          <span className="bg-blue-50 text-blue-600 px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest">
                            {c.projectCount} Projects
                          </span>
                        </td>
                        <td className="py-4 px-6 text-sm font-bold text-default-600">
                          <span className="bg-emerald-50 text-emerald-600 px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest">
                            ₹{c.totalCost.toLocaleString()}
                          </span>
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex items-center justify-end gap-2">
                            {canViewProjects && (
                              <button
                                type="button"
                                className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                                onClick={() => openCompanyDetails(c)}
                              >
                                <LuEye className="size-4" />
                              </button>
                            )}
                            {canEdit && (
                              <button
                                type="button"
                                className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                                onClick={() => {
                                  setEditItem(c);
                                  setModalOpen(true);
                                }}
                              >
                                <LuPencil className="size-4" />
                              </button>
                            )}
                            <Link
                              to={`/company/${c._id}`}
                              className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                            >
                              <LuArrowRight className="size-4" />
                            </Link>
                            {canDelete && (
                              <button
                                type="button"
                                className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-danger hover:bg-danger hover:text-white hover:border-danger transition-all active:scale-90"
                                onClick={() => confirmDelete(c._id)}
                              >
                                <LuTrash2 className="size-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-6 grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-6">
              {loading ? (
                <div className="col-span-full py-12 text-center">
                  <div className="flex flex-col items-center gap-2">
                    <div className="size-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                    <p className="text-xs font-bold text-default-400 uppercase tracking-widest">Loading Companies...</p>
                  </div>
                </div>
              ) : items.length === 0 ? (
                <div className="col-span-full py-12 text-center">
                  <p className="text-xs font-bold text-default-400 uppercase tracking-widest">No companies found</p>
                </div>
              ) : (
                items.map((c) => (
                  <div key={c._id} className="bg-default-50 border border-default-200 rounded-2xl p-5 transition-all group">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <div className="size-10 rounded-xl bg-primary text-white flex items-center justify-center font-black text-sm group-hover:scale-110 transition-transform">
                          {c.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <h6 className="font-black text-default-900 leading-none mb-1">{c.name}</h6>
                          <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">{c.companyId}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        {canViewProjects && (
                          <button
                            type="button"
                            className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                            onClick={() => openCompanyDetails(c)}
                          >
                            <LuEye className="size-4" />
                          </button>
                        )}
                        {canEdit && (
                          <button
                            type="button"
                            className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                            onClick={() => {
                              setEditItem(c);
                              setModalOpen(true);
                            }}
                          >
                            <LuPencil className="size-4" />
                          </button>
                        )}
                        {canDelete && (
                          <button
                            type="button"
                            className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-danger hover:bg-danger hover:text-white hover:border-danger transition-all active:scale-90"
                            onClick={() => confirmDelete(c._id)}
                          >
                            <LuTrash2 className="size-4" />
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="space-y-3 mb-4">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Email Address</span>
                        <span className="text-sm font-bold text-default-900">{c.email}</span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Phone Number</span>
                        <span className="text-sm font-bold text-default-900">{c.phone}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-4 border-t border-default-200">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Projects</span>
                        <span className="text-sm font-black text-primary">{c.projectCount}</span>
                      </div>
                      <div className="flex flex-col text-right">
                        <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Total Revenue</span>
                        <span className="text-sm font-black text-emerald-600">₹{c.totalCost.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          <div className="flex items-center justify-between p-6 border-t border-default-100 bg-default-50/50">
            <div className="text-xs font-bold text-default-500 uppercase tracking-widest">
              Showing <span className="text-default-900">{(page - 1) * limit + 1}</span> to <span className="text-default-900">{Math.min(page * limit, total)}</span> of <span className="text-default-900">{total}</span> Results
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center bg-white border border-default-200 rounded-xl p-1">
                <button
                  type="button"
                  className="h-9 px-4 flex items-center justify-center rounded-lg font-bold text-xs transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600"
                  disabled={page === 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                >
                  Prev
                </button>
                <div className="w-px h-4 bg-default-200 mx-1" />
                <button
                  type="button"
                  className="h-9 px-4 flex items-center justify-center rounded-lg font-bold text-xs transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600"
                  disabled={page * limit >= total}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Next
                </button>
              </div>

              <select
                className="bg-white border border-default-200 rounded-xl h-11 px-3 text-xs font-bold focus:ring-primary/20 focus:border-primary transition-all cursor-pointer"
                value={limit}
                onChange={(e) => {
                  setLimit(parseInt(e.target.value));
                  setPage(1);
                }}
              >
                <option value={10}>10 Per Page</option>
                <option value={20}>20 Per Page</option>
                <option value={50}>50 Per Page</option>
              </select>
            </div>
          </div>
        </div>

        {detailOpen && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-stretch justify-end z-50 animate-in fade-in duration-300">
            <div className="bg-white w-full max-w-2xl h-full flex flex-col animate-in slide-in-from-right duration-500">
              <div className="p-6 border-b border-default-200 flex items-center justify-between bg-white sticky top-0 z-10">
                <div>
                  <h4 className="text-lg font-black text-default-900 leading-none mb-1 uppercase tracking-widest">Company Projects</h4>
                  <p className="text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Viewing projects for {selectedCompany?.name}</p>
                </div>
                <button
                  type="button"
                  className="size-10 flex items-center justify-center rounded-xl bg-default-100 text-default-600 hover:bg-danger hover:text-white transition-all active:scale-90"
                  onClick={() => setDetailOpen(false)}
                >
                  <LuPlus className="size-6 rotate-45" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-6">
                {selectedCompany && (
                  <div className="bg-default-50 border border-default-200 rounded-2xl p-6 mb-8">
                    <div className="flex items-center gap-4 mb-4">
                      {selectedCompany.logo ? (
                        <img
                          src={`${api.defaults.baseURL?.replace('/api', '')}/${selectedCompany.logo}`}
                          alt={selectedCompany.name}
                          className="size-14 rounded-2xl object-contain bg-white border border-default-200"
                        />
                      ) : (
                        <div className="size-14 rounded-2xl bg-primary text-white flex items-center justify-center text-xl font-black">
                          {selectedCompany.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div>
                        <h3 className="text-xl font-black text-default-900 leading-none mb-1">{selectedCompany.name}</h3>
                        <div className="flex gap-2">
                          <span className="bg-white border border-default-200 px-2 py-1 rounded-lg text-[10px] font-black text-default-500 uppercase tracking-widest">
                            {selectedCompany.companyId}
                          </span>
                          {selectedCompany.companyType && (
                            <span className="bg-white border border-default-200 px-2 py-1 rounded-lg text-[10px] font-black text-default-500 uppercase tracking-widest">
                              {selectedCompany.companyType}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Email</span>
                        <span className="text-sm font-bold text-default-900">{selectedCompany.email}</span>
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Phone</span>
                        <span className="text-sm font-bold text-default-900">{selectedCompany.phone}</span>
                      </div>
                      {selectedCompany.city && (
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Location</span>
                          <span className="text-sm font-bold text-default-900">{selectedCompany.city}, {selectedCompany.country}</span>
                        </div>
                      )}
                      {selectedCompany.contactPersonName && (
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Contact Person</span>
                          <span className="text-sm font-bold text-default-900">{selectedCompany.contactPersonName}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {!canViewProjects ? (
                  <div className="py-12 text-center bg-danger/5 border border-danger/20 rounded-2xl">
                    <p className="text-sm font-black text-danger uppercase tracking-widest">Access Denied</p>
                    <p className="text-xs font-bold text-default-500 mt-1">You do not have permission to view projects.</p>
                  </div>
                ) : (
                  <div className="bg-white border border-default-200 rounded-2xl overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="min-w-full">
                        <thead>
                          <tr className="bg-default-50 border-b border-default-200">
                            <th className="py-4 px-4 text-left text-[10px] font-black text-default-500 uppercase tracking-widest">Project Name</th>
                            <th className="py-4 px-4 text-left text-[10px] font-black text-default-500 uppercase tracking-widest">Priority</th>
                            <th className="py-4 px-4 text-left text-[10px] font-black text-default-500 uppercase tracking-widest">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          {cpLoading ? (
                            <tr>
                              <td className="py-12 px-4 text-center" colSpan={3}>
                                <div className="size-6 border-3 border-primary/20 border-t-primary rounded-full animate-spin mx-auto mb-2" />
                                <p className="text-[10px] font-black text-default-400 uppercase tracking-widest">Loading Projects...</p>
                              </td>
                            </tr>
                          ) : companyProjects.length === 0 ? (
                            <tr>
                              <td className="py-12 px-4 text-center text-[10px] font-black text-default-400 uppercase tracking-widest" colSpan={3}>
                                No projects assigned
                              </td>
                            </tr>
                          ) : (
                            companyProjects.map((p) => (
                              <tr key={p._id} className="border-b border-default-100 hover:bg-default-50/50 transition-colors group">
                                <td className="py-4 px-4">
                                  <span className="text-sm font-black text-default-900 group-hover:text-primary transition-colors">{p.name}</span>
                                </td>
                                <td className="py-4 px-4">
                                  <span className={`px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest border ${p.priority === 'high' ? 'bg-danger/10 text-danger border-danger/20' :
                                    p.priority === 'medium' ? 'bg-warning/10 text-warning border-warning/20' :
                                      'bg-success/10 text-success border-success/20'
                                    }`}>
                                    {p.priority}
                                  </span>
                                </td>
                                <td className="py-4 px-4">
                                  <select
                                    value={p.status}
                                    disabled={updatingStatus === p._id}
                                    onChange={(e) => handleStatusUpdate(p._id, e.target.value)}
                                    className={`px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest border cursor-pointer outline-none appearance-none ${p.status === 'completed'
                                      ? 'bg-success/10 text-success border-success/20'
                                      : p.status === 'in_progress'
                                        ? 'bg-primary/10 text-primary border-primary/20'
                                        : p.status === 'on_hold'
                                          ? 'bg-warning/10 text-warning border-warning/20'
                                          : 'bg-default-100 text-default-600 border-default-200'
                                      }`}
                                  >
                                    <option value="pending" className="bg-white text-default-600">Pending</option>
                                    <option value="in_progress" className="bg-white text-primary">In Progress</option>
                                    <option value="completed" className="bg-white text-success">Completed</option>
                                    <option value="on_hold" className="bg-white text-warning">On Hold</option>
                                  </select>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                    <div className="p-4 border-t border-default-100 bg-default-50/50 flex flex-col gap-4">
                      <div className="flex items-center justify-between">
                        <div className="text-[10px] font-black text-default-500 uppercase tracking-widest">
                          Showing <span className="text-default-900">{((cpPage - 1) * cpLimit) + 1}</span> to <span className="text-default-900">{Math.min(cpPage * cpLimit, cpTotal)}</span> of <span className="text-default-900">{cpTotal}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center bg-white border border-default-200 rounded-xl p-1">
                            <button
                              type="button"
                              className="h-8 px-3 flex items-center justify-center rounded-lg font-black text-[10px] uppercase tracking-widest transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600"
                              disabled={cpPage === 1}
                              onClick={() => { const n = Math.max(1, cpPage - 1); setCpPage(n); loadCompanyProjects(selectedCompany._id, n); }}
                            >
                              Prev
                            </button>
                            <div className="w-px h-3 bg-default-200 mx-1" />
                            <button
                              type="button"
                              className="h-8 px-3 flex items-center justify-center rounded-lg font-black text-[10px] uppercase tracking-widest transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600"
                              disabled={cpPage * cpLimit >= cpTotal}
                              onClick={() => { const n = cpPage + 1; setCpPage(n); loadCompanyProjects(selectedCompany._id, n); }}
                            >
                              Next
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {modalOpen && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-300 p-4">
            <div className="bg-white w-full max-w-lg rounded-2xl overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="p-6 border-b border-default-200 flex items-center justify-between bg-white">
                <div>
                  <h4 className="text-lg font-black text-default-900 leading-none mb-1 uppercase tracking-widest">
                    {editItem ? 'Edit Company' : 'Add New Company'}
                  </h4>
                  <p className="text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">
                    {editItem ? 'Update company details' : 'Register a new company'}
                  </p>
                </div>
                <button
                  type="button"
                  className="size-10 flex items-center justify-center rounded-2xl bg-default-100 text-default-600 hover:bg-danger hover:text-white transition-all active:scale-90"
                  onClick={() => {
                    setModalOpen(false);
                    setEditItem(null);
                  }}
                >
                  <LuPlus className="size-6 rotate-45" />
                </button>
              </div>
              <form onSubmit={onSubmitCompany}>
                <div className="p-6 grid grid-cols-1 gap-6 bg-default-50/30 max-h-[70vh] overflow-y-auto">

                  {/* 1. Basic Information */}
                  <div className="space-y-4">
                    <h5 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2">1. Basic Information</h5>

                    {/* Logo Upload */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Company Logo</label>
                      <div className="flex items-center gap-4">
                        {editItem?.logo && (
                          <img
                            src={`${api.defaults.baseURL?.replace('/api', '')}/${editItem.logo}`}
                            alt="Company Logo"
                            className="w-16 h-16 object-contain border border-default-200 rounded-lg bg-white"
                          />
                        )}
                        <input
                          type="file"
                          name="logo"
                          accept="image/*"
                          className="w-full bg-white border-default-200 rounded-xl h-12 px-4 py-2 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all file:mr-4 file:py-1 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Company Name *</label>
                        <input
                          name="name"
                          className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.name ? 'border-danger' : ''}`}
                          placeholder="ENTER COMPANY NAME"
                          defaultValue={editItem?.name || ''}
                          required
                          onChange={() => clearFieldError('name')}
                        />
                        {fieldErrors.name && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.name}</div>}
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Company Type *</label>
                        <select
                          name="companyType"
                          className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.companyType ? 'border-danger' : ''}`}
                          defaultValue={editItem?.companyType || 'Company'}
                          required
                          onChange={() => clearFieldError('companyType')}
                        >
                          <option value="Company">Company</option>
                          <option value="Individual">Individual</option>
                        </select>
                        {fieldErrors.companyType && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.companyType}</div>}
                      </div>
                      <div className="space-y-1.5 md:col-span-2">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Industry</label>
                        <input
                          name="industry"
                          className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                          placeholder="ENTER INDUSTRY"
                          defaultValue={editItem?.industry || ''}
                        />
                      </div>
                    </div>
                  </div>

                  {/* 2. Contact Details */}
                  <div className="space-y-4">
                    <h5 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2">2. Contact Details (Company)</h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Company Email *</label>
                        <input
                          type="email"
                          name="email"
                          className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.email ? 'border-danger' : ''}`}
                          placeholder="EMAIL@COMPANY.COM"
                          defaultValue={editItem?.email || ''}
                          required
                          onChange={() => clearFieldError('email')}
                        />
                        {fieldErrors.email && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.email}</div>}
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Company Phone *</label>
                        <input
                          name="phone"
                          className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.phone ? 'border-danger' : ''}`}
                          placeholder="+1 (234) 567-890"
                          defaultValue={editItem?.phone || ''}
                          required
                          onChange={() => clearFieldError('phone')}
                        />
                        {fieldErrors.phone && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.phone}</div>}
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Alternate Phone</label>
                        <input
                          name="alternatePhone"
                          className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                          placeholder="ALTERNATE PHONE"
                          defaultValue={editItem?.alternatePhone || ''}
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Website</label>
                        <input
                          name="website"
                          className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.website ? 'border-danger' : ''}`}
                          placeholder="WWW.WEBSITE.COM"
                          defaultValue={editItem?.website || ''}
                          onChange={() => clearFieldError('website')}
                        />
                        {fieldErrors.website && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.website}</div>}
                      </div>
                    </div>
                  </div>

                  {/* 3. Address Details */}
                  <div className="space-y-4">
                    <h5 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2">3. Address Details</h5>
                    <div className="space-y-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Address Line 1 *</label>
                        <input
                          name="addressLine1"
                          className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.addressLine1 ? 'border-danger' : ''}`}
                          placeholder="STREET ADDRESS"
                          defaultValue={editItem?.addressLine1 || ''}
                          required
                          onChange={() => clearFieldError('addressLine1')}
                        />
                        {fieldErrors.addressLine1 && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.addressLine1}</div>}
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Address Line 2</label>
                        <input
                          name="addressLine2"
                          className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                          placeholder="APARTMENT, SUITE, ETC."
                          defaultValue={editItem?.addressLine2 || ''}
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">City *</label>
                          <input
                            name="city"
                            className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.city ? 'border-danger' : ''}`}
                            placeholder="CITY"
                            defaultValue={editItem?.city || ''}
                            required
                            onChange={() => clearFieldError('city')}
                          />
                          {fieldErrors.city && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.city}</div>}
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">State *</label>
                          <input
                            name="state"
                            className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.state ? 'border-danger' : ''}`}
                            placeholder="STATE"
                            defaultValue={editItem?.state || ''}
                            required
                            onChange={() => clearFieldError('state')}
                          />
                          {fieldErrors.state && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.state}</div>}
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Country *</label>
                          <input
                            name="country"
                            className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.country ? 'border-danger' : ''}`}
                            placeholder="COUNTRY"
                            defaultValue={editItem?.country || ''}
                            required
                            onChange={() => clearFieldError('country')}
                          />
                          {fieldErrors.country && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.country}</div>}
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Pincode *</label>
                          <input
                            name="pincode"
                            className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.pincode ? 'border-danger' : ''}`}
                            placeholder="PINCODE"
                            defaultValue={editItem?.pincode || ''}
                            required
                            onChange={() => clearFieldError('pincode')}
                          />
                          {fieldErrors.pincode && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.pincode}</div>}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 4. Business Information */}
                  <div className="space-y-4">
                    <h5 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2">4. Business Information</h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">GST Number</label>
                        <input
                          name="gstNumber"
                          className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                          placeholder="GST NUMBER"
                          defaultValue={editItem?.gstNumber || ''}
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">PAN Number</label>
                        <input
                          name="panNumber"
                          className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                          placeholder="PAN NUMBER"
                          defaultValue={editItem?.panNumber || ''}
                        />
                      </div>
                    </div>
                  </div>

                  {/* 5. Contact Person Details */}
                  <div className="space-y-4">
                    <h5 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2">5. Contact Person Details (Primary)</h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Contact Person Name *</label>
                        <input
                          name="contactPersonName"
                          className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.contactPersonName ? 'border-danger' : ''}`}
                          placeholder="FULL NAME"
                          defaultValue={editItem?.contactPersonName || ''}
                          required
                          onChange={() => clearFieldError('contactPersonName')}
                        />
                        {fieldErrors.contactPersonName && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.contactPersonName}</div>}
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Designation</label>
                        <input
                          name="designation"
                          className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                          placeholder="DESIGNATION"
                          defaultValue={editItem?.designation || ''}
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Email Address *</label>
                        <input
                          type="email"
                          name="contactPersonEmail"
                          className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.contactPersonEmail ? 'border-danger' : ''}`}
                          placeholder="EMAIL"
                          defaultValue={editItem?.contactPersonEmail || ''}
                          required
                          onChange={() => clearFieldError('contactPersonEmail')}
                        />
                        {fieldErrors.contactPersonEmail && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.contactPersonEmail}</div>}
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Phone Number *</label>
                        <input
                          name="contactPersonPhone"
                          className={`w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all ${fieldErrors.contactPersonPhone ? 'border-danger' : ''}`}
                          placeholder="PHONE"
                          defaultValue={editItem?.contactPersonPhone || ''}
                          required
                          onChange={() => clearFieldError('contactPersonPhone')}
                        />
                        {fieldErrors.contactPersonPhone && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.contactPersonPhone}</div>}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-6 border-t border-default-200 bg-white flex justify-end gap-3">
                  <button
                    type="button"
                    className="h-12 px-6 flex items-center justify-center rounded-xl font-black text-[10px] uppercase tracking-widest text-default-600 hover:bg-default-100 transition-all"
                    onClick={() => {
                      setModalOpen(false);
                      setEditItem(null);
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="h-12 px-8 flex items-center justify-center bg-primary text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all active:scale-95"
                  >
                    {editItem ? 'Update Company' : 'Register Company'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </>
  );
};

export default Index;
