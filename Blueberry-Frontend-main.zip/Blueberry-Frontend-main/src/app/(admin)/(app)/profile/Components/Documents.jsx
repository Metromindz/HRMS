import { LuImage, LuCreditCard, LuUser, LuBookOpen, LuBriefcase, LuMapPin, LuCalendar, LuMailOpen, LuExternalLink, LuFileWarning } from 'react-icons/lu';

const Documents = ({ data }) => {
  const documents = data?.documents || {};

  const fieldConfig = [
    { key: 'panCard', label: 'PAN Card', icon: LuCreditCard },
    { key: 'aadhaarCard', label: 'Aadhaar Card', icon: LuUser },
    { key: 'profilePhoto', label: 'Passport Photo', icon: LuImage },
    { key: 'bankPassbook', label: 'Bank Passbook', icon: LuCreditCard },
    { key: 'educationCertificates', label: 'Education Certificates', icon: LuBookOpen },
    { key: 'experienceLetter', label: 'Experience Letter', icon: LuBriefcase },
    { key: 'proofOfAddress', label: 'Proof Of Address', icon: LuMapPin },
    { key: 'proofOfDOB', label: 'Proof Of Date Of Birth', icon: LuCalendar },
    { key: 'offerLetter', label: 'Offer Letter', icon: LuMailOpen },
  ];

  const renderDocumentCard = (config) => {
    const { key, label, icon: Icon } = config;
    const value = documents[key];
    const isUploaded = value && value !== '';

    return (
      <div key={key} className="group relative bg-default-50/50 hover:bg-white border border-transparent hover:border-default-200 rounded-2xl p-4 transition-all duration-300">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className={`size-10 rounded-xl flex items-center justify-center ${isUploaded ? 'bg-primary/10 text-primary' : 'bg-default-100 text-default-400'}`}>
              <Icon className="size-5" />
            </div>
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-default-400 mb-0.5">{label}</p>
              {isUploaded ? (
                <span className="text-xs font-bold text-success flex items-center gap-1">
                  <div className="size-1.5 rounded-full bg-success" />
                  Verified & Uploaded
                </span>
              ) : (
                <span className="text-xs font-bold text-default-400 flex items-center gap-1">
                  <div className="size-1.5 rounded-full bg-default-300" />
                  Not Uploaded
                </span>
              )}
            </div>
          </div>
          
          {isUploaded && (
            <a
              href={value}
              target="_blank"
              rel="noopener noreferrer"
              className="size-8 rounded-lg bg-white border border-default-200 flex items-center justify-center text-default-500 hover:text-primary hover:border-primary transition-all shadow-sm"
              title="View Document"
            >
              <LuExternalLink className="size-4" />
            </a>
          )}
        </div>

        {!isUploaded && (
          <div className="mt-3 flex items-center gap-2 text-[10px] font-medium text-default-400 italic">
            <LuFileWarning className="size-3" />
            Please contact HR to upload this document
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="animate-in fade-in duration-500">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-default-900">Documents Vault</h2>
        <p className="text-sm text-default-500">Securely store and manage your official employment documents</p>
      </div>

      <div className="bg-white rounded-3xl border border-default-200 p-6 md:p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {fieldConfig.map(renderDocumentCard)}
        </div>
      </div>
    </div>
  );
};

export default Documents;
