import { LuBriefcase, LuCalendar, LuNetwork, LuUserCheck, LuMapPin, LuClock, LuCoffee, LuFingerprint } from 'react-icons/lu';

const EmploymentDetails = ({ data }) => {
  const employment = data?.employmentDetails || {};

  const fieldConfig = [
    { key: 'employeeId', label: 'Employee ID', icon: LuFingerprint },
    { key: 'dateOfJoining', label: 'Date of Joining', icon: LuCalendar, type: 'date' },
    { key: 'department', label: 'Department', icon: LuNetwork, value: employment.department?.name },
    { key: 'designation', label: 'Designation', icon: LuBriefcase, value: employment.designation?.name },
    { key: 'employmentType', label: 'Employment Type', icon: LuBriefcase },
    { key: 'workLocation', label: 'Work Location', icon: LuMapPin },
    { key: 'reportingManager', label: 'Reporting Manager', icon: LuUserCheck, value: employment.reportingManager?.name },
    { key: 'probationPeriod', label: 'Probation Period', icon: LuClock },
    { key: 'confirmationDate', label: 'Confirmation Date', icon: LuCalendar, type: 'date' },
    { key: 'shift', label: 'Shift Details', icon: LuClock, value: employment.shift?.name },
    { key: 'weekOff', label: 'Week Off', icon: LuCoffee },
  ];

  const renderField = (config) => {
    const { key, label, icon: Icon, type, value: customValue } = config;
    const value = customValue || employment[key];
    const displayValue = type === 'date' && value ? value.split('T')[0] : (value || '-');

    return (
      <div key={key} className="space-y-2">
        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-default-400">
          <Icon className="size-3" />
          {label}
        </label>
        <div className="min-h-[44px] flex items-center px-4 rounded-xl bg-default-50/50 border border-transparent text-sm font-medium text-default-700">
          {displayValue}
        </div>
      </div>
    );
  };

  return (
    <div className="animate-in fade-in duration-500">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-default-900">Employment Details</h2>
        <p className="text-sm text-default-500">View your current role and organizational information</p>
      </div>

      <div className="bg-white rounded-3xl border border-default-200 p-6 md:p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {fieldConfig.map(renderField)}
        </div>
      </div>
    </div>
  );
};

export default EmploymentDetails;

