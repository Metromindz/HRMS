import { useState, useEffect } from 'react';
import PersonalInfo from './Components/PersonalInfo';
import EmploymentDetails from './Components/EmploymentDetails';
import BankDetails from './Components/BankDetails';
import StatutoryCompliance from './Components/StatutoryCompliance';
import Documents from './Components/Documents';
import { jwtDecode } from 'jwt-decode';
import api from '../../../../config/api';
import { getUploadUrl } from '@/utils/uploadUrl';
import PageMeta from '@/components/PageMeta';
import UserAvatar from '@/assets/images/user/avatar-11.png';
import { LuUser, LuBriefcase, LuBanknote, LuShieldCheck, LuFileText, LuMapPin, LuMail, LuCalendar } from 'react-icons/lu';

const Index = () => {
  const [activeTab, setActiveTab] = useState('personal');
  const [employeeData, setEmployeeData] = useState(null);
  const [loading, setLoading] = useState(true);

  let user = { id: null };
  const token = sessionStorage.getItem('token');
  if (token) {
    const decoded = jwtDecode(token);
    user = { id: decoded.id, role: decoded.role };
  }

  useEffect(() => {
    if (!user.id) return;

    const fetchEmployeeDetails = async () => {
      try {
        setLoading(true);
        const response = await api.get(`/hr/employees/${user.id}`);
        if (response.status === 200) {
          setEmployeeData(response.data.employee);
        }
      } catch (error) {
        console.error('Error fetching employee details:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchEmployeeDetails();
  }, [user.id]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <div className="size-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
        <p className="text-sm font-black uppercase tracking-widest text-default-400">Loading Profile...</p>
      </div>
    );
  }

  const tabs = [
    { key: 'personal', label: 'Personal', icon: LuUser },
    { key: 'employment', label: 'Employment', icon: LuBriefcase },
    { key: 'bank', label: 'Bank', icon: LuBanknote },
    { key: 'statutory', label: 'Statutory', icon: LuShieldCheck },
    { key: 'documents', label: 'Documents', icon: LuFileText },
  ];

  return (
    <>
      <PageMeta title="My Profile" />
      <div className="p-4 md:p-8 bg-default-50/50 min-h-screen">
        {/* Header Card */}
        <div className="bg-white border border-default-200 rounded-[2rem] overflow-hidden mb-8 shadow-sm">
          <div className="relative h-48 bg-gradient-to-br from-primary via-primary/90 to-purple-600">
            <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
            <div className="absolute -bottom-16 left-8 flex flex-col md:flex-row items-end md:items-center gap-6">
              <div className="relative group">
                <img
                  src={getUploadUrl(employeeData?.documents?.profilePhoto) || UserAvatar}
                  alt="Profile"
                  className="size-32 md:size-40 rounded-[2.5rem] ring-8 ring-white object-cover shadow-2xl group-hover:scale-105 transition-transform duration-500 bg-white"
                />
                <div className="absolute inset-0 rounded-[2.5rem] bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              </div>
              <div className="mb-4 md:mb-0 md:pb-4">
                <h1 className="text-3xl md:text-4xl font-black text-white drop-shadow-md uppercase tracking-tight">
                  {employeeData?.fullName || employeeData?.name || 'Employee'}
                </h1>
                <div className="flex flex-wrap items-center gap-3 text-white/90 text-[10px] font-black uppercase tracking-widest mt-2">
                  <span className="bg-white/20 px-3 py-1 rounded-xl backdrop-blur-md border border-white/20">
                    {employeeData?.employeeId || '—'}
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-white/40 hidden md:block"></span>
                  <span className="bg-white/10 px-3 py-1 rounded-xl backdrop-blur-md">
                    {employeeData?.employmentDetails?.designation?.name || employeeData?.designation || '—'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="px-8 pt-20 pb-10">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="flex items-start gap-3">
                <div className="size-10 rounded-xl bg-default-50 flex items-center justify-center text-default-400">
                  <LuBriefcase className="size-5" />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Department</span>
                  <span className="text-sm font-bold text-default-900">{employeeData?.employmentDetails?.department?.name || employeeData?.department || '—'}</span>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="size-10 rounded-xl bg-default-50 flex items-center justify-center text-default-400">
                  <LuMapPin className="size-5" />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Work Location</span>
                  <span className="text-sm font-bold text-default-900">{employeeData?.employmentDetails?.workLocation || employeeData?.branch || '—'}</span>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="size-10 rounded-xl bg-default-50 flex items-center justify-center text-default-400">
                  <LuMail className="size-5" />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Email Address</span>
                  <span className="text-sm font-bold text-default-900 truncate max-w-[200px]">{employeeData?.email || employeeData?.employeePersonal?.emailAddress || '—'}</span>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="size-10 rounded-xl bg-default-50 flex items-center justify-center text-default-400">
                  <LuCalendar className="size-5" />
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Joining Date</span>
                  <span className="text-sm font-bold text-default-900">
                    {employeeData?.employmentDetails?.dateOfJoining ? new Date(employeeData.employmentDetails.dateOfJoining).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs Navigation */}
        <div className="mb-8">
          <div className="bg-white border border-default-200 rounded-[1.5rem] p-2 inline-flex items-center gap-2 overflow-x-auto max-w-full shadow-sm no-scrollbar">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`px-6 py-3 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all duration-300 whitespace-nowrap flex items-center gap-2.5 ${activeTab === tab.key
                    ? 'bg-primary text-white shadow-xl shadow-primary/20 translate-y-[-1px]'
                    : 'text-default-500 hover:bg-default-50 hover:text-default-700'
                  }`}
              >
                <tab.icon className={`size-4 ${activeTab === tab.key ? 'text-white' : 'text-default-400'}`} />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="min-h-[400px]">
          {activeTab === 'personal' && <PersonalInfo data={employeeData} />}
          {activeTab === 'employment' && <EmploymentDetails data={employeeData} />}
          {activeTab === 'bank' && <BankDetails data={employeeData} />}
          {activeTab === 'statutory' && <StatutoryCompliance data={employeeData} />}
          {activeTab === 'documents' && <Documents data={employeeData} />}
        </div>
      </div>
    </>
  );
};

export default Index;

