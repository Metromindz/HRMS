import { useState, useEffect, useMemo } from 'react';
import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import Calender from './components/Calender';
import api from '@/config/api';
import { LuShieldCheck, LuList, LuCalendar as LuCalendarIcon, LuPlus, LuRefreshCw, LuCircleCheck, LuClock, LuTrendingUp } from 'react-icons/lu';

const Index = () => {
  const [tasks, setTasks] = useState([]);
  const [holidays, setHolidays] = useState([]);
  const [, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [tasksRes, holidaysRes] = await Promise.all([
        api.get('/tasks/calendar'), // Fetch all for now
        api.get('/holiday/getAllholidays')
      ]);

      if (tasksRes.data.success) {
        setTasks(tasksRes.data.items || []);
      }
      if (holidaysRes.data.success) {
         setHolidays(holidaysRes.data.data || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const stats = useMemo(() => {
    const total = tasks.length;
    const active = tasks.filter(t => t.status === 'in_progress' || t.status === 'todo').length;
    const done = tasks.filter(t => t.status === 'done').length;
    const efficiency = total > 0 ? Math.round((done / total) * 100) : 0;
    return { active, done, efficiency };
  }, [tasks]);

  return (
    <>
      <PageMeta title="Task Planner" />
      <main>
        <PageBreadcrumb title="Task Planner" subtitle="Operational Control Center" />

        <div className="flex flex-col gap-6 h-[calc(100vh-140px)]">
            
            {/* Header & Stats Row */}
            <div className="flex flex-col gap-6 shrink-0">
                {/* Top Header */}
                <div className="bg-white p-4 rounded-2xl border border-default-200 flex flex-wrap justify-between items-center shadow-sm">
                   <div>
                      <h2 className="text-xl font-black text-default-900 uppercase tracking-tight">Facility Planner</h2>
                      <div className="flex items-center gap-2 text-default-400 text-[10px] font-black uppercase tracking-widest mt-0.5">
                        <LuShieldCheck className="size-3.5" /> Operational Control Center
                      </div>
                   </div>
                   <div className="flex items-center gap-3">
                      <div className="bg-default-100 p-1 rounded-xl flex items-center">
                         <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white shadow-sm text-xs font-black text-default-900 uppercase tracking-wider">
                            <LuCalendarIcon className="size-3.5" /> Calendar
                         </button>
                         <button className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-black text-default-500 uppercase tracking-wider hover:text-default-900 transition-colors">
                            <LuList className="size-3.5" /> List
                         </button>
                      </div>
                      <button className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-default-900 text-white text-xs font-black uppercase tracking-wider hover:bg-default-800 transition-all active:scale-95 shadow-lg shadow-default-900/20">
                         <LuPlus className="size-4" /> New Activity
                      </button>
                   </div>
                </div>

                {/* Stats Row */}
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Sync Status */}
                <div className="bg-white p-5 rounded-2xl border border-default-200 flex items-center justify-between shadow-sm">
                    <div className="flex items-center gap-3">
                        <div className="size-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                            <LuRefreshCw className="size-5" />
                        </div>
                        <div>
                            <h4 className="text-xs font-black text-default-400 uppercase tracking-widest">Sync Status</h4>
                            <p className="text-lg font-black text-default-900">Live</p>
                        </div>
                    </div>
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-success"></span>
                    </span>
                </div>

                {/* Active Tasks */}
                <div className="bg-white p-5 rounded-2xl border border-default-200 flex items-center justify-between shadow-sm">
                    <div className="flex items-center gap-3">
                        <div className="size-10 rounded-xl bg-warning/10 flex items-center justify-center text-warning">
                            <LuClock className="size-5" />
                        </div>
                        <div>
                            <h4 className="text-xs font-black text-default-400 uppercase tracking-widest">Active</h4>
                            <p className="text-lg font-black text-default-900">{stats.active}</p>
                        </div>
                    </div>
                </div>

                {/* Done Tasks */}
                <div className="bg-white p-5 rounded-2xl border border-default-200 flex items-center justify-between shadow-sm">
                    <div className="flex items-center gap-3">
                        <div className="size-10 rounded-xl bg-success/10 flex items-center justify-center text-success">
                            <LuCircleCheck className="size-5" />
                        </div>
                        <div>
                            <h4 className="text-xs font-black text-default-400 uppercase tracking-widest">Done</h4>
                            <p className="text-lg font-black text-default-900">{stats.done}</p>
                        </div>
                    </div>
                </div>

                {/* Efficiency */}
                <div className="bg-white p-5 rounded-2xl border border-default-200 flex items-center justify-between shadow-sm">
                    <div className="flex items-center gap-3">
                        <div className="size-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                            <LuTrendingUp className="size-5" />
                        </div>
                        <div>
                            <h4 className="text-xs font-black text-default-400 uppercase tracking-widest">Efficiency</h4>
                            <p className="text-lg font-black text-default-900">{stats.efficiency}%</p>
                        </div>
                    </div>
                </div>
            </div>
            </div>

            {/* Main Content Grid */}
            <div className="flex-1 min-h-0 h-full overflow-hidden bg-white rounded-3xl border border-default-200 shadow-sm">
               <Calender 
                   tasks={tasks} 
                   holidays={holidays}
                   onRefresh={fetchData}
                />
            </div>
        </div>
      </main>
    </>
  );
};

export default Index;
