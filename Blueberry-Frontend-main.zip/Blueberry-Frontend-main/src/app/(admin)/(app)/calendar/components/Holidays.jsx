import { LuPlus } from 'react-icons/lu';
import { useEffect, useState } from 'react';
import api from '../../../../../config/api';

const Holiydays = () => {
  const [displayHolidays, setDisplayHolidays] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchHolidays = async () => {
    try {
      setLoading(true);
      const response = await api.get('/holiday/getAllholidays');

      const currentYear = new Date().getFullYear();
      const currentYearHolidays = (response.data?.data || [])
        .filter((holiday) => {
          const holidayDate = new Date(holiday.date);
          return holidayDate.getFullYear() === currentYear;
        })
        .sort((a, b) => new Date(a.date) - new Date(b.date));

      setDisplayHolidays(currentYearHolidays);
    } catch (err) {
      console.error('Error fetching holidays:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHolidays();
  }, []);

  return (
    <div className="card h-full rounded-3xl border border-default-100 overflow-hidden bg-white shadow-sm">
      <div className="p-6 border-b border-default-100 bg-default-50/50">
        <div className="flex items-center gap-3">
          <div className="size-10 bg-warning/10 rounded-xl flex items-center justify-center text-warning ring-4 ring-warning/5">
            <LuPlus className="size-5 rotate-45" />
          </div>
          <div>
            <h6 className="text-sm font-black text-default-900 uppercase tracking-tight">Holidays {new Date().getFullYear()}</h6>
            <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Public Holidays</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col">
        <div className="overflow-x-auto">
          <div className="min-w-full inline-block align-middle">
            <div className="overflow-hidden">
              <table className="min-w-full divide-y divide-default-100">
                <thead className="bg-default-50/50">
                  <tr className="divide-x divide-default-100">
                    <th className="px-4 py-3 text-[10px] font-black text-default-400 uppercase tracking-widest text-start">Date</th>
                    <th className="px-4 py-3 text-[10px] font-black text-default-400 uppercase tracking-widest text-start">Holiday Name</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-default-100 bg-white">
                  {loading ? (
                    <tr>
                      <td colSpan="2" className="px-4 py-12 text-center">
                        <div className="flex flex-col items-center gap-2">
                          <div className="size-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                          <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Loading holidays...</p>
                        </div>
                      </td>
                    </tr>
                  ) : displayHolidays.length === 0 ? (
                    <tr>
                      <td colSpan="2" className="px-4 py-12 text-center">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">No holidays found</p>
                      </td>
                    </tr>
                  ) : (
                    displayHolidays.map((holiday) => (
                      <tr
                        key={holiday._id || holiday.id}
                        className="text-default-800 font-normal whitespace-nowrap divide-x divide-default-100 hover:bg-default-50/50 transition-all"
                      >
                        <td className="px-4 py-3 text-xs font-bold text-default-600">{holiday.date}</td>
                        <td className="px-4 py-3 text-xs font-black text-default-900 uppercase tracking-tight">{holiday.name}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Holiydays;
