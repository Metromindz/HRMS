import { useState, useEffect } from 'react';
import { LuX, LuListTodo, LuCalendar, LuClock, LuUsers, LuTag, LuPencil, LuPlus, LuTrash2 } from 'react-icons/lu';
import api from '@/config/api';
import { useAuth } from '@/context/AuthContext';

const priorities = ['High', 'Medium', 'Low'];
const statuses = [
  { value: 'todo', label: 'To Do' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'blocked', label: 'Blocked' },
  { value: 'done', label: 'Done' },
];
const projectTypes = ['Digital Marketing', 'Web Application', 'Design', 'Mobile App', 'SEO'];
const technologyMap = {
  'Web Application': ['React', 'Vue', 'Angular', 'Node.js', 'Django', 'Laravel', 'Other'],
  'Mobile App': ['Flutter', 'React Native', 'Android', 'iOS', 'Ionic', 'Other'],
  Design: ['Figma', 'Adobe XD', 'Photoshop', 'Illustrator', 'Other'],
  'Digital Marketing': ['Google Ads', 'Facebook Ads', 'Email Marketing', 'Social Media', 'Content', 'Other'],
  SEO: ['On-Page', 'Off-Page', 'Technical SEO', 'Local SEO', 'Other'],
  'Other': []
};

const EventModal = ({
  event,
  newEventData,
  onClose,
  onSaved
}) => {
  const { user } = useAuth();
  const [projects, setProjects] = useState([]);
  const [developers, setDevelopers] = useState([]);
  const [selectedAssigneeIds, setSelectedAssigneeIds] = useState([]);
  const [selectedType, setSelectedType] = useState('');
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [formError, setFormError] = useState('');
  const [fullTask, setFullTask] = useState(null);

  // Initial form state
  const isEdit = !!event;
  const sourceTask = event?.extendedProps?.sourceTask || {};
  
  // Initialize state based on taskData or defaults
  useEffect(() => {
    const init = async () => {
      setInitialLoading(true);
      try {
        // Fetch dependencies
        const [projectsRes, devsRes] = await Promise.all([
          api.get('/projects', { params: { page: 1, limit: 100 } }),
          api.get('/hr/employees-selection', { params: { page: 1, limit: 100 } })
        ]);
        setProjects(projectsRes.data.items || projectsRes.data.projects || []);
        setDevelopers(devsRes.data.employees || []);

        // Fetch full task details if editing
        if (isEdit && sourceTask._id) {
          try {
            const taskRes = await api.get(`/tasks/${sourceTask._id}`);
            const task = taskRes.data.task || taskRes.data;
            setFullTask(task);
            setSelectedAssigneeIds((task.assignees || []).map(d => d._id));
            setSelectedType(task.projectType || '');
          } catch (e) {
            console.error('Failed to fetch task details', e);
            // Fallback to sourceTask
            setFullTask(sourceTask);
            setSelectedAssigneeIds((sourceTask.assignees || []).map(d => d._id));
            setSelectedType(sourceTask.projectType || '');
          }
        } else {
            setFullTask({});
        }
      } catch (err) {
        console.error('Failed to load dependencies', err);
      } finally {
        setInitialLoading(false);
      }
    };
    init();
  }, [isEdit, sourceTask._id]); // Only re-run if ID changes

  const taskData = fullTask || sourceTask;

  const selfAssign = () => {
    const me = user?._id;
    if (!me) return;
    setSelectedAssigneeIds(prev => (prev.includes(me) ? prev : [...prev, me]));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError('');
    setLoading(true);

    const form = new FormData(e.currentTarget);
    const payload = {
      projectId: form.get('projectId'),
      title: form.get('title')?.trim(),
      description: form.get('description') || '',
      projectType: form.get('projectType'),
      technology: form.get('technology') || '',
      priority: form.get('priority'),
      status: form.get('status') || 'todo',
      assignees: selectedAssigneeIds,
      startDate: form.get('startDate') || null,
      dueDate: form.get('dueDate') || null,
      dueHours: Number(form.get('dueHours') || 0),
      estimatedHours: Number(form.get('estimatedHours') || 0),
      tags: (form.get('tags') || '').split(',').map(s => s.trim()).filter(Boolean),
    };

    if (!payload.projectId || !payload.title || !payload.priority || !payload.projectType) {
      setFormError('Please fill in all required fields');
      setLoading(false);
      return;
    }
    
    if (payload.dueDate && payload.startDate) {
      if (new Date(payload.dueDate) < new Date(payload.startDate)) {
        setFormError('Due date must be after start date');
        setLoading(false);
        return;
      }
    }

    try {
      if (isEdit && taskData._id) {
        await api.put(`/tasks/${taskData._id}`, payload);
      } else {
        await api.post('/tasks', payload);
      }
      
      if (onSaved) onSaved();
      onClose();
    } catch (err) {
      const msg = err?.response?.data?.message || 'Failed to save task';
      setFormError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!isEdit || !taskData._id) return;
    if (window.confirm('Delete this task?')) {
      try {
        setLoading(true);
        await api.delete(`/tasks/${taskData._id}`);
        if (onSaved) onSaved();
        onClose();
      } catch {
        setFormError('Failed to delete task');
      } finally {
        setLoading(false);
      }
    }
  };

  // Determine default dates
  const defaultStartDate = isEdit 
    ? (taskData.startDate ? new Date(taskData.startDate).toISOString().split('T')[0] : '')
    : (newEventData?.date ? new Date(newEventData.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
    
  const defaultDueDate = isEdit
    ? (taskData.dueDate ? new Date(taskData.dueDate).toISOString().split('T')[0] : '')
    : (newEventData?.date ? new Date(newEventData.date).toISOString().split('T')[0] : '');

  return (
    <div className="fixed inset-0 bg-default-900/40 backdrop-blur-sm flex items-center justify-center z-[100] p-4 animate-in fade-in duration-300">
      <div className="relative bg-white rounded-3xl w-full max-w-4xl mx-auto overflow-hidden animate-in zoom-in-95 duration-300 border border-default-100 shadow-2xl flex flex-col max-h-[90vh]">
        <div className="absolute inset-0 bg-default-900/40 backdrop-blur-sm -z-10" onClick={onClose} />
        
        {/* Header */}
        <div className="px-8 py-6 border-b border-default-100 flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center gap-4">
            <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
              {isEdit ? <LuPencil className="size-6" /> : <LuPlus className="size-6" />}
            </div>
            <div>
              <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">
                {isEdit ? 'Edit Task' : 'Add New Task'}
              </h3>
              <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">
                {isEdit ? 'Update existing task details' : 'Create a new task in the system'}
              </p>
            </div>
          </div>
          <button 
            type="button" 
            className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95" 
            onClick={onClose}
          >
            <LuX className="size-5" />
          </button>
        </div>

        {formError && (
          <div className="px-8 py-4 bg-danger/10 text-danger text-sm font-bold border-b border-danger/20">
            {formError}
          </div>
        )}

        {initialLoading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : (
          <form className="flex flex-col overflow-hidden flex-1" onSubmit={handleSubmit}>
            <div className="p-8 overflow-y-auto custom-scroll flex-1">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Basic Info Section */}
              <div className="space-y-5">
                <h4 className="text-[11px] font-black text-primary flex items-center gap-2 uppercase tracking-[0.2em] mb-4">
                  <LuListTodo className="size-4" /> Task Details
                </h4>
                
                <div>
                  <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Project *</label>
                  <select name="projectId" className="form-select w-full h-11 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-sm bg-default-50/50" defaultValue={taskData.project?._id || ''} required>
                    <option value="">Select Project</option>
                    {projects.map((p) => (
                      <option key={p._id} value={p._id}>{p.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Task Title *</label>
                  <input name="title" className="form-input w-full h-11 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-sm bg-default-50/50" placeholder="Enter task title" defaultValue={taskData.title || ''} required />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Priority *</label>
                    <select name="priority" className="form-select w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50" defaultValue={taskData.priority || ''} required>
                      <option value="">Select Priority</option>
                      {priorities.map((p) => (
                        <option key={p} value={p}>{p}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Status</label>
                    <select name="status" className="form-select w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50" defaultValue={taskData.status || 'todo'}>
                      {statuses.map((s) => (
                        <option key={s.value} value={s.value}>{s.label}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Project Type *</label>
                    <select
                      name="projectType"
                      className="form-select w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                      defaultValue={taskData.projectType || ''}
                      onChange={(e) => setSelectedType(e.target.value)}
                      required
                    >
                      <option value="">Select Type</option>
                      {projectTypes.map((t) => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Technology</label>
                    <select
                      name="technology"
                      className="form-select w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                      defaultValue={taskData.technology || ''}
                      disabled={!selectedType}
                    >
                      <option value="">{selectedType ? 'Select Technology' : 'Select Type first'}</option>
                      {(technologyMap[selectedType] || []).map((t) => (
                        <option key={t} value={t}>{t}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                    <LuTag className="size-3.5" /> Tags
                  </label>
                  <input
                    name="tags"
                    className="form-input w-full h-11 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-sm bg-default-50/50"
                    placeholder="Bug, Feature, UI, etc (comma separated)"
                    defaultValue={(taskData.tags || []).join(',')}
                  />
                </div>
              </div>

              {/* Timeline & Resources Section */}
              <div className="space-y-5">
                <h4 className="text-[11px] font-black text-primary flex items-center gap-2 uppercase tracking-[0.2em] mb-4">
                  <LuCalendar className="size-4" /> Timeline & Team
                </h4>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Start Date</label>
                    <input
                      type="date"
                      name="startDate"
                      className="form-input w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                      defaultValue={defaultStartDate}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Due Date</label>
                    <input
                      type="date"
                      name="dueDate"
                      className="form-input w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                      defaultValue={defaultDueDate}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                      <LuClock className="size-3.5" /> Due Hours
                    </label>
                    <input
                      type="number"
                      name="dueHours"
                      className="form-input w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                      placeholder="0"
                      defaultValue={taskData.dueHours || 0}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                      <LuClock className="size-3.5" /> Est. Hours
                    </label>
                    <input
                      type="number"
                      name="estimatedHours"
                      className="form-input w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                      placeholder="0"
                      defaultValue={taskData.estimatedHours || 0}
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <div className="flex items-center justify-between mb-3">
                    <label className="text-xs font-black text-default-400 uppercase tracking-widest flex items-center gap-2">
                      <LuUsers className="size-4" /> Assign Team Members
                    </label>
                    <div className="flex items-center gap-2">
                      {selectedAssigneeIds.length > 0 && (
                        <button 
                          type="button" 
                          onClick={() => setSelectedAssigneeIds([])}
                          className="text-[10px] font-black text-danger hover:underline uppercase tracking-[0.1em]"
                        >
                          Clear All
                        </button>
                      )}
                      {user && (
                        <button
                          type="button"
                          onClick={selfAssign}
                          disabled={!user?._id || selectedAssigneeIds.includes(user._id)}
                          className="text-[10px] font-black text-primary hover:underline uppercase tracking-[0.1em] disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Assign to me
                        </button>
                      )}
                      <span className="bg-primary/10 text-primary text-[10px] font-black px-2.5 py-1 rounded-lg uppercase tracking-wider">
                        {selectedAssigneeIds.length} Selected
                      </span>
                    </div>
                  </div>
                  
                  <div className="border border-default-200 rounded-xl max-h-48 overflow-y-auto p-2 bg-default-50/50 custom-scroll">
                    {developers.map((dev) => (
                      <label key={dev._id} className="flex items-center gap-3 p-2 hover:bg-white rounded-lg cursor-pointer transition-colors group">
                        <div className="relative">
                          <input
                            type="checkbox"
                            className="peer sr-only"
                            checked={selectedAssigneeIds.includes(dev._id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedAssigneeIds([...selectedAssigneeIds, dev._id]);
                              } else {
                                setSelectedAssigneeIds(selectedAssigneeIds.filter(id => id !== dev._id));
                              }
                            }}
                          />
                          <div className="size-5 border-2 border-default-300 rounded-md peer-checked:bg-primary peer-checked:border-primary transition-all flex items-center justify-center text-white">
                            <svg className="size-3.5 opacity-0 peer-checked:opacity-100 transition-opacity" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                            </svg>
                          </div>
                        </div>
                        <div className="size-8 rounded-full bg-default-200 overflow-hidden shrink-0">
                           {/* Avatar placeholder or image if available */}
                           <div className="size-full flex items-center justify-center bg-primary/10 text-primary font-bold text-xs">
                             {dev.name.charAt(0)}
                           </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-bold text-default-700 truncate group-hover:text-primary transition-colors">{dev.name}</p>
                          <p className="text-[10px] text-default-400 truncate">{dev.designation || 'Developer'}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Description</label>
                  <textarea
                    name="description"
                    className="form-textarea w-full h-24 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-medium text-sm bg-default-50/50 resize-none"
                    placeholder="Enter task description..."
                    defaultValue={taskData.description || ''}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-3 p-8 border-t border-default-100 bg-white shrink-0">
            <button 
              type="button" 
              onClick={onClose} 
              className="h-11 px-6 bg-default-100 text-default-700 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-default-200 transition-all active:scale-95 flex-1"
            >
              Cancel
            </button>

            {isEdit && (
              <button 
                type="button" 
                onClick={handleDelete} 
                className="h-11 px-6 bg-danger/10 text-danger rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-danger hover:text-white transition-all active:scale-95 flex-1 flex items-center justify-center gap-2"
                disabled={loading}
              >
                {loading ? 'Deleting...' : <><LuTrash2 className="size-4" /> Delete</>}
              </button>
            )}

            <button 
              type="submit" 
              className="h-11 px-6 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all active:scale-95 shadow-lg shadow-primary/20 flex-1 flex items-center justify-center gap-2"
              disabled={loading}
            >
              {loading ? 'Saving...' : <><LuPlus className="size-4" /> {isEdit ? 'Update Task' : 'Create Task'}</>}
            </button>
          </div>
        </form>
        )}
      </div>
    </div>
  );
};

export default EventModal;
