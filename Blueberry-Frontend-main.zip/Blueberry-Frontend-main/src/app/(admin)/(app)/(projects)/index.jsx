import { useCallback, useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import AsyncSelect from 'react-select/async';
import ReactQuill from 'react-quill-new';
import 'react-quill-new/dist/quill.snow.css';
import PageMeta from '@/components/PageMeta';
import PageBreadcrumb from '@/components/PageBreadcrumb';
import api from '@/config/api';
import { useAuth } from '@/context/AuthContext';
import { LuDownload, LuPencil, LuPlus, LuSearch, LuTrash2, LuEye, LuList, LuLayoutGrid, LuArrowRight, LuBuilding, LuCalendar, LuClock, LuX, LuCheck, LuFolderPlus, LuSave, LuUsers, LuListTodo, LuFolder, LuSettings } from 'react-icons/lu';
import { toast } from 'react-hot-toast';

const debounce = (fn, delay = 400) => {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), delay);
  };
};

const priorities = ['High', 'Medium', 'Low'];
const statuses = [
  { value: 'in_progress', label: 'In Progress' },
  { value: 'completed', label: 'Completed' },
  { value: 'pending', label: 'Pending' },
  { value: 'on_hold', label: 'On Hold' },
];
const projectTypes = ['Digital Marketing', 'Web Application', 'Design', 'Mobile App', 'SEO'];
const technologyMap = {
  'Web Application': ['React', 'Vue', 'Angular', 'Node.js', 'Django', 'Laravel', 'Other'],
  'Mobile App': ['Flutter', 'React Native', 'Android', 'iOS', 'Ionic', 'Other'],
  Design: ['Figma', 'Adobe XD', 'Photoshop', 'Illustrator', 'Other'],
  'Digital Marketing': ['Google Ads', 'Facebook Ads', 'Email Marketing', 'Social Media', 'Content', 'Other'],
  SEO: ['On-Page', 'Off-Page', 'Technical SEO', 'Local SEO', 'Other'],
};

const typePillClass = (t) => {
  const map = {
    'Web Application': 'bg-primary/10 text-primary border-primary/20',
    'Mobile App': 'bg-violet-500/10 text-violet-500 border-violet-500/20',
    Design: 'bg-pink-500/10 text-pink-500 border-pink-500/20',
    'Digital Marketing': 'bg-teal-500/10 text-teal-500 border-teal-500/20',
    SEO: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
  };
  return `px-3 py-1.5  rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${map[t] || 'bg-default-100 text-default-600 border-default-200'}`;
};

const statusPillClass = (s) => {
  const map = {
    in_progress: 'bg-primary/10 text-primary border-primary/20',
    completed: 'bg-success/10 text-success border-success/20',
    pending: 'bg-default-100 text-default-600 border-default-200',
    on_hold: 'bg-warning/10 text-warning border-warning/20',
  };
  return `px-3 py-1.5  rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${map[s] || 'bg-default-100 text-default-600 border-default-200'}`;
};

const formatHMS = (sec = 0) => {
  const s = Math.max(parseInt(sec || 0), 0);
  const h = String(Math.floor(s / 3600)).padStart(2, '0');
  const m = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
  const ss = String(s % 60).padStart(2, '0');
  return `${h}:${m}:${ss}`;
};

const Index = () => {
  const { hasPermission, loading: authLoading, user } = useAuth();
  const canView = hasPermission('project.view');
  const canCreate = hasPermission('project.create');
  const canEdit = hasPermission('project.edit');
  const canDelete = hasPermission('project.delete');
  const canExport = hasPermission('project.export');
  const canViewValue = hasPermission('project.value') || user?.role === 'superadmin';
  const canViewDocs = hasPermission('project.documents') || user?.role === 'superadmin';

  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [search, setSearch] = useState('');
  const [priority, setPriority] = useState('');
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [developers, setDevelopers] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [selectedDept, setSelectedDept] = useState('');
  const [devSearch, setDevSearch] = useState('');
  const [selectedDevIds, setSelectedDevIds] = useState([]);
  const [formError, setFormError] = useState('');
  const [viewMode, setViewMode] = useState('list');
  const [selectedType, setSelectedType] = useState('');
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [projectTasks, setProjectTasks] = useState([]);
  const [ptTotal, setPtTotal] = useState(0);
  const [ptPage, setPtPage] = useState(1);
  const [ptLimit, setPtLimit] = useState(10);
  const [ptLoading, setPtLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('projects'); // 'projects' | 'amc'
  const [selectedCompany, setSelectedCompany] = useState(null);
  const canViewTasks = hasPermission('task.view');

  const loadCompanyOptions = (inputValue) => {
    return api.get('/company/selection', { params: { search: inputValue, page: 1, limit: 100 } })
      .then(resp => (resp.data.items || []).map(c => ({ value: c._id, label: c.name })))
      .catch(() => []);
  };

  const getAMCStatus = (start, end) => {
    if (!start || !end) return 'Unknown';
    const now = new Date();
    const startDate = new Date(start);
    const endDate = new Date(end);

    if (endDate < now) return 'Expired';
    if (startDate > now) return 'Upcoming';
    return 'Active';
  };

  const amcStatusClass = (s) => {
    const map = {
      Active: 'bg-success/10 text-success border-success/20',
      Upcoming: 'bg-warning/10 text-warning border-warning/20',
      Expired: 'bg-danger/10 text-danger border-danger/20',
      Unknown: 'bg-default-100 text-default-600 border-default-200'
    };
    return `px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${map[s]}`;
  };

  const stats = useMemo(() => {
    const now = new Date();
    const active = items.filter((i) => i.status === 'in_progress').length;
    const completedCount = items.filter((i) => i.status === 'completed').length;
    const overdue = items.filter((i) => i.deadlineDate && new Date(i.deadlineDate) < now && i.status !== 'completed').length;
    return { total, active, completed: completedCount, overdue };
  }, [items, total]);
  const [viewOpen, setViewOpen] = useState(false);
  const [statusMenuOpen, setStatusMenuOpen] = useState(null);
  const [modalStatusOpen, setModalStatusOpen] = useState(false);
  const [error, setError] = useState(null);
  const [details, setDetails] = useState('');

  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('add') === 'true') {
      const companyId = params.get('companyId');
      setEditItem(companyId ? { company: { _id: companyId } } : null);
      setDetails('');
      setModalOpen(true);
      // Clear the query params after opening the modal
      window.history.replaceState({}, '', location.pathname);
    }
  }, [location]);

  useEffect(() => {
    if (modalOpen && editItem) {
      setDetails(editItem.details || '');
    } else if (modalOpen) {
      setDetails('');
    }
  }, [modalOpen, editItem]);

  const fetchProjects = useCallback(async (params = {}) => {
    setLoading(true);
    setError(null);
    try {
      const queryParams = {
        page,
        limit,
        search,
        priority,
        status,
        projectType: selectedType,
        isAMC: activeTab === 'amc',
        ...params
      };
      const resp = await api.get('/projects', { params: queryParams });
      if (resp.data.success) {
        setItems(resp.data.items || []);
        setTotal(resp.data.total || 0);
      } else {
        setError(resp.data.message || 'Failed to fetch projects');
      }
    } catch (err) {
      console.error('Failed to fetch projects:', err);
      setError('Failed to load projects. Please check your connection.');
    } finally {
      setLoading(false);
    }
  }, [page, limit, search, priority, status, selectedType, activeTab]);

  const debouncedSearch = useMemo(
    () =>
      debounce((val) => {
        setPage(1);
        fetchProjects({ search: val, page: 1 });
      }, 500),
    [fetchProjects]
  );

  useEffect(() => {
    return () => {
      // Cleanup debounced function if needed, but our debounce doesn't support it easily
    };
  }, []);

  const loadDevelopers = async () => {
    try {
      const resp = await api.get('/hr/employees-selection', { params: { page: 1, limit: 100 } });
      setDevelopers(resp.data.employees || []);
    } catch (err) {
      console.error('Failed to load developers:', err);
    }
  };
  const loadDepartments = async () => {
    try {
      const resp = await api.get('/department', { params: { page: 1, limit: 100 } });
      setDepartments(resp.data.departments || []);
    } catch (err) {
      console.error('Failed to load departments:', err);
    }
  };

  useEffect(() => {
    if (canView && !authLoading) fetchProjects();
  }, [fetchProjects, canView, authLoading]);

  useEffect(() => {
    if (canView && !authLoading) {
      loadDevelopers();
      loadDepartments();
    }
  }, [canView, authLoading]);

  useEffect(() => {
    if (modalOpen) {
      loadDevelopers();
      loadDepartments();
    }
  }, [modalOpen]);

  useEffect(() => {
    if (modalOpen) {
      setSelectedType(editItem?.projectType || '');
      setSelectedDevIds((editItem?.developers || []).map((d) => d._id));
      setSelectedDept('');
      setDevSearch('');
      if (editItem?.company) {
        setSelectedCompany({ value: editItem.company._id, label: editItem.company.name });
      } else {
        setSelectedCompany(null);
      }
    }
  }, [modalOpen, editItem]);

  const exportData = async (format) => {
    try {
      const resp = await api.get('/projects/export', {
        params: { format, search, priority, status, projectType: selectedType, isAMC: activeTab === 'amc' },
        responseType: 'blob',
      });
      const url = URL.createObjectURL(resp.data);
      const a = document.createElement('a');
      a.href = url;
      a.download = format === 'xlsx' ? 'projects.xlsx' : 'projects.csv';
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export failed:', err);
      alert('Failed to export data');
    }
  };

  const onSubmitProject = async (e) => {
    e.preventDefault();
    setFormError('');
    const setError = (msg) => {
      setFormError(msg);
      toast.error(msg);
    };
    const form = new FormData(e.currentTarget);

    const isAMC = activeTab === 'amc' || editItem?.isAMC;

    if (isAMC) {
      const payload = {
        isAMC: true,
        companyId: form.get('companyId'),
        amcTerm: form.get('amcTerm'),
        contactPerson: form.get('contactPerson')?.trim(),
        amcType: form.get('amcType'),
        amcStartDate: form.get('amcStartDate'),
        amcEndDate: form.get('amcEndDate'),
        contractValue: Number(form.get('contractValue') || 0),
        paymentTerms: form.get('paymentTerms')?.trim(),
        serviceFrequency: form.get('serviceFrequency'),
        details: details,
      };

      if (!payload.companyId) { setError('Company is required'); return; }
      if (!payload.amcType) { setError('AMC Type is required'); return; }
      if (!payload.amcStartDate) { setError('Start Date is required'); return; }
      if (!payload.amcEndDate) { setError('End Date is required'); return; }
      if (new Date(payload.amcEndDate) < new Date(payload.amcStartDate)) { setError('End Date must be >= Start Date'); return; }
      if (!Number.isFinite(payload.contractValue) || payload.contractValue <= 0) { setError('Contract Value must be > 0'); return; }
      if (!payload.serviceFrequency) { setError('Service Frequency is required'); return; }

      if (!payload.serviceFrequency) { setError('Service Frequency is required'); return; }

      const formData = new FormData();
      Object.keys(payload).forEach(k => {
        if (payload[k] !== undefined && payload[k] !== null) formData.append(k, payload[k]);
      });
      const files = form.getAll('documents');
      files.forEach(file => { if (file.size > 0) formData.append('documents', file); });

      try {
        if (editItem?._id) {
          await api.put(`/projects/${editItem._id}`, formData);
        } else {
          await api.post('/projects', formData);
        }
        toast.success(editItem?._id ? 'AMC project updated successfully' : 'AMC project created successfully');
        setModalOpen(false);
        if (!editItem?._id) setPage(1);
        setEditItem(null);
        fetchProjects(!editItem?._id ? { page: 1 } : {});
      } catch (err) {
        const msg = err?.response?.data?.message || 'Failed to save AMC project';
        setError(msg);
      }
      return;
    }

    const payload = {
      companyId: form.get('companyId'),
      name: form.get('name')?.trim(),
      priority: form.get('priority'),
      projectType: form.get('projectType'),
      technology: form.get('technology') || '',
      developers: selectedDevIds,
      startDate: form.get('startDate') || null,
      deadlineDate: form.get('deadlineDate') || null,
      deadlineHours: Number(form.get('deadlineHours') || 0),
      projectValue: Number(form.get('projectValue') || 0),
      details: details,
    };
    if (!payload.companyId || !payload.name || !payload.priority || !payload.projectType) {
      setError('Please fill in all required fields');
      return;
    }
    if (payload.name.length < 2) { setError('Project name must be at least 2 characters'); return; }
    if (payload.name.length > 120) { setError('Project name must be at most 120 characters'); return; }
    if (!priorities.includes(payload.priority)) { setError('Invalid priority'); return; }
    if (!projectTypes.includes(payload.projectType)) { setError('Invalid project type'); return; }
    if (!Number.isFinite(payload.deadlineHours) || payload.deadlineHours < 0) { setError('Deadline hours must be 0 or more'); return; }
    if (!Number.isFinite(payload.projectValue) || payload.projectValue < 0) { setError('Project value must be 0 or more'); return; }
    if (payload.deadlineDate && payload.startDate) {
      if (new Date(payload.deadlineDate) < new Date(payload.startDate)) {
        setError('Deadline date must be after start date');
        return;
      }
    }

    const formData = new FormData();
    Object.keys(payload).forEach(k => {
      if (k === 'developers' && payload[k]) {
        formData.append(k, JSON.stringify(payload[k]));
      } else if (payload[k] !== undefined && payload[k] !== null) {
        formData.append(k, payload[k]);
      }
    });
    const files = form.getAll('documents');
    files.forEach(file => { if (file.size > 0) formData.append('documents', file); });

    try {
      if (editItem?._id) {
        await api.put(`/projects/${editItem._id}`, formData);
      } else {
        await api.post('/projects', formData);
      }
      toast.success(editItem?._id ? 'Project updated successfully' : 'Project created successfully');
      setModalOpen(false);
      if (!editItem?._id) setPage(1);
      setEditItem(null);
      fetchProjects(!editItem?._id ? { page: 1 } : {});
    } catch (err) {
      const msg = err?.response?.data?.message || 'Failed to save project';
      setError(msg);
    }
  };

  const confirmDelete = async (id) => {
    if (!canDelete) return;
    if (window.confirm('Delete this project?')) {
      try {
        await api.delete(`/projects/${id}`);
        fetchProjects();
      } catch (err) {
        console.error('Delete failed:', err);
        alert('Failed to delete project');
      }
    }
  };

  const updateRowStatus = async (id, value) => {
    if (!canEdit) return;
    try {
      await api.patch(`/projects/${id}/status`, { status: value });
      fetchProjects();
    } catch (err) {
      console.error('Status update failed:', err);
    }
  };

  const openProjectDetails = async (project) => {
    setSelectedProject(project);
    setDetailOpen(true);
    setPtPage(1);
    await loadProjectTasks(project._id, 1);
  };

  const openProjectView = (project) => {
    setSelectedProject(project);
    setViewOpen(true);
  };

  const loadProjectTasks = async (id, pageArg = ptPage) => {
    if (!canViewTasks) return;
    setPtLoading(true);
    try {
      const resp = await api.get(`/projects/${id}/tasks`, { params: { page: pageArg, limit: ptLimit } });
      if (resp.data.success) {
        setProjectTasks(resp.data.items || []);
        setPtTotal(resp.data.total || 0);
      }
    } catch (err) {
      console.error('Failed to load tasks:', err);
    } finally {
      setPtLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="size-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!canView) {
    return (
      <>
        <PageMeta title="Projects" />
        <main>
          <PageBreadcrumb title="Projects" subtitle="Project Management" />
          <div className="card">
            <div className="card-body">
              <p className="text-default-500">You do not have permission to view this page.</p>
            </div>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <PageMeta title="Projects" />
      <main>
        <PageBreadcrumb title="Projects" subtitle="Project Management" />

        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => { setActiveTab('projects'); setPage(1); }}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all border ${activeTab === 'projects'
              ? 'bg-primary text-white border-primary shadow-lg shadow-primary/20'
              : 'bg-white text-default-600 border-default-200 hover:bg-default-50'
              }`}
          >
            <LuLayoutGrid className="size-4" />
            Standard Projects
          </button>
          <button
            onClick={() => { setActiveTab('amc'); setPage(1); }}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all border ${activeTab === 'amc'
              ? 'bg-primary text-white border-primary shadow-lg shadow-primary/20'
              : 'bg-white text-default-600 border-default-200 hover:bg-default-50'
              }`}
          >
            <LuSettings className="size-4" />
            AMC Projects
          </button>
        </div>

        <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5 mb-6">
          <div className="group bg-white  rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12  rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                <LuLayoutGrid className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Total Projects</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.total}</div>
              </div>
            </div>
          </div>
          <div className="group bg-white  rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12  rounded-xl bg-warning/10 flex items-center justify-center text-warning group-hover:scale-110 transition-transform duration-300">
                <LuClock className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Active Now</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.active}</div>
              </div>
            </div>
          </div>
          <div className="group bg-white  rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12  rounded-xl bg-success/10 flex items-center justify-center text-success group-hover:scale-110 transition-transform duration-300">
                <LuCheck className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Completed</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.completed}</div>
              </div>
            </div>
          </div>
          <div className="group bg-white  rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12  rounded-xl bg-danger/10 flex items-center justify-center text-danger group-hover:scale-110 transition-transform duration-300">
                <LuClock className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Overdue</div>
                <div className="text-2xl font-black text-danger leading-none">{stats.overdue}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white  rounded-xl p-4 border border-default-200   mb-6">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3 flex-wrap flex-1 min-w-0">
              <div className="relative flex-1 max-w-xs min-w-[200px]">
                <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-default-400" />
                <input
                  type="text"
                  className="form-input pl-9 h-11  rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-sm"
                  placeholder="Search projects..."
                  onChange={(e) => {
                    setSearch(e.target.value);
                    debouncedSearch(e.target.value);
                  }}
                />
              </div>

              <div className="flex flex-wrap gap-2">
                <select
                  className="form-select h-11 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-sm bg-default-50/50"
                  value={priority}
                  onChange={(e) => {
                    setPriority(e.target.value);
                    setPage(1);
                  }}
                >
                  <option value="">All Priority</option>
                  {priorities.map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>

                <select
                  className="form-select h-11 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-sm bg-default-50/50"
                  value={status}
                  onChange={(e) => {
                    setStatus(e.target.value);
                    setPage(1);
                  }}
                >
                  <option value="">All Status</option>
                  {statuses.map((s) => (
                    <option key={s.value} value={s.value}>{s.label}</option>
                  ))}
                </select>

                <select
                  className="form-select h-11 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-sm bg-default-50/50"
                  value={selectedType}
                  onChange={(e) => {
                    setSelectedType(e.target.value);
                    setPage(1);
                  }}
                >
                  <option value="">All Types</option>
                  {projectTypes.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
            </div>

            {canExport && (
              <div className="flex items-center gap-2">
                <button type="button" className="h-11 px-4 flex items-center gap-2 text-xs font-black text-default-600 bg-white border border-default-200 rounded-lg hover:bg-default-50 transition-all uppercase tracking-widest" onClick={() => exportData('csv')}>
                  <LuDownload className="size-3.5" /> CSV
                </button>
                <button type="button" className="h-11 px-4 flex items-center gap-2 text-xs font-black text-default-600 bg-white border border-default-200 rounded-lg hover:bg-default-50 transition-all uppercase tracking-widest" onClick={() => exportData('xlsx')}>
                  <LuDownload className="size-3.5" /> Excel
                </button>
              </div>
            )}

            <div className="flex items-center gap-2">
              <div className="flex items-center bg-default-100  rounded-xl p-1 mr-2">
                <button
                  type="button"
                  className={`size-10 flex items-center justify-center rounded-xl transition-all ${viewMode === 'list' ? 'bg-white text-primary  ' : 'text-default-500 hover:text-default-900'}`}
                  onClick={() => setViewMode('list')}
                  title="List view"
                >
                  <LuList className="size-5" />
                </button>
                <button
                  type="button"
                  className={`size-10 flex items-center justify-center rounded-xl transition-all ${viewMode === 'grid' ? 'bg-white text-primary  ' : 'text-default-500 hover:text-default-900'}`}
                  onClick={() => setViewMode('grid')}
                  title="Grid view"
                >
                  <LuLayoutGrid className="size-5" />
                </button>
              </div>

              {canCreate && (
                <button
                  type="button"
                  className="h-11 px-6 flex items-center gap-2 bg-primary text-white  rounded-xl hover:bg-primary-600 transition-all font-bold active:scale-95"
                  onClick={() => {
                    setEditItem(null);
                    setModalOpen(true);
                  }}
                >
                  <LuPlus className="size-5" /> <span className="hidden sm:inline">{activeTab === 'amc' ? 'Add AMC' : 'Add Project'}</span>
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="bg-white  rounded-xl border border-default-200   overflow-hidden">
          <div className="p-0">

            {viewMode === 'list' ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-default-200">
                  <thead>
                    <tr className="bg-default-50/50">
                      {activeTab === 'amc' ? (
                        <>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Company</th>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Term</th>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">AMC Type</th>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Start Date</th>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">End Date</th>
                          {canViewValue && <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Value</th>}
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Frequency</th>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">AMC Status</th>
                          <th className="py-4 px-6 text-right text-[11px] font-bold text-default-400 uppercase tracking-widest">Actions</th>
                        </>
                      ) : (
                        <>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Project</th>
                          {canViewValue && <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Value</th>}
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Priority</th>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Type</th>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Team</th>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Timeline</th>
                          <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Status</th>
                          <th className="py-4 px-6 text-right text-[11px] font-bold text-default-400 uppercase tracking-widest">Actions</th>
                        </>
                      )}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-default-200 bg-white">
                    {loading ? (
                      <tr>
                        <td className="py-16 px-6 text-center" colSpan={8}>
                          <div className="flex flex-col items-center gap-3">
                            <div className="size-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                            <span className="text-sm text-default-500 font-bold">Fetching projects...</span>
                          </div>
                        </td>
                      </tr>
                    ) : error ? (
                      <tr>
                        <td className="py-16 px-6 text-center" colSpan={8}>
                          <div className="flex flex-col items-center gap-3 text-danger">
                            <LuX className="size-12 opacity-20" />
                            <span className="text-sm font-bold">{error}</span>
                            <button
                              type="button"
                              onClick={() => fetchProjects()}
                              className="px-4 py-2 bg-primary text-white rounded-lg text-xs font-bold"
                            >
                              Retry
                            </button>
                          </div>
                        </td>
                      </tr>
                    ) : items.length === 0 ? (
                      <tr>
                        <td className="py-16 px-6 text-center" colSpan={8}>
                          <div className="flex flex-col items-center gap-3 text-default-300">
                            <LuLayoutGrid className="size-16 opacity-10" />
                            <span className="text-sm font-bold">No projects found in this view</span>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      items.map((p) => (
                        <tr key={p._id} className="hover:bg-default-50/50 transition-colors group">
                          {activeTab === 'amc' ? (
                            <>
                              <td className="py-4 px-6">
                                <div className="flex flex-col min-w-0">
                                  <span className="text-sm font-bold text-default-900 group-hover:text-primary transition-colors">{p.company?.name || 'N/A'}</span>
                                  <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mt-1">{p.contactPerson || ''}</span>
                                </div>
                              </td>
                              <td className="py-4 px-6"><span className="text-xs font-bold text-default-600">{p.amcTerm || '-'}</span></td>
                              <td className="py-4 px-6"><span className="text-xs font-bold text-default-600">{p.amcType || '-'}</span></td>
                              <td className="py-4 px-6"><span className="text-xs font-bold text-default-600">{p.amcStartDate ? new Date(p.amcStartDate).toLocaleDateString() : '-'}</span></td>
                              <td className="py-4 px-6"><span className="text-xs font-bold text-default-600">{p.amcEndDate ? new Date(p.amcEndDate).toLocaleDateString() : '-'}</span></td>
                              {canViewValue && <td className="py-4 px-6"><span className="text-xs font-black text-default-900">₹{p.contractValue?.toLocaleString('en-IN') || '0'}</span></td>}
                              <td className="py-4 px-6"><span className="text-xs font-bold text-default-600">{p.serviceFrequency || '-'}</span></td>
                              <td className="py-4 px-6">
                                <span className={amcStatusClass(getAMCStatus(p.amcStartDate, p.amcEndDate))}>
                                  {getAMCStatus(p.amcStartDate, p.amcEndDate)}
                                </span>
                              </td>
                            </>
                          ) : (
                            <>
                              <td className="py-4 px-6">
                                <div className="flex flex-col min-w-0">
                                  <span className="text-sm font-bold text-default-900 group-hover:text-primary transition-colors">{p.name}</span>
                                  <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mt-1">{p.company?.name || ''}</span>
                                </div>
                              </td>
                              {canViewValue && (
                                <td className="py-4 px-6">
                                  <span className="text-sm font-black text-default-700">₹{p.projectValue?.toLocaleString('en-IN') || '0'}</span>
                                </td>
                              )}
                              <td className="py-4 px-6">
                                <span className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${p.priority === 'High' ? 'bg-danger/10 text-danger border-danger/20' : p.priority === 'Medium' ? 'bg-warning/10 text-warning border-warning/20' : 'bg-success/10 text-success border-success/20'}`}>
                                  {p.priority}
                                </span>
                              </td>
                              <td className="py-4 px-6">
                                <span className={typePillClass(p.projectType || '-')}>{p.projectType || '-'}</span>
                              </td>
                              <td className="py-4 px-6">
                                {(() => {
                                  const devs = p.developers || [];
                                  return devs.length > 0 ? (
                                    <div className="flex -space-x-2.5 overflow-hidden">
                                      {devs.slice(0, 3).map((d, i) => {
                                        const photo = d.documents?.photograph || d.employeePersonal?.profilePhoto;
                                        return (
                                          <div key={i} className="size-8 rounded-full bg-white p-0.5 border border-default-100" title={d.name}>
                                            {photo ? (
                                              <img src={photo} alt={d.name} className="size-full rounded-full object-cover" />
                                            ) : (
                                              <div className="size-full rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-black text-primary uppercase">
                                                {(d.name || '').charAt(0)}
                                              </div>
                                            )}
                                          </div>
                                        );
                                      })}
                                      {devs.length > 3 && (
                                        <div className="size-8 rounded-full bg-white p-0.5   border border-default-100">
                                          <div className="size-full rounded-full bg-default-100 flex items-center justify-center text-[10px] font-black text-default-600 uppercase">
                                            +{devs.length - 3}
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  ) : (
                                    <span className="text-[11px] text-default-400 font-medium italic">Unassigned</span>
                                  );
                                })()}
                              </td>
                              <td className="py-4 px-6">
                                <div className="flex flex-col gap-1.5">
                                  <div className="flex items-center gap-2">
                                    <div className="size-1.5 rounded-full bg-success/50" />
                                    <span className="text-[11px] font-bold text-default-600">{p.startDate ? new Date(p.startDate).toLocaleDateString() : 'N/A'}</span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <div className="size-1.5 rounded-full bg-danger/50" />
                                    <span className="text-[11px] font-bold text-default-600">{p.deadlineDate ? new Date(p.deadlineDate).toLocaleDateString() : 'N/A'}</span>
                                  </div>
                                </div>
                              </td>
                              <td className="py-4 px-6">
                                <div className="relative inline-block">
                                  <button
                                    type="button"
                                    className={`${statusPillClass(p.status)} text-[10px] uppercase tracking-wider transition-all flex items-center gap-2 group/btn`}
                                    onClick={() => canEdit && setStatusMenuOpen(statusMenuOpen === p._id ? null : p._id)}
                                  >
                                    <span>{statuses.find((s) => s.value === p.status)?.label || p.status}</span>
                                    {canEdit && <LuClock className="size-3 opacity-50 group-hover/btn:opacity-100 transition-opacity" />}
                                  </button>
                                  {canEdit && statusMenuOpen === p._id && (
                                    <div className="absolute left-0 top-full mt-2 z-50 w-48  rounded-xl bg-white border border-default-200 p-2 animate-in fade-in slide-in-from-top-3">
                                      <div className="px-3 py-2 mb-1.5 text-[9px] font-black text-default-400 uppercase tracking-[0.2em]">Change Status</div>
                                      {statuses.map((s) => (
                                        <button
                                          key={s.value}
                                          type="button"
                                          className={`flex items-center justify-between w-full text-left px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${p.status === s.value ? 'bg-primary text-white' : 'text-default-600 hover:bg-default-100'}`}
                                          onClick={async () => {
                                            await updateRowStatus(p._id, s.value);
                                            setStatusMenuOpen(null);
                                          }}
                                        >
                                          {s.label}
                                          {p.status === s.value && <LuCheck className="size-3.5" />}
                                        </button>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              </td>
                            </>
                          )}
                          <td className="py-4 px-6 text-right">
                            <div className="flex items-center justify-end gap-1.5 transition-all">
                              <button
                                type="button"
                                className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                                onClick={() => openProjectView(p)}
                                title="View Project"
                              >
                                <LuEye className="size-4" />
                              </button>
                              {canViewTasks && (
                                <button
                                  type="button"
                                  className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                                  onClick={() => openProjectDetails(p)}
                                  title="Project Tasks"
                                >
                                  <LuArrowRight className="size-4" />
                                </button>
                              )}
                              {canEdit && (
                                <button
                                  type="button"
                                  className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                                  onClick={() => {
                                    setEditItem(p);
                                    setModalOpen(true);
                                  }}
                                  title="Edit Project"
                                >
                                  <LuPencil className="size-4" />
                                </button>
                              )}
                              {canDelete && (
                                <button
                                  type="button"
                                  className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-danger hover:text-white hover:border-danger transition-all active:scale-90"
                                  onClick={() => confirmDelete(p._id)}
                                  title="Delete Project"
                                >
                                  <LuTrash2 className="size-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-6 grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-6 bg-default-50/30">
                {loading ? (
                  <div className="col-span-full py-24 text-center flex flex-col items-center gap-3">
                    <div className="size-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                    <span className="text-sm text-default-500 font-bold">Loading projects grid...</span>
                  </div>
                ) : error ? (
                  <div className="col-span-full py-24 text-center flex flex-col items-center gap-3 text-danger">
                    <LuX className="size-12 opacity-20" />
                    <span className="text-sm font-bold">{error}</span>
                    <button
                      type="button"
                      onClick={() => fetchProjects()}
                      className="px-4 py-2 bg-primary text-white rounded-lg text-xs font-bold"
                    >
                      Retry
                    </button>
                  </div>
                ) : items.length === 0 ? (
                  <div className="col-span-full py-24 text-center flex flex-col items-center gap-3 text-default-300">
                    <LuLayoutGrid className="size-16 opacity-10" />
                    <span className="text-sm font-bold">No projects found</span>
                  </div>
                ) : (
                  items.map((p) => (
                    <div key={p._id} className="group bg-white border border-default-200  rounded-xl p-6 transition-all duration-300 flex flex-col relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-1 h-full bg-primary opacity-0 group-hover:opacity-100 transition-opacity" />

                      <div className="flex justify-between items-start mb-5">
                        <div className="flex flex-col min-w-0 flex-1">
                          <div className="flex items-center gap-2 mb-1.5">
                            <span className="text-[10px] font-black text-primary uppercase tracking-widest truncate opacity-70">{p.company?.name || 'N/A'}</span>
                            <div className="size-1 rounded-full bg-default-300" />
                            <span className="text-[10px] font-bold text-default-400 uppercase tracking-wider">{p.projectType}</span>
                          </div>
                          <h6 className="text-base font-black text-default-900 leading-tight group-hover:text-primary transition-colors line-clamp-2 pr-2" title={p.name}>{p.name}</h6>
                          {canViewValue && <p className="text-sm font-black text-default-700 mt-1">₹{p.projectValue?.toLocaleString('en-IN') || '0'}</p>}
                        </div>
                        <span className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all   ${p.priority === 'High' ? 'bg-danger/10 text-danger border-danger/20' : p.priority === 'Medium' ? 'bg-warning/10 text-warning border-warning/20' : 'bg-success/10 text-success border-success/20'}`}>
                          {p.priority}
                        </span>
                      </div>

                      <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-2.5">
                          <div className="-space-x-2.5 overflow-hidden flex">
                            {(p.developers || []).slice(0, 4).map((d, i) => {
                              const photo = d.documents?.photograph || d.employeePersonal?.profilePhoto;
                              return (
                                <div key={i} className="size-8 rounded-full bg-white p-0.5 border border-default-100" title={d.name}>
                                  {photo ? (
                                    <img src={photo} alt={d.name} className="size-full rounded-full object-cover" />
                                  ) : (
                                    <div className="size-full rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-black text-primary uppercase">
                                      {(d.name || '').charAt(0)}
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                            {(p.developers || []).length > 4 && (
                              <div className="size-8 rounded-full bg-white p-0.5 border border-default-100">
                                <div className="size-full rounded-full bg-default-100 flex items-center justify-center text-[10px] font-black text-default-600 uppercase">
                                  +{(p.developers || []).length - 4}
                                </div>
                              </div>
                            )}
                          </div>
                          <div className="flex flex-col">
                            <span className="text-[10px] font-black text-default-900 leading-none">{(p.developers || []).length}</span>
                            <span className="text-[9px] font-bold text-default-400 uppercase tracking-tighter">Team</span>
                          </div>
                        </div>

                        <div className="relative">
                          <button
                            type="button"
                            className={`${statusPillClass(p.status)} text-[10px] uppercase tracking-wider transition-all flex items-center gap-2`}
                            onClick={() => canEdit && setStatusMenuOpen(statusMenuOpen === p._id ? null : p._id)}
                          >
                            <span>{statuses.find((s) => s.value === p.status)?.label || p.status}</span>
                            {canEdit && <LuClock className="size-3 opacity-50" />}
                          </button>
                          {canEdit && statusMenuOpen === p._id && (
                            <div className="absolute right-0 bottom-full mb-2 z-50 w-44  rounded-xl bg-white border border-default-200 p-2 animate-in fade-in slide-in-from-bottom-3">
                              {statuses.map((s) => (
                                <button
                                  key={s.value}
                                  type="button"
                                  className={`flex items-center justify-between w-full text-left px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${p.status === s.value ? 'bg-primary text-white' : 'text-default-600 hover:bg-default-100'}`}
                                  onClick={async () => {
                                    await updateRowStatus(p._id, s.value);
                                    setStatusMenuOpen(null);
                                  }}
                                >
                                  {s.label}
                                  {p.status === s.value && <LuCheck className="size-3.5" />}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="mt-auto pt-5 border-t border-default-100 flex items-end justify-between">
                        <div className="flex flex-col gap-2">
                          <div className="flex items-center gap-2">
                            <LuCalendar className="size-3.5 text-default-400" />
                            <span className="text-[11px] font-bold text-default-600">{p.deadlineDate ? new Date(p.deadlineDate).toLocaleDateString() : 'N/A'}</span>
                          </div>
                          <div className="flex gap-1 flex-wrap">
                            <span className={typePillClass(p.projectType || '-')}>{p.projectType || '-'}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                            onClick={() => openProjectView(p)}
                            title="View Project"
                          >
                            <LuEye className="size-4" />
                          </button>
                          {canViewTasks && (
                            <button
                              type="button"
                              className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                              onClick={() => openProjectDetails(p)}
                              title="Project Tasks"
                            >
                              <LuArrowRight className="size-4" />
                            </button>
                          )}
                          {canEdit && (
                            <button
                              type="button"
                              className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                              onClick={() => {
                                setEditItem(p);
                                setModalOpen(true);
                              }}
                              title="Edit Project"
                            >
                              <LuPencil className="size-4" />
                            </button>
                          )}
                          {canDelete && (
                            <button
                              type="button"
                              className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-danger hover:text-white hover:border-danger transition-all active:scale-90"
                              onClick={() => confirmDelete(p._id)}
                              title="Delete Project"
                            >
                              <LuTrash2 className="size-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
            <div className="flex items-center justify-between p-6 border-t border-default-100 bg-default-50/50">
              <div className="text-xs font-bold text-default-500 uppercase tracking-widest">
                Showing <span className="text-default-900">{(page - 1) * limit + 1}</span> to <span className="text-default-900">{Math.min(page * limit, total)}</span> of <span className="text-default-900">{total}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-white border border-default-200 rounded-xl p-1  ">
                  <button
                    type="button"
                    className="h-9 px-4 flex items-center justify-center rounded-lg font-bold text-xs transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600"
                    disabled={page === 1}
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                  >
                    Prev
                  </button>
                  <div className="w-px h-4 bg-default-200 mx-1" />
                  <button
                    type="button"
                    className="h-9 px-4 flex items-center justify-center rounded-lg font-bold text-xs transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600"
                    disabled={page * limit >= total}
                    onClick={() => setPage((p) => p + 1)}
                  >
                    Next
                  </button>
                </div>
                <select
                  className="form-select h-11 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-xs bg-white   min-w-[100px]"
                  value={limit}
                  onChange={(e) => {
                    setLimit(parseInt(e.target.value));
                    setPage(1);
                  }}
                >
                  <option value={10}>10 Per Page</option>
                  <option value={20}>20 Per Page</option>
                  <option value={50}>50 Per Page</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {detailOpen && (
          <div className="fixed inset-0 bg-default-900/40 backdrop-blur-sm flex items-center justify-center z-[100] p-4 animate-in fade-in duration-300">
            <div className="relative bg-white rounded-3xl w-full max-w-3xl mx-auto overflow-hidden animate-in zoom-in-95 duration-300 border border-default-100">
              <div className="absolute inset-0 bg-default-900/40 backdrop-blur-sm -z-10" onClick={() => setDetailOpen(false)} />

              <div className="p-8">
                {/* Header */}
                <div className="flex justify-between items-center mb-8">
                  <div className="flex items-center gap-4">
                    <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                      <LuListTodo className="size-6" />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">Project Tasks</h3>
                      <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">{selectedProject?.name || 'Loading...'}</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                    onClick={() => setDetailOpen(false)}
                  >
                    <LuX className="size-5" />
                  </button>
                </div>

                <div className="space-y-6">
                  {selectedProject && (
                    <div className="p-4 bg-default-50 rounded-2xl border border-default-100">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Project Overview</p>
                        <span className={`px-2 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-widest ${selectedProject.priority === 'High' ? 'bg-danger/10 text-danger' :
                          selectedProject.priority === 'Medium' ? 'bg-warning/10 text-warning' :
                            'bg-success/10 text-success'
                          }`}>
                          {selectedProject.priority}
                        </span>
                      </div>
                      <p className="text-sm font-bold text-default-900">{selectedProject.company?.name} • {(selectedProject.developers || []).map(d => d.name).join(', ')}</p>
                    </div>
                  )}

                  {!canViewTasks ? (
                    <div className="py-12 text-center">
                      <p className="text-sm font-bold text-default-500 uppercase tracking-widest">You do not have permission to view tasks.</p>
                    </div>
                  ) : (
                    <>
                      <div className="overflow-hidden border border-default-100 rounded-2xl">
                        <table className="min-w-full divide-y divide-default-100">
                          <thead className="bg-default-50">
                            <tr>
                              <th className="py-3 px-4 text-left text-[10px] font-black text-default-400 uppercase tracking-widest">Title</th>
                              <th className="py-3 px-4 text-left text-[10px] font-black text-default-400 uppercase tracking-widest">Priority</th>
                              <th className="py-3 px-4 text-left text-[10px] font-black text-default-400 uppercase tracking-widest">Assignees</th>
                              <th className="py-3 px-4 text-left text-[10px] font-black text-default-400 uppercase tracking-widest">Status</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-default-100 bg-white">
                            {ptLoading ? (
                              <tr>
                                <td className="py-8 px-4 text-center" colSpan={4}>
                                  <div className="flex flex-col items-center gap-2">
                                    <div className="size-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Loading tasks...</p>
                                  </div>
                                </td>
                              </tr>
                            ) : projectTasks.length === 0 ? (
                              <tr>
                                <td className="py-12 px-4 text-center" colSpan={4}>
                                  <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">No tasks found</p>
                                </td>
                              </tr>
                            ) : (
                              projectTasks.map((t) => (
                                <tr key={t._id} className="hover:bg-default-50/50 transition-all">
                                  <td className="py-3 px-4 text-xs font-bold text-default-900">{t.title}</td>
                                  <td className="py-3 px-4">
                                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-widest ${t.priority === 'High' ? 'bg-danger/10 text-danger' :
                                      t.priority === 'Medium' ? 'bg-warning/10 text-warning' :
                                        'bg-success/10 text-success'
                                      }`}>
                                      {t.priority}
                                    </span>
                                  </td>
                                  <td className="py-3 px-4 text-xs font-bold text-default-600">
                                    {(t.assignees || []).map(a => a.name).join(', ') || '-'}
                                  </td>
                                  <td className="py-3 px-4">
                                    <span className="px-2 py-0.5 bg-default-100 text-default-700 rounded-lg text-[10px] font-black uppercase tracking-widest">
                                      {t.status}
                                    </span>
                                  </td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>

                      <div className="flex items-center justify-between">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">
                          Showing {(ptPage - 1) * ptLimit + 1} to {Math.min(ptPage * ptLimit, ptTotal)} of {ptTotal}
                        </p>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            className="h-10 px-4 bg-white border border-default-200 text-default-700 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-default-50 transition-all active:scale-95 disabled:opacity-50"
                            disabled={ptPage === 1}
                            onClick={() => { const n = Math.max(1, ptPage - 1); setPtPage(n); loadProjectTasks(selectedProject._id, n); }}
                          >
                            Prev
                          </button>
                          <button
                            type="button"
                            className="h-10 px-4 bg-white border border-default-200 text-default-700 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-default-50 transition-all active:scale-95 disabled:opacity-50"
                            disabled={ptPage * ptLimit >= ptTotal}
                            onClick={() => { const n = ptPage + 1; setPtPage(n); loadProjectTasks(selectedProject._id, n); }}
                          >
                            Next
                          </button>
                          <select
                            className="form-select h-10 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-[10px] uppercase tracking-widest bg-white"
                            value={ptLimit}
                            onChange={(e) => {
                              const v = parseInt(e.target.value);
                              setPtLimit(v);
                              setPtPage(1);
                              loadProjectTasks(selectedProject._id, 1);
                            }}
                          >
                            <option value={10}>10</option>
                            <option value={20}>20</option>
                            <option value={50}>50</option>
                          </select>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {viewOpen && selectedProject && (
          <div className="fixed inset-0 bg-default-900/40 backdrop-blur-sm flex items-center justify-center z-[100] p-4 animate-in fade-in duration-300">
            <div className="relative bg-white rounded-3xl w-full max-w-3xl mx-auto overflow-hidden animate-in zoom-in-95 duration-300 border border-default-100 shadow-2xl">
              <div className="absolute inset-0 bg-default-900/40 backdrop-blur-sm -z-10" onClick={() => setViewOpen(false)} />

              <div className="p-10">
                {/* Header */}
                <div className="flex justify-between items-center mb-10">
                  <div className="flex items-center gap-5">
                    <div className="size-14 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                      <LuFolder className="size-7" />
                    </div>
                    <div>
                      <h3 className="text-xl font-black text-default-900 uppercase tracking-tight">Project Details</h3>
                      <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">{selectedProject.company?.name || 'GENMINDZ'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    {canEdit && (
                      <button
                        type="button"
                        className="h-12 px-8 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all active:scale-95 shadow-sm flex items-center gap-2"
                        onClick={() => {
                          setViewOpen(false);
                          setEditItem(selectedProject);
                          setModalOpen(true);
                        }}
                      >
                        <LuPencil className="size-4" />
                        Edit Project
                      </button>
                    )}
                    {canViewTasks && (
                      <button
                        type="button"
                        className="h-12 px-8 bg-white border border-default-200 text-default-700 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-default-50 transition-all active:scale-95 shadow-sm"
                        onClick={() => openProjectDetails(selectedProject)}
                      >
                        View Tasks
                      </button>
                    )}
                    <button
                      type="button"
                      className="size-12 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                      onClick={() => setViewOpen(false)}
                    >
                      <LuX className="size-6" />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-x-12 gap-y-8">
                  {selectedProject.isAMC ? (
                    <>
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Company</p>
                        <p className="text-base font-black text-default-900">{selectedProject.company?.name || '-'}</p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Contact Person</p>
                        <p className="text-base font-black text-default-900">{selectedProject.contactPerson || '-'}</p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Term</p>
                        <p className="text-base font-black text-default-900">{selectedProject.amcTerm || '-'}</p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">AMC Type</p>
                        <p className="text-base font-black text-default-900">{selectedProject.amcType || '-'}</p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">AMC Status</p>
                        <span className={amcStatusClass(getAMCStatus(selectedProject.amcStartDate, selectedProject.amcEndDate))}>
                          {getAMCStatus(selectedProject.amcStartDate, selectedProject.amcEndDate)}
                        </span>
                      </div>
                      {canViewValue && (
                        <div className="space-y-2">
                          <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Contract Value</p>
                          <p className="text-base font-black text-default-900">₹{selectedProject.contractValue?.toLocaleString('en-IN') || '0'}</p>
                        </div>
                      )}
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Start Date</p>
                        <p className="text-base font-black text-default-900">{selectedProject.amcStartDate ? new Date(selectedProject.amcStartDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'}</p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">End Date</p>
                        <p className="text-base font-black text-default-900">{selectedProject.amcEndDate ? new Date(selectedProject.amcEndDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'}</p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Payment Terms</p>
                        <p className="text-base font-black text-default-900">{selectedProject.paymentTerms || '-'}</p>
                      </div>
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Frequency</p>
                        <p className="text-base font-black text-default-900">{selectedProject.serviceFrequency || '-'}</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Company</p>
                        <p className="text-base font-black text-default-900">{selectedProject.company?.name || '-'}</p>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Priority</p>
                        <div>
                          <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest ${selectedProject.priority === 'High' ? 'bg-danger/10 text-danger' :
                            selectedProject.priority === 'Medium' ? 'bg-warning/10 text-warning' :
                              'bg-success/10 text-success'
                            }`}>
                            {selectedProject.priority}
                          </span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Project Type</p>
                        <div className={typePillClass(selectedProject.projectType || '-')} style={{ display: 'inline-block' }}>
                          {selectedProject.projectType || '-'}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Technology</p>
                        <p className="text-base font-black text-default-900">{selectedProject.technology || '-'}</p>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Developers</p>
                        <p className="text-base font-black text-default-900">{(selectedProject.developers || []).map((d) => d.name).join(', ') || '-'}</p>
                      </div>

                      <div className="space-y-2 relative overflow-visible">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Status</p>
                        <div className="relative inline-block">
                          <button
                            type="button"
                            className={statusPillClass(selectedProject.status)}
                            onClick={() => canEdit && setModalStatusOpen(!modalStatusOpen)}
                          >
                            {statuses.find((s) => s.value === selectedProject.status)?.label || selectedProject.status}
                          </button>
                          {canEdit && modalStatusOpen && (
                            <div className="absolute left-0 top-full mt-2 z-50 w-48 rounded-2xl border border-default-200 bg-white shadow-xl p-2 animate-in fade-in zoom-in-95 duration-200">
                              {statuses.map((s) => (
                                <button
                                  key={s.value}
                                  type="button"
                                  className={`w-full text-left px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${selectedProject.status === s.value ? 'bg-primary text-white' : 'hover:bg-default-50 text-default-600'
                                    }`}
                                  onClick={async () => {
                                    await updateRowStatus(selectedProject._id, s.value);
                                    setSelectedProject((prev) => ({ ...prev, status: s.value }));
                                    setModalStatusOpen(false);
                                  }}
                                >
                                  {s.label}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Start Date</p>
                        <p className="text-base font-black text-default-900">{selectedProject.startDate ? new Date(selectedProject.startDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'}</p>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Deadline Date</p>
                        <p className="text-base font-black text-default-900">{selectedProject.deadlineDate ? new Date(selectedProject.deadlineDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '-'}</p>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Deadline Hours</p>
                        <p className="text-base font-black text-default-900">{selectedProject.deadlineHours ?? '-'}</p>
                      </div>

                      <div className="space-y-2">
                        <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Time Spent</p>
                        <p className="text-base font-black text-default-900">{formatHMS(selectedProject.timeSpentSeconds)}</p>
                      </div>

                      {canViewValue && (
                        <div className="space-y-2">
                          <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Project Value</p>
                          <p className="text-base font-black text-default-900">₹{selectedProject.projectValue?.toLocaleString('en-IN') || '0'}</p>
                        </div>
                      )}
                    </>
                  )}

                  <div className="col-span-2 space-y-3 pt-8 border-t border-default-100">
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Project Details</p>
                    <div className="text-sm font-bold text-default-600 leading-relaxed italic" dangerouslySetInnerHTML={{ __html: selectedProject.details || 'No details provided' }} />
                  </div>

                  {canViewDocs && selectedProject.documents && selectedProject.documents.length > 0 && (
                    <div className="col-span-2 space-y-3 pt-4 border-t border-default-100">
                      <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em]">Attached Documents</p>
                      <div className="grid grid-cols-2 gap-3">
                        {selectedProject.documents.map((doc, idx) => {
                          const baseUrl = import.meta.env.VITE_API_BASE_URL ? import.meta.env.VITE_API_BASE_URL.replace(/\/api.*$/, '') : '';
                          const fileUrl = doc.url.startsWith('http') ? doc.url : `${baseUrl}${doc.url}`;
                          return (
                            <div key={idx} className="flex items-center justify-between p-3 bg-default-50 rounded-xl border border-default-100 group">
                              <div className="flex items-center gap-3 overflow-hidden">
                                <div className="size-8 rounded-lg bg-white border border-default-200 flex items-center justify-center shrink-0">
                                  <LuFolder className="size-4 text-primary" />
                                </div>
                                <span className="text-xs font-bold text-default-900 truncate" title={doc.name}>{doc.name}</span>
                              </div>
                              <a href={fileUrl} target="_blank" rel="noreferrer" className="size-8 shrink-0 flex items-center justify-center bg-white text-default-600 hover:text-primary hover:border-primary rounded-lg border border-default-200 transition-all" title="Download">
                                <LuDownload className="size-4" />
                              </a>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {modalOpen && (
          <div className="fixed inset-0 bg-default-900/40 backdrop-blur-sm flex items-center justify-center z-[100] p-4 animate-in fade-in duration-300">
            <div className="relative bg-white rounded-3xl w-full max-w-4xl mx-auto overflow-hidden animate-in zoom-in-95 duration-300 border border-default-100 flex flex-col max-h-[90vh]">
              <div className="px-8 py-6 border-b border-default-100 flex items-center justify-between bg-white">
                <div className="flex items-center gap-4">
                  <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                    {editItem ? <LuPencil className="size-6" /> : <LuFolderPlus className="size-6" />}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">{editItem?._id ? 'Edit Project' : 'Add New Project'}</h3>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">{editItem?._id ? 'Update existing project details' : 'Create a new project workspace'}</p>
                  </div>
                </div>
                <button
                  type="button"
                  className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                  onClick={() => {
                    setModalOpen(false);
                    setEditItem(null);
                  }}
                >
                  <LuX className="size-5" />
                </button>
              </div>

              <form onSubmit={onSubmitProject} className="flex flex-col overflow-hidden">
                <div className="p-8 overflow-y-auto custom-scroll">
                  {(activeTab === 'amc' || editItem?.isAMC) ? (
                    <div className="grid md:grid-cols-2 gap-8">
                      {/* AMC Form Content */}
                      <div className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="size-8 bg-default-100 rounded-lg flex items-center justify-center text-default-600">
                            <LuBuilding className="size-4" />
                          </div>
                          <h4 className="text-[10px] font-black text-default-400 uppercase tracking-widest">Basic Information</h4>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Company *</label>
                          <AsyncSelect
                            className="text-xs font-bold"
                            classNamePrefix="react-select"
                            cacheOptions
                            defaultOptions
                            loadOptions={loadCompanyOptions}
                            value={selectedCompany}
                            onChange={setSelectedCompany}
                            placeholder="Select Company"
                            isClearable
                            styles={{
                              control: (base) => ({
                                ...base,
                                minHeight: '3rem',
                                borderRadius: '0.75rem',
                                borderColor: '#e5e7eb',
                                backgroundColor: 'rgba(249, 250, 251, 0.5)',
                                fontSize: '0.75rem',
                                fontWeight: 700,
                              }),
                              menu: (base) => ({
                                ...base,
                                fontSize: '0.75rem',
                                fontWeight: 700,
                                zIndex: 9999
                              })
                            }}
                          />
                          <input type="hidden" name="companyId" value={selectedCompany?.value || ''} />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Term</label>
                          <select name="amcTerm" className="form-select h-12 px-4 w-full rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-xs bg-default-50/50" defaultValue={editItem?.amcTerm || ''}>
                            <option value="">Select Term</option>
                            {['Term 1', 'Term 2', 'Term 3'].map((t) => (
                              <option key={t} value={t}>{t}</option>
                            ))}
                          </select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Contact Person</label>
                          <input name="contactPerson" className="form-input h-12 px-4 w-full rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-xs bg-default-50/50" placeholder="Contact Person Name" defaultValue={editItem?.contactPerson || ''} />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">AMC Type *</label>
                          <select name="amcType" className="form-select h-12 px-4 w-full rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-xs bg-default-50/50" defaultValue={editItem?.amcType || ''} required>
                            <option value="">Select AMC Type</option>
                            {['Annual', 'Quarterly', 'Monthly'].map((t) => (
                              <option key={t} value={t}>{t}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="size-8 bg-default-100 rounded-lg flex items-center justify-center text-default-600">
                            <LuCalendar className="size-4" />
                          </div>
                          <h4 className="text-[10px] font-black text-default-400 uppercase tracking-widest">AMC Details</h4>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Start Date *</label>
                            <input type="date" name="amcStartDate" className="form-input h-12 px-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50" defaultValue={editItem?.amcStartDate ? new Date(editItem.amcStartDate).toISOString().split('T')[0] : ''} required />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">End Date *</label>
                            <input type="date" name="amcEndDate" className="form-input h-12 px-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50" defaultValue={editItem?.amcEndDate ? new Date(editItem.amcEndDate).toISOString().split('T')[0] : ''} required />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Contract Value *</label>
                          <input type="number" name="contractValue" className="form-input h-12 px-4 w-full rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-xs bg-default-50/50" placeholder="0" defaultValue={editItem?.contractValue || 0} required />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Payment Terms</label>
                            <select name="paymentTerms" className="form-select h-12 px-4 w-full rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-xs bg-default-50/50" defaultValue={editItem?.paymentTerms || ''}>
                              <option value="">Select Terms</option>
                              {['One-time', 'Installments'].map((t) => (
                                <option key={t} value={t}>{t}</option>
                              ))}
                            </select>
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Service Frequency *</label>
                            <select name="serviceFrequency" className="form-select h-12 px-4 w-full rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-xs bg-default-50/50" defaultValue={editItem?.serviceFrequency || ''} required>
                              <option value="">Select Frequency</option>
                              {['Monthly', 'Quarterly', 'Custom'].map((t) => (
                                <option key={t} value={t}>{t}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>

                      <div className="col-span-2 space-y-2">
                        <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Documents</label>
                        <input type="file" name="documents" multiple className="form-input h-12 px-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50 pt-3" />
                        {editItem?.documents?.length > 0 && (
                          <div className="mt-2 text-[10px] font-bold text-default-500 uppercase tracking-widest">
                            Currently {editItem.documents.length} document(s) attached.
                          </div>
                        )}
                      </div>

                      <div className="col-span-2 space-y-2">
                        <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Description / Scope of Work</label>
                        <div className="bg-white rounded-2xl border border-default-200 overflow-hidden">
                          <ReactQuill
                            theme="snow"
                            value={details}
                            onChange={setDetails}
                            className="h-48 mb-12"
                          />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="grid md:grid-cols-2 gap-8">
                      {/* Basic Info Section */}
                      <div className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="size-8 bg-default-100 rounded-lg flex items-center justify-center text-default-600">
                            <LuBuilding className="size-4" />
                          </div>
                          <h4 className="text-[10px] font-black text-default-400 uppercase tracking-widest">Basic Information</h4>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Company *</label>
                          <AsyncSelect
                            className="text-xs font-bold"
                            classNamePrefix="react-select"
                            cacheOptions
                            defaultOptions
                            loadOptions={loadCompanyOptions}
                            value={selectedCompany}
                            onChange={setSelectedCompany}
                            placeholder="Select Company"
                            isClearable
                            styles={{
                              control: (base) => ({
                                ...base,
                                minHeight: '3rem',
                                borderRadius: '0.75rem',
                                borderColor: '#e5e7eb',
                                backgroundColor: 'rgba(249, 250, 251, 0.5)',
                                fontSize: '0.75rem',
                                fontWeight: 700,
                              }),
                              menu: (base) => ({
                                ...base,
                                fontSize: '0.75rem',
                                fontWeight: 700,
                                zIndex: 9999
                              })
                            }}
                          />
                          <input type="hidden" name="companyId" value={selectedCompany?.value || ''} />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Project Name *</label>
                          <input name="name" className="form-input h-12 px-4 w-full rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-xs bg-default-50/50" placeholder="Enter project name" defaultValue={editItem?.name || ''} required />
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Project Value</label>
                          <input type="number" name="projectValue" className="form-input h-12 px-4 w-full rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-xs bg-default-50/50" placeholder="Enter project value" defaultValue={editItem?.projectValue || 0} />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Priority *</label>
                            <select name="priority" className="form-select h-12 px-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50" defaultValue={editItem?.priority || ''} required>
                              <option value="">Select Priority</option>
                              {priorities.map((p) => (
                                <option key={p} value={p}>{p}</option>
                              ))}
                            </select>
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Project Type *</label>
                            <select
                              name="projectType"
                              className="form-select h-12 px-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50"
                              defaultValue={editItem?.projectType || ''}
                              onChange={(e) => setSelectedType(e.target.value)}
                              required
                            >
                              <option value="">Select Type</option>
                              {projectTypes.map((t) => (
                                <option key={t} value={t}>{t}</option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Technology</label>
                          <select
                            name="technology"
                            className="form-select h-12 px-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50"
                            defaultValue={editItem?.technology || ''}
                            disabled={!selectedType}
                          >
                            <option value="">{selectedType ? 'Select Technology' : 'Select Project Type first'}</option>
                            {(technologyMap[selectedType] || []).map((t) => (
                              <option key={t} value={t}>{t}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      {/* Timeline & Resources Section */}
                      <div className="space-y-6">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="size-8 bg-default-100 rounded-lg flex items-center justify-center text-default-600">
                            <LuCalendar className="size-4" />
                          </div>
                          <h4 className="text-[10px] font-black text-default-400 uppercase tracking-widest">Timeline & Team</h4>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Start Date</label>
                            <input
                              type="date"
                              name="startDate"
                              className="form-input h-12 px-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50"
                              defaultValue={editItem?.startDate ? new Date(editItem.startDate).toISOString().split('T')[0] : ''}
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Deadline Date</label>
                            <input
                              type="date"
                              name="deadlineDate"
                              className="form-input h-12 px-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50"
                              defaultValue={editItem?.deadlineDate ? new Date(editItem.deadlineDate).toISOString().split('T')[0] : ''}
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Estimated Hours</label>
                          <div className="relative">
                            <LuClock className="absolute left-4 top-1/2 -translate-y-1/2 size-4 text-default-400" />
                            <input
                              type="number"
                              name="deadlineHours"
                              className="form-input h-12 pl-12 pr-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50"
                              placeholder="0"
                              defaultValue={editItem?.deadlineHours || 0}
                              required
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Assign Team Members</label>
                          <div className="space-y-4">
                            <div className="relative">
                              <LuUsers className="absolute left-4 top-1/2 -translate-y-1/2 size-4 text-default-400" />
                              <input
                                type="text"
                                className="form-input h-12 pl-12 pr-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50"
                                placeholder="Search members..."
                                onChange={(e) => setDevSearch(e.target.value.toLowerCase())}
                              />
                            </div>

                            <div className="flex items-center gap-2">
                              <LuBuilding className="size-3.5 text-default-400" />
                              <select
                                className="form-select flex-1 text-xs font-bold rounded-xl border-default-200 bg-default-50/50 h-10 px-3"
                                value={selectedDept}
                                onChange={(e) => setSelectedDept(e.target.value)}
                              >
                                <option value="">All Departments</option>
                                {departments.map(d => (
                                  <option key={d._id} value={d.name}>{d.name}</option>
                                ))}
                              </select>
                            </div>

                            <div className="border border-default-100 rounded-2xl p-2 max-h-48 overflow-y-auto custom-scroll bg-default-50/30">
                              <div className="grid grid-cols-1 gap-1">
                                {developers
                                  .filter(d => (!selectedDept || d.department === selectedDept) && (!devSearch || d.name.toLowerCase().includes(devSearch)))
                                  .map((dev) => (
                                    <label key={dev._id} className="flex items-center gap-3 p-2 hover:bg-white hover:shadow-sm rounded-xl cursor-pointer transition-all group">
                                      <input
                                        type="checkbox"
                                        className="size-4 rounded-lg border-default-300 text-primary focus:ring-primary transition-all"
                                        checked={selectedDevIds.includes(dev._id)}
                                        onChange={(e) => {
                                          if (e.target.checked) setSelectedDevIds(prev => [...prev, dev._id]);
                                          else setSelectedDevIds(prev => prev.filter(id => id !== dev._id));
                                        }}
                                      />
                                      <div className="flex flex-col">
                                        <span className="text-xs font-bold text-default-900 group-hover:text-primary transition-colors">{dev.name}</span>
                                        <span className="text-[9px] font-black text-default-400 uppercase tracking-widest">{dev.department} • {dev.designation}</span>
                                      </div>
                                    </label>
                                  ))}
                              </div>
                            </div>

                            {selectedDevIds.length > 0 && (
                              <div className="flex flex-wrap gap-1.5 pt-2">
                                {selectedDevIds.map(id => {
                                  const dev = developers.find(d => d._id === id);
                                  return dev ? (
                                    <span key={id} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-primary/10 text-primary text-[10px] font-bold border border-primary/20 animate-in zoom-in-95">
                                      {dev.name}
                                      <button
                                        type="button"
                                        onClick={() => setSelectedDevIds(prev => prev.filter(i => i !== id))}
                                        className="hover:bg-primary/20 rounded-full p-0.5 transition-colors"
                                      >
                                        <LuX className="size-3" />
                                      </button>
                                    </span>
                                  ) : null;
                                })}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="col-span-2 space-y-2">
                        <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Documents</label>
                        <input type="file" name="documents" multiple className="form-input h-12 px-4 w-full rounded-xl border-default-200 font-bold text-xs bg-default-50/50 pt-3" />
                        {editItem?.documents?.length > 0 && (
                          <div className="mt-2 text-[10px] font-bold text-default-500 uppercase tracking-widest">
                            Currently {editItem.documents.length} document(s) attached.
                          </div>
                        )}
                      </div>

                      <div className="col-span-2 space-y-2">
                        <label className="text-[10px] font-black text-default-400 uppercase tracking-widest ml-1">Project Details</label>
                        <div className="bg-white rounded-2xl border border-default-200 overflow-hidden">
                          <ReactQuill
                            theme="snow"
                            value={details}
                            onChange={setDetails}
                            className="h-48 mb-12"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="px-8 py-6 border-t border-default-100 bg-default-50/50 flex items-center justify-between">
                  <div className="text-[10px] font-bold text-default-400 uppercase tracking-widest">
                    * Required fields
                  </div>
                  <div className="flex items-center gap-3">
                    {formError && <div className="text-danger text-[10px] font-black uppercase tracking-widest">{formError}</div>}
                    <button
                      type="button"
                      className="h-12 px-6 text-[10px] font-black uppercase tracking-widest text-default-600 hover:bg-default-100 rounded-xl transition-all active:scale-95"
                      onClick={() => {
                        setModalOpen(false);
                        setEditItem(null);
                      }}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="h-12 px-8 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all shadow-lg shadow-primary/20 active:scale-95 flex items-center gap-2"
                    >
                      {editItem ? <LuSave className="size-4" /> : <LuPlus className="size-4" />}
                      {editItem ? 'Update Project' : 'Create Project'}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </>
  );
};

export default Index;
