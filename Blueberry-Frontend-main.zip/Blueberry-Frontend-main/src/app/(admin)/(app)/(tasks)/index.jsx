import { useEffect, useMemo, useState } from 'react';
import AsyncSelect from 'react-select/async';
import ReactQuill from 'react-quill-new';
import 'react-quill-new/dist/quill.snow.css';
import PageMeta from '@/components/PageMeta';
import PageBreadcrumb from '@/components/PageBreadcrumb';
import api from '@/config/api';
import { useAuth } from '@/context/AuthContext';
import { LuDownload, LuPencil, LuPlus, LuSearch, LuTrash2, LuListTodo, LuPlay, LuPause, LuSquare, LuCheck, LuOctagonAlert, LuList, LuLayoutGrid, LuX, LuClock, LuUsers, LuTag, LuCalendar, LuEye, LuFolder } from 'react-icons/lu';
import TableView from './components/TableView';
import CalendarView from './components/CalendarView';
import { toast } from 'react-hot-toast';

const debounce = (fn, delay = 400) => {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), delay);
  };
};

const priorities = ['High', 'Medium', 'Low'];
const statuses = [
  { value: 'todo', label: 'To Do' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'paused', label: 'Paused' },
  { value: 'blocked', label: 'Blocked' },
  { value: 'done', label: 'Done' },
];
const projectTypes = ['Digital Marketing', 'Web Application', 'Design', 'Mobile App', 'SEO'];
const technologyMap = {
  'Web Application': ['React', 'Vue', 'Angular', 'Node.js', 'Django', 'Laravel', 'Other'],
  'Mobile App': ['Flutter', 'React Native', 'Android', 'iOS', 'Ionic', 'Other'],
  Design: ['Figma', 'Adobe XD', 'Photoshop', 'Illustrator', 'Other'],
  'Digital Marketing': ['Google Ads', 'Facebook Ads', 'Email Marketing', 'Social Media', 'Content', 'Other'],
  SEO: ['On-Page', 'Off-Page', 'Technical SEO', 'Local SEO', 'Other'],
};

const Index = () => {
  const { hasPermission, user } = useAuth();
  const canView = hasPermission('task.view');
  const canCreate = hasPermission('task.create');
  const canEdit = hasPermission('task.edit');
  const canDelete = hasPermission('task.delete');
  const canAssign = hasPermission('task.assign');
  const canExport = hasPermission('task.export');

  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [search, setSearch] = useState('');
  const [priority, setPriority] = useState('');
  const [status, setStatus] = useState('');
  const [projectId, setProjectId] = useState('');
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [viewItem, setViewItem] = useState(null);
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [selectedProjectFilter, setSelectedProjectFilter] = useState(null);
  const [selectedFormProject, setSelectedFormProject] = useState(null);
  const [currentProject, setCurrentProject] = useState(null);
  const [developers, setDevelopers] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [selectedDept, setSelectedDept] = useState('');
  const [assigneeSearch, setAssigneeSearch] = useState('');
  const [selectedAssigneeIds, setSelectedAssigneeIds] = useState([]);
  const [viewMode, setViewMode] = useState('list');
  const [selectedType, setSelectedType] = useState('');
  const [selectedTech, setSelectedTech] = useState('');
  const [statusMenuOpen, setStatusMenuOpen] = useState(null);
  const [formError, setFormError] = useState('');
  const [, setClockTick] = useState(0);
  const [taskViewTab, setTaskViewTab] = useState('table');
  const [calendarPrefill, setCalendarPrefill] = useState(null);
  const [description, setDescription] = useState('');
  const [formProjectId, setFormProjectId] = useState('');

  // Kanban Drag and Drop State
  const [draggedTaskId, setDraggedTaskId] = useState(null);
  const [dragOverColumn, setDragOverColumn] = useState(null);

  const debouncedSearch = useMemo(
    () =>
      debounce((val) => {
        setPage(1);
        fetchTasks({ search: val });
      }, 500),
    [page, limit, priority, status, projectId]
  );

  const selfAssign = () => {
    const me = user?._id;
    if (!me) return;
    setSelectedAssigneeIds(prev => (prev.includes(me) ? prev : [...prev, me]));
  };

  const formatDuration = (seconds) => {
    const total = Math.max(0, Math.floor(seconds || 0));
    const days = Math.floor(total / 86400);
    const hours = Math.floor((total % 86400) / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    return `${days} Day${days === 1 ? '' : 's'} ${hours} Hour${hours === 1 ? '' : 's'} ${minutes} Minute${minutes === 1 ? '' : 's'}`;
  };

  const getLiveSeconds = (t) => {
    const base = Math.floor(t.timeSpentSeconds || 0);
    if (t.timerStartAt) {
      const elapsed = Math.floor((Date.now() - new Date(t.timerStartAt).getTime()) / 1000);
      return base + Math.max(0, elapsed);
    }
    return base;
  };

  useEffect(() => {
    const anyRunning = items.some((t) => !!t.timerStartAt);
    if (!anyRunning) return;
    const i = setInterval(() => setClockTick((v) => v + 1), 30000);
    return () => clearInterval(i);
  }, [items]);

  const handleStart = async (t) => {
    if (!canEdit) return;
    try {
      await api.patch('/tasks/timer/pause-all');
      const resp = await api.patch(`/tasks/${t._id}/timer/start`);
      const updated = resp.data.task;
      setItems((list) => list.map((x) => (x._id === t._id ? { ...x, ...updated } : x)));
      fetchTasks();
    } catch (e) {
      console.error(e);
    }
  };

  const handlePause = async (t) => {
    if (!canEdit) return;
    try {
      const resp = await api.patch(`/tasks/${t._id}/timer/pause`);
      const updated = resp.data.task;
      setItems((list) => list.map((x) => (x._id === t._id ? { ...x, ...updated } : x)));
      setViewItem((cur) => (cur && cur._id === t._id ? { ...cur, ...updated } : cur));
      fetchTasks();
    } catch (e) {
      console.error(e);
    }
  };

  const handleEnd = async (t) => {
    if (!canEdit) return;
    try {
      const resp = await api.patch(`/tasks/${t._id}/timer/end`);
      const updated = resp.data.task;
      setItems((list) => list.map((x) => (x._id === t._id ? { ...x, ...updated } : x)));
      setViewItem((cur) => (cur && cur._id === t._id ? { ...cur, ...updated } : cur));
      fetchTasks();
    } catch (e) {
      console.error(e);
    }
  };

  const fetchTasks = async (params = {}) => {
    setLoading(true);
    try {
      const resp = await api.get('/tasks', {
        params: { page, limit, search, priority, status, projectId, ...params },
      });
      if (resp.data.success) {
        setItems(resp.data.items);
        setTotal(resp.data.total);
        try {
          const calendarResp = await api.get('/tasks/calendar');
          if (calendarResp.data.success && window.dispatchEvent) {
            const event = new CustomEvent('tasks-calendar-updated', {
              detail: { items: calendarResp.data.items },
            });
            window.dispatchEvent(event);
          }
        } catch (e) {
          console.error(e);
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const loadProjectOptions = (inputValue) => {
    return api.get('/projects', { params: { search: inputValue, page: 1, limit: 100 } })
      .then(resp => {
        const items = resp.data.items || resp.data.projects || [];
        return items.map(p => ({ value: p._id, label: p.name, original: p }));
      })
      .catch(() => []);
  };

  const fetchProjectDetails = async (pid) => {
    try {
      const resp = await api.get('/projects', { params: { _id: pid, page: 1, limit: 1 } });
      if (resp.data.items && resp.data.items.length > 0) {
        setCurrentProject(resp.data.items[0]);
      }
    } catch (e) {
      console.error('Failed to fetch project details', e);
    }
  };

  const loadDevelopers = async () => {
    const resp = await api.get('/hr/employees-selection', { params: { page: 1, limit: 100 } });
    setDevelopers(resp.data.employees || []);
  };
  const loadDepartments = async () => {
    try {
      const resp = await api.get('/department', { params: { page: 1, limit: 100 } });
      setDepartments(resp.data.departments || []);
    } catch (err) {
      console.error('Failed to load departments', err);
    }
  };

  useEffect(() => {
    if (canView) fetchTasks();
  }, [page, limit, priority, status, projectId, canView]);

  useEffect(() => {
    loadDevelopers();
    loadDepartments();
  }, []);

  useEffect(() => {
    if (modalOpen) {
      if (editItem) {
        setSelectedType(editItem?.projectType || '');
        setSelectedTech(editItem?.technology || '');
        setSelectedAssigneeIds((editItem?.assignees || []).map((d) => d._id));
        setSelectedDept('');
        setAssigneeSearch('');
        setFormError('');
        setDescription(editItem?.description || '');

        const pid = editItem?.project?._id || '';
        setFormProjectId(pid);

        if (editItem?.project) {
          setSelectedFormProject({
            value: editItem.project._id,
            label: editItem.project.name,
            original: editItem.project
          });
          // Fetch full details for developers list
          if (editItem.project._id) {
            fetchProjectDetails(editItem.project._id);
          }
        } else {
          setSelectedFormProject(null);
          setCurrentProject(null);
        }
      } else {
        // Reset for new task
        setSelectedType('');
        setSelectedTech('');
        setSelectedAssigneeIds([]);
        setSelectedDept('');
        setAssigneeSearch('');
        setFormError('');
        setDescription('');
        setFormProjectId('');
        setSelectedFormProject(null);
        setCurrentProject(null);
      }
    }
  }, [modalOpen, editItem]);

  const exportData = async (format) => {
    const resp = await api.get('/tasks/export', {
      params: { format, search, priority, status, projectId },
      responseType: 'blob',
    });
    const url = URL.createObjectURL(resp.data);
    const a = document.createElement('a');
    a.href = url;
    a.download = format === 'xlsx' ? 'tasks.xlsx' : 'tasks.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const stats = useMemo(() => {
    const now = new Date();
    const totalTasks = total;
    const active = items.filter(i => i.status === 'in_progress').length;
    const done = items.filter(i => i.status === 'done').length;
    const blocked = items.filter(i => i.status === 'blocked').length;
    const overdue = items.filter(i => i.dueDate && new Date(i.dueDate) < now && i.status !== 'done').length;
    return { totalTasks, active, done, blocked, overdue };
  }, [items, total]);

  const statusPillClass = (s) => {
    const map = {
      todo: 'bg-default-100 text-default-600 border-default-200',
      in_progress: 'bg-primary/10 text-primary border-primary/20',
      paused: 'bg-warning/10 text-warning border-warning/20',
      blocked: 'bg-danger/10 text-danger border-danger/20',
      done: 'bg-success/10 text-success border-success/20',
    };
    return `px-3 py-1.5 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all ${map[s] || 'bg-default-100 text-default-600 border-default-200'}`;
  };

  const priorityPillClass = (p) => {
    const map = {
      High: 'bg-danger/10 text-danger border-danger/20',
      Medium: 'bg-warning/10 text-warning border-warning/20',
      Low: 'bg-success/10 text-success border-success/20',
    };
    return `px-3 py-1.5 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all ${map[p] || 'bg-default-100 text-default-600 border-default-200'}`;
  };

  const onSubmitTask = async (e) => {
    e.preventDefault();
    setFormError('');
    const setError = (msg) => {
      setFormError(msg);
      toast.error(msg);
    };
    const form = new FormData(e.currentTarget);
    const payload = {
      projectId: form.get('projectId'),
      title: form.get('title')?.trim(),
      description: description,
      projectType: form.get('projectType'),
      technology: form.get('technology') || '',
      priority: form.get('priority'),
      status: form.get('status') || 'todo',
      assignees: selectedAssigneeIds,
      startDate: form.get('startDate') || null,
      dueDate: form.get('dueDate') || null,
      dueHours: Number(form.get('dueHours') || 0),
      estimatedHours: Number(form.get('estimatedHours') || 0),
      tags: (form.get('tags') || '').split(',').map(s => s.trim()).filter(Boolean),
    };
    if (!payload.projectId || !payload.title || !payload.priority || !payload.projectType) {
      setError('Please fill in all required fields');
      return;
    }
    if (payload.title.length < 3) { setError('Title must be at least 3 characters'); return; }
    if (payload.title.length > 140) { setError('Title must be at most 140 characters'); return; }
    if (!priorities.includes(payload.priority)) { setError('Invalid priority'); return; }
    if (!['todo', 'in_progress', 'paused', 'blocked', 'done'].includes(payload.status)) { setError('Invalid status'); return; }
    if (!Number.isFinite(payload.dueHours) || payload.dueHours < 0) { setError('Due hours must be 0 or more'); return; }
    if (!Number.isFinite(payload.estimatedHours) || payload.estimatedHours < 0) { setError('Estimated hours must be 0 or more'); return; }
    if (payload.tags.length > 10) { setError('Tags must be 10 or fewer'); return; }
    if (payload.tags.some(t => t.length > 20)) { setError('Each tag must be 20 characters or fewer'); return; }
    if (payload.dueDate && payload.startDate) {
      if (new Date(payload.dueDate) < new Date(payload.startDate)) {
        setError('Due date must be after start date');
        return;
      }
    }

    const formData = new FormData();
    Object.keys(payload).forEach(k => {
      if ((k === 'assignees' || k === 'tags') && payload[k]) {
        formData.append(k, JSON.stringify(payload[k]));
      } else if (payload[k] !== undefined && payload[k] !== null) {
        formData.append(k, payload[k]);
      }
    });

    const files = form.getAll('documents');
    files.forEach(file => { if (file.size > 0) formData.append('documents', file); });

    try {
      if (editItem) {
        await api.put(`/tasks/${editItem._id}`, formData);
      } else {
        await api.post('/tasks', formData);
      }
      toast.success(editItem ? 'Task updated successfully' : 'Task created successfully');
      setModalOpen(false);
      setEditItem(null);
      setCalendarPrefill(null);
      fetchTasks();
    } catch (err) {
      const msg = err?.response?.data?.message || 'Failed to save task';
      setError(msg);
    }
  };

  const confirmDelete = async (id) => {
    if (!canDelete) return;
    if (window.confirm('Delete this task?')) {
      await api.delete(`/tasks/${id}`);
      fetchTasks();
    }
  };

  const updateRowStatus = async (id, value) => {
    if (!canEdit) return;

    // Optimistic UI update for smoother Kanban drag-and-drop
    setItems((prev) => prev.map((t) => (t._id === id ? { ...t, status: value } : t)));

    try {
      await api.patch(`/tasks/${id}/status`, { status: value });
      fetchTasks();
    } catch (e) {
      console.error('Failed to update status', e);
      // Revert if failed
      fetchTasks();
    }
  };

  // Kanban Drag and Drop Handlers
  const handleDragStart = (e, taskId) => {
    if (!canEdit) return;
    setDraggedTaskId(taskId);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', taskId);
    // Optional: make the dragging element slightly transparent
    setTimeout(() => {
      e.target.style.opacity = '0.5';
    }, 0);
  };

  const handleDragEnd = (e) => {
    e.target.style.opacity = '1';
    setDraggedTaskId(null);
    setDragOverColumn(null);
  };

  const handleDragOver = (e, columnId) => {
    e.preventDefault();
    if (!canEdit) return;
    e.dataTransfer.dropEffect = 'move';
    if (dragOverColumn !== columnId) {
      setDragOverColumn(columnId);
    }
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    // Only clear if we actually leave the column (not moving to children)
    if (e.currentTarget === e.target) {
      setDragOverColumn(null);
    }
  };

  const handleDrop = (e, columnId) => {
    e.preventDefault();
    setDragOverColumn(null);
    if (!canEdit) return;

    const taskId = e.dataTransfer.getData('text/plain');
    if (!taskId) return;

    const task = items.find((t) => t._id === taskId);
    if (task && task.status !== columnId) {
      updateRowStatus(taskId, columnId);
    }
  };

  const renderKanbanCard = (t) => (
    <div
      key={t._id}
      draggable={canEdit && !t.timerStartAt}
      onDragStart={(e) => handleDragStart(e, t._id)}
      onDragEnd={handleDragEnd}
      className={`group bg-white border ${draggedTaskId === t._id ? 'border-dashed border-primary/50' : 'border-default-200'} rounded-2xl p-4 transition-all duration-200 flex flex-col relative overflow-hidden mb-3 hover:shadow-md ${canEdit && !t.timerStartAt ? 'cursor-grab active:cursor-grabbing' : 'opacity-80'}`}
    >
      <div className={`absolute top-0 left-0 w-1 h-full opacity-0 group-hover:opacity-100 transition-opacity ${t.priority === 'High' ? 'bg-danger' : t.priority === 'Medium' ? 'bg-warning' : 'bg-success'
        }`} />

      <div className="flex justify-between items-start mb-3">
        <div className="flex flex-col min-w-0 flex-1">
          <div className="flex items-center gap-1.5 mb-1 text-[10px]">
            <span className="font-black text-primary uppercase tracking-widest truncate opacity-70 max-w-[100px]">{t.project?.name}</span>
            <div className="size-1 rounded-full bg-default-300 flex-shrink-0" />
            <span className="font-bold text-default-400 uppercase tracking-wider truncate max-w-[80px]">{t.projectType}</span>
          </div>
          <h6 className="text-sm font-bold text-default-900 leading-tight group-hover:text-primary transition-colors line-clamp-2 pr-2" title={t.title}>{t.title}</h6>
        </div>
      </div>

      <div className="flex items-center justify-between mt-auto pt-3 border-t border-default-100">
        <div className="flex -space-x-2 overflow-hidden">
          {(t.assignees || []).slice(0, 3).map((d, i) => {
            const photo = d.documents?.photograph || d.employeePersonal?.profilePhoto;
            return (
              <div key={i} className="size-6 rounded-full bg-white p-0.5 border border-default-100" title={d.name}>
                {photo ? (
                  <img src={photo} alt={d.name} className="size-full rounded-full object-cover" />
                ) : (
                  <div className="size-full rounded-full bg-primary/10 flex items-center justify-center text-[8px] font-black text-primary uppercase">
                    {d.name.charAt(0)}
                  </div>
                )}
              </div>
            );
          })}
          {(t.assignees || []).length > 3 && (
            <div className="size-6 rounded-full bg-white p-0.5 border border-default-100">
              <div className="size-full rounded-full bg-default-100 flex items-center justify-center text-[8px] font-black text-default-600 uppercase">
                +{(t.assignees || []).length - 3}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            className="size-7 flex items-center justify-center bg-default-50 rounded-lg text-default-500 hover:text-primary hover:bg-primary/10 transition-all active:scale-90"
            onClick={() => { setViewItem(t); setViewModalOpen(true); }}
            title="View Details"
          >
            <LuEye className="size-3.5" />
          </button>
          {canEdit && (
            <button
              type="button"
              className="size-7 flex items-center justify-center bg-default-50 rounded-lg text-default-500 hover:text-primary hover:bg-primary/10 transition-all active:scale-90"
              onClick={() => { setEditItem(t); setModalOpen(true); }}
              title="Edit Task"
            >
              <LuPencil className="size-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );

  if (!canView) {
    return (
      <>
        <PageMeta title="Tasks" />
        <main>
          <PageBreadcrumb title="Tasks" subtitle="Task Management" />
          <div className="card">
            <div className="card-body">
              <p className="text-default-500">You do not have permission to view this page.</p>
            </div>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <PageMeta title="Tasks" />
      <main>
        <PageBreadcrumb title="Tasks" subtitle="Task Management" />

        <div className="mb-6 flex items-center justify-between gap-3 flex-wrap">
          <div className="bg-white border border-default-200 rounded-2xl p-1 inline-flex items-center gap-1 shadow-sm">
            <button
              type="button"
              className={`px-4 py-2.5 text-xs font-black rounded-xl flex items-center gap-2 uppercase tracking-widest transition-all ${taskViewTab === 'table' ? 'bg-primary text-white shadow-sm' : 'text-default-500 hover:text-default-900'}`}
              onClick={() => setTaskViewTab('table')}
            >
              <LuList className="size-4" />
              <span>Table View</span>
            </button>
            <button
              type="button"
              className={`px-4 py-2.5 text-xs font-black rounded-xl flex items-center gap-2 uppercase tracking-widest transition-all ${taskViewTab === 'calendar' ? 'bg-primary text-white shadow-sm' : 'text-default-500 hover:text-default-900'}`}
              onClick={() => setTaskViewTab('calendar')}
            >
              <LuCalendar className="size-4" />
              <span>Calendar View</span>
            </button>
          </div>
        </div>

        {taskViewTab === 'table' && (
          <TableView
            stats={stats}
            setSearch={setSearch}
            debouncedSearch={debouncedSearch}
            priority={priority}
            setPriority={setPriority}
            priorities={priorities}
            status={status}
            setStatus={setStatus}
            statuses={statuses}
            selectedProjectFilter={selectedProjectFilter}
            setSelectedProjectFilter={setSelectedProjectFilter}
            setProjectId={setProjectId}
            loadProjectOptions={loadProjectOptions}
            canExport={canExport}
            exportData={exportData}
            viewMode={viewMode}
            setViewMode={setViewMode}
            canCreate={canCreate}
            setEditItem={setEditItem}
            setModalOpen={setModalOpen}
            loading={loading}
            items={items}
            page={page}
            limit={limit}
            total={total}
            priorityPillClass={priorityPillClass}
            statusPillClass={statusPillClass}
            formatDuration={formatDuration}
            getLiveSeconds={getLiveSeconds}
            canEdit={canEdit}
            statusMenuOpen={statusMenuOpen}
            setStatusMenuOpen={setStatusMenuOpen}
            updateRowStatus={updateRowStatus}
            setViewItem={setViewItem}
            setViewModalOpen={setViewModalOpen}
            handleStart={handleStart}
            handlePause={handlePause}
            handleEnd={handleEnd}
            canDelete={canDelete}
            confirmDelete={confirmDelete}
            dragOverColumn={dragOverColumn}
            handleDragOver={handleDragOver}
            handleDragLeave={handleDragLeave}
            handleDrop={handleDrop}
            renderKanbanCard={renderKanbanCard}
            setPage={setPage}
            setLimit={setLimit}
          />
        )}

        {taskViewTab === 'calendar' && (
          <CalendarView
            items={items}
            setViewItem={setViewItem}
            setViewModalOpen={setViewModalOpen}
            setEditItem={setEditItem}
            setCalendarPrefill={setCalendarPrefill}
            setModalOpen={setModalOpen}
          />
        )}

        {modalOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 p-4 overflow-y-auto transition-all animate-in fade-in duration-300">
            <div className="bg-white rounded-3xl w-full max-w-4xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300 border border-default-200">
              <div className="px-8 py-6 border-b border-default-100 flex items-center justify-between bg-white">
                <div className="flex items-center gap-4">
                  <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                    {editItem ? <LuPencil className="size-6" /> : <LuPlus className="size-6" />}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">{editItem ? 'Edit Task' : 'Add New Task'}</h3>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">{editItem ? 'Update existing task details' : 'Create a new task in the system'}</p>
                  </div>
                </div>
                <button
                  type="button"
                  className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                  onClick={() => {
                    setModalOpen(false);
                    setEditItem(null);
                    setCalendarPrefill(null);
                  }}
                >
                  <LuX className="size-5" />
                </button>
              </div>

              <form onSubmit={onSubmitTask} className="flex flex-col overflow-hidden">
                <div className="p-8 overflow-y-auto custom-scroll">
                  <div className="grid md:grid-cols-2 gap-8">
                    {/* Basic Info Section */}
                    <div className="space-y-5">
                      <h4 className="text-[11px] font-black text-primary flex items-center gap-2 uppercase tracking-[0.2em] mb-4">
                        <LuListTodo className="size-4" /> Task Details
                      </h4>

                      <div>
                        <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Project *</label>
                        <AsyncSelect
                          className="text-sm font-bold"
                          classNamePrefix="react-select"
                          cacheOptions
                          defaultOptions
                          loadOptions={loadProjectOptions}
                          value={selectedFormProject}
                          onChange={(opt) => {
                            setSelectedFormProject(opt);
                            const pid = opt?.value || '';
                            setFormProjectId(pid);
                            setCurrentProject(opt?.original || null);

                            // Clear assignees when project changes to avoid invalid assignments
                            if (pid !== (editItem?.project?._id || '')) {
                              setSelectedAssigneeIds([]);
                            } else if (editItem?.project?._id === pid) {
                              // Restore original assignees if switching back to original project
                              setSelectedAssigneeIds((editItem?.assignees || []).map((d) => d._id));
                            }

                            const p = opt?.original;
                            if (p) {
                              if (p.projectType) setSelectedType(p.projectType);
                              if (p.technology) setSelectedTech(p.technology);
                            }
                          }}
                          placeholder="Select Project"
                          isClearable
                          styles={{
                            control: (base) => ({
                              ...base,
                              minHeight: '2.75rem',
                              borderRadius: '0.75rem',
                              borderColor: '#e5e7eb',
                              backgroundColor: 'rgba(249, 250, 251, 0.5)',
                              fontSize: '0.875rem',
                              fontWeight: 700,
                            }),
                            menu: (base) => ({
                              ...base,
                              fontSize: '0.875rem',
                              fontWeight: 700,
                              zIndex: 9999
                            })
                          }}
                        />
                        <input type="hidden" name="projectId" value={formProjectId} />
                      </div>

                      <div>
                        <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Task Title *</label>
                        <input name="title" className="form-input w-full h-11 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-sm bg-default-50/50" placeholder="Enter task title" defaultValue={editItem?.title || ''} required />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Priority *</label>
                          <select name="priority" className="form-select w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50" defaultValue={editItem?.priority || ''} required>
                            <option value="">Select Priority</option>
                            {priorities.map((p) => (
                              <option key={p} value={p}>{p}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Status</label>
                          <select name="status" className="form-select w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50" defaultValue={editItem?.status || 'todo'}>
                            {statuses.map((s) => (
                              <option key={s.value} value={s.value}>{s.label}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Project Type *</label>
                          <select
                            name="projectType"
                            className="form-select w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                            value={selectedType}
                            onChange={(e) => {
                              setSelectedType(e.target.value);
                              setSelectedTech('');
                            }}
                            required
                          >
                            <option value="">Select Type</option>
                            {projectTypes.map((t) => (
                              <option key={t} value={t}>{t}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Technology</label>
                          <select
                            name="technology"
                            className="form-select w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                            value={selectedTech}
                            onChange={(e) => setSelectedTech(e.target.value)}
                            disabled={!selectedType}
                          >
                            <option value="">{selectedType ? 'Select Technology' : 'Select Type first'}</option>
                            {(technologyMap[selectedType] || []).map((t) => (
                              <option key={t} value={t}>{t}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                          <LuTag className="size-3.5" /> Tags
                        </label>
                        <input
                          name="tags"
                          className="form-input w-full h-11 rounded-xl border-default-200 focus:border-primary focus:ring-primary font-bold text-sm bg-default-50/50"
                          placeholder="Bug, Feature, UI, etc (comma separated)"
                          defaultValue={(editItem?.tags || []).join(',')}
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                          <LuFolder className="size-3.5" /> Attached Documents
                        </label>
                        <input type="file" name="documents" multiple className="form-input w-full h-11 rounded-xl border-default-200 font-bold text-xs bg-default-50/50 pt-3" />
                        {editItem?.documents?.length > 0 && (
                          <div className="mt-2 text-[10px] font-bold text-default-500 uppercase tracking-widest">
                            Currently {editItem.documents.length} document(s) attached.
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Timeline & Resources Section */}
                    <div className="space-y-5">
                      <h4 className="text-[11px] font-black text-primary flex items-center gap-2 uppercase tracking-[0.2em] mb-4">
                        <LuCalendar className="size-4" /> Timeline & Team
                      </h4>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Start Date</label>
                          <input
                            type="date"
                            name="startDate"
                            className="form-input w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                            defaultValue={
                              editItem?.startDate
                                ? new Date(editItem.startDate).toISOString().split('T')[0]
                                : calendarPrefill?.startDate || ''
                            }
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2">Due Date</label>
                          <input
                            type="date"
                            name="dueDate"
                            className="form-input w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                            defaultValue={
                              editItem?.dueDate
                                ? new Date(editItem.dueDate).toISOString().split('T')[0]
                                : calendarPrefill?.dueDate || ''
                            }
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                            <LuClock className="size-3.5" /> Due Hours
                          </label>
                          <input
                            type="number"
                            name="dueHours"
                            className="form-input w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                            placeholder="0"
                            defaultValue={editItem?.dueHours || 0}
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                            <LuClock className="size-3.5" /> Est. Hours
                          </label>
                          <input
                            type="number"
                            name="estimatedHours"
                            className="form-input w-full h-11 rounded-xl border-default-200 font-bold text-sm bg-default-50/50"
                            placeholder="0"
                            defaultValue={editItem?.estimatedHours || 0}
                          />
                        </div>
                      </div>

                      <div className="pt-2">
                        <div className="flex items-center justify-between mb-3">
                          <label className="text-xs font-black text-default-400 uppercase tracking-widest flex items-center gap-2">
                            <LuUsers className="size-4" /> Assign Team Members
                          </label>
                          <div className="flex items-center gap-2">
                            {selectedAssigneeIds.length > 0 && (
                              <button
                                type="button"
                                onClick={() => setSelectedAssigneeIds([])}
                                className="text-[10px] font-black text-danger hover:underline uppercase tracking-[0.1em]"
                              >
                                Clear All
                              </button>
                            )}
                            {user && (
                              <button
                                type="button"
                                onClick={selfAssign}
                                disabled={!user?._id || selectedAssigneeIds.includes(user._id)}
                                className="text-[10px] font-black text-primary hover:underline uppercase tracking-[0.1em] disabled:opacity-50 disabled:cursor-not-allowed"
                              >
                                Assign to me
                              </button>
                            )}
                            <span className="bg-primary/10 text-primary text-[10px] font-black px-2.5 py-1 rounded-lg uppercase tracking-wider">
                              {selectedAssigneeIds.length} Selected
                            </span>
                          </div>
                        </div>

                        {/* Department Filter and Search */}
                        <div className="grid grid-cols-2 gap-3 mb-4">
                          <div className="relative">
                            <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-default-400" />
                            <input
                              type="text"
                              className="form-input pl-9 h-10 w-full text-xs font-bold rounded-xl border-default-200 bg-default-50/50"
                              placeholder="Search name..."
                              onChange={(e) => setAssigneeSearch(e.target.value.toLowerCase())}
                            />
                          </div>
                          <div className="relative">
                            <LuUsers className="absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-default-400" />
                            <select
                              className="form-select pl-9 h-10 w-full text-xs font-bold rounded-xl border-default-200 bg-default-50/50"
                              value={selectedDept}
                              onChange={(e) => setSelectedDept(e.target.value)}
                            >
                              <option value="">All Depts</option>
                              {departments.map(d => (
                                <option key={d._id} value={d.name}>{d.name}</option>
                              ))}
                            </select>
                          </div>
                        </div>

                        {/* Assignee Selection UI */}
                        <div className="border border-default-200 rounded-2xl p-2 max-h-48 overflow-y-auto bg-default-50/30 custom-scroll">
                          <div className="grid grid-cols-1 gap-1">
                            {developers
                              .filter(d => {
                                // Filter by selected department and search term
                                const matchesFilter = (!selectedDept || d.department === selectedDept) &&
                                  (!assigneeSearch || d.name.toLowerCase().includes(assigneeSearch));
                                if (!matchesFilter) return false;

                                // Filter by project team members if a project is selected
                                if (formProjectId) {
                                  const project = currentProject;
                                  if (project?.developers && project.developers.length > 0) {
                                    // Check if developer is in the project's developers list
                                    // project.developers contains user objects with _id
                                    return project.developers.some(dev => dev._id === d._id);
                                  }
                                  // If project has no developers, no one can be assigned (except maybe superadmin, but let's stick to team)
                                  return false;
                                }
                                // If no project selected, show no one (force project selection)
                                return false;
                              })
                              .map((d) => (
                                <label key={d._id} className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all border ${selectedAssigneeIds.includes(d._id) ? 'bg-primary/5 border-primary/20   ' : 'border-transparent hover:bg-white'}`}>
                                  <div className="relative flex items-center">
                                    <input
                                      type="checkbox"
                                      className="form-checkbox size-5 rounded-lg text-primary border-default-300 focus:ring-primary transition-all"
                                      checked={selectedAssigneeIds.includes(d._id)}
                                      onChange={(e) => {
                                        if (e.target.checked) {
                                          setSelectedAssigneeIds(prev => [...prev, d._id]);
                                        } else {
                                          setSelectedAssigneeIds(prev => prev.filter(id => id !== d._id));
                                        }
                                      }}
                                      disabled={!canAssign}
                                    />
                                  </div>
                                  <div className="flex-1 flex flex-col min-w-0">
                                    <span className={`text-sm font-bold transition-colors ${selectedAssigneeIds.includes(d._id) ? 'text-primary' : 'text-default-900'}`}>{d.name}</span>
                                    <span className="text-[10px] text-default-400 font-bold uppercase tracking-widest">{d.department} • {d.designation}</span>
                                  </div>
                                  {selectedAssigneeIds.includes(d._id) && (
                                    <LuCheck className="size-4 text-primary animate-in zoom-in" />
                                  )}
                                </label>
                              ))}
                          </div>
                          {developers.filter(d => {
                            const matchesFilter = (!selectedDept || d.department === selectedDept) &&
                              (!assigneeSearch || d.name.toLowerCase().includes(assigneeSearch));
                            if (!matchesFilter) return false;

                            if (formProjectId) {
                              const project = currentProject;
                              if (project?.developers) {
                                return project.developers.some(dev => dev._id === d._id);
                              }
                            }
                            return false;
                          }).length === 0 && (
                              <div className="text-center py-6">
                                <LuUsers className="size-8 mx-auto text-default-200 mb-2" />
                                <span className="text-[11px] font-bold text-default-400 uppercase tracking-widest">
                                  {formProjectId ? 'No team members found' : 'Select a project first'}
                                </span>
                              </div>
                            )}
                        </div>

                        {/* Selected Pills */}
                        {selectedAssigneeIds.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-4">
                            {selectedAssigneeIds.map(id => {
                              const dev = developers.find(d => d._id === id);
                              return dev ? (
                                <span key={id} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-primary text-white text-[10px] font-black uppercase tracking-wider animate-in zoom-in duration-300">
                                  {dev.name}
                                  <button type="button" onClick={() => setSelectedAssigneeIds(prev => prev.filter(i => i !== id))} className="hover:bg-white/20 rounded-lg p-0.5 transition-colors">
                                    <LuX className="size-3" />
                                  </button>
                                </span>
                              ) : null;
                            })}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="col-span-2">
                      <label className="block text-xs font-black text-default-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                        <LuListTodo className="size-4" /> Task Description
                      </label>
                      <div className="bg-white rounded-2xl border border-default-200 overflow-hidden">
                        <ReactQuill
                          theme="snow"
                          value={description}
                          onChange={setDescription}
                          className="h-48 mb-12"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="px-8 py-6 border-t bg-default-50/50 flex items-center justify-between">
                  <div className="text-[10px] font-bold text-default-400 uppercase tracking-widest">
                    * Fields are required
                  </div>
                  <div className="flex items-center gap-4">
                    {formError && (
                      <div className="flex items-center gap-2 text-danger px-4 py-2 bg-danger/10 rounded-xl animate-in slide-in-from-right-4">
                        <LuOctagonAlert className="size-4" />
                        <span className="text-xs font-bold">{formError}</span>
                      </div>
                    )}
                    <button
                      type="button"
                      className="px-6 py-2.5 text-sm font-bold text-default-500 hover:text-default-900 transition-colors uppercase tracking-widest"
                      onClick={() => {
                        setModalOpen(false);
                        setEditItem(null);
                        setCalendarPrefill(null);
                      }}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-8 py-2.5 text-sm font-black text-white bg-primary hover:bg-primary-600 rounded-xl transition-all flex items-center gap-2 active:scale-95"
                    >
                      {editItem ? (
                        <><LuPencil className="size-4" /> Save Changes</>
                      ) : (
                        <><LuPlus className="size-4" /> Create Task</>
                      )}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}

        {viewModalOpen && viewItem && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 p-4 overflow-y-auto transition-all animate-in fade-in duration-300">
            <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300 border border-default-200">
              <div className="px-8 py-6 border-b border-default-100 flex items-center justify-between bg-white">
                <div className="flex items-center gap-4">
                  <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                    <LuListTodo className="size-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">Task Details</h3>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">{viewItem.project?.name || 'Project Details'}</p>
                  </div>
                </div>
                <button
                  type="button"
                  className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                  onClick={() => {
                    setViewModalOpen(false);
                    setViewItem(null);
                  }}
                >
                  <LuX className="size-5" />
                </button>
              </div>

              <div className="p-8 overflow-y-auto custom-scroll">
                <div className="space-y-8">
                  {/* Title & Status Header */}
                  <div className="flex flex-col gap-4">
                    <div className="flex items-center gap-3">
                      <span className={`${priorityPillClass(viewItem.priority)}   `}>{viewItem.priority}</span>
                      <span className={`${statusPillClass(viewItem.status)}   `}>
                        {statuses.find((s) => s.value === viewItem.status)?.label || viewItem.status}
                      </span>
                    </div>
                    <h2 className="text-2xl font-black text-default-900 leading-tight">{viewItem.title}</h2>
                  </div>

                  {/* Info Grid */}
                  <div className="grid grid-cols-2 gap-6 p-6 bg-default-50/50 rounded-2xl border border-default-100">
                    <div className="space-y-1">
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Project Type</span>
                      <p className="text-sm font-bold text-default-700">{viewItem.projectType || 'N/A'}</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Technology</span>
                      <p className="text-sm font-bold text-default-700">{viewItem.technology || 'N/A'}</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Start Date</span>
                      <div className="flex items-center gap-2 text-sm font-bold text-default-700">
                        <LuCalendar className="size-4 text-success" />
                        {viewItem.startDate ? new Date(viewItem.startDate).toLocaleDateString() : 'Not set'}
                      </div>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Due Date</span>
                      <div className="flex items-center gap-2 text-sm font-bold text-default-700">
                        <LuCalendar className="size-4 text-danger" />
                        {viewItem.dueDate ? new Date(viewItem.dueDate).toLocaleDateString() : 'Not set'}
                      </div>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Estimated Hours</span>
                      <div className="flex items-center gap-2 text-sm font-bold text-default-700">
                        <LuClock className="size-4 text-primary" />
                        {viewItem.estimatedHours || 0} Hours
                      </div>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Due Hours</span>
                      <div className="flex items-center gap-2 text-sm font-bold text-default-700">
                        <LuClock className="size-4 text-warning" />
                        {viewItem.dueHours || 0} Hours
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-black text-default-900 uppercase tracking-widest flex items-center gap-2">
                      <LuListTodo className="size-4 text-primary" /> Description
                    </h4>
                    {viewItem.description ? (
                      <div
                        className="p-5 bg-default-50 rounded-2xl border border-default-100 text-sm text-default-600 leading-relaxed font-medium prose prose-sm max-w-none prose-headings:text-default-900 prose-headings:font-black prose-p:text-default-600 prose-li:text-default-600 prose-strong:text-default-800 prose-ul:list-disc prose-ol:list-decimal"
                        dangerouslySetInnerHTML={{ __html: viewItem.description }}
                      />
                    ) : (
                      <div className="p-5 bg-default-50 rounded-2xl border border-default-100 text-sm text-default-600 leading-relaxed font-medium">
                        No description provided.
                      </div>
                    )}
                  </div>

                  {/* Team Section */}
                  <div className="space-y-4">
                    <h4 className="text-xs font-black text-default-900 uppercase tracking-widest flex items-center gap-2">
                      <LuUsers className="size-4 text-primary" /> Assigned Team
                    </h4>
                    <div className="flex flex-wrap gap-3">
                      {(viewItem.assignees || []).map((dev) => {
                        const photo = dev.documents?.photograph || dev.employeePersonal?.profilePhoto;
                        return (
                          <div key={dev._id} className="flex items-center gap-3 p-2 pr-4 bg-white border border-default-200 rounded-xl   ">
                            {photo ? (
                              <img src={photo} alt={dev.name} className="size-9 rounded-lg object-cover" />
                            ) : (
                              <div className="size-9 rounded-lg bg-primary/10 flex items-center justify-center text-xs font-black text-primary uppercase">
                                {dev.name.charAt(0)}
                              </div>
                            )}
                            <div className="flex flex-col">
                              <span className="text-xs font-black text-default-900 leading-none mb-0.5">{dev.name}</span>
                              <span className="text-[10px] font-bold text-default-400 uppercase tracking-tight">{dev.department}</span>
                            </div>
                          </div>
                        );
                      })}
                      {(viewItem.assignees || []).length === 0 && (
                        <p className="text-xs font-bold text-default-400 italic">No team members assigned yet.</p>
                      )}
                    </div>
                  </div>

                  {/* Tags */}
                  {viewItem.tags?.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="text-xs font-black text-default-900 uppercase tracking-widest flex items-center gap-2">
                        <LuTag className="size-4 text-primary" /> Tags
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {viewItem.tags.map((tag, i) => (
                          <span key={i} className="px-3 py-1.5 rounded-xl bg-default-100 text-default-600 text-[10px] font-black uppercase tracking-widest border border-default-200">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Documents */}
                  {viewItem.documents?.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="text-xs font-black text-default-900 uppercase tracking-widest flex items-center gap-2">
                        <LuFolder className="size-4 text-primary" /> Attached Documents
                      </h4>
                      <div className="grid grid-cols-2 gap-3">
                        {viewItem.documents.map((doc, idx) => {
                          const baseUrl = import.meta.env.VITE_API_BASE_URL ? import.meta.env.VITE_API_BASE_URL.replace(/\/api.*$/, '') : '';
                          const fileUrl = doc.url.startsWith('http') ? doc.url : `${baseUrl}${doc.url}`;
                          return (
                            <div key={idx} className="flex items-center justify-between p-3 bg-default-50 rounded-xl border border-default-100 group">
                              <div className="flex items-center gap-3 overflow-hidden">
                                <div className="size-8 rounded-lg bg-white border border-default-200 flex items-center justify-center shrink-0">
                                  <LuFolder className="size-4 text-primary" />
                                </div>
                                <span className="text-xs font-bold text-default-900 truncate" title={doc.name}>{doc.name}</span>
                              </div>
                              <a href={fileUrl} target="_blank" rel="noreferrer" className="size-8 shrink-0 flex items-center justify-center bg-white text-default-600 hover:text-primary hover:border-primary rounded-lg border border-default-200 transition-all" title="Download">
                                <LuDownload className="size-4" />
                              </a>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="px-8 py-6 border-t bg-default-50/50 flex items-center justify-end gap-3">
                <button
                  type="button"
                  className="px-6 py-2.5 text-sm font-bold text-default-500 hover:text-default-900 transition-colors uppercase tracking-widest"
                  onClick={() => {
                    setViewModalOpen(false);
                    setViewItem(null);
                  }}
                >
                  Close
                </button>
                {canEdit && (
                  <button
                    type="button"
                    className="px-8 py-2.5 text-sm font-black text-white bg-primary hover:bg-primary-600 rounded-xl transition-all flex items-center gap-2 active:scale-95"
                    onClick={() => {
                      setViewModalOpen(false);
                      setEditItem(viewItem);
                      setModalOpen(true);
                    }}
                  >
                    <LuPencil className="size-4" /> Edit Task
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </>
  );
};

export default Index;
