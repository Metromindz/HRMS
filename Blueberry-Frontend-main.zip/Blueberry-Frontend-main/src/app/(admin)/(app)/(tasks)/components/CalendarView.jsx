import React from 'react';
import CalendarApp from '@/app/(admin)/(app)/calendar/components/Calender';

const CalendarView = ({
    items,
    setViewItem,
    setViewModalOpen,
    setEditItem,
    setCalendarPrefill,
    setModalOpen,
}) => {
    return (
        <div className="bg-white rounded-2xl border border-default-200 overflow-hidden">
            <div className="p-4">
                <CalendarApp
                    tasks={items}
                    onTaskClick={(id) => {
                        const task = items.find((t) => t._id === id);
                        if (task) {
                            setViewItem(task);
                            setViewModalOpen(true);
                        }
                    }}
                    onDateClick={(info) => {
                        setEditItem(null);
                        setCalendarPrefill({
                            startDate: info.dateStr,
                            dueDate: info.dateStr,
                        });
                        setModalOpen(true);
                    }}
                />
            </div>
        </div>
    );
};

export default CalendarView;
