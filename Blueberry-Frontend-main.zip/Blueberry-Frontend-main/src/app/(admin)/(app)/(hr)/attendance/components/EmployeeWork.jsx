import { useMemo, useState } from 'react';
import { LuCheck, LuSearch, LuSquarePen, LuX } from 'react-icons/lu';
import api from '../../../../../../config/api';
import { toast } from 'react-hot-toast';
import { useAuth } from '../../../../../../context/AuthContext';

const EmployeeWork = ({
  records = [],
  loading = false,
  error = '',
  onRetry,
  fullMonthView = false,
  onToggleFullMonth,
}) => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'superadmin' || user?.role === 'admin';

  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 10;
  const totalPages = Math.ceil(records.length / recordsPerPage);

  // Track which cell is being edited: { id, field: 'inTime' | 'outTime' }
  const [editCell, setEditCell] = useState(null); // { id, field }
  const [editValue, setEditValue] = useState('');

  const statusPillClass = useMemo(() => {
    const map = {
      present: 'bg-success/10 text-success border-success/20',
      absent: 'bg-danger/10 text-danger border-danger/20',
      late: 'bg-warning/10 text-warning border-warning/20',
      half_day: 'bg-warning/10 text-warning border-warning/20',
      weeklyOff: 'bg-default-100 text-default-600 border-default-200',
      '-': 'bg-default-100 text-default-500 border-default-200',
    };
    return (s) => {
      const key = s || '-';
      return `px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-widest border ${map[key] || map['-']}`;
    };
  }, []);

  // Convert "HH:MM AM/PM" → "HH:MM" (24-hr) for time input
  const to24Hr = (timeStr) => {
    if (!timeStr || timeStr === '--') return '';
    const match = timeStr.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
    if (!match) return timeStr; // already 24-hr or unknown format
    let hh = parseInt(match[1]);
    const mm = match[2];
    const meridiem = match[3].toUpperCase();
    if (meridiem === 'AM' && hh === 12) hh = 0;
    if (meridiem === 'PM' && hh !== 12) hh += 12;
    return `${String(hh).padStart(2, '0')}:${mm}`;
  };

  const startEdit = (record, field) => {
    setEditCell({ id: record._id, field });
    setEditValue(to24Hr(field === 'inTime' ? record.inTime : record.outTime));
  };

  const cancelEdit = () => {
    setEditCell(null);
    setEditValue('');
  };

  const handleSaveCell = async (record) => {
    const field = editCell.field;

    const parseTimeToMinutes = (t) => {
      if (!t || typeof t !== 'string') return null;
      const m = t.match(/^(\d{1,2}):(\d{2})$/);
      if (!m) return null;
      const hh = Number(m[1]);
      const mm = Number(m[2]);
      if (!Number.isFinite(hh) || !Number.isFinite(mm)) return null;
      if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
      return hh * 60 + mm;
    };

    const valMins = parseTimeToMinutes(editValue);
    if (valMins === null) {
      toast.error(`Enter a valid ${field === 'inTime' ? 'check-in' : 'check-out'} time`);
      return;
    }

    // Build payload — carry over the other time field unchanged
    const payload = {
      inTime: field === 'inTime' ? editValue : to24Hr(record.inTime),
      outTime: field === 'outTime' ? editValue : to24Hr(record.outTime),
    };

    // Cross-validate
    const inMins = parseTimeToMinutes(payload.inTime);
    const outMins = payload.outTime ? parseTimeToMinutes(payload.outTime) : null;
    if (inMins !== null && outMins !== null && outMins < inMins) {
      toast.error('Check-out time must be after check-in time');
      return;
    }

    try {
      const res = await api.put(`/attendance/${record._id}`, payload);
      if (res.status === 200) {
        toast.success(`${field === 'inTime' ? 'Check-in' : 'Check-out'} updated successfully`);
        cancelEdit();
        onRetry && onRetry();
      }
    } catch (error) {
      console.error('Error updating attendance:', error);
      toast.error(error?.response?.data?.message || 'Failed to update attendance');
    }
  };

  const handleOvertime = async (id, status) => {
    if (!['approved', 'rejected'].includes(status)) {
      toast.error('Invalid overtime status');
      return;
    }
    try {
      const res = await api.patch(`/attendance/overtime/${id}`, { status });
      if (res.status === 200) {
        toast.success(`Overtime ${status} successfully`);
        onRetry && onRetry();
      }
    } catch (error) {
      console.error('Error updating overtime status:', error);
      toast.error(error?.response?.data?.message || 'Failed to update overtime status');
    }
  };

  const startIndex = (currentPage - 1) * recordsPerPage;
  const endIndex = Math.min(currentPage * recordsPerPage, records.length);
  const paginatedRecords = records.slice(startIndex, endIndex);
  const displayedRecords = fullMonthView ? records : paginatedRecords;

  // Reusable editable cell for Check In / Check Out
  const EditableTimeCell = ({ record, field }) => {
    const isEditing = editCell?.id === record._id && editCell?.field === field;
    const displayValue = field === 'inTime' ? record.inTime : record.outTime;

    if (!isAdmin || fullMonthView) {
      return <span className="text-sm font-medium text-default-700">{displayValue}</span>;
    }

    if (isEditing) {
      return (
        <div className="flex items-center gap-2">
          <input
            type="time"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            autoFocus
            className="bg-default-50 border border-default-200 rounded-lg h-9 text-xs focus:ring-primary focus:border-primary transition-all px-2 min-w-[120px]"
          />
          <button
            title="Save"
            className="size-8 flex items-center justify-center bg-success text-white rounded-lg hover:bg-success/90 transition-all"
            onClick={() => handleSaveCell(record)}
          >
            <LuCheck className="size-3.5" />
          </button>
          <button
            title="Cancel"
            className="size-8 flex items-center justify-center bg-default-100 text-default-600 rounded-lg hover:bg-default-200 transition-all"
            onClick={cancelEdit}
          >
            <LuX className="size-3.5" />
          </button>
        </div>
      );
    }

    return (
      <div className="group flex items-center gap-2">
        <span className="text-sm font-medium text-default-700">{displayValue}</span>
        <button
          title={`Edit ${field === 'inTime' ? 'Check In' : 'Check Out'}`}
          className="size-7 flex items-center justify-center rounded-lg bg-primary/10 text-primary opacity-0 group-hover:opacity-100 hover:bg-primary hover:text-white transition-all"
          onClick={() => startEdit(record, field)}
        >
          <LuSquarePen className="size-3.5" />
        </button>
      </div>
    );
  };

  return (
    <div className="bg-white border border-default-200 rounded-2xl overflow-hidden">
      {/* Loading State */}
      {loading && (
        <div className="flex justify-center items-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-sm font-bold text-default-500 uppercase tracking-widest">Loading attendance data...</p>
          </div>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="m-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center justify-between">
          <p className="text-sm font-bold text-red-600 uppercase tracking-widest">{error}</p>
          <button
            onClick={onRetry}
            className="h-9 px-4 bg-red-600 text-white rounded-lg font-bold text-xs uppercase tracking-widest hover:bg-red-700 transition-all"
          >
            Retry
          </button>
        </div>
      )}

      {/* No Records Found */}
      {!loading && !error && records.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16">
          <div className="size-16 bg-default-50 rounded-full flex items-center justify-center mb-4">
            <LuSearch className="size-8 text-default-300" />
          </div>
          <h3 className="text-lg font-black text-default-900 mb-1 uppercase tracking-widest">No Records Found</h3>
          <p className="text-sm font-bold text-default-500 uppercase tracking-widest opacity-60">No attendance records available for this period.</p>
        </div>
      )}

      {/* Data Table */}
      {!loading && !error && records.length > 0 && (
        <div className="flex flex-col">
          <div className="p-5 border-b border-default-100 bg-default-50/50 flex items-center justify-between gap-3">
            <div className="text-xs font-black text-default-500 uppercase tracking-widest">
              {fullMonthView ? 'Full Month Summary' : 'Monthly Records'}
            </div>
            <button
              type="button"
              className="h-10 px-4 rounded-xl bg-white border border-default-200 text-default-700 font-black text-[10px] uppercase tracking-widest hover:bg-default-50 transition-all active:scale-95"
              onClick={() => {
                setCurrentPage(1);
                onToggleFullMonth && onToggleFullMonth();
              }}
            >
              {fullMonthView ? 'View Paged' : 'View Full Month'}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-default-200">
              <thead className="bg-default-50/50">
                <tr>
                  <th className="px-6 py-4 text-start text-xs font-black text-default-500 uppercase tracking-widest">Date</th>
                  <th className="px-6 py-4 text-start text-xs font-black text-default-500 uppercase tracking-widest">Check In</th>
                  <th className="px-6 py-4 text-start text-xs font-black text-default-500 uppercase tracking-widest">Check Out</th>
                  <th className="px-6 py-4 text-start text-xs font-black text-default-500 uppercase tracking-widest">Hours</th>
                  {fullMonthView ? (
                    <th className="px-6 py-4 text-start text-xs font-black text-default-500 uppercase tracking-widest">Status</th>
                  ) : (
                    <>
                      <th className="px-6 py-4 text-start text-xs font-black text-default-500 uppercase tracking-widest">Overtime</th>
                      {isAdmin && (
                        <th className="px-6 py-4 text-end text-xs font-black text-default-500 uppercase tracking-widest">OT Action</th>
                      )}
                    </>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-default-100">
                {displayedRecords.map((record, index) => (
                  <tr key={index} className="hover:bg-default-50/50 transition-colors group/row">
                    {/* Date */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-default-900">{record.date}</span>
                        <span className="bg-default-100 text-default-600 rounded-xl px-2 py-0.5 font-black text-[10px] tracking-widest uppercase">
                          {record.day}
                        </span>
                      </div>
                    </td>

                    {/* Check In — individually editable */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <EditableTimeCell record={record} field="inTime" />
                    </td>

                    {/* Check Out — individually editable */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <EditableTimeCell record={record} field="outTime" />
                    </td>

                    {/* Hours */}
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-default-900">{record.workHours}</td>

                    {fullMonthView ? (
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={statusPillClass(record.status)}>{String(record.status || '-').replaceAll('_', ' ')}</span>
                      </td>
                    ) : (
                      <>
                        {/* Overtime */}
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={record.overtime !== '0.00 Hrs' ? 'text-sm font-bold text-primary' : 'text-sm font-medium text-default-400'}>
                            {record.overtime}
                          </span>
                        </td>

                        {/* OT Approve / Reject — admin only */}
                        {isAdmin && (
                          <td className="px-6 py-4 whitespace-nowrap text-end">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                className={`size-9 flex items-center justify-center rounded-lg transition-all
                                  ${record.overtimeStatus !== 'pending'
                                    ? 'bg-default-50 text-default-300 cursor-not-allowed'
                                    : 'bg-success/10 text-success hover:bg-success hover:text-white'
                                  }`}
                                disabled={record.overtimeStatus !== 'pending'}
                                title="Approve OT"
                                onClick={() => handleOvertime(record._id, 'approved')}
                              >
                                <LuCheck className="size-4" />
                              </button>
                              <button
                                className={`size-9 flex items-center justify-center rounded-lg transition-all
                                  ${record.overtimeStatus !== 'pending'
                                    ? 'bg-default-50 text-default-300 cursor-not-allowed'
                                    : 'bg-danger/10 text-danger hover:bg-danger hover:text-white'
                                  }`}
                                disabled={record.overtimeStatus !== 'pending'}
                                title="Reject OT"
                                onClick={() => handleOvertime(record._id, 'rejected')}
                              >
                                <LuX className="size-4" />
                              </button>
                            </div>
                          </td>
                        )}
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {!fullMonthView && totalPages > 1 && (
            <div className="flex items-center justify-between p-6 border-t border-default-100 bg-default-50/50">
              <div className="text-xs font-bold text-default-500 uppercase tracking-widest">
                Showing <span className="text-default-900">{startIndex + 1}</span> to <span className="text-default-900">{endIndex}</span> of <span className="text-default-900">{records.length}</span> Results
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center bg-white border border-default-200 rounded-xl p-1">
                  <button
                    type="button"
                    className="h-10 px-4 flex items-center justify-center rounded-lg font-bold text-xs transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600"
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  >
                    Prev
                  </button>
                  <div className="w-px h-4 bg-default-200 mx-1" />
                  <div className="flex items-center px-2">
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                      <button
                        key={page}
                        type="button"
                        onClick={() => setCurrentPage(page)}
                        className={`size-10 flex items-center justify-center rounded-lg text-xs font-bold transition-all
                          ${currentPage === page ? 'bg-primary text-white' : 'text-default-600 hover:bg-default-50'}`}
                      >
                        {page}
                      </button>
                    ))}
                  </div>
                  <div className="w-px h-4 bg-default-200 mx-1" />
                  <button
                    type="button"
                    className="h-10 px-4 flex items-center justify-center rounded-lg font-bold text-xs transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600"
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  >
                    Next
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default EmployeeWork;
