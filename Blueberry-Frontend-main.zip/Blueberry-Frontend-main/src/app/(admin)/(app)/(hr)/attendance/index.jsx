import { useState, useEffect, useCallback } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import PageBreadcrumb from '@/components/PageBreadcrumb';
import EmployeeDetails from './components/EmployeeDetails';
import EmployeeWork from './components/EmployeeWork';
import PageMeta from '@/components/PageMeta';
import api from '../../../../../config/api';

const Index = () => {
  const params = useParams();
  const location = useLocation();
  
  const userId = params.id;
  const searchParams = new URLSearchParams(location.search);
  
  // Convert month and year to state variables
  const [month, setMonth] = useState(searchParams.get('month') || (new Date().getMonth() + 1));
  const [year, setYear] = useState(searchParams.get('year') || new Date().getFullYear());
  
  const [employee, setEmployee] = useState(null);
  const [summary, setSummary] = useState(null);
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [fullMonthView, setFullMonthView] = useState(
    searchParams.get('fullMonth') === '1' || searchParams.get('fullMonth') === 'true'
  );

  const handleMonthYearChange = (newMonth, newYear) => {
    // Parse to numbers to ensure consistency
    setMonth(parseInt(newMonth));
    setYear(parseInt(newYear));
  };

  const transformAttendanceToRecords = useCallback((attendanceArray, employeeName) => {
    if (!attendanceArray || !Array.isArray(attendanceArray)) return [];

    return attendanceArray.map(attendance => {
      const attendanceDate = new Date(attendance.date);
      const dayName = attendanceDate.toLocaleDateString('en-US', { weekday: 'short' });
      const dateStr = attendanceDate.toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });

      // Format time from 24hr to 12hr format
      const formatTime = timeStr => {
        if (!timeStr) return '--';
        const [hours, minutes] = timeStr.split(':');
        const hour = parseInt(hours);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const displayHour = hour % 12 || 12;
        return `${displayHour}:${minutes} ${ampm}`;
      };

      // Convert minutes to hours format
      const minutesToHours = minutes => {
        if (!minutes) return '0.00 Hrs';
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return `${hours}.${mins.toString().padStart(2, '0')} Hrs`;
      };

      return {
        _id: attendance._id,
        employeeId: attendance.employeeId,
        userName: employeeName,
        date: dateStr,
        day: dayName,
        inTime: formatTime(attendance.inTime),
        outTime: formatTime(attendance.outTime),
        mealBreak: minutesToHours(attendance.breakMinutes),
        workHours: minutesToHours(attendance.workingMinutes),
        overtime: minutesToHours(attendance.overtimeMinutes),
        status: attendance.status,
        overtimeStatus: attendance.overtimeStatus,
      };
    });
  }, []);

  const fetchAttendanceData = useCallback(async () => {
    if (!userId) return;

    setLoading(true);
    setError('');

    try {
      const fullMonthParam = fullMonthView ? '&fullMonth=1' : '';
      const response = await api.get(`/attendance/employee/${userId}?month=${month}&year=${year}${fullMonthParam}`);

      if (response.data && response.data.success) {
        setEmployee(response.data.employee);
        setSummary(response.data.summary);

        const transformedRecords = transformAttendanceToRecords(
          response.data.attendance,
          response.data.employee?.name || 'Unknown'
        );
        setRecords(transformedRecords);
      } else {
        setRecords([]);
      }
    } catch (err) {
      console.error('Error fetching attendance details:', err);
      setError('Failed to fetch attendance details');
    } finally {
      setLoading(false);
    }
  }, [fullMonthView, month, transformAttendanceToRecords, userId, year]);

  // Single useEffect that depends on userId, month, and year
  useEffect(() => {
    if (userId) {
      fetchAttendanceData();
    }
  }, [fetchAttendanceData, userId]);

  return <>
      <PageMeta title="Punch Details" />
      <main>
        <PageBreadcrumb title="Punch Details (Monthly)" subtitle="Menu" />
        <div className="flex flex-col gap-5">
          <EmployeeDetails 
            employee={employee} 
            summary={summary} 
            month={month}
            year={year}
            onMonthYearChange={handleMonthYearChange}
          />
    
          <EmployeeWork 
            records={records}
            loading={loading}
            error={error}
            onRetry={fetchAttendanceData}
            fullMonthView={fullMonthView}
            onToggleFullMonth={() => setFullMonthView(v => !v)}
            hasRecords={records.length > 0}
          />
        </div>
      </main>
    </>;
};

export default Index;
