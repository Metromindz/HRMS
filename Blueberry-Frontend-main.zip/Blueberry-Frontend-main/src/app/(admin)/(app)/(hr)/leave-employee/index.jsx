import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import EmpLeave from './components/EmpLeave';
import LeaveCard from './components/LeaveCard';

const Index = () => {
  return <>
      <PageMeta title="Leave Manage (Employee)" />
      <main>
        <PageBreadcrumb title="Employee Leave Details" subtitle="Menu" />
        <LeaveCard />
        <EmpLeave />
      </main>
    </>;
};
export default Index;