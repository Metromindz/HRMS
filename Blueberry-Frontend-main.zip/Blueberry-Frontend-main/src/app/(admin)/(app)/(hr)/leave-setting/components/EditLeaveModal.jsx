import { useState, useEffect } from 'react';
import { LuX, LuCalendarRange, LuSave } from 'react-icons/lu';

const EditLeaveModal = ({ isOpen, onClose, onSave, leave }) => {
  const [formData, setFormData] = useState({
    leaveName: '',
    yearlyCount: '',
    monthlyLimit: '',
    carryForward: false,
  });

  useEffect(() => {
    if (leave) {
      setFormData({
        id: leave._id,
        leaveName: leave.leaveName || '',
        yearlyCount: leave.yearlyCount || '',
        monthlyLimit: leave.monthlyLimit || '',
        carryForward: leave.carryForward || false,
      });
    }
  }, [leave]);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({
      ...formData,
      yearlyCount: parseInt(formData.yearlyCount) || 0,
      monthlyLimit: parseInt(formData.monthlyLimit) || 0
    });
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({ 
      ...formData, 
      [name]: type === 'checkbox' ? checked : value 
    });
  };

  const getFieldClassName = () => {
    return "h-14 w-full bg-white border-2 border-default-100 rounded-2xl px-5 text-sm font-bold text-default-900 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all placeholder:text-default-300 shadow-sm";
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-default-950/40 backdrop-blur-md animate-in fade-in duration-500" onClick={onClose} />
      
      <div className="relative bg-white rounded-[2.5rem] w-full max-w-2xl overflow-hidden shadow-2xl shadow-default-950/20 animate-in zoom-in-95 slide-in-from-bottom-10 duration-500">
        {/* Decorative Background Element */}
        <div className="absolute -top-24 -right-24 size-64 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-24 -left-24 size-64 bg-primary/5 rounded-full blur-3xl" />

        {/* Sticky Header */}
        <div className="relative sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-default-100 px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-5">
            <div className="size-14 flex items-center justify-center bg-primary/10 rounded-2xl text-primary shadow-inner shadow-primary/20 group">
              <LuCalendarRange className="size-7 group-hover:scale-110 transition-transform duration-500" />
            </div>
            <div className="flex flex-col">
              <h3 className="text-xl font-black text-default-900 uppercase tracking-tight">Edit Leave Type</h3>
              <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em] mt-0.5">Update leave policy configurations</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="size-12 flex items-center justify-center rounded-2xl bg-default-50 text-default-400 hover:bg-danger/10 hover:text-danger transition-all duration-300 active:scale-90 group"
          >
            <LuX className="size-6 group-hover:rotate-90 transition-transform duration-300" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="relative">
          <div className="p-10 max-h-[70vh] overflow-y-auto custom-scrollbar">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Leave Name */}
              <div className="space-y-3">
                <label className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] px-1">
                  Leave Name <span className="text-danger">*</span>
                </label>
                <input 
                  type="text" 
                  name="leaveName"
                  value={formData.leaveName}
                  onChange={handleChange}
                  className={getFieldClassName()}
                  placeholder="e.g. Annual Leave" 
                  required
                />
              </div>

              {/* Yearly Count */}
              <div className="space-y-3">
                <label className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] px-1">
                  Yearly Count <span className="text-danger">*</span>
                </label>
                <input 
                  type="number" 
                  name="yearlyCount"
                  value={formData.yearlyCount}
                  onChange={handleChange}
                  className={getFieldClassName()}
                  placeholder="e.g. 12" 
                  min="0"
                  required
                />
              </div>

              {/* Monthly Limit */}
              <div className="space-y-3">
                <label className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] px-1">
                  Monthly Limit
                </label>
                <input 
                  type="number" 
                  name="monthlyLimit"
                  value={formData.monthlyLimit}
                  onChange={handleChange}
                  className={getFieldClassName()}
                  placeholder="0 = no limit" 
                  min="0"
                />
              </div>

              {/* Carry Forward */}
              <div className="flex items-center justify-between bg-default-50/50 p-5 rounded-3xl border-2 border-default-100 hover:border-primary/20 transition-all group">
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-black text-default-900 uppercase tracking-[0.1em]">
                    Allow Carry Forward
                  </span>
                  <span className="text-[9px] font-bold text-default-400 uppercase tracking-widest">
                    Balance rolls to next year
                  </span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    name="carryForward"
                    checked={formData.carryForward}
                    onChange={handleChange}
                    className="sr-only peer" 
                  />
                  <div className="w-14 h-7 bg-default-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:start-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-[20px] after:w-[20px] after:transition-all peer-checked:bg-primary shadow-sm"></div>
                </label>
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="p-8 border-t border-default-100 bg-default-50/30 flex items-center justify-end gap-4">
            <button 
              type="button"
              onClick={onClose}
              className="h-14 px-8 rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] text-default-500 hover:bg-default-100 hover:text-default-900 transition-all active:scale-95"
            >
              Discard Changes
            </button>
            <button 
              type="submit" 
              className="h-14 px-10 bg-primary text-white rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] hover:bg-primary-600 hover:shadow-xl hover:shadow-primary/20 transition-all active:scale-95 flex items-center gap-3 group"
            >
              <LuSave className="size-4 group-hover:scale-110 transition-transform" />
              Update Configuration
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditLeaveModal;