import { LuPencil, LuPlus, LuTrash2, LuFileSpreadsheet } from 'react-icons/lu';

const LeaveList = ({ leaves, loading, canCreate, canEdit, canDelete, onAdd, onEdit, onDelete }) => {
  const displayLeaves = leaves || [];

  return (
    <div className="bg-white border-2 border-default-100 rounded-[2.5rem] overflow-hidden shadow-sm hover:shadow-xl hover:shadow-default-900/5 transition-all duration-700 group/list">
      <div className="p-10 flex flex-wrap items-center justify-between gap-6 border-b border-default-100 sticky top-0 z-20 bg-white/90 backdrop-blur-xl">
        <div className="flex items-center gap-5">
          <div className="size-14 flex items-center justify-center bg-default-50 rounded-2xl text-default-400 group-hover/list:bg-primary/10 group-hover/list:text-primary transition-colors duration-500">
            <LuFileSpreadsheet className="size-7" />
          </div>
          <div className="flex flex-col">
            <h4 className="text-2xl font-black text-default-900 uppercase tracking-tight">Leave Types</h4>
            <p className="text-[10px] font-bold text-default-400 uppercase tracking-[0.2em] mt-0.5">Manage employee leave policies</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          {canCreate && (
            <button
              onClick={onAdd}
              className="h-14 px-8 bg-primary text-white rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] hover:bg-primary-600 hover:shadow-xl hover:shadow-primary/20 transition-all flex items-center gap-3 active:scale-95 group/add"
            >
              <LuPlus className="size-5 group-hover:rotate-90 transition-transform duration-300" />
              Add Leave Type
            </button>
          )}
        </div>
      </div>

      <div className="overflow-x-auto custom-scrollbar">
        <table className="min-w-full">
          <thead>
            <tr className="bg-default-50/50">
              <th className="py-6 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">#</th>
              <th className="py-6 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Leave Name</th>
              <th className="py-6 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Yearly Count</th>
              <th className="py-6 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Monthly Limit</th>
              <th className="py-6 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Carry Forward</th>
              <th className="py-6 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Description</th>
              <th className="py-6 px-8 text-right text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Actions</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-default-100">
            {loading ? (
              <tr>
                <td colSpan="7" className="py-32 text-center">
                  <div className="flex flex-col items-center justify-center gap-6">
                    <div className="relative">
                      <div className="size-16 border-4 border-primary/10 border-t-primary rounded-full animate-spin" />
                      <div className="absolute inset-0 bg-primary/5 rounded-full blur-xl animate-pulse" />
                    </div>
                    <p className="text-[11px] font-black text-default-400 uppercase tracking-[0.2em]">Loading leave types...</p>
                  </div>
                </td>
              </tr>
            ) : displayLeaves.length === 0 ? (
              <tr>
                <td colSpan="7" className="py-32 text-center">
                  <div className="flex flex-col items-center justify-center gap-5 text-default-200 group/empty">
                    <LuFileSpreadsheet className="size-16 group-hover:scale-110 transition-transform duration-500 opacity-20" />
                    <p className="text-[11px] font-black uppercase tracking-[0.2em] opacity-40">No leave types found</p>
                  </div>
                </td>
              </tr>
            ) : (
              displayLeaves.map((leave, index) => (
                <tr key={leave._id || index} className="hover:bg-default-50/50 transition-all duration-500 group/row">
                  <td className="py-6 px-8">
                    <span className="text-xs font-black text-default-300 group-hover/row:text-primary transition-colors">
                      {(index + 1).toString().padStart(2, '0')}
                    </span>
                  </td>
                  <td className="py-6 px-8">
                    <div className="flex flex-col">
                      <span className="text-sm font-black text-default-900 uppercase tracking-tight group-hover/row:text-primary transition-colors">
                        {leave.leaveName}
                      </span>
                    </div>
                  </td>
                  <td className="py-6 px-8">
                    <div className="inline-flex items-center gap-2 bg-primary/5 px-3 py-1.5 rounded-xl border border-primary/10">
                      <span className="text-sm font-black text-primary uppercase tracking-tight">
                        {leave.yearlyCount}
                      </span>
                      <span className="text-[9px] font-bold text-primary/60 uppercase tracking-widest">Days</span>
                    </div>
                  </td>
                  <td className="py-6 px-8">
                    <span className="text-sm font-bold text-default-700 uppercase tracking-tight bg-default-100/50 px-3 py-1.5 rounded-xl border border-default-200">
                      {leave.monthlyLimit === 0 ? 'Unlimited' : leave.monthlyLimit}
                    </span>
                  </td>
                  <td className="py-6 px-8">
                    <span className={`inline-flex px-4 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest border-2 transition-all shadow-sm ${
                      leave.carryForward 
                        ? 'bg-success/5 text-success border-success/20 ring-4 ring-success/5' 
                        : 'bg-danger/5 text-danger border-danger/20 ring-4 ring-danger/5'
                    }`}>
                      {leave.carryForward ? 'Enabled' : 'Disabled'}
                    </span>
                  </td>
                  <td className="py-6 px-8 max-w-xs">
                    <p className="text-sm font-bold text-default-400 truncate group-hover/row:text-default-600 transition-colors">
                      {leave.description || 'No description provided'}
                    </p>
                  </td>
                  <td className="py-6 px-8 text-right">
                    <div className="flex items-center justify-end gap-3 opacity-0 group-hover/row:opacity-100 transition-all duration-500 translate-x-4 group-hover/row:translate-x-0">
                      {canEdit && (
                        <button
                          onClick={() => onEdit(leave)}
                          className="size-11 flex items-center justify-center bg-white border border-default-200 rounded-2xl text-default-600 hover:bg-primary hover:text-white hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all active:scale-90 group/edit"
                          title="Edit Policy"
                        >
                          <LuPencil className="size-4 group-hover/edit:rotate-12 transition-transform" />
                        </button>
                      )}
                      {canDelete && (
                        <button
                          onClick={() => onDelete(leave)}
                          className="size-11 flex items-center justify-center bg-white border border-default-200 rounded-2xl text-danger hover:bg-danger hover:text-white hover:border-danger hover:shadow-lg hover:shadow-danger/20 transition-all active:scale-90 group/delete"
                          title="Delete Policy"
                        >
                          <LuTrash2 className="size-4 group-hover/delete:scale-110 transition-transform" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LeaveList;
