import { leaveService } from '@/services/leaveService';
import { shiftService } from '@/services/shiftService';
import { useEffect, useState, useMemo } from 'react';
import { LuPencil, LuTrash2, LuPlus, LuClipboardList, LuClock, LuCircleCheck, LuRotateCcw, LuTriangleAlert } from 'react-icons/lu';
import DeleteLeaveModal from './DeleteLeaveModal';
import EditLeaveModal from './EditLeaveModal';
import EditShiftModal from './EditShiftModal';
import DeleteShiftModal from './DeleteShiftModal';
import { useAuth } from '@/context/AuthContext';

const LeaveSettings = () => {
  const { hasPermission } = useAuth();
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedLeave, setSelectedLeave] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedShift, setSelectedShift] = useState(null);
  const [isEditShiftModalOpen, setIsEditShiftModalOpen] = useState(false);
  const [isDeleteShiftModalOpen, setIsDeleteShiftModalOpen] = useState(false);
  const [shifts, setShifts] = useState([]);
  const [message, setMessage] = useState({ type: '', text: '' });

  // Calculate Stats
  const stats = useMemo(() => {
    return {
      totalLeaves: leaves.length,
      totalShifts: shifts.length,
      carryForwardLeaves: leaves.filter(l => l.carryForward).length,
      defaultShifts: shifts.filter(s => s.isDefault).length
    };
  }, [leaves, shifts]);

  // Permission checks for Leave Settings
  const canCreateLeave = hasPermission('commonleave.create');
  const canEditLeave = hasPermission('commonleave.edit');
  const canDeleteLeave = hasPermission('commonleave.delete');
  const canViewLeave = hasPermission('commonleave.view');

  // Permission checks for Shift Details
  const canCreateShift = hasPermission('shift.create');
  const canEditShift = hasPermission('shift.edit');
  const canDeleteShift = hasPermission('shift.delete');
  const canViewShift = hasPermission('shift.view');

  const [activeTab, setActiveTab] = useState('Leave Settings');
  const [formData, setFormData] = useState({
    leaveName: '',
    yearlyCount: '',
    monthlyLimit: '',
    carryForward: false,
  });

  // Shift Details state
  const [shiftData, setShiftData] = useState({
    name: '',
    startTime: '',
    endTime: '',
    isDefault: false
  });

  // Only show tabs that user has permission to view
  const tabs = [];
  if (canViewLeave) tabs.push('Leave Settings');
  if (canViewShift) tabs.push('Shift Details');

  // Fetch leaves and shifts on component mount only if user has view permission
  useEffect(() => {
    if (canViewLeave && activeTab === 'Leave Settings') {
      fetchLeaves();
    }
    if (canViewShift && activeTab === 'Shift Details') {
      fetchShifts();
    }
  }, [activeTab, canViewLeave, canViewShift]);

  // Set initial active tab based on permissions
  useEffect(() => {
    if (tabs.length > 0 && !tabs.includes(activeTab)) {
      setActiveTab(tabs[0]);
    }
  }, [tabs]);

  // Clear message after 3 seconds
  useEffect(() => {
    if (message.text) {
      const timer = setTimeout(() => setMessage({ type: '', text: '' }), 3000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  const fetchLeaves = async () => {
    try {
      setLoading(true);
      const leavesData = await leaveService.getAll();
      setLeaves(leavesData);
    } catch (error) {
      console.error('Error fetching leaves:', error);
      setMessage({ type: 'error', text: 'Failed to fetch leave types' });
    } finally {
      setLoading(false);
    }
  };

  const fetchShifts = async () => {
    try {
      setLoading(true);
      const data = await shiftService.getAll();
      setShifts(data);
    } catch (error) {
      console.error('Error fetching shifts:', error);
      setMessage({ type: 'error', text: 'Failed to fetch shifts' });
    } finally {
      setLoading(false);
    }
  };

  const handleAddShift = async (e) => {
    e.preventDefault();
    if (!shiftData.name || !shiftData.startTime || !shiftData.endTime) {
      setMessage({ type: 'error', text: 'Shift name, start time and end time are required' });
      return;
    }

    try {
      setLoading(true);
      await shiftService.create(shiftData);
      await fetchShifts();
      setShiftData({ name: '', startTime: '', endTime: '', isDefault: false });
      setMessage({ type: 'success', text: 'Shift added successfully!' });
    } catch (error) {
      console.error('Error adding shift:', error);
      setMessage({ type: 'error', text: error.response?.data?.message || 'Failed to add shift' });
    } finally {
      setLoading(false);
    }
  };

  const handleEditShift = async (shiftData) => {
    try {
      setLoading(true);
      await shiftService.update(shiftData.id, shiftData);
      await fetchShifts();
      setIsEditShiftModalOpen(false);
      setSelectedShift(null);
      setMessage({ type: 'success', text: 'Shift updated successfully!' });
    } catch (error) {
      console.error('Error updating shift:', error);
      setMessage({ type: 'error', text: error.response?.data?.message || 'Failed to update shift' });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteShift = async () => {
    try {
      setLoading(true);
      await shiftService.delete(selectedShift._id);
      await fetchShifts();
      setIsDeleteShiftModalOpen(false);
      setSelectedShift(null);
      setMessage({ type: 'success', text: 'Shift deleted successfully!' });
    } catch (error) {
      console.error('Error deleting shift:', error);
      setMessage({ type: 'error', text: 'Failed to delete shift' });
    } finally {
      setLoading(false);
    }
  };

  const handleAddLeave = async e => {
    e.preventDefault();
    if (!formData.leaveName || !formData.yearlyCount) {
      setMessage({ type: 'error', text: 'Leave name and yearly count are required' });
      return;
    }

    try {
      setLoading(true);
      await leaveService.create({
        leaveName: formData.leaveName,
        yearlyCount: parseInt(formData.yearlyCount) || 0,
        monthlyLimit: parseInt(formData.monthlyLimit) || 0,
        carryForward: formData.carryForward,
      });
      await fetchLeaves();
      setFormData({ leaveName: '', yearlyCount: '', monthlyLimit: '', carryForward: false });
      setMessage({ type: 'success', text: 'Leave type added successfully!' });
    } catch (error) {
      console.error('Error adding leave:', error);
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Failed to add leave type',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = e => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleEditLeave = async leaveData => {
    try {
      setLoading(true);
      await leaveService.update(leaveData.id, leaveData);
      await fetchLeaves();
      setIsEditModalOpen(false);
      setSelectedLeave(null);
      setMessage({ type: 'success', text: 'Leave type updated successfully!' });
    } catch (error) {
      console.error('Error updating leave:', error);
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Failed to update leave type',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteLeave = async id => {
    try {
      setLoading(true);
      await leaveService.delete(id);
      await fetchLeaves();
      setIsDeleteModalOpen(false);
      setSelectedLeave(null);
      setMessage({ type: 'success', text: 'Leave type deleted successfully!' });
    } catch (error) {
      console.error('Error deleting leave:', error);
      setMessage({
        type: 'error',
        text: error.response?.data?.message || 'Failed to delete leave type',
      });
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Leave Types', value: stats.totalLeaves, icon: LuClipboardList, color: 'primary' },
          { label: 'Total Shifts', value: stats.totalShifts, icon: LuClock, color: 'info' },
          { label: 'Carry Forward', value: stats.carryForwardLeaves, icon: LuRotateCcw, color: 'success' },
          { label: 'Default Shifts', value: stats.defaultShifts, icon: LuCircleCheck, color: 'warning' },
        ].map((stat, idx) => (
          <div key={idx} className="bg-white dark:bg-default-50 p-5  rounded-xl border border-default-200 dark:border-default-100 flex items-center gap-4 group hover:border-primary/30 hover:shadow-xl hover:shadow-primary/5 transition-all duration-500 cursor-default">
            <div className={`size-14 rounded-2xl bg-${stat.color}/10 flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition-all duration-500  `}>
              <stat.icon className={`size-7 text-${stat.color}`} />
            </div>
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-default-400 mb-1">{stat.label}</p>
              <p className="text-2xl font-black text-default-900 dark:text-default-100 group-hover:translate-x-1 transition-transform duration-500">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Success/Error Messages */}
      {message.text && (
        <div className={`fixed top-4 right-4 z-[100] min-w-[320px] p-5  rounded-xl border-2 shadow-2xl animate-in slide-in-from-right-10 duration-500 backdrop-blur-xl ${
          message.type === 'success' 
            ? 'bg-success/5 border-success/20 text-success shadow-success/10' 
            : 'bg-danger/5 border-danger/20 text-danger shadow-danger/10'
        }`}>
          <div className="flex items-center gap-4">
            <div className={`size-12 rounded-2xl flex items-center justify-center shadow-inner animate-bounce ${
              message.type === 'success' ? 'bg-success/20' : 'bg-danger/20'
            }`}>
              {message.type === 'success' ? (
                <LuCircleCheck className="size-6" />
              ) : (
                <LuTriangleAlert className="size-6" />
              )}
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60">
                {message.type === 'success' ? 'Success' : 'Error'}
              </span>
              <p className="text-sm font-black uppercase tracking-tight">{message.text}</p>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white dark:bg-default-50 border border-default-200 dark:border-default-100  rounded-xl overflow-hidden  hover:shadow-md transition-all duration-500">
        <div className="p-8 flex flex-wrap items-center justify-between gap-6 border-b border-default-200 dark:border-default-100 bg-white/80 dark:bg-default-50/80 backdrop-blur-md sticky top-0 z-10">
          <div className="flex flex-col">
            <h4 className="text-2xl font-black text-default-900 dark:text-default-100 uppercase tracking-tight">Common Settings</h4>
            <p className="text-[10px] font-black text-default-400 uppercase tracking-[0.3em] mt-1">Manage leave policies and work shifts</p>
          </div>

          <div className="flex bg-default-100 dark:bg-default-200 p-1.5 rounded-2xl border border-default-200/50 dark:border-default-100/50">
            {tabs.map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all duration-500 active:scale-95 ${
                  activeTab === tab
                    ? 'bg-white dark:bg-default-50 text-primary shadow-lg shadow-primary/10 ring-1 ring-default-200 dark:ring-default-100 translate-y-[-1px]'
                    : 'text-default-500 hover:text-default-700 dark:hover:text-default-300 hover:bg-default-200/50'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        <div className="p-8">
          {activeTab === 'Leave Settings' && canViewLeave && (
            <div className="space-y-10 animate-in fade-in zoom-in-95 duration-700">
              {canCreateLeave && (
                <div className="bg-default-50/50 dark:bg-default-100/50 p-10  rounded-xl border border-default-200 dark:border-default-100 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                    <LuClipboardList className="size-24 rotate-12" />
                  </div>
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-2 h-6 bg-primary rounded-full shadow-[0_0_15px_rgba(var(--primary-rgb),0.5)]" />
                    <span className="text-xs font-black text-primary uppercase tracking-[0.2em]">Add New Leave Type</span>
                  </div>
                  <form onSubmit={handleAddLeave} className="grid grid-cols-1 md:grid-cols-4 gap-8 items-end relative z-10">
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] px-1">Leave Name</label>
                      <input
                        type="text"
                        name="leaveName"
                        value={formData.leaveName}
                        onChange={handleInputChange}
                        className="h-14 w-full bg-white dark:bg-default-50 border-2 border-default-100 dark:border-default-200 rounded-2xl px-5 text-sm font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all placeholder:text-default-300  "
                        placeholder="e.g. Sick Leave"
                        required
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] px-1">Yearly Count</label>
                      <input
                        type="number"
                        name="yearlyCount"
                        value={formData.yearlyCount}
                        onChange={handleInputChange}
                        className="h-14 w-full bg-white dark:bg-default-50 border-2 border-default-100 dark:border-default-200 rounded-2xl px-5 text-sm font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all placeholder:text-default-300  "
                        placeholder="12"
                        min="0"
                        required
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] px-1">Monthly Limit</label>
                      <input
                        type="number"
                        name="monthlyLimit"
                        value={formData.monthlyLimit}
                        onChange={handleInputChange}
                        className="h-14 w-full bg-white dark:bg-default-50 border-2 border-default-100 dark:border-default-200 rounded-2xl px-5 text-sm font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all placeholder:text-default-300  "
                        placeholder="2"
                        min="0"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={loading}
                      className="h-14 px-10 bg-primary text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] hover:bg-primary-600 hover:shadow-xl hover:shadow-primary/20 transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed group/btn"
                    >
                      {loading ? (
                        <div className="size-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          <LuPlus className="size-4 group-hover:rotate-90 transition-transform duration-500" />
                          <span>Add Leave</span>
                        </>
                      )}
                    </button>
                  </form>
                </div>
              )}

              <div className="border border-default-200 dark:border-default-100  rounded-xl overflow-hidden  ">
                <table className="min-w-full">
                  <thead>
                    <tr className="bg-default-50/50 dark:bg-default-100/50 border-b border-default-200 dark:border-default-100">
                      <th className="py-5 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Leave Type</th>
                      <th className="py-5 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Yearly</th>
                      <th className="py-5 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Monthly</th>
                      <th className="py-5 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Carry Forward</th>
                      <th className="py-5 px-8 text-right text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-default-100 dark:divide-default-200 bg-white dark:bg-default-50">
                    {loading ? (
                      <tr>
                        <td colSpan="5" className="py-32 text-center">
                          <div className="flex flex-col items-center justify-center gap-4">
                            <div className="size-16 border-4 border-primary/20 border-t-primary rounded-full animate-spin shadow-inner" />
                            <p className="text-xs font-black text-default-400 uppercase tracking-[0.3em]">Fetching Leave Data...</p>
                          </div>
                        </td>
                      </tr>
                    ) : leaves.length === 0 ? (
                      <tr>
                        <td colSpan="5" className="py-32 text-center">
                          <div className="flex flex-col items-center justify-center gap-5">
                            <div className="size-20 bg-default-50 dark:bg-default-100  rounded-xl flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform duration-500">
                              <LuPlus className="size-10 text-default-200" />
                            </div>
                            <p className="text-xs font-black text-default-400 uppercase tracking-[0.3em]">No leave types found</p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      leaves.map(leave => (
                        <tr key={leave._id} className="hover:bg-primary/[0.02] transition-all duration-500 group/row">
                          <td className="py-6 px-8">
                            <div className="flex flex-col">
                              <span className="text-sm font-black text-default-900 dark:text-default-100 uppercase tracking-tight group-hover/row:text-primary transition-colors">{leave.leaveName}</span>
                              <span className="text-[10px] font-bold text-default-400 uppercase tracking-widest mt-0.5">Leave Type</span>
                            </div>
                          </td>
                          <td className="py-6 px-8">
                            <span className="text-sm font-black text-default-700 dark:text-default-300">{leave.yearlyCount} Days</span>
                          </td>
                          <td className="py-6 px-8">
                            <span className="text-sm font-black text-default-700 dark:text-default-300">{leave.monthlyLimit === 0 ? '0' : leave.monthlyLimit} Days</span>
                          </td>
                          <td className="py-6 px-8">
                            <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] border transition-all ${
                              leave.carryForward 
                                ? 'bg-success/10 text-success border-success/20 ring-4 ring-success/5' 
                                : 'bg-danger/10 text-danger border-danger/20 ring-4 ring-danger/5'
                            }`}>
                              {leave.carryForward ? 'Yes' : 'No'}
                            </span>
                          </td>
                          <td className="py-6 px-8 text-right">
                            <div className="flex items-center justify-end gap-3 opacity-0 group-hover/row:opacity-100 transition-all duration-500 translate-x-4 group-hover/row:translate-x-0">
                              {canEditLeave && (
                                <button
                                  onClick={() => {
                                    setSelectedLeave(leave);
                                    setIsEditModalOpen(true);
                                  }}
                                  className="size-11 flex items-center justify-center bg-white dark:bg-default-100 border border-default-200 dark:border-default-200 rounded-2xl text-default-600 dark:text-default-400 hover:bg-primary hover:text-white hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all active:scale-90 group/edit"
                                >
                                  <LuPencil className="size-4 group-hover/edit:rotate-12 transition-transform" />
                                </button>
                              )}
                              {canDeleteLeave && (
                                <button
                                  onClick={() => {
                                    setSelectedLeave(leave);
                                    setIsDeleteModalOpen(true);
                                  }}
                                  className="size-11 flex items-center justify-center bg-white dark:bg-default-100 border border-default-200 dark:border-default-200 rounded-2xl text-default-600 dark:text-default-400 hover:bg-danger hover:text-white hover:border-danger hover:shadow-lg hover:shadow-danger/20 transition-all active:scale-90 group/delete"
                                >
                                  <LuTrash2 className="size-4 group-hover/delete:scale-110 transition-transform" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'Shift Details' && canViewShift && (
            <div className="space-y-10 animate-in fade-in zoom-in-95 duration-700">
              {canCreateShift && (
                <div className="bg-default-50/50 dark:bg-default-100/50 p-10  rounded-xl border border-default-200 dark:border-default-100 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                    <LuClock className="size-24 -rotate-12" />
                  </div>
                  <div className="flex items-center gap-3 mb-8">
                    <div className="w-2 h-6 bg-primary rounded-full shadow-[0_0_15px_rgba(var(--primary-rgb),0.5)]" />
                    <span className="text-xs font-black text-primary uppercase tracking-[0.2em]">Add New Work Shift</span>
                  </div>
                  <form onSubmit={handleAddShift} className="grid grid-cols-1 md:grid-cols-4 gap-8 items-end relative z-10">
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] px-1">Shift Name</label>
                      <input
                        type="text"
                        value={shiftData.name}
                        onChange={e => setShiftData({ ...shiftData, name: e.target.value })}
                        className="h-14 w-full bg-white dark:bg-default-50 border-2 border-default-100 dark:border-default-200 rounded-2xl px-5 text-sm font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all placeholder:text-default-300  "
                        placeholder="e.g. Morning Shift"
                        required
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] px-1">Start Time</label>
                      <input
                        type="time"
                        value={shiftData.startTime}
                        onChange={e => setShiftData({ ...shiftData, startTime: e.target.value })}
                        className="h-14 w-full bg-white dark:bg-default-50 border-2 border-default-100 dark:border-default-200 rounded-2xl px-5 text-sm font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all  "
                        required
                      />
                    </div>
                    <div className="space-y-3">
                      <label className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] px-1">End Time</label>
                      <input
                        type="time"
                        value={shiftData.endTime}
                        onChange={e => setShiftData({ ...shiftData, endTime: e.target.value })}
                        className="h-14 w-full bg-white dark:bg-default-50 border-2 border-default-100 dark:border-default-200 rounded-2xl px-5 text-sm font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all  "
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={loading}
                      className="h-14 px-10 bg-primary text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] hover:bg-primary-600 hover:shadow-xl hover:shadow-primary/20 transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed group/btn"
                    >
                      {loading ? (
                        <div className="size-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          <LuPlus className="size-4 group-hover:rotate-90 transition-transform duration-500" />
                          <span>Add Shift</span>
                        </>
                      )}
                    </button>
                  </form>
                </div>
              )}

              <div className="border border-default-200 dark:border-default-100  rounded-xl overflow-hidden  ">
                <table className="min-w-full">
                  <thead>
                    <tr className="bg-default-50/50 dark:bg-default-100/50 border-b border-default-200 dark:border-default-100">
                      <th className="py-5 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Shift Name</th>
                      <th className="py-5 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Start Time</th>
                      <th className="py-5 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">End Time</th>
                      <th className="py-5 px-8 text-left text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Default</th>
                      <th className="py-5 px-8 text-right text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-default-100 dark:divide-default-200 bg-white dark:bg-default-50">
                    {loading ? (
                      <tr>
                        <td colSpan="5" className="py-32 text-center">
                          <div className="flex flex-col items-center justify-center gap-4">
                            <div className="size-16 border-4 border-primary/20 border-t-primary rounded-full animate-spin shadow-inner" />
                            <p className="text-xs font-black text-default-400 uppercase tracking-[0.3em]">Fetching Shift Data...</p>
                          </div>
                        </td>
                      </tr>
                    ) : shifts.length === 0 ? (
                      <tr>
                        <td colSpan="5" className="py-32 text-center">
                          <div className="flex flex-col items-center justify-center gap-5">
                            <div className="size-20 bg-default-50 dark:bg-default-100  rounded-xl flex items-center justify-center shadow-inner">
                              <LuClock className="size-10 text-default-200" />
                            </div>
                            <p className="text-xs font-black text-default-400 uppercase tracking-[0.3em]">No shifts found</p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      shifts.map(shift => (
                        <tr key={shift._id} className="hover:bg-primary/[0.02] transition-all duration-500 group/row">
                          <td className="py-6 px-8">
                            <div className="flex flex-col">
                              <span className="text-sm font-black text-default-900 dark:text-default-100 uppercase tracking-tight group-hover/row:text-primary transition-colors">{shift.name}</span>
                              <span className="text-[10px] font-bold text-default-400 uppercase tracking-widest mt-0.5">Work Shift</span>
                            </div>
                          </td>
                          <td className="py-6 px-8">
                            <span className="text-sm font-black text-default-700 dark:text-default-300">{shift.startTime}</span>
                          </td>
                          <td className="py-6 px-8">
                            <span className="text-sm font-black text-default-700 dark:text-default-300">{shift.endTime}</span>
                          </td>
                          <td className="py-6 px-8">
                            <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] border transition-all ${
                              shift.isDefault 
                                ? 'bg-success/10 text-success border-success/20 ring-4 ring-success/5' 
                                : 'bg-default-50 dark:bg-default-100 text-default-400 border-default-200'
                            }`}>
                              {shift.isDefault ? 'Yes' : 'No'}
                            </span>
                          </td>
                          <td className="py-6 px-8 text-right">
                            <div className="flex items-center justify-end gap-3 opacity-0 group-hover/row:opacity-100 transition-all duration-500 translate-x-4 group-hover/row:translate-x-0">
                              {canEditShift && (
                                <button
                                  onClick={() => {
                                    setSelectedShift(shift);
                                    setIsEditShiftModalOpen(true);
                                  }}
                                  className="size-11 flex items-center justify-center bg-white dark:bg-default-100 border border-default-200 dark:border-default-200 rounded-2xl text-default-600 dark:text-default-400 hover:bg-primary hover:text-white hover:border-primary hover:shadow-lg hover:shadow-primary/20 transition-all active:scale-90 group/edit"
                                >
                                  <LuPencil className="size-4 group-hover/edit:rotate-12 transition-transform" />
                                </button>
                              )}
                              {canDeleteShift && (
                                <button
                                  onClick={() => {
                                    setSelectedShift(shift);
                                    setIsDeleteShiftModalOpen(true);
                                  }}
                                  className="size-11 flex items-center justify-center bg-white dark:bg-default-100 border border-default-200 dark:border-default-200 rounded-2xl text-default-600 dark:text-default-400 hover:bg-danger hover:text-white hover:border-danger hover:shadow-lg hover:shadow-danger/20 transition-all active:scale-90 group/delete"
                                >
                                  <LuTrash2 className="size-4 group-hover/delete:scale-110 transition-transform" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      {canEditLeave && (
        <EditLeaveModal
          isOpen={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            setSelectedLeave(null);
          }}
          onSave={handleEditLeave}
          leave={selectedLeave}
        />
      )}
      {canDeleteLeave && (
        <DeleteLeaveModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            setIsDeleteModalOpen(false);
            setSelectedLeave(null);
          }}
          onConfirm={() => selectedLeave && handleDeleteLeave(selectedLeave._id)}
          leave={selectedLeave}
        />
      )}
      {canEditShift && (
        <EditShiftModal
          isOpen={isEditShiftModalOpen}
          onClose={() => {
            setIsEditShiftModalOpen(false);
            setSelectedShift(null);
          }}
          onSave={handleEditShift}
          shift={selectedShift}
        />
      )}
      {canDeleteShift && (
        <DeleteShiftModal
          isOpen={isDeleteShiftModalOpen}
          onClose={() => {
            setIsDeleteShiftModalOpen(false);
            setSelectedShift(null);
          }}
          onConfirm={handleDeleteShift}
          shift={selectedShift}
        />
      )}
    </div>
  );
};

export default LeaveSettings;