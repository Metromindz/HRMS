import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import LeaveSettings from './components/LeaveSettings';

const Index = () => {
  return (
    <>
      <PageMeta title="Common Setting" />
      <main>
        <PageBreadcrumb title="Common Settings" subtitle="Menu" />
        <LeaveSettings/>
      </main>
    </>
  );
};

export default Index;
