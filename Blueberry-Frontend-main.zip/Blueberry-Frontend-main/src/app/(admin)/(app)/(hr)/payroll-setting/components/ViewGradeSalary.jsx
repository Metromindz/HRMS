import { LuX } from 'react-icons/lu';

const ViewGradeSalary = ({ isOpen, onClose, grade }) => {
  if (!isOpen || !grade) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-default-900/60 backdrop-blur-sm transition-all duration-300 animate-in fade-in">
      <div className="relative bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-default-100 animate-in zoom-in-95 duration-300">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-default-100 bg-default-50/50 sticky top-0 z-10 backdrop-blur-md">
          <div className="flex flex-col gap-1">
            <h3 className="text-xl font-black text-default-900 uppercase tracking-tight">Grade Structure Details</h3>
            <p className="text-xs font-bold text-default-500 uppercase tracking-widest">Complete breakdown of salary components</p>
          </div>
          <button 
            type="button" 
            className="size-10 flex items-center justify-center text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-90" 
            onClick={onClose}
          >
            <LuX className="size-6" />
          </button>
        </div>

        <div className="p-8 overflow-y-auto custom-scrollbar flex-1">
          <div className="space-y-10">
            {/* Basic Information */}
            <div className="space-y-6">
              <div className="flex items-center gap-2 px-1">
                <div className="w-1 h-4 bg-primary rounded-full" />
                <h4 className="text-xs font-black text-default-900 uppercase tracking-widest">Basic Information</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-4 bg-default-50/50 rounded-2xl border border-default-100 space-y-1 transition-all hover:border-primary/20 hover:bg-white group">
                  <label className="text-[10px] font-black text-default-400 uppercase tracking-widest group-hover:text-primary transition-colors">Grade</label>
                  <p className="text-sm font-black text-default-900 uppercase">{grade.grade}</p>
                </div>
                <div className="p-4 bg-default-50/50 rounded-2xl border border-default-100 space-y-1 transition-all hover:border-primary/20 hover:bg-white group">
                  <label className="text-[10px] font-black text-default-400 uppercase tracking-widest group-hover:text-primary transition-colors">Basic Pay</label>
                  <p className="text-sm font-black text-default-900">
                    {grade.basic?.value ? `${grade.basic.value}${grade.basic.unit === 'percent' ? '%' : ''}` : 'Not Set'}
                  </p>
                </div>
                <div className="p-4 bg-default-50/50 rounded-2xl border border-default-100 space-y-1 transition-all hover:border-primary/20 hover:bg-white group">
                  <label className="text-[10px] font-black text-default-400 uppercase tracking-widest group-hover:text-primary transition-colors">HRA</label>
                  <p className="text-sm font-black text-default-900">
                    {grade.hra?.value ? `${grade.hra.value}${grade.hra.unit === 'percent' ? '%' : ''}` : 'Not Set'}
                  </p>
                </div>
              </div>
            </div>

            {/* Statutory Compliance */}
            <div className="space-y-6">
              <div className="flex items-center gap-2 px-1">
                <div className="w-1 h-4 bg-primary rounded-full" />
                <h4 className="text-xs font-black text-default-900 uppercase tracking-widest">Statutory Compliance</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-5 bg-default-50/50 rounded-2xl border border-default-100 flex items-center justify-between transition-all hover:border-primary/20 hover:bg-white group">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-default-400 uppercase tracking-widest group-hover:text-primary transition-colors">Provident Fund (PF)</label>
                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all ${
                        grade.pfEnabled ? 'bg-success/10 text-success border-success/20' : 'bg-danger/10 text-danger border-danger/20'
                      }`}>
                        {grade.pfEnabled ? 'Enabled' : 'Disabled'}
                      </span>
                      {grade.pfEnabled && grade.pfPercent && (
                        <span className="text-xs font-bold text-default-500">({grade.pfPercent}%)</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="p-5 bg-default-50/50 rounded-2xl border border-default-100 flex items-center justify-between transition-all hover:border-primary/20 hover:bg-white group">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-default-400 uppercase tracking-widest group-hover:text-primary transition-colors">ESI Status</label>
                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all ${
                        grade.esiEnabled ? 'bg-success/10 text-success border-success/20' : 'bg-danger/10 text-danger border-danger/20'
                      }`}>
                        {grade.esiEnabled ? 'Enabled' : 'Disabled'}
                      </span>
                      {grade.esiEnabled && grade.esiPercent && (
                        <span className="text-xs font-bold text-default-500">({grade.esiPercent}%)</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Fixed Allowances */}
            <div className="space-y-6">
              <div className="flex items-center gap-2 px-1">
                <div className="w-1 h-4 bg-primary rounded-full" />
                <h4 className="text-xs font-black text-default-900 uppercase tracking-widest">Fixed Allowances</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { label: 'Medical', value: grade.medical, icon: 'M' },
                  { label: 'Special', value: grade.specialAllowance, icon: 'S' },
                  { label: 'Conveyance', value: grade.conveyanceAllowance, icon: 'C' },
                  { label: 'Prof. Tax', value: grade.pt, icon: 'P' },
                  { label: 'TDS', value: grade.tds, icon: 'T' }
                ].map((item, idx) => (
                  <div key={idx} className="p-4 bg-default-50/50 rounded-2xl border border-default-100 flex items-center gap-4 transition-all hover:border-primary/20 hover:bg-white group">
                    <div className="size-10 rounded-xl bg-default-100 text-default-400 flex items-center justify-center font-black text-xs group-hover:bg-primary/10 group-hover:text-primary transition-all">
                      {item.icon}
                    </div>
                    <div className="space-y-0.5">
                      <label className="text-[10px] font-black text-default-400 uppercase tracking-widest">{item.label}</label>
                      <p className="text-sm font-black text-default-900">${item.value || '0.00'}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Extra Allowances */}
            {grade.extraAllowances && grade.extraAllowances.length > 0 && (
              <div className="space-y-6">
                <div className="flex items-center gap-2 px-1">
                  <div className="w-1 h-4 bg-primary rounded-full" />
                  <h4 className="text-xs font-black text-default-900 uppercase tracking-widest">Extra Allowances</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {grade.extraAllowances.map((allowance, index) => (
                    <div key={index} className="p-5 bg-default-50/50 border border-default-100 rounded-2xl flex justify-between items-center transition-all hover:border-primary/20 hover:bg-white group">
                      <div className="space-y-1">
                        <label className="text-[10px] font-black text-default-400 uppercase tracking-widest group-hover:text-primary transition-colors">Allowance Name</label>
                        <p className="text-sm font-black text-default-900 uppercase tracking-tight">{allowance.name}</p>
                      </div>
                      <div className="text-right space-y-1">
                        <label className="text-[10px] font-black text-default-400 uppercase tracking-widest">Amount</label>
                        <p className="text-sm font-black text-primary">${allowance.amount}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end items-center p-6 border-t border-default-100 bg-default-50/50 sticky bottom-0 z-10 backdrop-blur-md">
          <button 
            type="button"
            onClick={onClose}
            className="h-10 px-8 text-sm font-black text-white bg-primary hover:bg-primary-600 rounded-xl transition-all active:scale-95"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};

export default ViewGradeSalary;