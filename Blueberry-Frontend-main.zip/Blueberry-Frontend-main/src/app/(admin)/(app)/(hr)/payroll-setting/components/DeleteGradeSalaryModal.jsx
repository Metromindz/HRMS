import { LuX } from 'react-icons/lu';

const DeleteGradeSalaryModal = ({ isOpen, onClose, onConfirm, grade }) => {
  if (!isOpen || !grade) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-default-900/60 backdrop-blur-sm transition-all duration-300 animate-in fade-in">
      <div className="relative bg-white rounded-3xl max-w-md w-full overflow-hidden border border-default-100 animate-in zoom-in-95 duration-300">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-default-100 bg-default-50/50">
          <div className="flex flex-col gap-1">
            <h3 className="text-xl font-black text-default-900 uppercase tracking-tight">Delete Grade</h3>
            <p className="text-xs font-bold text-default-500 uppercase tracking-widest">Permanent action required</p>
          </div>
          <button 
            type="button" 
            className="size-10 flex items-center justify-center text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-90" 
            onClick={onClose}
          >
            <LuX className="size-6" />
          </button>
        </div>

        <div className="p-8">
          <div className="flex flex-col items-center text-center gap-6">
            <div className="size-20 bg-danger/10 rounded-3xl flex items-center justify-center text-danger animate-bounce">
              <svg className="size-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
              </svg>
            </div>
            
            <div className="space-y-2">
              <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">Confirm Deletion</h3>
              <p className="text-sm font-bold text-default-500 leading-relaxed px-4">
                Are you sure you want to delete the salary structure for grade <span className="text-danger">{grade.grade}</span>? This action cannot be undone.
              </p>
            </div>

            <div className="w-full p-4 bg-default-50 rounded-2xl border border-default-100 flex items-center justify-between">
              <div className="text-left">
                <p className="text-[10px] font-black text-default-400 uppercase tracking-widest">Grade Name</p>
                <p className="text-sm font-black text-default-900 uppercase">{grade.grade}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-black text-default-400 uppercase tracking-widest">Basic Pay</p>
                <p className="text-sm font-black text-default-900">
                  {grade.basic?.value ? `${grade.basic.value}${grade.basic.unit === 'percent' ? '%' : ''}` : 'N/A'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 p-6 border-t border-default-100 bg-default-50/50">
          <button 
            type="button"
            onClick={onClose}
            className="flex-1 h-10 px-6 text-[10px] font-black text-default-500 uppercase tracking-widest hover:text-default-700 hover:bg-default-100 rounded-xl transition-all active:scale-95"
          >
            Keep Structure
          </button>
          <button 
            type="button"
            onClick={onConfirm}
            className="flex-1 h-10 px-6 text-[10px] font-black text-white bg-danger hover:bg-danger-600 rounded-xl transition-all active:scale-95"
          >
            Confirm Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default DeleteGradeSalaryModal;