import { useState, useEffect, useMemo } from 'react';
import { gradeService } from '@/services/gradeService';
import GradeSalaryList from './GradeSalaryList';
import AddGradeSalary from './AddGradeSalary';
import EditGradeSalary from './EditGradeSalary';
import ViewGradeSalary from './ViewGradeSalary';
import DeleteGradeSalaryModal from './DeleteGradeSalaryModal';
import { useAuth } from '@/context/AuthContext';
import { LuAward, LuWallet, LuBanknote, LuCircleCheck } from 'react-icons/lu';

const Payrolls = () => {
  const {hasPermission } = useAuth();
  const [grades, setGrades] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedGrade, setSelectedGrade] = useState(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  // Pagination State
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 1
  });

  // Calculate Stats
  const stats = useMemo(() => {
    const total = pagination.total || 0;
    const active = grades.filter(g => g.status === 'active').length;
    const withSalaryRange = grades.filter(g => g.basic?.value && g.hra?.value).length;
    const withoutSalaryRange = grades.filter(g => !g.basic?.value || !g.hra?.value).length;
    return { total, active, withSalaryRange, withoutSalaryRange };
  }, [grades, pagination.total]);

  // Permission checks (hardcoded for now)
  const canCreate = hasPermission('grade.create');
  const canEdit = hasPermission('grade.edit');
  const canDelete = hasPermission('grade.delete');


  // Fetch grades on component mount
  useEffect(() => {
    fetchGrades();
  }, [pagination.page]);

  // Clear message after 3 seconds
  useEffect(() => {
    if (message.text) {
      const timer = setTimeout(() => setMessage({ type: '', text: '' }), 3000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  const fetchGrades = async () => {
    try {
      setLoading(true);
      const gradesData = await gradeService.getAll();
      setGrades(gradesData);
      setPagination(prev => ({
        ...prev,
        total: gradesData.length,
        totalPages: Math.ceil(gradesData.length / prev.limit)
      }));
    } catch (error) {
      console.error('Error fetching grades:', error);
      setMessage({ type: 'error', text: 'Failed to fetch grades' });
    } finally {
      setLoading(false);
    }
  };

  const handleAddGrade = async (gradeData) => {
    try {
      setLoading(true);
      const transformedData = gradeService.transformToBackend(gradeData);
      await gradeService.create(transformedData);
      await fetchGrades();
      setIsAddModalOpen(false);
      setMessage({ type: 'success', text: 'Grade added successfully!' });
    } catch (error) {
      console.error('Error adding grade:', error);
       setIsAddModalOpen(false);
      setMessage({ type: 'error', text: error.response?.data?.error || 'Failed to add grade' });
    } finally {
      setLoading(false);
    }
  };

  const handleEditGrade = async (gradeData) => {
    try {
      setLoading(true);
      const transformedData = gradeService.transformToBackend(gradeData);
      await gradeService.update(gradeData.id, transformedData);
      await fetchGrades();
      setIsEditModalOpen(false);
      setSelectedGrade(null);
      setMessage({ type: 'success', text: 'Grade updated successfully!' });
    } catch (error) {
      console.error('Error updating grade:', error);
      setMessage({ type: 'error', text: error.response?.data?.error || 'Failed to update grade' });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteGrade = async (id) => {
    try {
      setLoading(true);
      await gradeService.delete(id);
      await fetchGrades();
      setIsDeleteModalOpen(false);
      setSelectedGrade(null);
      setMessage({ type: 'success', text: 'Grade deleted successfully!' });
    } catch (error) {
      console.error('Error deleting grade:', error);
      setMessage({ type: 'error', text: error.response?.data?.error || 'Failed to delete grade' });
    } finally {
      setLoading(false);
    }
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      setPagination((prev) => ({ ...prev, page: newPage }));
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-700">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Grades', value: stats.total, icon: LuAward, color: 'primary' },
          { label: 'Active Grades', value: stats.active, icon: LuCircleCheck, color: 'success' },
          { label: 'With Salary Range', value: stats.withSalaryRange, icon: LuWallet, color: 'info' },
          { label: 'No Salary Range', value: stats.withoutSalaryRange, icon: LuBanknote, color: 'warning' },
        ].map((stat, idx) => (
          <div key={idx} className="bg-white dark:bg-default-50 p-4 rounded-2xl border border-default-200 dark:border-default-100 flex items-center gap-4 group hover:border-primary/20 transition-all duration-300">
            <div className={`size-12 rounded-2xl bg-${stat.color}/10 flex items-center justify-center group-hover:scale-110 transition-transform duration-500`}>
              <stat.icon className={`size-6 text-${stat.color}`} />
            </div>
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest opacity-50 dark:text-default-400">{stat.label}</p>
              <p className="text-2xl font-black dark:text-default-100">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Success/Error Messages */}
      {message.text && (
        <div className={`fixed top-4 right-4 z-[100] min-w-[320px] p-4 rounded-2xl border animate-in slide-in-from-top-4 duration-300 ${
          message.type === 'success' 
            ? 'bg-success/10 border-success/20 text-success' 
            : 'bg-danger/10 border-danger/20 text-danger'
        }`}>
          <div className="flex items-center gap-3">
            <div className={`size-10 rounded-2xl flex items-center justify-center ${
              message.type === 'success' ? 'bg-success/20' : 'bg-danger/20'
            }`}>
              <span className="text-xl">
                {message.type === 'success' ? '✓' : '✕'}
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-black uppercase tracking-widest">
                {message.type === 'success' ? 'Success' : 'Error'}
              </span>
              <p className="text-xs font-bold opacity-80 uppercase tracking-widest">{message.text}</p>
            </div>
          </div>
        </div>
      )}
      
      <div className="animate-in fade-in zoom-in-95 duration-500">
        <GradeSalaryList 
          grades={grades}
          loading={loading}
          canCreate={canCreate}
          canEdit={canEdit}
          canDelete={canDelete}
          onAdd={() => setIsAddModalOpen(true)}
          onEdit={grade => {
            setSelectedGrade(grade);
            setIsEditModalOpen(true);
          }}
          onView={grade => {
            setSelectedGrade(grade);
            setIsViewModalOpen(true);
          }}
          onDelete={grade => {
            setSelectedGrade(grade);
            setIsDeleteModalOpen(true);
          }}
          pagination={pagination}
          onPageChange={handlePageChange}
        />
      </div>

      {canCreate && (
        <AddGradeSalary
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onSave={handleAddGrade}
        />
      )}

      {canEdit && (
        <EditGradeSalary
          isOpen={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            setSelectedGrade(null);
          }}
          onSave={handleEditGrade}
          grade={selectedGrade}
        />
      )}

      <ViewGradeSalary
        isOpen={isViewModalOpen}
        onClose={() => {
          setIsViewModalOpen(false);
          setSelectedGrade(null);
        }}
        grade={selectedGrade}
      />

      {canDelete && (
        <DeleteGradeSalaryModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            setIsDeleteModalOpen(false);
            setSelectedGrade(null);
          }}
          onConfirm={() => selectedGrade && handleDeleteGrade(selectedGrade._id)}
          grade={selectedGrade}
        />
      )}
    </div>
  );
};

export default Payrolls;
