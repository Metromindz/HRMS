import PageMeta from '@/components/PageMeta';
import PageBreadcrumb from '@/components/PageBreadcrumb';
import Payrolls from './components/Payrolls';

const Index = () => {
  return (
    <>
      <PageMeta title="Payroll Setting" />
      <main>
        <PageBreadcrumb title="Payroll Settings" subtitle="Menu" />
        <Payrolls/>
      </main>
    </>
  );
};

export default Index;
