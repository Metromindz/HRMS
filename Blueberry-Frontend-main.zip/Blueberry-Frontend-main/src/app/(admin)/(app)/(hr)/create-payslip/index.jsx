import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import CreatesSlip from './components/CreatesSlip';
import { Link } from 'react-router';
import { LuArrowLeft } from 'react-icons/lu';
const Index = () => {
  return <>
      <PageMeta title="Create Payslip" />
      <main>
        <PageBreadcrumb title="Generate Payslip" subtitle="Menu" />
        <div className="flex justify-between mb-6 container">
                  <Link to="/payroll-employee-salary" className="btn btn-sm bg-primary text-white flex items-center gap-1">
                    <LuArrowLeft className="size-4" /> Go Back
                  </Link>
        
                  {/* <button className="btn btn-sm bg-success text-white flex items-center gap-1">
                    <LuPrinter className="size-4" /> Print
                  </button> */}
                </div>
        <CreatesSlip />
      </main>
    </>;
};
export default Index;
