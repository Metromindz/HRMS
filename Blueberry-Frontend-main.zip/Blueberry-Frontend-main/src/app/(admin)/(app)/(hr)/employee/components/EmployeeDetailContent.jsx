import { LuX, LuUser, LuBriefcase, LuBanknote, LuShieldCheck, LuFileText, LuMail, LuCalendar, LuMapPin, LuSmartphone, LuUsers, LuShieldAlert, LuHistory, LuClock, LuExternalLink, LuLayoutDashboard, LuListTodo, LuCalendarOff, LuCircleCheck, LuDownload, LuActivity } from 'react-icons/lu';
import { useState, useEffect } from 'react';
import api from '@/config/api';
import { getUploadUrl } from '@/utils/uploadUrl';

const EmployeeDetailContent = ({ employee, onClose, isPage = false }) => {
  const [activeTab, setActiveTab] = useState('personal');
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(false);
  const employeeData = employee || null;
  const employeeId = employeeData?._id;
  const employeeName =
    employeeData?.employeePersonal?.fullName || employeeData?.name || employeeData?.employeeId;

  const tabs = [
    { key: 'personal', label: 'Personal', icon: LuUser, color: 'primary' },
    { key: 'employment', label: 'Employment', icon: LuBriefcase, color: 'success' },
    { key: 'projects', label: 'Projects', icon: LuLayoutDashboard, color: 'primary' },
    { key: 'tasks', label: 'Tasks', icon: LuListTodo, color: 'warning' },
    { key: 'leaves', label: 'Leaves', icon: LuCalendarOff, color: 'danger' },
    { key: 'salary', label: 'Salary', icon: LuBanknote, color: 'info' },
    { key: 'bank', label: 'Bank', icon: LuBanknote, color: 'warning' },
    { key: 'statutory', label: 'Statutory', icon: LuShieldCheck, color: 'danger' },
    { key: 'documents', label: 'Documents', icon: LuFileText, color: 'secondary' },
  ];

  useEffect(() => {
    const fetchData = async () => {
      if (!employeeId) return;
      setLoading(true);
      try {
        if (activeTab === 'projects') {
          const resp = await api.get('/projects', { params: { limit: 100 } });
          // Filter projects where this employee is a developer
          const allProjects = resp.data.items || [];
          const empProjects = allProjects.filter(p =>
            p.developers?.some(dev => dev._id === employeeId)
          );
          setProjects(empProjects);
        } else if (activeTab === 'tasks') {
          const resp = await api.get('/tasks', { params: { limit: 100 } });
          // Filter tasks where this employee is an assignee
          const allTasks = resp.data.items || [];
          const empTasks = allTasks.filter(t =>
            t.assignees?.some(assignee => assignee._id === employeeId)
          );
          setTasks(empTasks);
        } else if (activeTab === 'leaves') {
          // Using searchByEmployee with employee ID or Name
          const resp = await api.get('/leave-requests/all', {
            params: { searchByEmployee: employeeName, limit: 100 }
          });
          setLeaves(resp.data.data || []);
        }
      } catch (err) {
        console.error("Failed to fetch data for tab " + activeTab, err);
      } finally {
        setLoading(false);
      }
    };

    if (['projects', 'tasks', 'leaves'].includes(activeTab)) {
      fetchData();
    }
  }, [activeTab, employeeId, employeeName]);

  const handleExportLogs = async () => {
    try {
      const response = await api.get('/activity-logs/export', {
        params: { userId: employeeId },
        responseType: 'blob'
      });

      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `activity-logs-${employeeData.employeeId || 'employee'}.xlsx`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error("Error exporting logs", error);
    }
  };

  if (!employeeData) return null;

  return (
    <>
      {/* Header */}
      <div className={`${isPage ? 'px-5 py-5' : 'px-8 py-6'} border-b border-default-100 flex items-center justify-between bg-white shrink-0 ${isPage ? 'rounded-t-3xl' : ''}`}>
        <div className="flex items-center gap-4">
          <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5 overflow-hidden">
            {employeeData?.employeePersonal?.profilePhoto ? (
              <img
                src={getUploadUrl(employeeData.employeePersonal.profilePhoto)}
                alt={employeeData.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <LuUser className="size-6" />
            )}
          </div>
          <div>
            <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">{employeeData?.employeePersonal?.fullName || employeeData?.name || 'Employee Details'}</h3>
            <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest flex items-center gap-2">
              {employeeData?.employeeId || 'ID Not Set'}
              <span className="size-1 rounded-full bg-default-300" />
              {employeeData?.employmentDetails?.designation?.name || 'Designation Not Set'}
            </p>
          </div>
        </div>
        {onClose && (
          <button
            type="button"
            className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
            onClick={onClose}
          >
            <LuX className="size-5" />
          </button>
        )}
      </div>

      {/* Content */}
      <div className={`${isPage ? 'p-5' : 'p-8'} overflow-y-auto custom-scroll flex-1 bg-white`}>

        {/* Tabs */}
        <div className="bg-default-50/50 p-1.5 rounded-2xl border border-default-100 mb-8 inline-flex items-center gap-1 overflow-x-auto max-w-full no-scrollbar">
          {tabs.map(t => {
            const Icon = t.icon;
            const isActive = activeTab === t.key;
            return (
              <button
                key={t.key}
                type="button"
                onClick={() => setActiveTab(t.key)}
                className={`px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-[0.1em] transition-all duration-300 whitespace-nowrap flex items-center gap-2.5 ${isActive
                  ? 'bg-white text-primary shadow-sm ring-1 ring-black/5'
                  : 'text-default-500 hover:text-default-900 hover:bg-white/50'
                  }`}
              >
                <Icon className={`size-3.5 ${isActive ? 'text-primary' : 'text-default-400'}`} />
                {t.label}
              </button>
            );
          })}
        </div>

        <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
          {activeTab === 'personal' && (
            <div className="space-y-8">
              <SectionHeading icon={LuUser} title="Personal Profile" />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6 bg-default-50/50 rounded-2xl border border-default-100">
                <Info label="Full Name" value={employeeData?.employeePersonal?.fullName} />
                <Info label="Date of Birth" value={employeeData?.employeePersonal?.dateOfBirth ? new Date(employeeData.employeePersonal.dateOfBirth).toLocaleDateString('en-GB') : ''} icon={LuCalendar} />
                <Info label="Gender" value={employeeData?.employeePersonal?.gender} />
                <Info label="Marital Status" value={employeeData?.employeePersonal?.maritalStatus} />
                <Info label="Father/Spouse Name" value={employeeData?.employeePersonal?.fatherOrSpouseName} />
                <Info label="Contact Number" value={employeeData?.employeePersonal?.contactNumber} icon={LuSmartphone} />
                <Info label="Email Address" value={employeeData.email} icon={LuMail} />
                <Info label="Blood Group" value={employeeData?.employeePersonal?.bloodGroup} />

                <div className="md:col-span-2 lg:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-default-200/50 mt-2">
                  <Info label="Current Address" value={employeeData?.employeePersonal?.currentAddress} icon={LuMapPin} />
                  <Info label="Permanent Address" value={employeeData?.employeePersonal?.permanentAddress} icon={LuMapPin} />
                </div>

                <div className="md:col-span-2 lg:col-span-3 pt-2">
                  <div className="p-4 rounded-xl bg-danger/5 border border-danger/10 flex items-start gap-3">
                    <LuShieldAlert className="size-5 text-danger mt-0.5" />
                    <div>
                      <span className="text-[10px] font-black text-danger uppercase tracking-widest block mb-1">Emergency Contact</span>
                      <p className="text-sm font-bold text-default-700">
                        {employeeData?.employeePersonal?.emergencyContact?.name ? `${employeeData.employeePersonal.emergencyContact.name} (${employeeData.employeePersonal.emergencyContact.number})` : <span className="text-default-400 italic font-normal">Not Provided</span>}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="md:col-span-2 lg:col-span-3 grid grid-cols-2 gap-4 mt-2">
                  <button className="flex items-center justify-center gap-3 p-3 rounded-xl border border-default-200 bg-white hover:border-primary/30 hover:text-primary transition-all text-xs font-bold uppercase tracking-wider text-default-600">
                    <LuDownload className="size-4" /> Export Profile
                  </button>
                  <button
                    onClick={handleExportLogs}
                    className="flex items-center justify-center gap-3 p-3 rounded-xl border border-default-200 bg-white hover:border-primary/30 hover:text-primary transition-all text-xs font-bold uppercase tracking-wider text-default-600"
                  >
                    <LuActivity className="size-4" /> Export Activity Logs
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'employment' && (
            <div className="space-y-8">
              <SectionHeading icon={LuBriefcase} title="Career Information" />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6 bg-default-50/50 rounded-2xl border border-default-100">
                <Info label="Employee ID" value={employeeData.employeeId} icon={LuShieldCheck} />
                <Info label="Date of Joining" value={employeeData?.employmentDetails?.dateOfJoining ? new Date(employeeData.employmentDetails.dateOfJoining).toLocaleDateString('en-GB') : ''} icon={LuCalendar} />
                <Info label="Department" value={employeeData?.employmentDetails?.department?.name} icon={LuUsers} />
                <Info label="Designation" value={employeeData?.employmentDetails?.designation?.name} icon={LuBriefcase} />
                <Info label="Employment Type" value={employeeData?.employmentDetails?.employmentType} icon={LuHistory} />
                <Info label="Work Location" value={employeeData?.employmentDetails?.workLocation} icon={LuMapPin} />
                <Info label="Reporting Manager" value={employeeData?.employmentDetails?.reportingManager?.name} icon={LuUser} />
                <Info label="Probation Period" value={employeeData?.employmentDetails?.probationPeriod} />
                <Info label="Confirmation Date" value={employeeData?.employmentDetails?.confirmationDate ? new Date(employeeData.employmentDetails.confirmationDate).toLocaleDateString('en-GB') : ''} icon={LuCalendar} />
                <Info label="Shift Details" value={employeeData?.employmentDetails?.shift?.name} icon={LuClock} />
                <Info label="Week Off" value={employeeData?.employmentDetails?.weekOff?.join(', ')} />
              </div>
            </div>
          )}

          {activeTab === 'projects' && (
            <div className="space-y-8">
              <SectionHeading icon={LuLayoutDashboard} title="Assigned Projects" />
              {loading ? (
                <div className="flex items-center justify-center py-10">
                  <div className="size-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                </div>
              ) : projects.length === 0 ? (
                <div className="p-8 text-center bg-default-50/50 rounded-2xl border border-default-100 text-default-400">
                  <p className="text-sm font-bold">No projects assigned</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {projects.map(project => (
                    <div key={project._id} className="p-5 rounded-2xl border border-default-200 bg-white hover:border-primary/30 transition-all group">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h5 className="font-bold text-default-900 group-hover:text-primary transition-colors">{project.name}</h5>
                          <p className="text-xs text-default-500 mt-1">{project.company?.name}</p>
                        </div>
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider ${project.status === 'completed' ? 'bg-success/10 text-success' :
                          project.status === 'in_progress' ? 'bg-primary/10 text-primary' :
                            'bg-default-100 text-default-500'
                          }`}>{project.status.replace('_', ' ')}</span>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-default-500 font-medium">
                        <span className="flex items-center gap-1.5"><LuCalendar className="size-3.5" /> {project.deadlineDate ? new Date(project.deadlineDate).toLocaleDateString() : 'No Deadline'}</span>
                        <span className="flex items-center gap-1.5"><LuUsers className="size-3.5" /> {project.developers?.length || 0} Team Members</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'tasks' && (
            <div className="space-y-8">
              <SectionHeading icon={LuListTodo} title="Assigned Tasks" />
              {loading ? (
                <div className="flex items-center justify-center py-10">
                  <div className="size-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                </div>
              ) : tasks.length === 0 ? (
                <div className="p-8 text-center bg-default-50/50 rounded-2xl border border-default-100 text-default-400">
                  <p className="text-sm font-bold">No tasks assigned</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4">
                  {tasks.map(task => (
                    <div key={task._id} className="p-5 rounded-2xl border border-default-200 bg-white hover:border-primary/30 transition-all group">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex-1">
                          <div className='flex items-center gap-2 mb-1'>
                            <span className='text-[10px] font-bold text-default-400 uppercase'>{task.project?.name}</span>
                          </div>
                          <h5 className="font-bold text-default-900 group-hover:text-primary transition-colors">{task.title}</h5>
                        </div>
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider ${task.priority === 'High' ? 'bg-danger/10 text-danger' :
                          task.priority === 'Medium' ? 'bg-warning/10 text-warning' :
                            'bg-success/10 text-success'
                          }`}>{task.priority}</span>
                      </div>
                      <div className="flex items-center justify-between mt-4 pt-4 border-t border-default-100">
                        <span className={`text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 ${task.status === 'done' ? 'text-success' : 'text-default-500'
                          }`}>
                          {task.status === 'done' ? <LuCircleCheck className="size-3.5" /> : <LuClock className="size-3.5" />}
                          {task.status.replace('_', ' ')}
                        </span>
                        <span className="text-xs text-default-500 font-bold">{task.dueDate ? new Date(task.dueDate).toLocaleDateString() : 'No Due Date'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'leaves' && (
            <div className="space-y-8">
              <SectionHeading icon={LuCalendarOff} title="Leave History" />
              {loading ? (
                <div className="flex items-center justify-center py-10">
                  <div className="size-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                </div>
              ) : leaves.length === 0 ? (
                <div className="p-8 text-center bg-default-50/50 rounded-2xl border border-default-100 text-default-400">
                  <p className="text-sm font-bold">No leave history found</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {leaves.map(leave => (
                    <div key={leave._id} className="p-4 rounded-xl border border-default-200 bg-white flex items-center justify-between gap-4">
                      <div className="flex items-center gap-4">
                        <div className={`size-10 rounded-xl flex items-center justify-center ${leave.status === 'Approved' ? 'bg-success/10 text-success' :
                          leave.status === 'Rejected' ? 'bg-danger/10 text-danger' :
                            'bg-warning/10 text-warning'
                          }`}>
                          {leave.status === 'Approved' ? <LuCircleCheck className="size-5" /> :
                            leave.status === 'Rejected' ? <LuShieldAlert className="size-5" /> :
                              <LuClock className="size-5" />}
                        </div>
                        <div>
                          <h6 className='text-sm font-bold text-default-900'>{leave.leaveType}</h6>
                          <p className='text-xs text-default-500 mt-0.5'>{new Date(leave.fromDate).toLocaleDateString()} - {new Date(leave.toDate).toLocaleDateString()} ({leave.numberOfDays} days)</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`text-[10px] font-black uppercase tracking-widest ${leave.status === 'Approved' ? 'text-success' :
                          leave.status === 'Rejected' ? 'text-danger' :
                            'text-warning'
                          }`}>{leave.status}</div>
                        <div className="text-[10px] text-default-400 mt-1 font-medium">{new Date(leave.appliedOn).toLocaleDateString()}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'salary' && (
            <div className="space-y-8">
              <SectionHeading icon={LuBanknote} title="Compensation" />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6 bg-default-50/50 rounded-2xl border border-default-100">
                <div className="p-5 rounded-2xl bg-white border border-default-200 shadow-sm">
                  <Info label="Gross CTC (Annual)" value={employeeData?.salaryDetails?.ctc ? `$${employeeData.salaryDetails.ctc.toLocaleString()}` : ''} icon={LuBanknote} highlight />
                </div>
                <Info label="Payment Mode" value={employeeData?.salaryDetails?.paymentMode} />
                <Info label="Effective From" value={employeeData?.salaryDetails?.effectiveFrom ? new Date(employeeData.salaryDetails.effectiveFrom).toLocaleDateString('en-GB') : ''} icon={LuCalendar} />
              </div>
            </div>
          )}

          {activeTab === 'bank' && (
            <div className="space-y-8">
              <SectionHeading icon={LuBanknote} title="Banking Details" />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6 bg-default-50/50 rounded-2xl border border-default-100">
                <Info label="Bank Name" value={employeeData?.bankDetails?.bankName} icon={LuBanknote} />
                <Info label="Account Holder" value={employeeData?.bankDetails?.accountHolderName} icon={LuUser} />
                <Info label="Account Number" value={employeeData?.bankDetails?.accountNumber} />
                <Info label="IFSC Code" value={employeeData?.bankDetails?.ifscCode} />
                <Info label="Branch Name" value={employeeData?.bankDetails?.branchName} icon={LuMapPin} />
              </div>
            </div>
          )}

          {activeTab === 'statutory' && (
            <div className="space-y-8">
              <SectionHeading icon={LuShieldCheck} title="Compliance & Tax" />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6 bg-default-50/50 rounded-2xl border border-default-100">
                <Info label="PF Number" value={employeeData?.statutoryCompliance?.pfNumber} />
                <Info label="ESI Number" value={employeeData?.statutoryCompliance?.esiNumber} />
                <Info label="PAN Number" value={employeeData?.statutoryCompliance?.panNumber?.toUpperCase()} />
                <Info label="Aadhaar Number" value={employeeData?.statutoryCompliance?.aadhaarNumber} />
                <div className="md:col-span-2 lg:col-span-3">
                  <Info label="Previous Employment" value={employeeData?.statutoryCompliance?.previousEmployment} icon={LuHistory} />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'documents' && (
            <div className="space-y-8">
              <SectionHeading icon={LuFileText} title="Verified Documents" />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <DocumentLink label="PAN Card" url={employeeData?.documents?.panCard} />
                <DocumentLink label="Aadhaar Card" url={employeeData?.documents?.aadhaarCard} />
                <DocumentLink label="Photograph" url={employeeData?.documents?.photograph} />
                <DocumentLink label="Bank Passbook" url={employeeData?.documents?.bankPassbook} />
                <DocumentLink label="Experience Letter" url={employeeData?.documents?.experienceLetter} />
                <DocumentLink label="Proof of Address" url={employeeData?.documents?.proofOfAddress} />
                <DocumentLink label="Proof of DOB" url={employeeData?.documents?.proofOfDOB} />
                <DocumentLink label="Offer Letter" url={employeeData?.documents?.offerLetter} />
                <DocumentLink label="Income Tax Declaration" url={employeeData?.statutoryCompliance?.incomeTaxDeclaration} />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      {!isPage && onClose && (
        <div className="px-8 py-6 border-t bg-default-50/50 flex items-center justify-end gap-3 shrink-0 rounded-b-3xl">
          <button
            type="button"
            className="px-6 py-2.5 text-sm font-bold text-default-500 hover:text-default-900 transition-colors uppercase tracking-widest"
            onClick={onClose}
          >
            Close
          </button>
        </div>
      )}
    </>
  );
};

const SectionHeading = ({ title, icon: Icon }) => (
  <h4 className="text-xs font-black text-default-900 uppercase tracking-widest flex items-center gap-2">
    {Icon && <Icon className="size-4 text-primary" />} {title}
  </h4>
);

const Info = ({ label, value, icon: Icon, highlight }) => (
  <div className="space-y-1.5">
    <span className="text-[10px] font-black text-default-400 uppercase tracking-widest flex items-center gap-2">
      {Icon && <Icon className={`size-3.5 ${highlight ? 'text-primary' : 'text-default-400'}`} />} {label}
    </span>
    <p className={`text-sm font-bold ${highlight ? 'text-primary text-lg' : 'text-default-700'}`}>
      {value || <span className="text-default-300 font-medium italic text-xs">Not Provided</span>}
    </p>
  </div>
);

const DocumentLink = ({ label, url }) => (
  <div className="p-4 rounded-2xl border border-default-200 bg-white hover:border-primary/20 hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 group flex items-center justify-between">
    <div className="flex items-center gap-3">
      <div className="size-10 rounded-xl bg-default-50 text-default-400 group-hover:bg-primary/10 group-hover:text-primary flex items-center justify-center transition-all duration-300">
        <LuFileText className="size-5" />
      </div>
      <span className="text-[11px] font-black text-default-600 uppercase tracking-wider group-hover:text-default-900 transition-colors">{label}</span>
    </div>

    {url ? (
      <a
        href={getUploadUrl(url)}
        target="_blank"
        rel="noopener noreferrer"
        className="size-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-all active:scale-95"
        title="View Document"
      >
        <LuExternalLink className="size-4" />
      </a>
    ) : (
      <span className="size-8 rounded-lg bg-default-50 text-default-300 flex items-center justify-center cursor-not-allowed">
        <LuX className="size-4" />
      </span>
    )}
  </div>
);

export default EmployeeDetailContent;
