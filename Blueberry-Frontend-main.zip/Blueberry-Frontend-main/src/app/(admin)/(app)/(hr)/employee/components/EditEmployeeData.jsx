// Add Employee Modal
import img from '@/assets/images/user/user-dummy-img.jpg';
import { useState, useEffect, useRef } from 'react';
import { LuImagePlus, LuX, LuUpload, LuArrowLeft, LuArrowRight, LuUser, LuCheck, LuTriangleAlert, LuShield, LuShieldCheck } from 'react-icons/lu';
import api from '../../../../../../config/api';
import { useAuth } from '@/context/AuthContext';
import { useLayoutContext } from '@/context/useLayoutContext';
import Select from 'react-select';


// Label component
const Label = ({ text, htmlFor }) => (
  <label
    htmlFor={htmlFor}
    className="text-[10px] font-black text-default-700 dark:text-default-400 uppercase tracking-[0.15em] ml-1 mb-2.5 block group-hover:text-primary transition-colors duration-300"
  >
    {text}
  </label>
);

const FileUpload = ({ label, accept = '.pdf,.jpg,.jpeg,.png', onFileChange, fileName, error }) => {
  const fileInputRef = useRef(null);
  const id = label.replace(/\s+/g, '');

  return (
    <div className="space-y-3 group">
      <Label text={label} htmlFor={id} />
      <div className="relative">
        <input
          ref={fileInputRef}
          type="file"
          accept={accept}
          className="hidden"
          id={id}
          onChange={onFileChange}
        />
        <div
          onClick={() => fileInputRef.current?.click()}
          className="flex flex-col items-center justify-center min-h-[140px] bg-default-50/50 dark:bg-default-100/10 border-2 border-dashed border-default-200 dark:border-default-200/50 rounded-[2rem] hover:border-primary/50 hover:bg-primary/[0.02] transition-all duration-500 cursor-pointer group-hover:scale-[0.99] group-hover:shadow-xl group-hover:shadow-primary/5"
        >
          <div className="size-12 bg-white dark:bg-default-200 rounded-2xl border border-default-100 dark:border-default-200 shadow-sm flex items-center justify-center mb-4 group-hover:text-primary group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/10 transition-all duration-500">
            <LuUpload className="size-5" />
          </div>
          <p className="text-[10px] font-black text-default-600 dark:text-default-400 uppercase tracking-widest group-hover:text-primary transition-colors duration-300">Click to upload {label}</p>
          <p className="text-[8px] font-bold text-default-400 dark:text-default-500 uppercase tracking-tight mt-1.5">Allowed: {accept} | Max: 5MB</p>
        </div>
      </div>
      {fileName && (
        <div className="flex items-center gap-3 px-4 py-3 bg-success/5 border border-success/10 rounded-2xl animate-in fade-in slide-in-from-top-2 duration-500 shadow-sm">
          <div className="size-2 bg-success rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
          <p className="text-[10px] font-bold text-success uppercase tracking-wider truncate flex-1" title={fileName}>
            {fileName}
          </p>
        </div>
      )}
      {error && (
        <div className="flex items-center gap-3 px-4 py-3 bg-danger/5 border border-danger/10 rounded-2xl animate-in fade-in slide-in-from-top-2 duration-500 shadow-sm">
          <div className="size-2 bg-danger rounded-full shadow-[0_0_8px_rgba(244,63,94,0.5)]" />
          <p className="text-[10px] font-bold text-danger uppercase tracking-wider">
            {error}
          </p>
        </div>
      )}
    </div>
  );
};

const bloodGroupOptions = [
  { value: 'A+', label: 'A+' },
  { value: 'A-', label: 'A-' },
  { value: 'B+', label: 'B+' },
  { value: 'B-', label: 'B-' },
  { value: 'AB+', label: 'AB+' },
  { value: 'AB-', label: 'AB-' },
  { value: 'O+', label: 'O+' },
  { value: 'O-', label: 'O-' },
];

const genderOptions = [
  { value: 'Male', label: 'MALE' },
  { value: 'Female', label: 'FEMALE' },
  { value: 'Other', label: 'OTHER' },
];

const maritalStatusOptions = [
  { value: 'Single', label: 'SINGLE' },
  { value: 'Married', label: 'MARRIED' },
];

const employmentTypeOptions = [
  { value: 'Permanent', label: 'PERMANENT' },
  { value: 'Contract', label: 'CONTRACT' },
  { value: 'Part-time', label: 'PART-TIME' },
  { value: 'Internship', label: 'INTERNSHIP' },
];

const probationPeriodOptions = [
  { value: '3 months', label: '3 MONTHS' },
  { value: '6 months', label: '6 MONTHS' },
  { value: 'No', label: 'NO PROBATION' },
];

const paymentModeOptions = [
  { value: 'Bank Transfer', label: 'BANK TRANSFER' },
  { value: 'Cheque', label: 'CHEQUE' },
  { value: 'Cash', label: 'CASH' },
];

const weekOffOptions = [
  { value: 'Monday', label: 'Monday' },
  { value: 'Tuesday', label: 'Tuesday' },
  { value: 'Wednesday', label: 'Wednesday' },
  { value: 'Thursday', label: 'Thursday' },
  { value: 'Friday', label: 'Friday' },
  { value: 'Saturday', label: 'Saturday' },
  { value: 'Sunday', label: 'Sunday' },
];

const EditEmployeeData = ({ employee, onEmployeeUpdated }) => {
  const { user } = useAuth();
  const { theme } = useLayoutContext();
  const isDark = theme === 'dark';
  const isAdmin = user?.role === 'superadmin' || user?.role === 'admin';

  const [currentStep, setCurrentStep] = useState(1);
  const [profileImage, setProfileImage] = useState(img);
  const fileInputRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [departments, setDepartments] = useState([]);
  const [designations, setDesignations] = useState([]);
  const [groupedPermissions, setGroupedPermissions] = useState({});
  const [permissionSearch, setPermissionSearch] = useState('');
  const [reportingManagers, setReportingManagers] = useState([]);
  const [grades, setGrades] = useState([]);
  const [shifts, setShifts] = useState([]);
  const [formData, setFormData] = useState({
    // Personal Details
    fullName: '',
    dateOfBirth: '',
    gender: '',
    maritalStatus: '',
    fatherOrSpouseName: '',
    contactNumber: '',
    email: '',
    currentAddress: '',
    permanentAddress: '',
    emergencyContactName: '',
    emergencyContactNumber: '',
    bloodGroup: '',
    // Employment Details
    employeeId: '',
    dateOfJoining: '',
    department: '',
    designation: '',
    employmentType: '',
    workLocation: '',
    reportingManager: '',
    probationPeriod: '',
    confirmationDate: '',
    shift: '',
    // Salary Details
    grade: '',
    ctc: '',
    paymentMode: '',
    effectiveFrom: '',
    // Bank Details
    bankName: '',
    accountHolderName: '',
    accountNumber: '',
    ifscCode: '',
    branchName: '',
    // amazonq-ignore-next-line
    // Statutory Details
    pfNumber: '',
    esiNumber: '',
    previousEmployment: '',
    incomeTaxDeclaration: '',
    weekOff: [],
    // Basic Info (for User model)
    name: '',
    password: '',
    role: 'employee',
  });

  // Fetch departments on mount
  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const res = await api.get('/department', { params: { limit: 1000 } });
        setDepartments(res.data.departments || []);
      } catch (error) {
        console.error('Error fetching departments:', error);
        setErrorMessage('Failed to load departments. Please refresh the page.');
      }
    };
    fetchDepartments();
  }, []);

  // Fetch designations dynamically when department changes
  useEffect(() => {
    if (!formData.department) {
      setDesignations([]);
      return;
    }

    const fetchDesignations = async () => {
      try {
        let departmentId;
        try {
          const deptData = JSON.parse(formData.department);
          departmentId = deptData.id;
        } catch {
          departmentId = formData.department;
        }

        if (!departmentId) {
          setDesignations([]);
          return;
        }

        const res = await api.get('/designation', {
          params: { departmentId: departmentId, limit: 1000 },
        });
        setDesignations(res.data.designations || []);
      } catch (error) {
        console.error('Error fetching designations:', error);
        setDesignations([]);
        setErrorMessage('Failed to load designations for selected department.');
      }
    };

    fetchDesignations();
  }, [formData.department]);

  useEffect(() => {
    fetchPermissions();
    fetchReportingManagers();
    fetchGrades();
    fetchShifts();
  }, []);

  const fetchPermissions = async () => {
    try {
      const res = await api.get('/permissions');
      if (res.status === 200) {
        const data = res.data.permissions || [];

        // Group by module
        const grouped = data.reduce((acc, item) => {
          if (!acc[item.module]) acc[item.module] = [];
          acc[item.module].push(item);
          return acc;
        }, {});

        // Ensure Project permissions group exists in UI
        const projectModule = 'Project';
        const projectPermissions = [
          { module: projectModule, label: 'View', key: 'project.view', description: 'Browse and view all assigned projects and their details' },
          { module: projectModule, label: 'Add', key: 'project.create', description: 'Create new projects and define their scope' },
          { module: projectModule, label: 'Edit', key: 'project.edit', description: 'Modify project details, timelines, and settings' },
          { module: projectModule, label: 'Delete', key: 'project.delete', description: 'Permanently remove projects from the system' },
          { module: projectModule, label: 'Export', key: 'project.export', description: 'Download project data as CSV or Excel reports' },
          { module: projectModule, label: 'Manage Details', key: 'project.details', description: 'Update milestones, team members, and project settings' },
          { module: projectModule, label: 'View Value', key: 'project.value', description: 'See project contract value and financial info' },
          { module: projectModule, label: 'View Documents', key: 'project.documents', description: 'Access uploaded project files and documents' },
        ];
        if (!grouped[projectModule] || grouped[projectModule].length === 0) {
          grouped[projectModule] = projectPermissions;
        }

        const taskModule = 'Task';
        const taskPermissions = [
          { module: taskModule, label: 'View', key: 'task.view', description: 'View tasks assigned to the employee and team' },
          { module: taskModule, label: 'Create', key: 'task.create', description: 'Create new tasks and sub-tasks for projects' },
          { module: taskModule, label: 'Edit', key: 'task.edit', description: 'Update task details, status, and priority' },
          { module: taskModule, label: 'Delete', key: 'task.delete', description: 'Permanently remove tasks from the system' },
          { module: taskModule, label: 'Export', key: 'task.export', description: 'Download task data as CSV or Excel reports' },
          { module: taskModule, label: 'Assign', key: 'task.assign', description: 'Assign tasks to team members and set deadlines' },
        ];
        if (!grouped[taskModule] || grouped[taskModule].length === 0) {
          grouped[taskModule] = taskPermissions;
        }

        const leadModule = 'Lead';
        const leadPermissions = [
          { module: leadModule, label: 'View', key: 'lead.view', description: 'Browse and view assigned leads and their details' },
          { module: leadModule, label: 'Create', key: 'lead.create', description: 'Add new leads with contact and source info' },
          { module: leadModule, label: 'Edit', key: 'lead.edit', description: 'Update lead details, status, and follow-up info' },
          { module: leadModule, label: 'Delete', key: 'lead.delete', description: 'Permanently remove leads from the system' },
          { module: leadModule, label: 'Assign', key: 'lead.assign', description: 'Assign leads to team members for follow-up' },
          { module: leadModule, label: 'Import', key: 'lead.import', description: 'Bulk import leads from CSV or Excel files' },
          { module: leadModule, label: 'Export', key: 'lead.export', description: 'Download lead data as CSV or Excel reports' },
        ];
        if (!grouped[leadModule] || grouped[leadModule].length === 0) {
          grouped[leadModule] = leadPermissions;
        }

        const announcementModule = 'Announcement';
        const announcementPermissions = [
          { module: announcementModule, label: 'View', key: 'announcement.view', description: 'Read company-wide announcements and news' },
          { module: announcementModule, label: 'Create', key: 'announcement.create', description: 'Publish new announcements visible to the team' },
          { module: announcementModule, label: 'Delete', key: 'announcement.delete', description: 'Remove published announcements from the system' },
        ];
        if (!grouped[announcementModule] || grouped[announcementModule].length === 0) {
          grouped[announcementModule] = announcementPermissions;
        }

        const dashboardModule = 'Dashboard';
        const dashboardPermissions = [
          { module: dashboardModule, label: 'View', key: 'dashboard.view', description: 'Access to the main dashboard page' },
          { module: dashboardModule, label: 'Employee Profile', key: 'widget.profile_card', description: 'Shows own profile card with photo, role & department info' },
          { module: dashboardModule, label: 'Attendance Control', key: 'widget.attendance_widget', description: 'Check-in/out controls and daily attendance tracking' },
          { module: dashboardModule, label: 'Notifications', key: 'widget.notifications_panel', description: 'Real-time alerts and notifications relevant to the employee' },
          { module: dashboardModule, label: 'Announcements', key: 'widget.announcements_widget', description: 'Company-wide announcements and news visible to the employee' },
          { module: dashboardModule, label: 'Activity Logs', key: 'widget.activity_logs', description: 'Recent system activities and audit trail' },
          { module: dashboardModule, label: 'Upcoming Birthdays', key: 'widget.upcoming_birthdays', description: 'Upcoming team member birthdays' },
          { module: dashboardModule, label: 'Task Summary Cards', key: 'widget.employee_task_summary', description: 'KPI cards showing project & task counts' },
          { module: dashboardModule, label: 'Leads Overview Chart', key: 'widget.leads_overview', description: 'Leads trend chart showing lead data' },
          { module: dashboardModule, label: 'Project Status Chart', key: 'widget.project_status', description: 'Pie chart of project statuses' },
          { module: dashboardModule, label: 'Workforce Overview', key: 'widget.workforce_overview', description: 'Department & designation breakdown of the workforce' },
          { module: dashboardModule, label: 'Today Priorities', key: 'widget.today_priorities_widget', description: 'High-priority tasks assigned to the employee' },
          { module: dashboardModule, label: 'Task Board', key: 'widget.task_board_widget', description: 'Kanban board showing tasks by status' },
          { module: dashboardModule, label: 'Employee Task Summary', key: 'widget.employee_task_summary', description: 'Detailed task summary with project and completion stats' },
          { module: dashboardModule, label: 'Task Status Distribution', key: 'widget.task_status_overview', description: 'Chart showing distribution of tasks by status' },
        ];
        if (!grouped[dashboardModule] || grouped[dashboardModule].length === 0) {
          grouped[dashboardModule] = dashboardPermissions;
        }

        setGroupedPermissions(grouped);
      }
    } catch (error) {
      console.error('Error fetching permissions:', error);
      setErrorMessage('Failed to load permissions. Some features may not work properly.');
    }
  };

  const fetchReportingManagers = async () => {
    try {
      const res = await api.get('/hr/employees-for-reporting');

      if (res.status === 200) {
        setReportingManagers(res.data.employees || []);
      }
    } catch (error) {
      console.error('Error fetching reporting managers:', error);
      setErrorMessage('Failed to load reporting managers.');
    }
  };

  const fetchGrades = async () => {
    try {
      const res = await api.get('/grades', { params: { limit: 1000 } });
      if (res.status === 200) {
        setGrades(res.data || []);
      }
    } catch (error) {
      console.error('Error fetching grades:', error);
      setErrorMessage('Failed to load salary grades.');
    }
  };

  const fetchShifts = async () => {
    try {
      const res = await api.get('/shifts', { params: { limit: 1000 } });
      if (res.status === 200) {
        setShifts(res.data.shifts || []);
      }
    } catch (error) {
      console.error('Error fetching shifts:', error);
      setErrorMessage('Failed to load shifts.');
    }
  };

  // Predefined features and permissions
  // const features = [
  //   { id: 'employee_management', name: 'Employee Management' },
  //   { id: 'leave_management', name: 'Leave Management' },
  //   { id: 'attendance', name: 'Attendance' },
  //   { id: 'payroll', name: 'Payroll' },
  //   { id: 'master_settings', name: 'Master Settings' },
  // ];

  // const permissions = [
  //   { id: 'create', name: 'Add' },
  //   { id: 'read', name: 'View' },
  //   { id: 'update', name: 'Edit' },
  //   { id: 'delete', name: 'Delete' },
  //   { id: 'import', name: 'Import' },
  //   { id: 'export', name: 'Export' },
  // ];

  const [selectedPermissions, setSelectedPermissions] = useState({});

  const [uploadedFiles, setUploadedFiles] = useState({});
  const [fileErrors, setFileErrors] = useState({});
  const [sameAsCurrentAddress, setSameAsCurrentAddress] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Populate form data when employee prop changes
  // Populate form data when employee prop changes
  useEffect(() => {
    if (employee) {
      setUploadedFiles({});
      setFileErrors({});
      setErrorMessage('');
      setCurrentStep(1);

      const formatDate = dateString => {
        if (!dateString) return '';
        return new Date(dateString).toISOString().split('T')[0];
      };

      // Convert weekOff array to React Select format
      const employeeWeekOff = employee.employmentDetails?.weekOff || [];
      const weekOffValues = weekOffOptions.filter(option =>
        employeeWeekOff.includes(option.value)
      );

      setFormData({
        // Personal Details
        fullName: employee.employeePersonal?.fullName || employee.name || '',
        dateOfBirth: formatDate(employee.employeePersonal?.dateOfBirth),
        gender: employee.employeePersonal?.gender || '',
        maritalStatus: employee.employeePersonal?.maritalStatus || '',
        fatherOrSpouseName: employee.employeePersonal?.fatherOrSpouseName || '',
        contactNumber: employee.employeePersonal?.contactNumber || '',
        email: employee.email || '',
        currentAddress: employee.employeePersonal?.currentAddress || '',
        permanentAddress: employee.employeePersonal?.permanentAddress || '',
        emergencyContactName: employee.employeePersonal?.emergencyContact?.name || '',
        emergencyContactNumber: employee.employeePersonal?.emergencyContact?.number || '',
        bloodGroup: employee.employeePersonal?.bloodGroup || '',
        // Employment Details
        employeeId: employee.employeeId || '',
        dateOfJoining: formatDate(employee.employmentDetails?.dateOfJoining),
        department: employee.employmentDetails?.department?.id || '',
        designation: employee.employmentDetails?.designation?.id || '',
        employmentType: employee.employmentDetails?.employmentType || '',
        workLocation: employee.employmentDetails?.workLocation || '',
        reportingManager: employee.employmentDetails?.reportingManager?.id || '',
        probationPeriod: employee.employmentDetails?.probationPeriod || '',
        confirmationDate: formatDate(employee.employmentDetails?.confirmationDate),
        shift: employee.employmentDetails?.shift?.id || '',
        // Salary Details
        grade: employee.salaryDetails?.grade || '',
        ctc: employee.salaryDetails?.ctc || '',
        paymentMode: employee.salaryDetails?.paymentMode || '',
        effectiveFrom: formatDate(employee.salaryDetails?.effectiveFrom),
        // Bank Details
        bankName: employee.bankDetails?.bankName || '',
        accountHolderName: employee.bankDetails?.accountHolderName || '',
        accountNumber: employee.bankDetails?.accountNumber || '',
        ifscCode: employee.bankDetails?.ifscCode || '',
        branchName: employee.bankDetails?.branchName || '',
        // Statutory Details
        pfNumber: employee.statutoryCompliance?.pfNumber || '',
        esiNumber: employee.statutoryCompliance?.esiNumber || '',
        panNumber: employee.statutoryCompliance?.panNumber || '',
        aadhaarNumber: employee.statutoryCompliance?.aadhaarNumber || '',
        previousEmployment: employee.statutoryCompliance?.previousEmployment || '',
        incomeTaxDeclaration: employee.statutoryCompliance?.incomeTaxDeclaration || '',
        // Week off in React Select format
        weekOff: weekOffValues,
        // Basic Info
        name: employee.name || '',
        password: '',
        role: employee.role || 'employee',
      });

      // Set profile image
      if (employee.employeePersonal?.profilePhoto || employee.documents?.profilePhoto) {
        setProfileImage(
          employee.employeePersonal?.profilePhoto || employee.documents?.profilePhoto
        );
      }

      // Set permissions
      if (employee.permissions && Array.isArray(employee.permissions)) {
        const permissionMap = {};
        employee.permissions.forEach(perm => {
          const parts = perm.split('.');
          if (parts.length >= 2) {
            // Special handling for widget permissions which are grouped under "Dashboard"
            const module = parts[0] === 'widget' ? 'Dashboard' : parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
            if (!permissionMap[module]) permissionMap[module] = {};
            permissionMap[module][perm] = true;
          }
        });
        setSelectedPermissions(permissionMap);
      }
    }
  }, [employee]);

  const steps = [
    { id: 1, label: 'Personal Details', required: true },
    { id: 2, label: 'Employment Details', required: true },
    { id: 3, label: 'Salary & Payroll', required: true },
    { id: 4, label: 'Bank Details', required: true },
    { id: 5, label: 'Statutory Compliance', required: false },
    { id: 6, label: 'Documents', required: false },
    { id: 7, label: 'Permissions', required: true },
  ];

  const handleInputChange = e => {
    const { name, value } = e.target;

    if (fieldErrors[name]) {
      setFieldErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }

    // Basic validation for specific fields
    if (name === 'email' && value) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(value)) {
        setErrorMessage('Please enter a valid email address');
      } else {
        setErrorMessage('');
      }
    }

    if (name === 'contactNumber' && value) {
      const phoneRegex = /^[0-9]{10}$/;
      if (!phoneRegex.test(value.replace(/\D/g, ''))) {
        setErrorMessage('Contact number should be 10 digits');
      } else {
        setErrorMessage('');
      }
    }


    if (name === 'ifscCode' || name === 'pfNumber') {
      const upperValue = value.toUpperCase();
      // const finalValue = sanitizeInput(upperValue);
      setFormData(prev => ({ ...prev, [name]: upperValue }));
      return;
    }


    if (name === 'panNumber') {
      const upperValuePAN = value.toUpperCase();
      // const finalValue = sanitizeInput(upperValue);
      setFormData(prev => ({ ...prev, [name]: upperValuePAN }));
      return;
    }


    // Don't sanitize dropdown values like bloodGroup, gender, etc.
    const noSanitizeFields = [
      'bloodGroup',
      'gender',
      'maritalStatus',
      'employmentType',
      'paymentMode',
      'department',
      'designation',
      'shift',
      'reportingManager',
      'grade',
    ];
    const finalValue = noSanitizeFields.includes(name) ? value : sanitizeInput(value);

    setFormData(prev => ({ ...prev, [name]: finalValue }));
  };

  const ErrorMessage = ({ field }) => {
    if (!fieldErrors[field]) return null;

    return (
      <div className="flex items-center gap-1.5 mt-2 ml-1 animate-in slide-in-from-top-1 duration-200">
        <div className="size-1.5 bg-danger rounded-full shadow-[0_0_8px_rgba(244,63,94,0.5)]" />
        <p className="text-[10px] font-black text-danger uppercase tracking-widest">
          {fieldErrors[field]}
        </p>
      </div>
    );
  };

  const handleSameAddressChange = e => {
    const checked = e.target.checked;
    setSameAsCurrentAddress(checked);
    if (checked) {
      setFormData(prev => ({ ...prev, permanentAddress: prev.currentAddress }));
    }
  };

  const selectStyles = {
    control: (base) => ({
      ...base,
      border: isDark ? '2px solid #374151' : '2px solid #e5e7eb',
      borderRadius: '1rem',
      minHeight: '56px',
      fontSize: '13px',
      fontWeight: '700',
      boxShadow: 'none',
      backgroundColor: isDark ? '#111827' : '#f9fafb80', // bg-default-50/50
      transition: 'all 0.3s ease',
      '&:hover': {
        borderColor: isDark ? '#4b5563' : '#d1d5db',
      },
      '&:focus-within': {
        borderColor: '#0061ff', // primary
        boxShadow: '0 0 0 4px rgba(0, 97, 255, 0.1)',
      },
    }),
    placeholder: (base) => ({
      ...base,
      color: isDark ? '#6b7280' : '#9ca3af',
      fontWeight: '500',
    }),
    singleValue: (base) => ({
      ...base,
      color: isDark ? '#f3f4f6' : '#111827',
    }),
    menu: (base) => ({
      ...base,
      backgroundColor: isDark ? '#1f2937' : '#ffffff',
      borderRadius: '1rem',
      border: isDark ? '1px solid #374151' : '1px solid #e5e7eb',
      zIndex: 50,
      overflow: 'hidden',
      boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)',
    }),
    option: (base, state) => ({
      ...base,
      fontSize: '13px',
      fontWeight: '600',
      padding: '10px 15px',
      backgroundColor: state.isSelected
        ? '#0061ff'
        : state.isFocused
          ? isDark ? '#0061ff20' : '#0061ff10'
          : 'transparent',
      color: state.isSelected
        ? '#ffffff'
        : state.isFocused
          ? '#0061ff'
          : isDark ? '#9ca3af' : '#4b5563',
      '&:active': {
        backgroundColor: '#0061ff20',
      },
    }),
    multiValue: (base) => ({
      ...base,
      backgroundColor: isDark ? '#0061ff30' : '#0061ff10',
      border: isDark ? '1px solid #0061ff40' : '1px solid #0061ff20',
      borderRadius: '0.5rem',
      padding: '2px 4px',
    }),
    multiValueLabel: (base) => ({
      ...base,
      color: '#0061ff',
      fontSize: '11px',
      fontWeight: '700',
    }),
    multiValueRemove: (base) => ({
      ...base,
      color: '#0061ff',
      '&:hover': {
        backgroundColor: '#0061ff20',
        color: '#0061ff',
      },
    }),
    indicatorSeparator: () => ({
      display: 'none',
    }),
    dropdownIndicator: (base) => ({
      ...base,
      color: isDark ? '#6b7280' : '#9ca3af',
      '&:hover': {
        color: isDark ? '#9ca3af' : '#6b7280',
      },
    }),
  };

  // Add this handler function
  const handleWeekOffChange = (selectedOptions) => {
    setFormData(prev => ({
      ...prev,
      weekOff: selectedOptions || [] // React Select returns array of objects
    }));
  };

  const handleProfileImageChange = e => {
    const file = e.target.files?.[0];

    if (!file) {
      return;
    }

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (!allowedTypes.includes(file.type)) {
      setErrorMessage('Please select a valid image file (JPG, JPEG, PNG)');
      return;
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      setErrorMessage('Profile image size must be less than 5MB');
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = event => {
      setProfileImage(event.target.result);
    };
    reader.onerror = error => {
      console.error('FileReader error:', error);
    };
    reader.readAsDataURL(file);

    // Store file for upload
    setUploadedFiles(prev => ({ ...prev, profilePhoto: file }));
    setErrorMessage('');
  };

  const handleFileUpload = fieldName => e => {
    const file = e.target.files?.[0];

    if (!file) {
      return;
    }

    // Clear previous error
    setFileErrors(prev => ({ ...prev, [fieldName]: null }));

    // Check file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      setFileErrors(prev => ({ ...prev, [fieldName]: 'File size must be less than 5MB' }));
      return;
    }

    // Check file format
    const allowedTypes = {
      panCard: ['.pdf', '.jpg', '.jpeg', '.png'],
      aadhaarCard: ['.pdf', '.jpg', '.jpeg', '.png'],
      photograph: ['.jpg', '.jpeg', '.png'],
      bankPassbook: ['.pdf', '.jpg', '.jpeg', '.png'],
      educationCertificates: ['.pdf', '.jpg', '.jpeg', '.png'],
      experienceLetter: ['.pdf', '.jpg', '.jpeg', '.png'],
      proofOfAddress: ['.pdf', '.jpg', '.jpeg', '.png'],
      proofOfDOB: ['.pdf', '.jpg', '.jpeg', '.png'],
      offerLetter: ['.pdf', '.jpg', '.jpeg', '.png'],
      incomeTaxDeclaration: ['.pdf', '.jpg', '.jpeg', '.png'],
    };

    const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
    const allowedExtensions = allowedTypes[fieldName] || ['.pdf', '.jpg', '.jpeg', '.png'];

    if (!allowedExtensions.includes(fileExtension)) {
      setFileErrors(prev => ({
        ...prev,
        [fieldName]: `Invalid file format. Allowed: ${allowedExtensions.join(', ')}`,
      }));
      return;
    }

    setUploadedFiles(prev => ({ ...prev, [fieldName]: file }));
  };

  const handleCheckboxChange = (module, permissionKey) => {
    setSelectedPermissions(prev => ({
      ...prev,
      [module]: {
        ...prev[module],
        [permissionKey]: !prev[module]?.[permissionKey],
      },
    }));
  };


  const handleStepClick = (stepId) => {
    if (stepId === currentStep) return;
    // In edit mode, allow jumping to any step directly
    setCurrentStep(stepId);
    setErrorMessage('');
  };

  const formatPermissions = () => {
    const selectedPerms = [];
    Object.keys(selectedPermissions).forEach(module => {
      Object.keys(selectedPermissions[module]).forEach(permKey => {
        if (selectedPermissions[module][permKey]) {
          selectedPerms.push(permKey);
        }
      });
    });
    return selectedPerms;
  };

  const [fieldErrors, setFieldErrors] = useState({});
  // Validation for current step
  const validateCurrentStep = () => {
    const errors = {};

    switch (currentStep) {
      case 1:
        if (!formData.fullName?.trim()) errors.fullName = 'Full Name is required';
        if (!formData.dateOfBirth) errors.dateOfBirth = 'Date of Birth is required';
        if (!formData.gender) errors.gender = 'Gender is required';
        if (!formData.maritalStatus) errors.maritalStatus = 'Marital Status is required';
        if (!formData.fatherOrSpouseName?.trim()) errors.fatherOrSpouseName = 'Father/Spouse Name is required';
        if (!formData.contactNumber?.trim()) errors.contactNumber = 'Contact Number is required';
        if (!formData.email?.trim()) errors.email = 'Email is required';
        if (!formData.currentAddress?.trim()) errors.currentAddress = 'Current Address is required';
        if (!formData.permanentAddress?.trim()) errors.permanentAddress = 'Permanent Address is required';
        if (!formData.emergencyContactName?.trim()) errors.emergencyContactName = 'Emergency Contact Name is required';
        if (!formData.emergencyContactNumber?.trim()) errors.emergencyContactNumber = 'Emergency Contact Number is required';
        // if (!formData.password?.trim()) errors.password = 'Password is required';

        // Email format validation
        if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
          errors.email = 'Invalid email format';
        }
        break;

      case 2:
        if (!formData.employeeId?.trim()) errors.employeeId = 'Employee ID is required';
        if (!formData.dateOfJoining) errors.dateOfJoining = 'Date of Joining is required';
        if (!formData.department) errors.department = 'Department is required';
        if (!formData.designation) errors.designation = 'Designation is required';
        if (!formData.employmentType) errors.employmentType = 'Employment Type is required';
        if (!formData.workLocation?.trim()) errors.workLocation = 'Work Location is required';
        if (!formData.shift) errors.shift = 'Shift Details is required';
        break;

      case 3:
        if (!formData.grade) errors.grade = 'Grade is required';
        if (!formData.ctc) errors.ctc = 'CTC is required';
        // if (!formData.paymentMode) errors.paymentMode = 'Payment Mode is required';
        break;

      case 4:
        if (!formData.bankName?.trim()) errors.bankName = 'Bank Name is required';
        if (!formData.accountHolderName?.trim()) errors.accountHolderName = 'Account Holder Name is required';
        if (!formData.accountNumber?.trim()) errors.accountNumber = 'Account Number is required';
        if (!formData.ifscCode?.trim()) errors.ifscCode = 'IFSC Code is required';
        if (!formData.branchName?.trim()) errors.branchName = 'Branch Name is required';
        break;

      case 5:
        if (!formData.panNumber?.trim()) errors.panNumber = 'Pan Number is required';
        if (!formData.aadhaarNumber?.trim()) errors.aadhaarNumber = 'Aadhaar Number is required';
        break;

      case 7:
        {
          const hasPermissions = Object.values(selectedPermissions).some(module =>
            Object.values(module).some(perm => perm)
          );
          if (!hasPermissions) {
            errors.permissions = 'Please select at least one permission';
          }
        }
        break;

      default:
        break;
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const getFieldClassName = (fieldName, isTextarea = false) => {
    const baseClass = `${isTextarea ? 'p-5' : 'h-14 px-5'} w-full bg-default-50/50 border-2 border-default-200 rounded-2xl text-[13px] font-bold text-default-900 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all placeholder:text-default-400 placeholder:font-medium hover:border-default-300`;

    if (fieldErrors[fieldName]) {
      return `${baseClass} border-danger/50 focus:border-danger focus:ring-danger/10`;
    }

    return baseClass;
  };

  // Update nextStep function
  const nextStep = () => {
    if (validateCurrentStep()) {
      setFieldErrors({});
      setErrorMessage('');
      setCurrentStep(prev => Math.min(prev + 1, steps.length));
    } else {
      const firstError = Object.values(fieldErrors)[0];
      setErrorMessage(firstError);

      // Scroll to first error field
      setTimeout(() => {
        const firstErrorField = document.querySelector('.border-red-500');
        if (firstErrorField) {
          firstErrorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const sanitizeInput = input => {
    if (typeof input !== 'string') return input;
    return input.replace(/[<>"'&]/g, match => {
      const entities = { '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#x27;', '&': '&amp;' };
      return entities[match];
    });
  };

  const handleSubmit = async e => {
    e.preventDefault();

    // Ensure user has completed all steps including permissions
    if (currentStep !== 7) {
      setErrorMessage('Please complete all steps including permissions before submitting.');
      return;
    }

    if (!validateCurrentStep()) {
      setErrorMessage('Please complete all required steps before submitting.');
      return;
    }

    // Final validation for permissions (admin only)
    if (isAdmin) {
      const hasPermissions = Object.values(selectedPermissions).some(module =>
        Object.values(module).some(perm => perm)
      );
      if (!hasPermissions) {
        setErrorMessage('Please select at least one permission before submitting.');
        return;
      }
    }

    setLoading(true);
    setErrorMessage('');

    try {
      // Use provided employee ID
      const employeeId = formData.employeeId?.trim();

      if (!employeeId) {
        setErrorMessage('Employee ID is required');
        setLoading(false);
        return;
      }

      // Validate required fields
      if (!formData.fullName?.trim()) {
        setErrorMessage('Full Name is required');
        setLoading(false);
        return;
      }

      if (!formData.email?.trim()) {
        setErrorMessage('Email is required');
        setLoading(false);
        return;
      }


      // Prepare form data for file upload
      const submitData = new FormData();

      // Basic user info with sanitization
      submitData.append('name', sanitizeInput(formData.fullName || formData.name));
      submitData.append('email', sanitizeInput(formData.email));
      submitData.append('role', formData.role);
      submitData.append('employeeId', sanitizeInput(employeeId));
      if (isAdmin) {
        submitData.append('permissions', JSON.stringify(formatPermissions()));
      }

      // Employee Personal Details with proper profile photo handling
      const employeePersonalData = {
        fullName: sanitizeInput(formData.fullName),
        dateOfBirth: formData.dateOfBirth,
        gender: formData.gender,
        maritalStatus: formData.maritalStatus,
        fatherOrSpouseName: sanitizeInput(formData.fatherOrSpouseName),
        contactNumber: sanitizeInput(formData.contactNumber),
        emailAddress: sanitizeInput(formData.email),
        permanentAddress: sanitizeInput(formData.permanentAddress),
        currentAddress: sanitizeInput(formData.currentAddress),
        emergencyContact: {
          name: sanitizeInput(formData.emergencyContactName),
          number: sanitizeInput(formData.emergencyContactNumber),
        },
        aadhaarNumber: sanitizeInput(formData.aadhaarNumber),
        panNumber: sanitizeInput(formData.panNumber),
        bloodGroup: formData.bloodGroup,
      };

      // CRITICAL FIX: Handle profile photo properly
      if (uploadedFiles.profilePhoto) {
        // Case 1: New profile photo uploaded

        // Don't add profilePhoto to employeePersonalData - it will be sent as a file
      } else {
        // Case 2: No new photo - preserve existing photo
        const existingPhotoUrl = employee?.employeePersonal?.profilePhoto || employee?.documents?.profilePhoto;


        if (existingPhotoUrl && existingPhotoUrl !== img) {
          // Only add if we have a real existing photo (not the dummy image)
          employeePersonalData.profilePhoto = existingPhotoUrl;
        }
      }

      submitData.append('employeePersonal', JSON.stringify(employeePersonalData));

      // Employment Details - Send objects with id and name
      const getDepartmentData = () => {
        const dept = departments.find(d => d._id === formData.department);
        return dept ? { id: dept._id, name: dept.name } : null;
      };

      const getDesignationData = () => {
        const desg = designations.find(d => d._id === formData.designation);
        return desg ? { id: desg._id, name: desg.name } : null;
      };

      const getReportingManagerData = () => {
        const manager = reportingManagers.find(m => m._id === formData.reportingManager);
        return manager
          ? {
            id: manager._id,
            name: manager.name,
            department: manager.department,
            designation: manager.designation,
          }
          : null;
      };

      submitData.append(
        'employmentDetails',
        JSON.stringify({
          employeeId: employeeId,
          dateOfJoining: formData.dateOfJoining,
          department: getDepartmentData(),
          designation: getDesignationData(),
          employmentType: formData.employmentType,
          workLocation: formData.workLocation,
          reportingManager: getReportingManagerData(),
          probationPeriod: formData.probationPeriod,
          confirmationDate: formData.confirmationDate,
          shift: (() => {
            const shift = shifts.find(s => s._id === formData.shift);
            return shift ? {
              id: shift._id,
              name: shift.name,
              startTime: shift.startTime,
              endTime: shift.endTime
            } : null;
          })(),
          weekOff: formData.weekOff.map(option => option.value),
        })
      );

      // Salary Details
      submitData.append(
        'salaryDetails',
        JSON.stringify({
          grade: formData.grade,
          ctc: parseFloat(formData.ctc) || 0,
          paymentMode: formData.paymentMode,
          effectiveFrom: formData.effectiveFrom || new Date().toISOString(),
        })
      );

      // Bank Details
      submitData.append(
        'bankDetails',
        JSON.stringify({
          bankName: formData.bankName,
          accountHolderName: formData.accountHolderName,
          accountNumber: formData.accountNumber,
          ifscCode: formData.ifscCode,
          branchName: formData.branchName,
        })
      );

      // Statutory Compliance
      submitData.append(
        'statutoryCompliance',
        JSON.stringify({
          pfNumber: formData.pfNumber,
          esiNumber: formData.esiNumber,
          panNumber: formData.panNumber,
          aadhaarNumber: formData.aadhaarNumber,
          previousEmployment: formData.previousEmployment,
          incomeTaxDeclaration: formData.incomeTaxDeclaration,
        })
      );

      // Append files
      Object.keys(uploadedFiles).forEach(key => {
        if (uploadedFiles[key]) {
          submitData.append(key, uploadedFiles[key]);
        }
      });

      // API call
      const response = await api.put(`/hr/employees/${employee._id}`, submitData);

      if (response.status === 200 && response.data.success) {
        setErrorMessage('');

        // Close modal
        window.HSOverlay.close('#employeeEdit');

        // Reset form to initial state
        const initialFormData = {
          fullName: '',
          dateOfBirth: '',
          gender: '',
          maritalStatus: '',
          fatherOrSpouseName: '',
          contactNumber: '',
          email: '',
          currentAddress: '',
          permanentAddress: '',
          emergencyContactName: '',
          emergencyContactNumber: '',
          bloodGroup: '',
          employeeId: '',
          dateOfJoining: '',
          department: '',
          designation: '',
          employmentType: '',
          workLocation: '',
          reportingManager: '',
          probationPeriod: '',
          confirmationDate: '',
          shift: '',
          grade: '',
          ctc: '',
          paymentMode: '',
          effectiveFrom: '',
          bankName: '',
          accountHolderName: '',
          accountNumber: '',
          ifscCode: '',
          branchName: '',
          pfNumber: '',
          esiNumber: '',
          previousEmployment: '',
          weekOff: [],
          name: '',
          password: '',
          role: 'employee',
        };

        setFormData(initialFormData);
        setProfileImage(img);
        setSelectedPermissions({});
        setUploadedFiles({});
        setFileErrors({});
        setErrorMessage('');
        setSameAsCurrentAddress(false);
        setCurrentStep(1);

        // Show success message
        setTimeout(() => {
          alert('Employee updated successfully!');
        }, 100);

        // Call the callback to refresh employee list
        if (onEmployeeUpdated) {
          onEmployeeUpdated();
        }
      } else {
        const result = response.data;
        console.error('❌ Error updating employee:', result);
        setErrorMessage(result?.message || 'Error creating employee');
      }
    } catch (error) {
      console.error('❌ Error updating employee:', error);
      console.error('Error response:', error?.response);
      console.error('Error data:', error?.response?.data);

      let errorMsg = 'Error updating employee. Please try again.';

      if (error?.response?.data?.message) {
        errorMsg = error.response.data.message;
      } else if (error?.response?.status === 500) {
        errorMsg = 'Server error. Please check all required fields and try again.';
      } else if (error?.message) {
        errorMsg = error.message;
      }

      setErrorMessage(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  // Step progress indicator
  const StepProgress = () => (
    <div className="mb-12">
      <div className="flex items-center justify-between relative px-4">
        {/* Background Line */}
        <div className="absolute top-[18px] left-0 right-0 h-[2px] bg-default-100 -z-10 mx-12" />

        {steps.map((step) => {
          const isCompleted = currentStep > step.id;
          const isActive = currentStep === step.id;

          return (
            <div key={step.id} className="flex flex-col items-center gap-3 group relative">
              <button
                type="button"
                onClick={() => handleStepClick(step.id)}
                className={`size-9 flex items-center justify-center rounded-2xl font-black text-[11px] transition-all duration-500 z-10 ${currentStep >= step.id
                  ? 'bg-primary text-white scale-110 shadow-lg shadow-primary/25'
                  : 'bg-white border-2 border-default-200 text-default-400 group-hover:border-primary/30 group-hover:text-primary group-hover:scale-105'
                  }`}
                disabled={currentStep === step.id}
              >
                {isCompleted ? <LuCheck className="size-5" /> : step.id}
              </button>
              <span className={`text-[9px] font-black uppercase tracking-widest text-center max-w-[80px] transition-colors duration-300 ${isActive ? 'text-primary' : isCompleted ? 'text-success' : 'text-default-400'
                }`}>
                {step.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <div id="employeeEdit" className="hs-overlay hidden size-full fixed top-0 start-0 z-[80] overflow-x-hidden overflow-y-auto pointer-events-none" role="dialog" tabIndex="-1">
      <div className="hs-overlay-open:mt-7 hs-overlay-open:opacity-100 hs-overlay-open:duration-500 mt-0 opacity-0 ease-out transition-all sm:max-w-4xl sm:w-full m-3 sm:mx-auto min-h-[calc(100%-3.5rem)] flex items-center">
        <div className="w-full flex flex-col bg-white dark:bg-default-50 border border-default-200 dark:border-default-100 shadow-2xl rounded-3xl pointer-events-auto overflow-hidden">
          {/* Header */}
          <div className="flex justify-between items-center px-8 py-6 border-b border-default-100 dark:border-default-200 bg-default-50/30 dark:bg-default-100/10">
            <div className="flex items-center gap-5">
              <div className="size-14 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                <LuUser className="size-7" />
              </div>
              <div>
                <h3 className="text-xl font-black text-default-900 dark:text-default-100 uppercase tracking-tight">Edit Employee</h3>
                <p className="text-[10px] font-bold text-default-400 dark:text-default-500 uppercase tracking-[0.2em]">Step {currentStep} of {steps.length}: {steps[currentStep - 1].label}</p>
              </div>
            </div>
            <button
              type="button"
              className="size-12 flex items-center justify-center bg-white dark:bg-default-100 text-default-400 hover:text-danger hover:bg-danger/5 border border-default-100 dark:border-default-200 rounded-xl transition-all active:scale-95 shadow-sm"
              onClick={() => window.HSOverlay.close('#employeeEdit')}
            >
              <LuX className="size-6" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col h-full">
            <div className="p-8 max-h-[70vh] overflow-y-auto">
              <StepProgress />
              {errorMessage && (
                <div className="mb-6 p-4 rounded-2xl border border-danger/20 bg-danger/5 text-danger text-xs font-bold">
                  {errorMessage}
                </div>
              )}

              <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
                {currentStep === 1 && (
                  <>
                    {/* Profile Image Section */}
                    <div className="lg:col-span-12 flex flex-col items-center justify-center pb-8 border-b border-default-100">
                      <div className="relative group">
                        <div className="size-32 rounded-3xl overflow-hidden border-4 border-white shadow-xl ring-1 ring-default-200 group-hover:ring-primary/50 transition-all duration-500">
                          <img
                            src={profileImage || img}
                            alt="Profile"
                            className="size-full object-cover transition-transform duration-700 group-hover:scale-110"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="absolute -bottom-2 -right-2 size-10 bg-primary text-white rounded-xl shadow-lg shadow-primary/30 flex items-center justify-center hover:bg-primary-600 hover:scale-110 active:scale-95 transition-all duration-300 ring-4 ring-white"
                        >
                          <LuImagePlus className="size-5" />
                        </button>
                        <input
                          ref={fileInputRef}
                          type="file"
                          className="hidden"
                          accept="image/*"
                          onChange={handleProfileImageChange}
                        />
                      </div>
                      <div className="mt-4 text-center">
                        <p className="text-[10px] font-black text-default-900 uppercase tracking-widest">Profile Photograph</p>
                        <p className="text-[8px] font-bold text-default-400 uppercase tracking-tight mt-1">JPG, PNG up to 5MB</p>
                      </div>
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Full Name (as per PAN/Aadhaar) *" />
                      <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          if (!/[a-zA-Z]/.test(e.key) && e.key !== ' ' && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        placeholder="Enter Full Name"
                        className={getFieldClassName('fullName')}
                        required
                      />
                      <ErrorMessage field="fullName" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Date of Birth *" />
                      <input
                        type="date"
                        name="dateOfBirth"
                        value={formData.dateOfBirth}
                        onChange={handleInputChange}
                        className={getFieldClassName('dateOfBirth')}
                        required
                      />
                      <ErrorMessage field="dateOfBirth" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Gender *" />
                      <Select
                        options={genderOptions}
                        value={genderOptions.find(opt => opt.value === formData.gender)}
                        onChange={opt => handleInputChange({ target: { name: 'gender', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT GENDER"
                        classNamePrefix="react-select"
                        required
                      />
                      <ErrorMessage field="gender" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Marital Status *" />
                      <Select
                        options={maritalStatusOptions}
                        value={maritalStatusOptions.find(opt => opt.value === formData.maritalStatus)}
                        onChange={opt => handleInputChange({ target: { name: 'maritalStatus', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT STATUS"
                        classNamePrefix="react-select"
                        required
                      />
                      <ErrorMessage field="maritalStatus" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Father's / Spouse's Name *" />
                      <input
                        type="text"
                        name="fatherOrSpouseName"
                        value={formData.fatherOrSpouseName}
                        onKeyPress={(e) => {
                          if (!/[a-zA-Z]/.test(e.key) && e.key !== ' ' && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        onChange={handleInputChange}
                        placeholder="Enter Name"
                        className={getFieldClassName('fatherOrSpouseName')}
                        required
                      />
                      <ErrorMessage field="fatherOrSpouseName" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Contact Number *" />
                      <input
                        type="tel"
                        name="contactNumber"
                        value={formData.contactNumber}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          const key = e.key;
                          if (!/[0-9]/.test(key)) {
                            e.preventDefault();
                          }
                          if (e.target.value.length === 0 && !/[6-9]/.test(key)) {
                            e.preventDefault();
                          }
                        }}
                        maxLength={10}
                        placeholder="Enter Contact Number"
                        className={getFieldClassName('contactNumber')}
                        required
                      />
                      <ErrorMessage field="contactNumber" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Email Address *" />
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="Enter Email"
                        className={getFieldClassName('email')}
                        required
                      />
                      <ErrorMessage field="email" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Emergency Contact Name *" />
                      <input
                        type="text"
                        name="emergencyContactName"
                        value={formData.emergencyContactName}
                        onKeyPress={(e) => {
                          if (!/[a-zA-Z]/.test(e.key) && e.key !== ' ' && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        onChange={handleInputChange}
                        placeholder="Enter Emergency Contact Name"
                        className={getFieldClassName('emergencyContactName')}
                        required
                      />
                      <ErrorMessage field="emergencyContactName" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Emergency Contact Number *" />
                      <input
                        type="tel"
                        name="emergencyContactNumber"
                        value={formData.emergencyContactNumber}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          const key = e.key;
                          if (!/[0-9]/.test(key)) {
                            e.preventDefault();
                          }
                          if (e.target.value.length === 0 && !/[6-9]/.test(key)) {
                            e.preventDefault();
                          }
                        }}
                        maxLength={10}
                        placeholder="Enter Emergency Contact Number"
                        className={getFieldClassName('emergencyContactNumber')}
                        required
                      />
                      <ErrorMessage field="emergencyContactNumber" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Blood Group" />
                      <Select
                        options={bloodGroupOptions}
                        value={bloodGroupOptions.find(opt => opt.value === formData.bloodGroup)}
                        onChange={opt => handleInputChange({ target: { name: 'bloodGroup', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT BLOOD GROUP"
                        classNamePrefix="react-select"
                      />
                    </div>

                    <div className="lg:col-span-12 group">
                      <Label text="Current Address *" />
                      <textarea
                        name="currentAddress"
                        value={formData.currentAddress}
                        onChange={handleInputChange}
                        placeholder="Enter Current Address"
                        className={getFieldClassName('currentAddress', true)}
                        rows="3"
                        required
                      />
                      <ErrorMessage field='currentAddress' />
                    </div>

                    <div className="lg:col-span-12 group">
                      <div className="flex items-center gap-3 mb-4 p-4 bg-primary/5 rounded-2xl border border-primary/10 transition-all duration-300 hover:bg-primary/10 hover:border-primary/20">
                        <input
                          id="checkbox-1"
                          type="checkbox"
                          checked={sameAsCurrentAddress}
                          onChange={handleSameAddressChange}
                          className="size-5 rounded-lg border-default-300 text-primary focus:ring-primary/20 transition-all cursor-pointer"
                        />
                        <label htmlFor="checkbox-1" className="text-[10px] font-black text-primary uppercase tracking-widest cursor-pointer select-none">
                          Permanent address is same as current address
                        </label>
                      </div>
                      {!sameAsCurrentAddress && (
                        <div className="animate-in fade-in slide-in-from-top-2 duration-300">
                          <Label text="Permanent Address *" />
                          <textarea
                            name="permanentAddress"
                            value={formData.permanentAddress}
                            onChange={handleInputChange}
                            placeholder="Enter Permanent Address"
                            className={getFieldClassName('permanentAddress', true)}
                            rows="3"
                            required
                          />
                          <ErrorMessage field='permanentAddress' />
                        </div>
                      )}
                    </div>
                  </>
                )}

                {/* <div className="lg:col-span-6">
                    <Label text="Aadhaar Number *" />
                    <input
                      type="text"
                      name="aadhaarNumber"
                      value={formData.aadhaarNumber}
                      onChange={handleInputChange}
                      placeholder="Enter Aadhaar Number"
                      className="form-input"
                      required
                    />
                  </div>

                  <div className="lg:col-span-6">
                    <Label text="PAN Number *" />
                    <input
                      type="text"
                      name="panNumber"
                      value={formData.panNumber}
                      onChange={handleInputChange}
                      placeholder="Enter PAN Number"
                      className="form-input"
                      required
                    />
                  </div> */}



                {/* Step 2: Employment Details */}
                {currentStep === 2 && (
                  <>
                    <div className="lg:col-span-6 group">
                      <Label text="Employee ID *" />
                      <input
                        type="text"
                        name="employeeId"
                        value={formData.employeeId}
                        onChange={handleInputChange}
                        placeholder="Enter Employee ID"
                        className={getFieldClassName('employeeId')}
                        required
                      />
                      <ErrorMessage field="employeeId" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Date of Joining *" />
                      <input
                        type="date"
                        name="dateOfJoining"
                        value={formData.dateOfJoining}
                        onChange={handleInputChange}
                        className={getFieldClassName('dateOfJoining')}
                        required
                      />
                      <ErrorMessage field="dateOfJoining" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Department *" />
                      <Select
                        options={departments.map(dept => ({ value: dept._id, label: dept.name.toUpperCase() }))}
                        value={departments.map(dept => ({ value: dept._id, label: dept.name.toUpperCase() })).find(opt => opt.value === formData.department)}
                        onChange={opt => handleInputChange({ target: { name: 'department', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT DEPARTMENT"
                        classNamePrefix="react-select"
                        required
                      />
                      <ErrorMessage field="department" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Designation / Job Title *" />
                      <Select
                        options={designations.map(desg => ({ value: desg._id, label: desg.name.toUpperCase() }))}
                        value={designations.map(desg => ({ value: desg._id, label: desg.name.toUpperCase() })).find(opt => opt.value === formData.designation)}
                        onChange={opt => handleInputChange({ target: { name: 'designation', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT DESIGNATION"
                        classNamePrefix="react-select"
                        required
                      />
                      <ErrorMessage field="designation" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Employment Type *" />
                      <Select
                        options={employmentTypeOptions}
                        value={employmentTypeOptions.find(opt => opt.value === formData.employmentType)}
                        onChange={opt => handleInputChange({ target: { name: 'employmentType', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT TYPE"
                        classNamePrefix="react-select"
                        required
                      />
                      <ErrorMessage field="employmentType" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Work Location / Branch *" />
                      <input
                        type="text"
                        name="workLocation"
                        value={formData.workLocation}
                        onChange={handleInputChange}
                        placeholder="Enter Work Location"
                        className={getFieldClassName('workLocation')}
                        required
                      />
                      <ErrorMessage field="workLocation" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Reporting Manager" />
                      <Select
                        options={reportingManagers.map(manager => ({
                          value: manager._id,
                          label: `${manager.name} (${manager.department}) (${manager.designation})`.toUpperCase()
                        }))}
                        value={reportingManagers.map(manager => ({
                          value: manager._id,
                          label: `${manager.name} (${manager.department}) (${manager.designation})`.toUpperCase()
                        })).find(opt => opt.value === formData.reportingManager)}
                        onChange={opt => handleInputChange({ target: { name: 'reportingManager', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT MANAGER"
                        classNamePrefix="react-select"
                      />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Probation Period" />
                      <Select
                        options={probationPeriodOptions}
                        value={probationPeriodOptions.find(opt => opt.value === formData.probationPeriod)}
                        onChange={opt => handleInputChange({ target: { name: 'probationPeriod', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT OPTION"
                        classNamePrefix="react-select"
                      />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Confirmation Date" />
                      <input
                        type="date"
                        name="confirmationDate"
                        value={formData.confirmationDate}
                        onChange={handleInputChange}
                        className={getFieldClassName('confirmationDate')}
                      />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Office Timings / Shift Details *" />
                      <Select
                        options={shifts.map(shift => ({
                          value: shift._id,
                          label: `${shift.name} (${shift.startTime} - ${shift.endTime})`.toUpperCase()
                        }))}
                        value={shifts.map(shift => ({
                          value: shift._id,
                          label: `${shift.name} (${shift.startTime} - ${shift.endTime})`.toUpperCase()
                        })).find(opt => opt.value === formData.shift)}
                        onChange={opt => handleInputChange({ target: { name: 'shift', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT SHIFT"
                        classNamePrefix="react-select"
                        required
                      />
                      <ErrorMessage field="shift" />
                    </div>

                    <div className="lg:col-span-6 group">
                      <Label text="Week Off (Select multiple)" />
                      <Select
                        options={weekOffOptions}
                        value={formData.weekOff}
                        onChange={handleWeekOffChange}
                        isMulti
                        styles={selectStyles}
                        className="react-select-container"
                        classNamePrefix="react-select"
                        placeholder="SELECT DAYS"
                        closeMenuOnSelect={false}
                      />
                    </div>
                  </>
                )}

                {/* Step 3: Salary & Payroll */}
                {currentStep === 3 && (
                  <>
                    <div className="lg:col-span-6 group">
                      <Label text="Grade *" />
                      <Select
                        options={grades.map(grade => ({ value: grade._id, label: grade.grade.toUpperCase() }))}
                        value={grades.map(grade => ({ value: grade._id, label: grade.grade.toUpperCase() })).find(opt => opt.value === formData.grade)}
                        onChange={opt => handleInputChange({ target: { name: 'grade', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT GRADE"
                        classNamePrefix="react-select"
                        required
                      />
                      <ErrorMessage field="grade" />
                    </div>
                    <div className="lg:col-span-6 group">
                      <Label text="CTC (Cost to Company) *" />
                      <input
                        type="number"
                        name="ctc"
                        value={formData.ctc}
                        onChange={handleInputChange}
                        placeholder="Enter CTC Amount"
                        className={getFieldClassName('ctc')}
                        required
                      />
                      <ErrorMessage field="ctc" />
                    </div>
                    <div className="lg:col-span-6 group">
                      <Label text="Payment Mode *" />
                      <Select
                        options={paymentModeOptions}
                        value={paymentModeOptions.find(opt => opt.value === formData.paymentMode)}
                        onChange={opt => handleInputChange({ target: { name: 'paymentMode', value: opt?.value } })}
                        styles={selectStyles}
                        placeholder="SELECT MODE"
                        classNamePrefix="react-select"
                        required
                      />
                      <ErrorMessage field="paymentMode" />
                    </div>
                    <div className="lg:col-span-6 group">
                      <Label text="Effective From" />
                      <input
                        type="date"
                        name="effectiveFrom"
                        value={formData.effectiveFrom}
                        onChange={handleInputChange}
                        className={getFieldClassName('effectiveFrom')}
                      />
                    </div>
                  </>
                )}

                {/* Step 4: Bank Details */}
                {currentStep === 4 && (
                  <>
                    <div className="lg:col-span-6 group">
                      <Label text="Bank Name *" />
                      <input
                        type="text"
                        name="bankName"
                        value={formData.bankName}
                        onKeyPress={(e) => {
                          // Allow only letters (A-Z, a-z) and backspace
                          if (!/[a-zA-Z]/.test(e.key) && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        onChange={handleInputChange}
                        placeholder="Enter Bank Name"
                        className={getFieldClassName('bankName')}
                        required
                      />
                      <ErrorMessage field="bankName" />

                    </div>
                    <div className="lg:col-span-6 group">
                      <Label text="Account Holder Name *" />
                      <input
                        type="text"
                        name="accountHolderName"
                        value={formData.accountHolderName}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          // Allow only letters (A-Z, a-z) and backspace
                          if (!/[a-zA-Z]/.test(e.key) && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        placeholder="Enter Account Holder Name"
                        className={getFieldClassName('accountHolderName')}
                        required
                      />
                      <ErrorMessage field="accountHolderName" />
                    </div>
                    <div className="lg:col-span-6 group">
                      <Label text="Account Number *" />
                      <input
                        type="text"
                        name="accountNumber"
                        value={formData.accountNumber}
                        onChange={handleInputChange}
                        placeholder="Enter Account Number"
                        onKeyPress={(e) => {
                          // Allow only numbers (0-9) and backspace
                          if (!/[0-9]/.test(e.key) && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        className={getFieldClassName('accountNumber')}
                        required
                      />
                      <ErrorMessage field="accountNumber" />
                    </div>
                    <div className="lg:col-span-6 group">
                      <Label text="IFSC Code *" />
                      <input
                        type="text"
                        name="ifscCode"
                        value={formData.ifscCode}
                        onChange={handleInputChange}
                        placeholder="Enter IFSC Code"
                        onKeyPress={(e) => {
                          // Allow only letters (A-Z, a-z) and backspace
                          if (!/[a-zA-Z0-9]/.test(e.key) && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        className={getFieldClassName('ifscCode')}
                        required
                      />
                      <ErrorMessage field="ifscCode" />
                    </div>
                    <div className="lg:col-span-6 group">
                      <Label text="Branch Name *" />
                      <input
                        type="text"
                        name="branchName"
                        value={formData.branchName}
                        onChange={handleInputChange}
                        placeholder="Enter Branch Name"
                        className={getFieldClassName('branchName')}
                        required
                      />
                      <ErrorMessage field="branchName" />
                    </div>
                  </>
                )}

                {/* Step 5: Statutory Compliance */}
                {currentStep === 5 && (
                  <>
                    <div className="lg:col-span-6 group">
                      <Label text="PF Number / UAN" />
                      <input
                        type="text"
                        name="pfNumber"
                        value={formData.pfNumber}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          if (!/[a-zA-Z0-9]/.test(e.key) && e.key !== 'Backspace' && e.key !== '/') {
                            e.preventDefault();
                          }
                        }}
                        placeholder="Enter PF Number"
                        className={getFieldClassName('pfNumber')}
                      />
                    </div>
                    <div className="lg:col-span-6 group">
                      <Label text="ESI Number" />
                      <input
                        type="text"
                        name="esiNumber"
                        value={formData.esiNumber}
                        onChange={handleInputChange}
                        placeholder="Enter ESI Number"
                        onKeyPress={(e) => {
                          if (!/[0-9]/.test(e.key) && e.key !== 'Backspace' && e.key !== '-') {
                            e.preventDefault();
                          }
                        }}
                        className={getFieldClassName('esiNumber')}
                      />
                    </div>
                    <div className="lg:col-span-6 group">
                      <Label text="PAN Number (for TDS purposes) *" />
                      <input
                        type="text"
                        name="panNumber"
                        value={formData.panNumber}
                        onChange={handleInputChange}
                        placeholder="Enter PAN Number"
                        onKeyPress={(e) => {
                          if (!/[a-zA-Z0-9]/.test(e.key) && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        className={getFieldClassName('panNumber')}
                        required
                      />
                      <ErrorMessage field="panNumber" />
                    </div>
                    <div className="lg:col-span-6 group">
                      <Label text="Aadhaar Number *" />
                      <input
                        type="text"
                        name="aadhaarNumber"
                        value={formData.aadhaarNumber}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          if (!/[0-9]/.test(e.key) && e.key !== ' ') {
                            e.preventDefault();
                          }
                        }}
                        maxLength={14}
                        placeholder="Enter Aadhaar Number"
                        className={getFieldClassName('aadhaarNumber')}
                        required
                      />
                      <ErrorMessage field="aadhaarNumber" />
                    </div>
                    <div className="lg:col-span-6 group">
                      <FileUpload
                        label="Income Tax Declaration (Form 12BB)"
                        onFileChange={handleFileUpload('incomeTaxDeclaration')}
                        fileName={uploadedFiles.incomeTaxDeclaration?.name}
                        error={fileErrors.incomeTaxDeclaration}
                      />
                      {employee?.statutoryCompliance?.incomeTaxDeclaration && (
                        <div className="mt-3 p-3 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-between group">
                          <div className="flex items-center gap-2">
                            <div className="size-8 bg-white rounded-lg flex items-center justify-center text-primary shadow-sm group-hover:scale-110 transition-all">
                              <LuCheck className="size-4" />
                            </div>
                            <span className="text-[10px] font-bold text-default-600 uppercase tracking-wider">Current Declaration</span>
                          </div>
                          <a
                            href={employee.statutoryCompliance.incomeTaxDeclaration}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[9px] font-black text-primary uppercase tracking-widest hover:underline"
                          >
                            View File
                          </a>
                        </div>
                      )}
                    </div>
                    <div className="lg:col-span-12 group">
                      <Label text="Previous Employment Details" />
                      <textarea
                        name="previousEmployment"
                        value={formData.previousEmployment}
                        onChange={handleInputChange}
                        placeholder="Enter previous employment details (if applicable, for tax computation)"
                        className={getFieldClassName('previousEmployment', true)}
                        rows="3"
                      />
                    </div>
                  </>
                )}

                {/* Step 6: Documents */}
                {currentStep === 6 && (
                  <div className="lg:col-span-12 grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-4 group">
                      <FileUpload
                        label="PAN Card Copy"
                        onFileChange={handleFileUpload('panCard')}
                        fileName={uploadedFiles.panCard?.name}
                        error={fileErrors.panCard}
                      />
                      {employee?.documents?.panCard && (
                        <div className="p-3 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-between group-hover:border-primary/20 transition-all duration-300">
                          <div className="flex items-center gap-2">
                            <div className="size-8 bg-white rounded-lg flex items-center justify-center text-primary shadow-sm group-hover:scale-110 transition-all">
                              <LuCheck className="size-4" />
                            </div>
                            <span className="text-[10px] font-bold text-default-600 uppercase tracking-wider">PAN Card Uploaded</span>
                          </div>
                          <a href={employee.documents.panCard} target="_blank" rel="noopener noreferrer" className="text-[9px] font-black text-primary uppercase tracking-widest hover:underline">View File</a>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4 group">
                      <FileUpload
                        label="Aadhaar Card Copy"
                        onFileChange={handleFileUpload('aadhaarCard')}
                        fileName={uploadedFiles.aadhaarCard?.name}
                        error={fileErrors.aadhaarCard}
                      />
                      {employee?.documents?.aadhaarCard && (
                        <div className="p-3 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-between group-hover:border-primary/20 transition-all duration-300">
                          <div className="flex items-center gap-2">
                            <div className="size-8 bg-white rounded-lg flex items-center justify-center text-primary shadow-sm group-hover:scale-110 transition-all">
                              <LuCheck className="size-4" />
                            </div>
                            <span className="text-[10px] font-bold text-default-600 uppercase tracking-wider">Aadhaar Uploaded</span>
                          </div>
                          <a href={employee.documents.aadhaarCard} target="_blank" rel="noopener noreferrer" className="text-[9px] font-black text-primary uppercase tracking-widest hover:underline">View File</a>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4 group">
                      <FileUpload
                        label="Passport Photo"
                        accept=".jpg,.jpeg,.png"
                        onFileChange={handleFileUpload('photograph')}
                        fileName={uploadedFiles.photograph?.name}
                        error={fileErrors.photograph}
                      />
                      {employee?.documents?.photograph && (
                        <div className="p-3 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-between group-hover:border-primary/20 transition-all duration-300">
                          <div className="flex items-center gap-2">
                            <div className="size-8 bg-white rounded-lg flex items-center justify-center text-primary shadow-sm group-hover:scale-110 transition-all">
                              <LuCheck className="size-4" />
                            </div>
                            <span className="text-[10px] font-bold text-default-600 uppercase tracking-wider">Photo Uploaded</span>
                          </div>
                          <a href={employee.documents.photograph} target="_blank" rel="noopener noreferrer" className="text-[9px] font-black text-primary uppercase tracking-widest hover:underline">View File</a>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4 group">
                      <FileUpload
                        label="Bank Passbook"
                        onFileChange={handleFileUpload('bankPassbook')}
                        fileName={uploadedFiles.bankPassbook?.name}
                        error={fileErrors.bankPassbook}
                      />
                      {employee?.documents?.bankPassbook && (
                        <div className="p-3 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-between group-hover:border-primary/20 transition-all duration-300">
                          <div className="flex items-center gap-2">
                            <div className="size-8 bg-white rounded-lg flex items-center justify-center text-primary shadow-sm group-hover:scale-110 transition-all">
                              <LuCheck className="size-4" />
                            </div>
                            <span className="text-[10px] font-bold text-default-600 uppercase tracking-wider">Passbook Uploaded</span>
                          </div>
                          <a href={employee.documents.bankPassbook} target="_blank" rel="noopener noreferrer" className="text-[9px] font-black text-primary uppercase tracking-widest hover:underline">View File</a>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4 group">
                      <FileUpload
                        label="Education Certificates"
                        onFileChange={handleFileUpload('educationCertificates')}
                        fileName={uploadedFiles.educationCertificates?.name}
                        error={fileErrors.educationCertificates}
                      />
                      {Array.isArray(employee?.documents?.educationCertificates) && employee.documents.educationCertificates.length > 0 && (
                        <div className="p-4 bg-primary/5 rounded-2xl border border-primary/10 space-y-3 group-hover:border-primary/20 transition-all duration-300">
                          <p className="text-[10px] font-black text-primary uppercase tracking-widest mb-2">Current Certificates</p>
                          <div className="grid grid-cols-1 gap-2">
                            {employee.documents.educationCertificates.map((file, index) => (
                              <a key={index} href={file} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between p-2 bg-white rounded-lg border border-default-100 hover:border-primary/30 hover:shadow-sm transition-all group/item">
                                <span className="text-[10px] font-bold text-default-600 uppercase tracking-tight">Certificate {index + 1}</span>
                                <LuArrowRight className="size-3 text-primary group-hover/item:translate-x-1 transition-transform" />
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4 group">
                      <FileUpload
                        label="Experience Letter"
                        onFileChange={handleFileUpload('experienceLetter')}
                        fileName={uploadedFiles.experienceLetter?.name}
                        error={fileErrors.experienceLetter}
                      />
                      {employee?.documents?.experienceLetter && (
                        <div className="p-3 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-between group-hover:border-primary/20 transition-all duration-300">
                          <div className="flex items-center gap-2">
                            <div className="size-8 bg-white rounded-lg flex items-center justify-center text-primary shadow-sm group-hover:scale-110 transition-all">
                              <LuCheck className="size-4" />
                            </div>
                            <span className="text-[10px] font-bold text-default-600 uppercase tracking-wider">Letter Uploaded</span>
                          </div>
                          <a href={employee.documents.experienceLetter} target="_blank" rel="noopener noreferrer" className="text-[9px] font-black text-primary uppercase tracking-widest hover:underline">View File</a>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4 group">
                      <FileUpload
                        label="Proof of Address"
                        onFileChange={handleFileUpload('proofOfAddress')}
                        fileName={uploadedFiles.proofOfAddress?.name}
                        error={fileErrors.proofOfAddress}
                      />
                      {employee?.documents?.proofOfAddress && (
                        <div className="p-3 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-between group-hover:border-primary/20 transition-all duration-300">
                          <div className="flex items-center gap-2">
                            <div className="size-8 bg-white rounded-lg flex items-center justify-center text-primary shadow-sm group-hover:scale-110 transition-all">
                              <LuCheck className="size-4" />
                            </div>
                            <span className="text-[10px] font-bold text-default-600 uppercase tracking-wider">Proof Uploaded</span>
                          </div>
                          <a href={employee.documents.proofOfAddress} target="_blank" rel="noopener noreferrer" className="text-[9px] font-black text-primary uppercase tracking-widest hover:underline">View File</a>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4 group">
                      <FileUpload
                        label="Proof of Date of Birth"
                        onFileChange={handleFileUpload('proofOfDOB')}
                        fileName={uploadedFiles.proofOfDOB?.name}
                        error={fileErrors.proofOfDOB}
                      />
                      {employee?.documents?.proofOfDOB && (
                        <div className="p-3 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-between group-hover:border-primary/20 transition-all duration-300">
                          <div className="flex items-center gap-2">
                            <div className="size-8 bg-white rounded-lg flex items-center justify-center text-primary shadow-sm group-hover:scale-110 transition-all">
                              <LuCheck className="size-4" />
                            </div>
                            <span className="text-[10px] font-bold text-default-600 uppercase tracking-wider">DOB Proof Uploaded</span>
                          </div>
                          <a href={employee.documents.proofOfDOB} target="_blank" rel="noopener noreferrer" className="text-[9px] font-black text-primary uppercase tracking-widest hover:underline">View File</a>
                        </div>
                      )}
                    </div>

                    <div className="space-y-4 group">
                      <FileUpload
                        label="Offer Letter"
                        onFileChange={handleFileUpload('offerLetter')}
                        fileName={uploadedFiles.offerLetter?.name}
                        error={fileErrors.offerLetter}
                      />
                      {employee?.documents?.offerLetter && (
                        <div className="p-3 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-between group-hover:border-primary/20 transition-all duration-300">
                          <div className="flex items-center gap-2">
                            <div className="size-8 bg-white rounded-lg flex items-center justify-center text-primary shadow-sm group-hover:scale-110 transition-all">
                              <LuCheck className="size-4" />
                            </div>
                            <span className="text-[10px] font-bold text-default-600 uppercase tracking-wider">Letter Uploaded</span>
                          </div>
                          <a href={employee.documents.offerLetter} target="_blank" rel="noopener noreferrer" className="text-[9px] font-black text-primary uppercase tracking-widest hover:underline">View File</a>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Step 7: Permissions */}
                {currentStep === 7 && (
                  <div className="lg:col-span-12 space-y-8">
                    {/* System Role Selection */}
                    <div className="bg-default-50/50 rounded-3xl p-8 border border-default-200 shadow-sm">
                      <div className="flex items-center gap-4 mb-6">
                        <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                          <LuShield className="size-6" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-default-900">System Access</h3>
                          <p className="text-sm text-default-500">Define user role and basic account settings</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <Label text="User Role *" />
                          <select
                            name="role"
                            value={formData.role}
                            onChange={handleInputChange}
                            className={getFieldClassName('role')}
                            required
                          >
                            <option value="">Select Role</option>
                            <option value="Admin">Admin</option>
                            <option value="Manager">Manager</option>
                            <option value="Employee">Employee</option>
                            <option value="HR">HR</option>
                          </select>
                          <ErrorMessage field="role" />
                          <p className="text-[10px] text-default-400 mt-2 px-1">Role determines the primary access level and default module visibility.</p>
                        </div>
                      </div>
                    </div>

                    {/* Detailed Permissions */}
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="text-base font-bold text-default-900">Module Permissions</h4>
                          <p className="text-sm text-default-500">Granular control over specific system capabilities</p>
                        </div>
                        {isAdmin && (
                          <div className="flex items-center gap-3 p-2 bg-amber-50 rounded-xl border border-amber-100">
                            <LuTriangleAlert className="size-4 text-amber-500" />
                            <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider">Admin Override Active</span>
                          </div>
                        )}
                      </div>

                      {/* Jump to Module */}
                      <div className="relative group">
                        <Label text="Jump to Module" />
                        <Select
                          options={Object.keys(groupedPermissions).map(module => ({
                            value: module,
                            label: module
                          }))}
                          value={permissionSearch && Object.keys(groupedPermissions).includes(permissionSearch)
                            ? { value: permissionSearch, label: permissionSearch }
                            : null}
                          onChange={(opt) => setPermissionSearch(opt ? opt.value : '')}
                          isClearable
                          placeholder="Select Module..."
                          styles={selectStyles}
                          classNamePrefix="react-select"
                        />
                      </div>

                      <div className="space-y-4">
                        {Object.keys(groupedPermissions)
                          .filter(module => module.toLowerCase().includes(permissionSearch.toLowerCase()))
                          .map(module => (
                            <div key={module} className="bg-white rounded-2xl border border-default-200 overflow-hidden hover:border-primary/20 transition-all duration-300 shadow-sm group">
                              <div className="px-6 py-4 bg-default-50/50 border-b border-default-100 flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <div className="size-8 bg-white rounded-lg border border-default-200 flex items-center justify-center text-default-600 group-hover:text-primary group-hover:border-primary/30 transition-all">
                                    <LuShieldCheck className="size-4" />
                                  </div>
                                  <h5 className="font-bold text-default-800 uppercase tracking-wide text-xs">{module}</h5>
                                </div>
                                <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-primary cursor-pointer hover:opacity-80">
                                  <input
                                    type="checkbox"
                                    className="size-4 rounded border-default-300 text-primary focus:ring-primary/20 transition-all cursor-pointer"
                                    checked={groupedPermissions[module].every(perm => selectedPermissions[module]?.[perm.key])}
                                    onChange={e => {
                                      const checked = e.target.checked;
                                      const modulePermissions = {};
                                      groupedPermissions[module].forEach(perm => {
                                        modulePermissions[perm.key] = checked;
                                      });
                                      setSelectedPermissions(prev => ({
                                        ...prev,
                                        [module]: modulePermissions,
                                      }));
                                    }}
                                    disabled={!isAdmin}
                                  />
                                  Select All
                                </label>
                              </div>
                              <div className="p-6">
                                <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                                  {groupedPermissions[module].map(permission => {
                                    const isChecked = selectedPermissions[module]?.[permission.key] || false;
                                    return (
                                      <label
                                        key={permission.key}
                                        className={`flex flex-col gap-2 p-3 rounded-xl border transition-all cursor-pointer group/item
                                      ${isChecked
                                            ? 'bg-primary/5 border-primary/20 text-primary'
                                            : 'bg-white border-default-100 text-default-600 hover:border-default-300 hover:bg-default-50'
                                          }`}
                                      >
                                        <div className="flex items-center gap-3">
                                          <div className={`size-5 rounded flex items-center justify-center transition-all shrink-0
                                        ${isChecked ? 'bg-primary text-white' : 'bg-default-100 text-transparent'}`}>
                                            <LuCheck className="size-3 stroke-[3]" />
                                          </div>
                                          <input
                                            type="checkbox"
                                            className="hidden"
                                            checked={isChecked}
                                            onChange={() => handleCheckboxChange(module, permission.key)}
                                            disabled={!isAdmin}
                                          />
                                          <span className="text-[11px] font-bold uppercase tracking-tight">{permission.label}</span>
                                        </div>
                                        {permission.description && (
                                          <p className="text-[10px] font-medium text-default-400 leading-relaxed pl-8">{permission.description}</p>
                                        )}
                                      </label>
                                    );
                                  })}
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="card-footer flex justify-between items-center px-6 py-3 border-t">
              <div>
                {currentStep > 1 && (
                  <button
                    type="button"
                    onClick={prevStep}
                    className="h-10 px-6 text-[10px] font-black uppercase tracking-widest border border-default-300 text-default-700 hover:bg-default-50 flex items-center gap-2 rounded-xl transition-all active:scale-95"
                    disabled={loading}
                  >
                    <LuArrowLeft className="size-4" />
                    Previous
                  </button>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  className="h-10 px-6 text-[10px] font-black uppercase tracking-widest text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                  onClick={() => window.HSOverlay.close('#employeeEdit')}
                  disabled={loading}
                >
                  Cancel
                </button>

                {currentStep < steps.length ? (
                  <button
                    type="button"
                    onClick={nextStep}
                    className="h-10 px-6 text-[10px] font-black uppercase tracking-widest bg-primary text-white flex items-center gap-2 rounded-xl transition-all active:scale-95"
                    disabled={loading}
                  >
                    Next
                    <LuArrowRight className="size-4" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleSubmit}
                    className="h-10 px-6 text-[10px] font-black uppercase tracking-widest bg-success text-white rounded-xl transition-all active:scale-95"
                    disabled={loading}
                  >
                    {loading ? 'Updating...' : 'Update Employee'}
                  </button>
                )}
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditEmployeeData;
