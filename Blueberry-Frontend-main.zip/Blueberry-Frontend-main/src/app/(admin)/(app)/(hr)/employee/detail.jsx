import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import api from '@/config/api';
import EmployeeDetailContent from './components/EmployeeDetailContent';
import { 
  LuLayoutDashboard, 
  LuListTodo, 
  LuCalendarOff, 
  LuClock
} from 'react-icons/lu';

const EmployeeDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [employee, setEmployee] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [stats, setStats] = useState({
    projects: 0,
    tasks: 0,
    leaves: 0,
    pendingTasks: 0
  });

  useEffect(() => {
    const fetchEmployee = async () => {
      if (!id) return;
      
      try {
        setLoading(true);
        const response = await api.get(`/hr/employees/${id}`);
        
        if (response.data.success) {
          setEmployee(response.data.employee);
        } else {
          setError('Failed to load employee details');
        }
      } catch (err) {
        console.error('Error fetching employee:', err);
        setError(err.response?.data?.message || 'Error loading employee details');
      } finally {
        setLoading(false);
      }
    };

    fetchEmployee();
  }, [id]);

  useEffect(() => {
    const fetchStats = async () => {
      if (!employee?._id) return;
      
      try {
        const [projectsResp, tasksResp, leavesResp] = await Promise.all([
          api.get('/projects', { params: { limit: 100 } }),
          api.get('/tasks', { params: { limit: 100 } }),
          api.get('/leave-requests/all', {
             params: { searchByEmployee: employee.employeePersonal?.fullName || employee.name, limit: 100 }
          })
        ]);

        const allProjects = projectsResp.data.items || [];
        const empProjects = allProjects.filter(p =>
          p.developers?.some(dev => dev._id === employee._id)
        );

        const allTasks = tasksResp.data.items || [];
        const empTasks = allTasks.filter(t =>
          t.assignees?.some(assignee => assignee._id === employee._id)
        );
        
        // Count pending tasks (assuming status is not 'completed' or 'done')
        const pendingTasks = empTasks.filter(t => 
          !['completed', 'done', 'closed'].includes(t.status?.toLowerCase())
        ).length;

        const empLeaves = leavesResp.data.data || [];

        setStats({
          projects: empProjects.length,
          tasks: empTasks.length,
          pendingTasks: pendingTasks,
          leaves: empLeaves.length
        });

      } catch (err) {
        console.error("Error fetching stats", err);
      }
    };

    if (employee) {
      fetchStats();
    }
  }, [employee]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <div className="size-12 border-4 border-primary/10 border-t-primary rounded-full animate-spin" />
        <p className="text-xs font-bold text-default-400 uppercase tracking-widest">Loading Employee Profile...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
        <div className="size-16 bg-danger/10 text-danger rounded-2xl flex items-center justify-center">
          <span className="text-2xl">!</span>
        </div>
        <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">Error Loading Profile</h3>
        <p className="text-sm text-default-500">{error}</p>
        <button 
          onClick={() => navigate('/employee')}
          className="px-6 py-2 bg-default-100 hover:bg-default-200 text-default-900 rounded-xl text-xs font-bold uppercase tracking-widest transition-colors"
        >
          Back to Directory
        </button>
      </div>
    );
  }

  return (
    <main className="w-full space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-default-200 shadow-sm flex items-center gap-4 transition-all hover:shadow-md">
          <div className="size-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
            <LuLayoutDashboard className="size-6" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Projects</div>
            <div className="text-2xl font-black text-default-900 leading-none">{stats.projects}</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-default-200 shadow-sm flex items-center gap-4 transition-all hover:shadow-md">
          <div className="size-12 rounded-2xl bg-warning/10 flex items-center justify-center text-warning">
            <LuListTodo className="size-6" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Total Tasks</div>
            <div className="text-2xl font-black text-default-900 leading-none">{stats.tasks}</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-default-200 shadow-sm flex items-center gap-4 transition-all hover:shadow-md">
          <div className="size-12 rounded-2xl bg-success/10 flex items-center justify-center text-success">
            <LuClock className="size-6" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Pending Tasks</div>
            <div className="text-2xl font-black text-default-900 leading-none">{stats.pendingTasks}</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-default-200 shadow-sm flex items-center gap-4 transition-all hover:shadow-md">
          <div className="size-12 rounded-2xl bg-danger/10 flex items-center justify-center text-danger">
            <LuCalendarOff className="size-6" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Leaves Taken</div>
            <div className="text-2xl font-black text-default-900 leading-none">{stats.leaves}</div>
          </div>
        </div>
      </div>

      <div className="bg-white border border-default-200 rounded-xl overflow-hidden shadow-sm">
        <EmployeeDetailContent 
          employee={employee} 
          isPage={true} 
        />
      </div>
    </main>
  );
};

export default EmployeeDetailPage;
