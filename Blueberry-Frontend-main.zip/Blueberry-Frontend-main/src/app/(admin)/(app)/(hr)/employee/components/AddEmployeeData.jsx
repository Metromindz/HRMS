// Add Employee Modal
import img from '@/assets/images/user/user-dummy-img.jpg';
import { useState, useEffect } from 'react';
import { LuImagePlus, LuX, LuUpload, LuArrowLeft, LuArrowRight, LuCheck, LuTriangleAlert, LuShield, LuShieldCheck, LuTrash2, LuUser, LuPlus } from 'react-icons/lu';
import api from '../../../../../../config/api';
import { useAuth } from '@/context/AuthContext';
import { useLayoutContext } from '@/context/useLayoutContext';
import { FaEye, FaEyeSlash } from 'react-icons/fa';
import Select from 'react-select';


// Label component
const Label = ({ text, htmlFor }) => (
  <label
    htmlFor={htmlFor}
    className="text-[10px] font-black text-default-700 dark:text-default-300 uppercase tracking-[0.15em] ml-1 mb-2.5 block group-hover:text-primary transition-colors duration-300"
  >
    {text}
  </label>
);

const FileUpload = ({ label, accept = '.pdf,.jpg,.jpeg,.png', onFileChange, fileName, error }) => {
  const id = label.replace(/\s+/g, '');
  return (
    <div className="space-y-3 group">
      <Label text={label} htmlFor={id} />
      <div className="relative">
        <input
          type="file"
          accept={accept}
          className="hidden"
          id={id}
          onChange={onFileChange}
        />
        <label
          htmlFor={id}
          className="flex flex-col items-center justify-center min-h-[140px] bg-default-50/50 dark:bg-default-100/20 border-2 border-dashed border-default-200 dark:border-default-100 rounded-[2rem] hover:border-primary/50 hover:bg-primary/[0.02] transition-all duration-500 cursor-pointer group-hover:scale-[0.99] group-hover:shadow-xl group-hover:shadow-primary/5"
        >
          <div className="size-12 bg-white dark:bg-default-50 rounded-2xl border border-default-100 dark:border-default-200 shadow-sm flex items-center justify-center mb-4 group-hover:text-primary group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/10 transition-all duration-500">
            <LuUpload className="size-5" />
          </div>
          <p className="text-[10px] font-black text-default-600 dark:text-default-400 uppercase tracking-widest group-hover:text-primary transition-colors duration-300">Click to upload {label}</p>
          <p className="text-[8px] font-bold text-default-400 dark:text-default-500 uppercase tracking-tight mt-1.5">Allowed: {accept} | Max: 5MB</p>
        </label>
      </div>
      {fileName && (
        <div className="flex items-center gap-3 px-4 py-3 bg-success/5 border border-success/10 rounded-2xl animate-in fade-in slide-in-from-top-2 duration-500 shadow-sm">
          <div className="size-2 bg-success rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
          <p className="text-[10px] font-bold text-success uppercase tracking-wider truncate flex-1" title={fileName}>
            {fileName}
          </p>
        </div>
      )}
      {error && (
        <div className="flex items-center gap-3 px-4 py-3 bg-danger/5 border border-danger/10 rounded-2xl animate-in fade-in slide-in-from-top-2 duration-500 shadow-sm">
          <div className="size-2 bg-danger rounded-full shadow-[0_0_8px_rgba(244,63,94,0.5)]" />
          <p className="text-[10px] font-bold text-danger uppercase tracking-wider">
            {error}
          </p>
        </div>
      )}
    </div>
  );
};

const AddEmployeeData = ({ onEmployeeAdded }) => {
  const { user } = useAuth();
  const { theme } = useLayoutContext();
  const isDark = theme === 'dark';
  const isAdmin = user?.role === 'superadmin' || user?.role === 'admin';
  const [currentStep, setCurrentStep] = useState(1);
  const [profileImage, setProfileImage] = useState(img);
  const [loading, setLoading] = useState(false);
  const [departments, setDepartments] = useState([]);
  const [designations, setDesignations] = useState([]);
  const [, setPermissions] = useState([]);
  const [groupedPermissions, setGroupedPermissions] = useState({});
  const [reportingManagers, setReportingManagers] = useState([]);
  const [permissionSearch, setPermissionSearch] = useState('');
  const [grades, setGrades] = useState([]);
  const [shifts, setShifts] = useState([]);
  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState({
    // Personal Details
    fullName: '',
    dateOfBirth: '',
    gender: '',
    maritalStatus: '',
    fatherOrSpouseName: '',
    contactNumber: '',
    email: '',
    currentAddress: '',
    permanentAddress: '',
    emergencyContactName: '',
    emergencyContactNumber: '',
    bloodGroup: '',
    // Employment Details
    employeeId: '',
    dateOfJoining: '',
    department: '',
    designation: '',
    employmentType: '',
    workLocation: '',
    reportingManager: '',
    probationPeriod: '',
    confirmationDate: '',
    shift: '',
    weekOff: [],
    // Salary Details
    grade: '',
    ctc: '',
    paymentMode: '',
    effectiveFrom: '',
    // Bank Details
    bankName: '',
    accountHolderName: '',
    accountNumber: '',
    ifscCode: '',
    branchName: '',
    // Statutory Details
    pfNumber: '',
    esiNumber: '',
    aadhaarNumber: '',
    panNumber: '',
    incomeTaxDeclaration: '',
    previousEmployment: '',

    // Basic Info (for User model)
    name: '',
    password: '',
    role: 'employee',
  });

  const weekOffOptions = [
    { value: 'Monday', label: 'Monday' },
    { value: 'Tuesday', label: 'Tuesday' },
    { value: 'Wednesday', label: 'Wednesday' },
    { value: 'Thursday', label: 'Thursday' },
    { value: 'Friday', label: 'Friday' },
    { value: 'Saturday', label: 'Saturday' },
    { value: 'Sunday', label: 'Sunday' },
  ];

  // Fetch departments on mount
  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const res = await api.get('/department', { params: { limit: 1000 } });
        setDepartments(res.data.departments || []);
      } catch (error) {
        console.error('Error fetching departments:', error);
        setErrorMessage('Failed to load departments. Please refresh the page.');
      }
    };
    fetchDepartments();
  }, []);

  // Fetch designations dynamically when department changes
  useEffect(() => {
    if (!formData.department) {
      setDesignations([]);
      return;
    }

    const fetchDesignations = async () => {
      try {
        let departmentId;
        try {
          const deptData = JSON.parse(formData.department);
          departmentId = deptData.id;
        } catch {
          departmentId = formData.department;
        }

        if (!departmentId) {
          setDesignations([]);
          return;
        }

        const res = await api.get('/designation', {
          params: { departmentId: departmentId, limit: 1000 },
        });
        setDesignations(res.data.designations || []);
      } catch (error) {
        console.error('Error fetching designations:', error);
        setDesignations([]);
        setErrorMessage('Failed to load designations for selected department.');
      }
    };

    fetchDesignations();
  }, [formData.department]);

  useEffect(() => {
    fetchPermissions();
    fetchReportingManagers();
    fetchGrades();
    fetchShifts();
  }, []);

  const fetchPermissions = async () => {
    try {
      const res = await api.get('/permissions');
      if (res.status === 200) {
        const data = res.data.permissions || [];

        // Group by module
        const grouped = data.reduce((acc, item) => {
          if (!acc[item.module]) acc[item.module] = [];
          acc[item.module].push(item);
          return acc;
        }, {});

        // Ensure Project permissions group exists in UI
        const projectModule = 'Project';
        const projectPermissions = [
          { module: projectModule, label: 'View', key: 'project.view', description: 'Browse and view all assigned projects and their details' },
          { module: projectModule, label: 'Add', key: 'project.create', description: 'Create new projects and define their scope' },
          { module: projectModule, label: 'Edit', key: 'project.edit', description: 'Modify project details, timelines, and settings' },
          { module: projectModule, label: 'Delete', key: 'project.delete', description: 'Permanently remove projects from the system' },
          { module: projectModule, label: 'Export', key: 'project.export', description: 'Download project data as CSV or Excel reports' },
          { module: projectModule, label: 'Manage Details', key: 'project.details', description: 'Update milestones, team members, and project settings' },
          { module: projectModule, label: 'View Value', key: 'project.value', description: 'See project contract value and financial info' },
          { module: projectModule, label: 'View Documents', key: 'project.documents', description: 'Access uploaded project files and documents' },
        ];
        if (!grouped[projectModule] || grouped[projectModule].length === 0) {
          grouped[projectModule] = projectPermissions;
        }

        const taskModule = 'Task';
        const taskPermissions = [
          { module: taskModule, label: 'View', key: 'task.view', description: 'View tasks assigned to the employee and team' },
          { module: taskModule, label: 'Create', key: 'task.create', description: 'Create new tasks and sub-tasks for projects' },
          { module: taskModule, label: 'Edit', key: 'task.edit', description: 'Update task details, status, and priority' },
          { module: taskModule, label: 'Delete', key: 'task.delete', description: 'Permanently remove tasks from the system' },
          { module: taskModule, label: 'Export', key: 'task.export', description: 'Download task data as CSV or Excel reports' },
          { module: taskModule, label: 'Assign', key: 'task.assign', description: 'Assign tasks to team members and set deadlines' },
        ];
        if (!grouped[taskModule] || grouped[taskModule].length === 0) {
          grouped[taskModule] = taskPermissions;
        }

        const leadModule = 'Lead';
        const leadPermissions = [
          { module: leadModule, label: 'View', key: 'lead.view', description: 'Browse and view assigned leads and their details' },
          { module: leadModule, label: 'Create', key: 'lead.create', description: 'Add new leads with contact and source info' },
          { module: leadModule, label: 'Edit', key: 'lead.edit', description: 'Update lead details, status, and follow-up info' },
          { module: leadModule, label: 'Delete', key: 'lead.delete', description: 'Permanently remove leads from the system' },
          { module: leadModule, label: 'Assign', key: 'lead.assign', description: 'Assign leads to team members for follow-up' },
          { module: leadModule, label: 'Import', key: 'lead.import', description: 'Bulk import leads from CSV or Excel files' },
          { module: leadModule, label: 'Export', key: 'lead.export', description: 'Download lead data as CSV or Excel reports' },
        ];
        if (!grouped[leadModule] || grouped[leadModule].length === 0) {
          grouped[leadModule] = leadPermissions;
        }

        const announcementModule = 'Announcement';
        const announcementPermissions = [
          { module: announcementModule, label: 'View', key: 'announcement.view', description: 'Read company-wide announcements and news' },
          { module: announcementModule, label: 'Create', key: 'announcement.create', description: 'Publish new announcements visible to the team' },
          { module: announcementModule, label: 'Delete', key: 'announcement.delete', description: 'Remove published announcements from the system' },
        ];
        if (!grouped[announcementModule] || grouped[announcementModule].length === 0) {
          grouped[announcementModule] = announcementPermissions;
        }

        const dashboardModule = 'Dashboard';
        const dashboardPermissions = [
          { module: dashboardModule, label: 'View', key: 'dashboard.view', description: 'Access to the main dashboard page' },
          { module: dashboardModule, label: 'Employee Profile', key: 'widget.profile_card', description: 'Shows employee\'s own profile card with photo, role & department info' },
          { module: dashboardModule, label: 'Attendance Control', key: 'widget.attendance_widget', description: 'Check-in/out controls and daily attendance tracking for the employee' },
          { module: dashboardModule, label: 'Notifications', key: 'widget.notifications_panel', description: 'Real-time alerts and notifications relevant to the employee' },
          { module: dashboardModule, label: 'Announcements', key: 'widget.announcements_widget', description: 'Company-wide announcements and news visible to the employee' },
          { module: dashboardModule, label: 'Activity Logs', key: 'widget.activity_logs', description: 'Recent system activities and audit trail for the employee' },
          { module: dashboardModule, label: 'Upcoming Birthdays', key: 'widget.upcoming_birthdays', description: 'Upcoming team member birthdays visible to the employee' },
          { module: dashboardModule, label: 'Task Summary Cards', key: 'widget.employee_task_summary', description: 'KPI cards showing employee\'s own project & task counts' },
          { module: dashboardModule, label: 'Leads Overview Chart', key: 'widget.leads_overview', description: 'Leads trend chart showing lead data relevant to the employee' },
          { module: dashboardModule, label: 'Project Status Chart', key: 'widget.project_status', description: 'Pie chart of project statuses the employee is involved in' },
          { module: dashboardModule, label: 'Workforce Overview', key: 'widget.workforce_overview', description: 'Department & designation breakdown of the workforce' },
          { module: dashboardModule, label: 'Today Priorities', key: 'widget.today_priorities_widget', description: 'Today\'s high-priority tasks assigned to the employee' },
          { module: dashboardModule, label: 'Task Board', key: 'widget.task_board_widget', description: 'Kanban board showing employee\'s tasks by status' },
          { module: dashboardModule, label: 'Employee Task Summary', key: 'widget.employee_task_summary', description: 'Detailed task summary with project and completion stats' },
          { module: dashboardModule, label: 'Task Status Distribution', key: 'widget.task_status_overview', description: 'Chart showing distribution of employee\'s tasks by status' },
        ];
        if (!grouped[dashboardModule] || grouped[dashboardModule].length === 0) {
          grouped[dashboardModule] = dashboardPermissions;
        }

        setPermissions(data);
        setGroupedPermissions(grouped);
      }
    } catch (error) {
      console.error('Error fetching permissions:', error);
      setErrorMessage('Failed to load permissions. Some features may not work properly.');
    }
  };

  const fetchReportingManagers = async () => {
    try {
      const res = await api.get('/hr/employees-for-reporting');

      if (res.status === 200) {
        setReportingManagers(res.data.employees || []);
      }
    } catch (error) {
      console.error('Error fetching reporting managers:', error);
      setErrorMessage('Failed to load reporting managers.');
    }
  };

  const fetchGrades = async () => {
    try {
      const res = await api.get('/grades', { params: { limit: 1000 } });
      if (res.status === 200) {
        setGrades(res.data || []);
      }
    } catch (error) {
      console.error('Error fetching grades:', error);
      setErrorMessage('Failed to load salary grades.');
    }
  };

  const fetchShifts = async () => {
    try {
      const res = await api.get('/shifts', { params: { limit: 1000 } });

      if (res.status === 200) {
        setShifts(res.data.shifts || []);
      }
    } catch (error) {
      console.error('Error fetching shifts:', error);
      setErrorMessage('Failed to load shifts.');
    }
  };

  const [selectedPermissions, setSelectedPermissions] = useState({});
  const [uploadedFiles, setUploadedFiles] = useState({});
  const [fileErrors, setFileErrors] = useState({});
  const [sameAsCurrentAddress, setSameAsCurrentAddress] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const steps = [
    { id: 1, label: 'Personal Details', required: true },
    { id: 2, label: 'Employment Details', required: true },
    { id: 3, label: 'Salary & Payroll', required: true },
    { id: 4, label: 'Bank Details', required: true },
    { id: 5, label: 'Statutory Compliance', required: false },
    { id: 6, label: 'Documents', required: false },
    // { id: 7, label: 'Attendance & Leave', required: false },
    { id: 7, label: 'Permissions', required: true },
  ];

  const handleInputChange = e => {
    const { name, value } = e.target;

    if (fieldErrors[name]) {
      setFieldErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }

    // Basic validation for specific fields
    if (name === 'email' && value) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(value)) {
        setErrorMessage('Please enter a valid email address');
      } else {
        setErrorMessage('');
      }
    }

    if (name === 'contactNumber' && value) {
      const phoneRegex = /^[0-9]{10}$/;
      if (!phoneRegex.test(value.replace(/\D/g, ''))) {
        setErrorMessage('Contact number should be 10 digits');
      } else {
        setErrorMessage('');
      }
    }

    if (name === 'ifscCode' || name === 'pfNumber') {
      const upperValue = value.toUpperCase();
      // const finalValue = sanitizeInput(upperValue);
      setFormData(prev => ({ ...prev, [name]: upperValue }));
      return;
    }

    if (name === 'panNumber') {
      const upperValuePAN = value.toUpperCase();
      // const finalValue = sanitizeInput(upperValue);
      setFormData(prev => ({ ...prev, [name]: upperValuePAN }));
      return;
    }

    // Don't sanitize dropdown values like bloodGroup, gender, etc.
    const noSanitizeFields = [
      'bloodGroup',
      'gender',
      'maritalStatus',
      'employmentType',
      'paymentMode',
      'department',
      'designation',
      'shiftDetails',
      'weekOff',
      'reportingManager',
    ];
    const finalValue = noSanitizeFields.includes(name) ? value : sanitizeInput(value);

    setFormData(prev => ({ ...prev, [name]: finalValue }));
  };

  const ErrorMessage = ({ field }) => {
    if (!fieldErrors[field]) return null;

    return (
      <div className="flex items-center gap-1.5 mt-2 ml-1 animate-in slide-in-from-top-1 duration-200">
        <div className="size-1.5 bg-danger rounded-full shadow-[0_0_8px_rgba(244,63,94,0.5)]" />
        <p className="text-[10px] font-black text-danger uppercase tracking-widest">
          {fieldErrors[field]}
        </p>
      </div>
    );
  };

  const handleSameAddressChange = e => {
    const checked = e.target.checked;
    setSameAsCurrentAddress(checked);
    if (checked) {
      setFormData(prev => ({ ...prev, permanentAddress: prev.currentAddress }));
    }
  };

  const handleProfileImageChange = e => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = e => {
        setProfileImage(e.target.result);
      };
      reader.readAsDataURL(file);
      setUploadedFiles(prev => ({ ...prev, profilePhoto: file }));
    }
  };

  const handleFileUpload = fieldName => e => {
    const file = e.target.files[0];
    if (file) {
      // Clear previous error
      setFileErrors(prev => ({ ...prev, [fieldName]: null }));

      // Check file size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        setFileErrors(prev => ({ ...prev, [fieldName]: 'File size must be less than 5MB' }));
        return;
      }

      // Check file format
      const allowedTypes = {
        panCard: ['.pdf', '.jpg', '.jpeg', '.png'],
        aadhaarCard: ['.pdf', '.jpg', '.jpeg', '.png'],
        photograph: ['.jpg', '.jpeg', '.png'],
        bankPassbook: ['.pdf', '.jpg', '.jpeg', '.png'],
        educationCertificates: ['.pdf', '.jpg', '.jpeg', '.png'],
        experienceLetter: ['.pdf', '.jpg', '.jpeg', '.png'],
        proofOfAddress: ['.pdf', '.jpg', '.jpeg', '.png'],
        proofOfDOB: ['.pdf', '.jpg', '.jpeg', '.png'],
        offerLetter: ['.pdf', '.jpg', '.jpeg', '.png'],
        incomeTaxDeclaration: ['.pdf', '.jpg', '.jpeg', '.png'],
      };

      const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
      const allowedExtensions = allowedTypes[fieldName] || ['.pdf', '.jpg', '.jpeg', '.png'];

      if (!allowedExtensions.includes(fileExtension)) {
        setFileErrors(prev => ({
          ...prev,
          [fieldName]: `Invalid file format. Allowed: ${allowedExtensions.join(', ')}`,
        }));
        return;
      }

      setUploadedFiles(prev => ({ ...prev, [fieldName]: file }));
    }
  };

  // const calculateGrossSalary = () => {
  //   const basic = parseFloat(formData.basicSalary) || 0;
  //   const conveyance = parseFloat(formData.conveyanceAllowance) || 0;
  //   const medical = parseFloat(formData.medicalAllowance) || 0;
  //   const special = parseFloat(formData.specialAllowance) || 0;
  //   return basic + conveyance + medical + special;
  // };

  // const calculateNetSalary = () => {
  //   const gross = calculateGrossSalary();
  //   const pf = parseFloat(formData.pfDeduction) || 0;
  //   const esi = parseFloat(formData.esiDeduction) || 0;
  //   const pt = parseFloat(formData.professionalTax) || 0;
  //   const it = parseFloat(formData.incomeTax) || 0;
  //   return gross - (pf + esi + pt + it);
  // };

  const handleCheckboxChange = (module, permissionKey) => {
    setSelectedPermissions(prev => ({
      ...prev,
      [module]: {
        ...prev[module],
        [permissionKey]: !prev[module]?.[permissionKey],
      },
    }));
  };

  // Format permissions for API
  const formatPermissions = () => {
    const selectedPerms = [];
    Object.keys(selectedPermissions).forEach(module => {
      Object.keys(selectedPermissions[module]).forEach(permKey => {
        if (selectedPermissions[module][permKey]) {
          selectedPerms.push(permKey);
        }
      });
    });
    return selectedPerms;
  };

  const [fieldErrors, setFieldErrors] = useState({});
  const specialCharRegex = new RegExp("[!@#$%^&*()_+=\\[\\]{};':\"\\\\|,.<>/?-]");
  // Validation for current step
  const validateCurrentStep = () => {
    const errors = {};

    switch (currentStep) {
      case 1:
        if (!formData.fullName?.trim()) errors.fullName = 'Full Name is required';
        if (!formData.dateOfBirth) errors.dateOfBirth = 'Date of Birth is required';
        if (!formData.gender) errors.gender = 'Gender is required';
        if (!formData.maritalStatus) errors.maritalStatus = 'Marital Status is required';
        if (!formData.fatherOrSpouseName?.trim()) errors.fatherOrSpouseName = 'Father/Spouse Name is required';
        if (!formData.contactNumber?.trim()) errors.contactNumber = 'Contact Number is required';
        if (!formData.email?.trim()) errors.email = 'Email is required';
        // if (!formData.currentAddress?.trim()) errors.currentAddress = 'Current Address is required';
        // if (!formData.permanentAddress?.trim()) errors.permanentAddress = 'Permanent Address is required';
        if (!formData.emergencyContactName?.trim()) errors.emergencyContactName = 'Emergency Contact Name is required';
        if (!formData.emergencyContactNumber?.trim()) errors.emergencyContactNumber = 'Emergency Contact Number is required';
        if (!formData.password?.trim()) errors.password = 'Password is required';
        else if (formData.password.length < 6) {
          errors.password = 'Password must be at least 6 characters long';
        } else if (!/[A-Z]/.test(formData.password)) {
          errors.password = 'Password must contain at least one uppercase letter (A-Z)';
        } else if (!/[a-z]/.test(formData.password)) {
          errors.password = 'Password must contain at least one lowercase letter (a-z)';
        } else if (!/\d/.test(formData.password)) {
          errors.password = 'Password must contain at least one number (0-9)';
        } else if (!specialCharRegex.test(formData.password)) {
          errors.password = 'Password must contain at least one special character (!@#$%^&* etc.)';
        }


        // Email format validation
        if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
          errors.email = 'Invalid email format';
        }
        break;

      case 2:
        if (!formData.employeeId?.trim()) errors.employeeId = 'Employee ID is required';
        if (!formData.dateOfJoining) errors.dateOfJoining = 'Date of Joining is required';
        if (!formData.department) errors.department = 'Department is required';
        if (!formData.designation) errors.designation = 'Designation is required';
        if (!formData.employmentType) errors.employmentType = 'Employment Type is required';
        if (!formData.workLocation?.trim()) errors.workLocation = 'Work Location is required';
        if (!formData.shift) errors.shift = 'Shift Details is required';
        break;

      case 3:
        if (!formData.grade) errors.grade = 'Grade is required';
        if (!formData.ctc) errors.ctc = 'CTC is required';
        // if (!formData.paymentMode) errors.paymentMode = 'Payment Mode is required';
        break;

      case 4:
        if (!formData.bankName?.trim()) errors.bankName = 'Bank Name is required';
        if (!formData.accountHolderName?.trim()) errors.accountHolderName = 'Account Holder Name is required';
        if (!formData.accountNumber?.trim()) errors.accountNumber = 'Account Number is required';
        if (!formData.ifscCode?.trim()) errors.ifscCode = 'IFSC Code is required';
        if (!formData.branchName?.trim()) errors.branchName = 'Branch Name is required';
        break;

      case 5:
        if (!formData.panNumber?.trim()) errors.panNumber = 'Pan Number is required';
        if (!formData.aadhaarNumber?.trim()) errors.aadhaarNumber = 'Aadhaar Number is required';
        break;

      case 7: {
        const hasPermissions = Object.values(selectedPermissions).some(module =>
          Object.values(module).some(perm => perm)
        );
        if (!hasPermissions) {
          errors.permissions = 'Please select at least one permission';
        }
        break;
      }

      default:
        break;
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const getFieldClassName = (fieldName, isTextarea = false) => {
    const baseClass = `${isTextarea ? 'p-5' : 'h-14 px-5'} w-full bg-default-50/50 dark:bg-default-100/20 border-2 border-default-200 dark:border-default-100 rounded-2xl text-[13px] font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all placeholder:text-default-400 placeholder:font-medium hover:border-default-300 dark:hover:border-default-200`;

    if (fieldErrors[fieldName]) {
      return `${baseClass} border-danger/50 focus:border-danger focus:ring-danger/10`;
    }

    return baseClass;
  };


  const nextStep = () => {
    if (validateCurrentStep()) {
      setFieldErrors({});
      setErrorMessage('');
      setCurrentStep(prev => Math.min(prev + 1, steps.length));
    } else {
      const firstError = Object.values(fieldErrors)[0];
      setErrorMessage(firstError);

      // Scroll to first error field
      setTimeout(() => {
        const firstErrorField = document.querySelector('.border-red-500');
        if (firstErrorField) {
          firstErrorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 100);
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const sanitizeInput = input => {
    if (typeof input !== 'string') return input;
    return input.replace(/[<>"'&]/g, match => {
      const entities = { '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#x27;', '&': '&amp;' };
      return entities[match];
    });
  };

  const selectStyles = {
    control: (base) => ({
      ...base,
      border: isDark ? '2px solid #374151' : '2px solid #e5e7eb',
      borderRadius: '1rem',
      minHeight: '56px',
      fontSize: '13px',
      fontWeight: '700',
      boxShadow: 'none',
      backgroundColor: isDark ? '#111827' : '#f9fafb80', // bg-default-50/50
      transition: 'all 0.3s ease',
      '&:hover': {
        borderColor: isDark ? '#4b5563' : '#d1d5db',
      },
      '&:focus-within': {
        borderColor: '#0061ff', // primary
        boxShadow: '0 0 0 4px rgba(0, 97, 255, 0.1)',
      },
    }),
    placeholder: (base) => ({
      ...base,
      color: isDark ? '#6b7280' : '#9ca3af',
      fontWeight: '500',
    }),
    singleValue: (base) => ({
      ...base,
      color: isDark ? '#f3f4f6' : '#111827',
    }),
    menu: (base) => ({
      ...base,
      backgroundColor: isDark ? '#1f2937' : '#ffffff',
      borderRadius: '1rem',
      border: isDark ? '1px solid #374151' : '1px solid #e5e7eb',
      zIndex: 50,
      overflow: 'hidden',
      boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)',
    }),
    option: (base, state) => ({
      ...base,
      fontSize: '13px',
      fontWeight: '600',
      padding: '10px 15px',
      backgroundColor: state.isSelected
        ? '#0061ff'
        : state.isFocused
          ? '#0061ff10'
          : 'transparent',
      color: state.isSelected
        ? '#ffffff'
        : state.isFocused
          ? '#0061ff'
          : '#4b5563',
      '@media (prefers-color-scheme: dark)': {
        color: state.isSelected
          ? '#ffffff'
          : state.isFocused
            ? '#0061ff'
            : '#94a3b8', // dark:text-default-400
      },
      ...(document.documentElement.classList.contains('dark') && {
        color: state.isSelected
          ? '#ffffff'
          : state.isFocused
            ? '#0061ff'
            : '#94a3b8',
      }),
      '&:active': {
        backgroundColor: '#0061ff20',
      },
    }),
    multiValue: (base) => ({
      ...base,
      backgroundColor: '#0061ff10',
      border: '1px solid #0061ff20',
      borderRadius: '0.5rem',
      padding: '2px 4px',
    }),
    multiValueLabel: (base) => ({
      ...base,
      color: '#0061ff',
      fontSize: '11px',
      fontWeight: '700',
      textTransform: 'uppercase',
      letterSpacing: '0.05em',
    }),
    multiValueRemove: (base) => ({
      ...base,
      color: '#0061ff',
      '&:hover': {
        backgroundColor: '#0061ff',
        color: '#ffffff',
      },
      borderRadius: '0.25rem',
      marginLeft: '4px',
      transition: 'all 0.2s ease',
    }),
    indicatorSeparator: () => ({
      display: 'none',
    }),
    dropdownIndicator: (base) => ({
      ...base,
      color: '#9ca3af',
      '&:hover': {
        color: '#0061ff',
      },
    }),
  };

  const handleWeekOffChange = (selectedOptions) => {
    setFormData(prev => ({
      ...prev,
      weekOff: selectedOptions || [] // React Select returns array of objects
    }));
  };

  const handleSubmit = async e => {
    e.preventDefault();

    // Only allow submission on the last step with explicit submit button click
    if (currentStep !== 7) {
      return; // Don't submit if not on last step
    }

    // if (!validateCurrentStep()) {
    //   setErrorMessage('Please complete all required steps before submitting.');
    //   return;
    // }

    // Final validation for permissions (only for admin)
    if (isAdmin) {
      const hasPermissions = Object.values(selectedPermissions).some(module =>
        Object.values(module).some(perm => perm)
      );
      if (!hasPermissions) {
        setErrorMessage('Please select at least one permission before submitting.');
        return;
      }
    }

    handleSubmitAction(false);
  };

  const handleSaveDraft = (e) => {
    e.preventDefault();
    handleSubmitAction(true);
  };

  const handleSubmitAction = async (isDraft = false) => {
    setLoading(true);
    setErrorMessage('');

    try {
      // Use provided employee ID
      const employeeId = formData.employeeId?.trim();

      // Only strictly validate required fields if NOT draft
      if (!isDraft) {
        if (!employeeId) {
          setErrorMessage('Employee ID is required');
          setLoading(false);
          return;
        }

        if (!formData.fullName?.trim()) {
          setErrorMessage('Full Name is required');
          setLoading(false);
          return;
        }

        if (!formData.email?.trim()) {
          setErrorMessage('Email is required');
          setLoading(false);
          return;
        }

        if (!formData.password?.trim()) {
          setErrorMessage('Password is required');
          setLoading(false);
          return;
        }
      } else {
        // For draft, at least name is needed
        if (!formData.fullName?.trim()) {
          setErrorMessage('Full Name is required to save draft');
          setLoading(false);
          return;
        }
      }

      // Prepare form data for file upload
      const submitData = new FormData();

      // Add draft status
      if (isDraft) {
        submitData.append('status', 'draft');
      }

      // Basic user info with sanitization
      submitData.append('name', sanitizeInput(formData.fullName || formData.name));
      submitData.append('email', sanitizeInput(formData.email));
      submitData.append('password', formData.password || '123456'); // Default for draft
      submitData.append('role', formData.role || 'employee');
      submitData.append('employeeId', sanitizeInput(employeeId) || `DRAFT-${Date.now()}`); // Temp ID for draft
      submitData.append('permissions', JSON.stringify(isAdmin ? formatPermissions() : []));

      // Employee Personal Details with sanitization
      submitData.append(
        'employeePersonal',
        JSON.stringify({
          fullName: sanitizeInput(formData.fullName),
          dateOfBirth: formData.dateOfBirth,
          gender: formData.gender,
          maritalStatus: formData.maritalStatus,
          fatherOrSpouseName: sanitizeInput(formData.fatherOrSpouseName),
          contactNumber: sanitizeInput(formData.contactNumber),
          emailAddress: sanitizeInput(formData.email),
          permanentAddress: sanitizeInput(formData.permanentAddress),
          currentAddress: sanitizeInput(formData.currentAddress),
          emergencyContact: {
            name: sanitizeInput(formData.emergencyContactName),
            number: sanitizeInput(formData.emergencyContactNumber),
          },
          // aadhaarNumber: sanitizeInput(formData.aadhaarNumber),
          // panNumber: sanitizeInput(formData.panNumber),
          bloodGroup: formData.bloodGroup,
        })
      );

      // Employment Details - Send objects with id and name
      const getDepartmentData = () => {
        const dept = departments.find(d => d._id === formData.department);
        return dept ? { id: dept._id, name: dept.name } : null;
      };

      const getDesignationData = () => {
        const desg = designations.find(d => d._id === formData.designation);
        return desg ? { id: desg._id, name: desg.name } : null;
      };

      const getReportingManagerData = () => {
        const manager = reportingManagers.find(m => m._id === formData.reportingManager);
        return manager
          ? {
            id: manager._id,
            name: manager.name,
            department: manager.department,
            designation: manager.designation,
          }
          : null;
      };

      const getShiftData = () => {
        const shift = shifts.find(s => s._id === formData.shift);
        return shift
          ? {
            id: shift._id,
            name: shift.name,
            startTime: shift.startTime,
            endTime: shift.endTime,
          }
          : null;
      };

      submitData.append(
        'employmentDetails',
        JSON.stringify({
          employeeId: employeeId,
          dateOfJoining: formData.dateOfJoining,
          department: getDepartmentData(),
          designation: getDesignationData(),
          employmentType: formData.employmentType,
          workLocation: formData.workLocation,
          reportingManager: getReportingManagerData(),
          probationPeriod: formData.probationPeriod,
          confirmationDate: formData.confirmationDate,
          shift: getShiftData(),
          weekOff: formData.weekOff.map(option => option.value),
        })
      );

      // Salary Details
      submitData.append(
        'salaryDetails',
        JSON.stringify({
          grade: formData.grade,
          ctc: parseFloat(formData.ctc) || 0,
          paymentMode: formData.paymentMode,
          effectiveFrom: formData.effectiveFrom || new Date().toISOString(),
        })
      );

      // Bank Details
      submitData.append(
        'bankDetails',
        JSON.stringify({
          bankName: formData.bankName,
          accountHolderName: formData.accountHolderName,
          accountNumber: formData.accountNumber,
          ifscCode: formData.ifscCode,
          branchName: formData.branchName,
        })
      );

      // Statutory Compliance
      submitData.append(
        'statutoryCompliance',
        JSON.stringify({
          pfNumber: formData.pfNumber,
          esiNumber: formData.esiNumber,
          panNumber: formData.panNumber,
          aadhaarNumber: formData.aadhaarNumber,
          incomeTaxDeclaration: formData.incomeTaxDeclaration,
          previousEmployment: formData.previousEmployment,
        })
      );

      // Append files - FIXED: Only append files that actually exist


      // Helper function to check if a file is valid
      const isValidFile = (file) => {
        return file && file instanceof File;
      };

      // Process uploaded files
      Object.keys(uploadedFiles).forEach(key => {
        const file = uploadedFiles[key];

        if (!file) {

          return;
        }

        // Handle educationCertificates specially (it might be an array)
        if (key === 'educationCertificates') {
          if (Array.isArray(file)) {
            const validFiles = file.filter(isValidFile);
            if (validFiles.length > 0) {
              validFiles.forEach(validFile => {
                submitData.append('educationCertificates', validFile);
              });
            }
          } else if (isValidFile(file)) {
            // Single file
            submitData.append('educationCertificates', file);
          }
        } else {
          // Handle other single file fields
          if (isValidFile(file)) {
            submitData.append(key, file);
          }
        }
      });

      // Log FormData contents for debugging
      // API call
      const response = await api.post('/hr/employees', submitData);

      if (response.status === 201 && response.data.success) {
        setErrorMessage('');

        // Close modal
        // document.getElementById('employeeAdd').classList.add('hidden');
        window.HSOverlay.close('#employeeAdd');
        // Reset form to initial state
        const initialFormData = {
          fullName: '',
          dateOfBirth: '',
          gender: '',
          maritalStatus: '',
          fatherOrSpouseName: '',
          contactNumber: '',
          email: '',
          currentAddress: '',
          permanentAddress: '',
          emergencyContactName: '',
          emergencyContactNumber: '',
          aadhaarNumber: '',
          panNumber: '',
          bloodGroup: '',
          employeeId: '',
          dateOfJoining: '',
          department: '',
          designation: '',
          employmentType: '',
          workLocation: '',
          reportingManager: '',
          probationPeriod: '',
          confirmationDate: '',
          shift: '',
          grade: '',
          ctc: '',
          paymentMode: '',
          effectiveFrom: '',
          bankName: '',
          accountHolderName: '',
          accountNumber: '',
          ifscCode: '',
          branchName: '',
          pfNumber: '',
          esiNumber: '',
          incomeTaxDeclaration: '',
          weekOff: [],

          name: '',
          password: '',
          role: 'employee',
        };

        setFormData(initialFormData);
        setProfileImage(img);
        setSelectedPermissions({});
        setUploadedFiles({});
        setFileErrors({});
        setErrorMessage('');
        setSameAsCurrentAddress(false);
        setCurrentStep(1);

        // Show success message
        const successMsg = isDraft ? 'Employee draft saved successfully!' : 'Employee created successfully!';
        setTimeout(() => {
          alert(successMsg);
        }, 100);

        // Call the callback to refresh employee list
        if (onEmployeeAdded) {
          onEmployeeAdded();
        }
      } else {
        const result = response.data;
        console.error('Error creating employee:', result);
        setErrorMessage(result?.message || 'Error creating employee');
      }
    } catch (error) {
      console.error('Error creating employee:', error);
      console.error('Error response:', error?.response);
      console.error('Error data:', error?.response?.data);

      let errorMsg = 'Error creating employee. Please try again.';

      if (error?.response?.data?.message) {
        errorMsg = error.response.data.message;
      } else if (error?.response?.status === 500) {
        errorMsg = 'Server error. Please check all required fields and try again.';
      } else if (error?.message) {
        errorMsg = error.message;
      }

      setErrorMessage(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  // Step progress indicator
  const StepProgress = () => (
    <div className="mb-12">
      <div className="flex items-center justify-between relative px-4">
        {/* Background Line */}
        <div className="absolute top-[18px] left-0 right-0 h-[2px] bg-default-100 dark:bg-default-100/50 -z-10 mx-12" />

        {steps.map((step) => (
          <div key={step.id} className="flex flex-col items-center gap-3 group relative">
            <div
              className={`size-9 flex items-center justify-center rounded-2xl font-black text-[11px] transition-all duration-500 z-10 ${currentStep >= step.id
                ? 'bg-primary text-white scale-110 shadow-lg shadow-primary/25'
                : 'bg-white dark:bg-default-50 border-2 border-default-200 dark:border-default-100 text-default-400 dark:text-default-500 group-hover:border-primary/30 group-hover:text-primary group-hover:scale-105'
                }`}
            >
              {currentStep > step.id ? <LuCheck className="size-5" /> : step.id}
            </div>
            <span
              className={`text-[9px] font-black uppercase tracking-[0.15em] transition-all duration-300 absolute -bottom-6 whitespace-nowrap ${currentStep === step.id ? 'text-primary' : 'text-default-400 dark:text-default-500 group-hover:text-default-600 dark:group-hover:text-default-300'
                }`}
            >
              {step.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );



  return (
    <div
      id="employeeAdd"
      className="hs-overlay hidden size-full fixed top-0 start-0 z-[100] overflow-x-hidden overflow-y-auto pointer-events-none"
      role="dialog"
      tabIndex={-1}
      aria-labelledby="employeeAddlabel"
    >
      <div
        className="hs-overlay-animation-target hs-overlay-open:scale-100 hs-overlay-open:opacity-100 
        scale-95 opacity-0 ease-in-out transition-all duration-200 max-w-4xl w-full m-3 mx-auto 
        min-h-[calc(100%-56px)] flex items-center"
      >
        <form
          onSubmit={handleSubmit}
          className="w-full flex flex-col bg-white dark:bg-default-50 rounded-[2rem] border border-default-200 dark:border-default-100 overflow-hidden pointer-events-auto shadow-2xl"
        >
          {/* Header */}
          <div className="px-10 py-8 border-b border-default-100 dark:border-default-100 flex items-center justify-between bg-white/80 dark:bg-default-50/80 sticky top-0 z-20 backdrop-blur-md">
            <div className="flex flex-col gap-1.5">
              <h3 id="employeeAddlabel" className="text-2xl font-black text-default-900 dark:text-default-100 uppercase tracking-tight">
                Add Employee Details
              </h3>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-primary/10 rounded-full">
                  <div className="size-1.5 bg-primary rounded-full animate-pulse" />
                  <p className="text-[10px] font-black text-primary uppercase tracking-widest">
                    Step {currentStep} of {steps.length}
                  </p>
                </div>
                <p className="text-[10px] font-bold text-default-400 dark:text-default-500 uppercase tracking-widest">
                  {steps.find(s => s.id === currentStep)?.label}
                </p>
              </div>
            </div>
            <button
              type="button"
              className="size-11 flex items-center justify-center bg-default-50 dark:bg-default-100 text-default-400 dark:text-default-500 hover:text-danger hover:bg-danger/10 rounded-2xl transition-all active:scale-90 shadow-sm hover:shadow-md group"
              onClick={() => window.HSOverlay.close('#employeeAdd')}
              title="Close Modal"
            >
              <LuX className="size-5 group-hover:rotate-90 transition-transform duration-300" />
            </button>
          </div>

          <div className="p-10 overflow-y-auto max-h-[75vh]">
            {/* Step Progress */}
            <StepProgress />

            {/* Error Message */}
            {errorMessage && (
              <div className="mb-8 p-5 bg-danger/[0.03] dark:bg-danger/5 border-2 border-danger/10 dark:border-danger/20 rounded-[1.5rem] flex items-center gap-4 animate-in fade-in slide-in-from-top-2 duration-500 shadow-sm">
                <div className="size-10 bg-white dark:bg-default-50 rounded-2xl border border-danger/10 dark:border-danger/20 shadow-sm flex items-center justify-center text-danger">
                  <LuTriangleAlert className="size-5" />
                </div>
                <div className="flex flex-col gap-0.5">
                  <p className="text-[10px] font-black text-danger uppercase tracking-[0.15em]">Error Encountered</p>
                  <p className="text-[11px] font-bold text-default-600 dark:text-default-400 uppercase tracking-tight">{errorMessage}</p>
                </div>
              </div>
            )}

            {/* Step Content */}
            <div className="space-y-10">
              <div className="flex items-center gap-4">
                <div className="h-px flex-1 bg-gradient-to-r from-transparent via-default-200 dark:via-default-100 to-transparent"></div>
                <h4 className="text-[11px] font-black text-primary flex items-center gap-3 uppercase tracking-[0.25em]">
                  <span className="size-1.5 rounded-full bg-primary animate-pulse"></span>
                  {steps.find(s => s.id === currentStep)?.label}
                </h4>
                <div className="h-px flex-1 bg-gradient-to-r from-transparent via-default-200 dark:via-default-100 to-transparent"></div>
              </div>

              <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
                {/* Step 1: Personal Details */}
                {currentStep === 1 && (
                  <>
                    {/* Profile Image */}
                    <div className="lg:col-span-12 flex justify-center mb-6">
                      <div className="relative mx-auto rounded-full size-24 bg-default-200 dark:bg-default-100">
                        <img
                          src={profileImage}
                          alt="Profile"
                          className="object-cover w-full h-full rounded-full user-profile-image"
                        />
                        <div className="absolute bottom-0 right-0 flex items-center justify-center rounded-full size-8 bg-default-50 dark:bg-default-100 cursor-pointer border border-default-200 dark:border-default-200">
                          <input
                            id="profile-img-file-input"
                            name="profile-img-file-input"
                            type="file"
                            className="hidden"
                            accept=".jpg,.jpeg,.png"
                            onChange={handleProfileImageChange}
                          />
                          <label
                            htmlFor="profile-img-file-input"
                            className="flex items-center justify-center w-full h-full rounded-full cursor-pointer"
                          >
                            <LuImagePlus className="size-4 text-default-400" />
                          </label>
                        </div>
                      </div>
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Full Name (as per PAN/Aadhaar) *" />
                      <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        placeholder="Enter Full Name"
                        onKeyPress={(e) => {
                          if (!/[a-zA-Z]/.test(e.key) && e.key !== ' ' && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        className={getFieldClassName('fullName')}
                        required
                      />
                      <ErrorMessage field="fullName" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Date of Birth *" />
                      <input
                        type="date"
                        name="dateOfBirth"
                        value={formData.dateOfBirth}
                        onChange={handleInputChange}
                        className={getFieldClassName('dateOfBirth')}
                        // className="form-input"
                        required
                        max={new Date().toISOString().split('T')[0]} // 👈 restricts future dates
                      />
                      <ErrorMessage field="dateOfBirth" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Gender *" />
                      <select
                        name="gender"
                        value={formData.gender}
                        onChange={handleInputChange}
                        className={getFieldClassName('gender')}
                        required
                      >
                        <option value="">Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                      </select>
                      <ErrorMessage field="gender" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Marital Status *" />
                      <select
                        name="maritalStatus"
                        value={formData.maritalStatus}
                        onChange={handleInputChange}
                        className={getFieldClassName('maritalStatus')}
                        required
                      >
                        <option value="">Select Marital Status</option>
                        <option value="Single">Single</option>
                        <option value="Married">Married</option>
                      </select>
                      <ErrorMessage field="maritalStatus" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Father's / Spouse's Name *" />
                      <input
                        type="text"
                        name="fatherOrSpouseName"
                        value={formData.fatherOrSpouseName}
                        onKeyPress={(e) => {
                          if (!/[a-zA-Z]/.test(e.key) && e.key !== ' ' && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        onChange={handleInputChange}
                        placeholder="Enter Name"
                        className={getFieldClassName('fatherOrSpouseName')}
                        required
                      />
                      <ErrorMessage field="fatherOrSpouseName" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Contact Number *" />
                      <input
                        type="tel"
                        name="contactNumber"
                        value={formData.contactNumber}
                        onChange={handleInputChange}
                        placeholder="Enter Contact Number"
                        onKeyPress={(e) => {
                          const key = e.key;

                          // Allow only digits
                          if (!/[0-9]/.test(key)) {
                            e.preventDefault();
                          }

                          // If first digit typed, it must be 6,7,8,9
                          if (e.target.value.length === 0 && !/[6-9]/.test(key)) {
                            e.preventDefault();
                          }
                        }}
                        maxLength={10}

                        className={getFieldClassName('contactNumber')}
                        required
                      />
                      <ErrorMessage field="contactNumber" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Email Address *" />
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="Enter Email"
                        className={getFieldClassName('email')}
                        required
                      />
                      <ErrorMessage field="email" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Emergency Contact Name *" />
                      <input
                        type="text"
                        name="emergencyContactName"
                        value={formData.emergencyContactName}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          if (!/[a-zA-Z]/.test(e.key) && e.key !== ' ' && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}

                        placeholder="Enter Emergency Contact Name"
                        className={getFieldClassName('emergencyContactName')}
                        required
                      />
                      <ErrorMessage field="emergencyContactName" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Emergency Contact Number *" />
                      <input
                        type="tel"
                        name="emergencyContactNumber"
                        value={formData.emergencyContactNumber}
                        onKeyPress={(e) => {
                          const key = e.key;

                          // Allow only digits
                          if (!/[0-9]/.test(key)) {
                            e.preventDefault();
                          }

                          // If first digit typed, it must be 6,7,8,9
                          if (e.target.value.length === 0 && !/[6-9]/.test(key)) {
                            e.preventDefault();
                          }
                        }}
                        maxLength={10}

                        onChange={handleInputChange}
                        placeholder="Enter Emergency Contact Number"
                        className={getFieldClassName('emergencyContactNumber')}

                        required
                      />
                      <ErrorMessage field="emergencyContactNumber" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Blood Group" />
                      <select
                        name="bloodGroup"
                        value={formData.bloodGroup}
                        onChange={handleInputChange}
                        className={getFieldClassName('bloodGroup')}
                      >
                        <option value="">Select Blood Group</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                      </select>
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Password *" />
                      <div className="relative">
                        <input
                          type={showPassword ? "text" : "password"}
                          name="password"
                          value={formData.password}
                          onChange={handleInputChange}
                          placeholder="Enter Password"
                          className={getFieldClassName('password')}
                          required
                        />
                        <ErrorMessage field="password" />

                        <button
                          type="button"
                          className="absolute right-4 top-1/2 -translate-y-1/2 text-default-400 hover:text-primary transition-colors"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? (
                            <FaEyeSlash className="size-5" />
                          ) : (
                            <FaEye className="size-5" />
                          )}
                        </button>
                      </div>
                    </div>

                    <div className="lg:col-span-12">
                      <Label text="Current Address *" />
                      <textarea
                        name="currentAddress"
                        value={formData.currentAddress}
                        onChange={handleInputChange}
                        placeholder="Enter Current Address"
                        className={getFieldClassName('currentAddress', true)}
                        rows="3"
                        required
                      />
                    </div>

                    <div className="lg:col-span-12">
                      <Label text="Permanent Address *" />
                      <div className="mb-3 ml-1">
                        <label className="inline-flex items-center gap-2 cursor-pointer group">
                          <input
                            id="checkbox-1"
                            type="checkbox"
                            checked={sameAsCurrentAddress}
                            onChange={handleSameAddressChange}
                            className="size-4 rounded border-default-300 dark:border-default-200 text-primary focus:ring-primary/20 cursor-pointer transition-all bg-white dark:bg-default-50"
                          />
                          <span className="text-[10px] font-black text-default-600 dark:text-default-400 uppercase tracking-widest group-hover:text-primary transition-colors">Same as current address</span>
                        </label>
                      </div>
                      <textarea
                        name="permanentAddress"
                        value={formData.permanentAddress}
                        onChange={handleInputChange}
                        placeholder="Enter Permanent Address"
                        className={getFieldClassName('permanentAddress', true)}
                        rows="3"
                        required
                        disabled={sameAsCurrentAddress}
                      />
                    </div>

                    {/* <div className="lg:col-span-6">
                    <Label text="Aadhaar Number *" />
                    <input
                      type="text"
                      name="aadhaarNumber"
                      value={formData.aadhaarNumber}
                      onChange={handleInputChange}
                      placeholder="Enter Aadhaar Number"
                      className="form-input"
                      required
                    />
                  </div>

                  <div className="lg:col-span-6">
                    <Label text="PAN Number *" />
                    <input
                      type="text"
                      name="panNumber"
                      value={formData.panNumber}
                      onChange={handleInputChange}
                      placeholder="Enter PAN Number"
                      className="form-input"
                      required
                    />
                  </div> */}


                  </>
                )}

                {/* Step 2: Employment Details */}
                {currentStep === 2 && (
                  <>
                    <div className="lg:col-span-6">
                      <Label text="Employee ID *" />
                      <input
                        type="text"
                        name="employeeId"
                        value={formData.employeeId}
                        onChange={handleInputChange}
                        placeholder="Enter Employee ID"
                        className={getFieldClassName('employeeId')}

                        required
                      />
                      <ErrorMessage field="employeeId" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Date of Joining *" />
                      <input
                        type="date"
                        name="dateOfJoining"
                        value={formData.dateOfJoining}
                        onChange={handleInputChange}
                        className={getFieldClassName('dateOfJoining')}

                        required
                      />
                      <ErrorMessage field="dateOfJoining" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Department *" />
                      <select
                        name="department"
                        value={formData.department}
                        onChange={handleInputChange}
                        // className="form-input"
                        className={getFieldClassName('department')}

                        required
                      >
                        <option value="">Select Department</option>
                        {departments.map(dept => (
                          <option key={dept._id} value={dept._id}>
                            {dept.name}
                          </option>
                        ))}
                      </select>
                      <ErrorMessage field="department" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Designation / Job Title *" />
                      <select
                        name="designation"
                        value={formData.designation}
                        onChange={handleInputChange}
                        // className="form-input"
                        className={getFieldClassName('designation')}

                        required
                      >
                        <option value="">Select Designation</option>
                        {designations.map(desg => (
                          <option key={desg._id} value={desg._id}>
                            {desg.name}
                          </option>
                        ))}
                      </select>
                      <ErrorMessage field="designation" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Employment Type *" />
                      <select
                        name="employmentType"
                        value={formData.employmentType}
                        onChange={handleInputChange}
                        // className="form-input"
                        className={getFieldClassName('employmentType')}

                        required
                      >
                        <option value="">Select Employment Type</option>
                        <option value="Permanent">Permanent</option>
                        <option value="Contract">Contract</option>
                        <option value="Part-time">Part-time</option>
                        <option value="Internship">Internship</option>
                      </select>
                      <ErrorMessage field="employmentType" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Work Location / Branch *" />
                      <input
                        type="text"
                        name="workLocation"
                        value={formData.workLocation}
                        onChange={handleInputChange}
                        placeholder="Enter Work Location"
                        // className="form-input"
                        className={getFieldClassName('workLocation')}

                        required
                      />
                      <ErrorMessage field="workLocation" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Reporting Manager" />
                      <select
                        name="reportingManager"
                        value={formData.reportingManager}
                        onChange={handleInputChange}
                        className={getFieldClassName('reportingManager')}
                      >
                        <option value="">Select Reporting Manager</option>
                        {reportingManagers.map(manager => (
                          <option key={manager._id} value={manager._id}>
                            {manager.name} ({manager.department}) ({manager.designation})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Probation Period" />
                      <select
                        name="probationPeriod"
                        value={formData.probationPeriod}
                        onChange={handleInputChange}
                        className={getFieldClassName('probationPeriod')}
                      >
                        <option value="">Select Option</option>
                        <option value="3 months">3 months</option>
                        <option value="6 months">6 months</option>
                        <option value="No">No Probation</option>
                      </select>
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Confirmation Date" />
                      <input
                        type="date"
                        name="confirmationDate"
                        value={formData.confirmationDate}
                        onChange={handleInputChange}
                        className={getFieldClassName('confirmationDate')}
                      />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Office Timings / Shift Details *" />
                      <select
                        name="shift"
                        value={formData.shift}
                        onChange={handleInputChange}
                        // className="form-input"
                        className={getFieldClassName('shift')}

                        required
                      >
                        <option value="">Select Shift</option>
                        {shifts.map(shift => (
                          <option key={shift._id} value={shift._id}>
                            {shift.name} ({shift.startTime} - {shift.endTime})
                          </option>
                        ))}
                      </select>
                      <ErrorMessage field="shift" />
                    </div>

                    <div className="lg:col-span-6">
                      <Label text="Week Off (Select multiple)" />
                      <Select
                        options={weekOffOptions}
                        value={formData.weekOff}
                        onChange={handleWeekOffChange}
                        isMulti
                        styles={selectStyles}
                        className="react-select-container"
                        classNamePrefix="react-select"
                        placeholder="Select days..."
                        closeMenuOnSelect={false}
                      />
                    </div>
                  </>
                )}

                {/* Step 3: Salary & Payroll */}
                {currentStep === 3 && (
                  <>
                    <div className="lg:col-span-6">
                      <Label text="Grade *" />
                      <select
                        name="grade"
                        value={formData.grade}
                        onChange={handleInputChange}
                        // className="form-input"
                        className={getFieldClassName('grade')}

                        required
                      >
                        <option value="">Select Grade</option>
                        {grades.map(grade => (
                          <option key={grade._id} value={grade._id}>
                            {grade.grade}
                          </option>
                        ))}
                      </select>
                      <ErrorMessage field="grade" />
                    </div>
                    <div className="lg:col-span-6">
                      <Label text="CTC (Cost to Company) *" />
                      <input
                        type="number"
                        name="ctc"
                        value={formData.ctc}
                        onChange={handleInputChange}
                        placeholder="Enter CTC Amount"
                        // className="form-input"
                        className={getFieldClassName('ctc')}

                        required
                      />
                      <ErrorMessage field="ctc" />
                    </div>
                    <div className="lg:col-span-6">
                      <Label text="Payment Mode " />
                      <select
                        name="paymentMode"
                        value={formData.paymentMode}
                        onChange={handleInputChange}
                        className={getFieldClassName('paymentMode')}
                        required
                      >
                        <option value="">Select Payment Mode</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                        <option value="Cheque">Cheque</option>
                        <option value="Cash">Cash</option>
                      </select>
                    </div>
                    <div className="lg:col-span-6">
                      <Label text="Effective From" />
                      <input
                        type="date"
                        name="effectiveFrom"
                        value={formData.effectiveFrom}
                        onChange={handleInputChange}
                        className={getFieldClassName('effectiveFrom')}
                      />
                    </div>
                  </>
                )}

                {/* Step 4: Bank Details */}
                {currentStep === 4 && (
                  <>
                    <div className="lg:col-span-6">
                      <Label text="Bank Name *" />
                      <input
                        type="text"
                        name="bankName"
                        value={formData.bankName}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          // Allow only letters (A-Z, a-z) and backspace
                          if (!/[a-zA-Z]/.test(e.key) && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        placeholder="Enter Bank Name"
                        // className="form-input"
                        className={getFieldClassName('bankName')}

                        required
                      />
                      <ErrorMessage field="bankName" />
                    </div>
                    <div className="lg:col-span-6">
                      <Label text="Account Holder Name *" />
                      <input
                        type="text"
                        name="accountHolderName"
                        value={formData.accountHolderName}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          // Allow only letters (A-Z, a-z) and backspace
                          if (!/[a-zA-Z]/.test(e.key) && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}

                        placeholder="Enter Account Holder Name"
                        // className="form-input"
                        className={getFieldClassName('accountHolderName')}
                        required
                      />
                      <ErrorMessage field="accountHolderName" />
                    </div>
                    <div className="lg:col-span-6">
                      <Label text="Account Number *" />
                      <input
                        type="text"
                        name="accountNumber"
                        pattern="[0-9]*"
                        value={formData.accountNumber}
                        onChange={handleInputChange}
                        placeholder="Enter Account Number"
                        onKeyPress={(e) => {
                          // Allow only numbers (0-9) and backspace
                          if (!/[0-9]/.test(e.key) && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        // className="form-input"
                        className={getFieldClassName('accountNumber')}

                        required
                      />
                      <ErrorMessage field="accountNumber" />
                    </div>
                    <div className="lg:col-span-6">
                      <Label text="IFSC Code *" />
                      <input
                        type="text"
                        name="ifscCode"
                        value={formData.ifscCode}
                        onChange={handleInputChange}
                        placeholder="Enter IFSC Code"
                        onKeyPress={(e) => {
                          // Allow only letters (A-Z, a-z) and backspace
                          if (!/[a-zA-Z0-9]/.test(e.key) && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}
                        // className="form-input" 
                        className={getFieldClassName('ifscCode')}

                        required
                      />
                      <ErrorMessage field="ifscCode" />
                    </div>
                    <div className="lg:col-span-6">
                      <Label text="Branch Name *" />
                      <input
                        type="text"
                        name="branchName"
                        value={formData.branchName}
                        onChange={handleInputChange}
                        placeholder="Enter Branch Name"
                        // className="form-input"
                        required
                        className={getFieldClassName('branchName')}

                      />
                      <ErrorMessage field="branchName" />
                    </div>
                  </>
                )}

                {/* Step 5: Statutory Compliance */}
                {currentStep === 5 && (
                  <>
                    <div className="lg:col-span-6">
                      <Label text="PF Number / UAN" />
                      <input
                        type="text"
                        name="pfNumber"
                        value={formData.pfNumber}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          // Allow only letters (A-Z, a-z) and backspace
                          if (!/[a-zA-Z0-9]/.test(e.key) && e.key !== 'Backspace' && e.key !== '/') {
                            e.preventDefault();
                          }
                        }}
                        placeholder="Enter PF Number"
                        className={getFieldClassName('pfNumber')}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <Label text="ESI Number" />
                      <input
                        type="text"
                        name="esiNumber"
                        value={formData.esiNumber}
                        pattern="[0-9]*"
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          // Allow only numbers (0-9) and backspace
                          if (!/[0-9]/.test(e.key) && e.key !== 'Backspace' && e.key !== '-') {
                            e.preventDefault();
                          }
                        }}
                        placeholder="Enter ESI Number"
                        className={getFieldClassName('esiNumber')}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <Label text="PAN Number (for TDS purposes)" />
                      <input
                        type="text"
                        name="panNumber"
                        value={formData.panNumber}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          if (!/[a-zA-Z0-9]/.test(e.key) && e.key !== 'Backspace') {
                            e.preventDefault();
                          }
                        }}

                        placeholder="Enter PAN Number"
                        // className="form-input"
                        className={getFieldClassName('panNumber')}

                        required
                      />
                      <ErrorMessage field="panNumber" />
                    </div>
                    <div className="lg:col-span-6">
                      <Label text="Aadhaar Number " />
                      <input
                        type="text"
                        name="aadhaarNumber"
                        value={formData.aadhaarNumber}
                        onChange={handleInputChange}
                        onKeyPress={(e) => {
                          if (!/[0-9]/.test(e.key) && e.key !== ' ') {
                            e.preventDefault();
                          }
                        }}
                        maxLength={14}
                        placeholder="Enter Aadhaar Number"
                        // className="form-input"
                        className={getFieldClassName('aadhaarNumber')}

                        required
                      />
                      <ErrorMessage field="aadhaarNumber" />
                    </div>
                    <div className="lg:col-span-6">
                      <FileUpload
                        label="Income Tax Declaration (Form 12BB)"
                        onFileChange={handleFileUpload('incomeTaxDeclaration')}
                        fileName={uploadedFiles.incomeTaxDeclaration?.name}
                        error={fileErrors.incomeTaxDeclaration}
                      />
                    </div>
                    <div className="lg:col-span-12">
                      <Label text="Previous Employment Details (if applicable, for tax computation)" />
                      <textarea
                        name="previousEmployment"
                        value={formData.previousEmployment}
                        onChange={handleInputChange}
                        placeholder="Enter previous employment details"
                        className={getFieldClassName('previousEmployment', true)}
                      />
                    </div>
                  </>
                )}

                {/* Step 6: Documents */}
                {currentStep === 6 && (
                  <>
                    <div className="lg:col-span-6">
                      <FileUpload
                        label="PAN Card Copy"
                        onFileChange={handleFileUpload('panCard')}
                        fileName={uploadedFiles.panCard?.name}
                        error={fileErrors.panCard}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <FileUpload
                        label="Aadhaar Card Copy"
                        onFileChange={handleFileUpload('aadhaarCard')}
                        fileName={uploadedFiles.aadhaarCard?.name}
                        error={fileErrors.aadhaarCard}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <FileUpload
                        label="Passport Photo"
                        accept=".jpg,.jpeg,.png"
                        onFileChange={handleFileUpload('photograph')}
                        fileName={uploadedFiles.photograph?.name}
                        error={fileErrors.photograph}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <FileUpload
                        label="Bank Passbook"
                        onFileChange={handleFileUpload('bankPassbook')}
                        fileName={uploadedFiles.bankPassbook?.name}
                        error={fileErrors.bankPassbook}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <FileUpload
                        label="Education Certificates"
                        onFileChange={handleFileUpload('educationCertificates')}
                        fileName={uploadedFiles.educationCertificates?.name}
                        error={fileErrors.educationCertificates}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <FileUpload
                        label="Experience Letter"
                        onFileChange={handleFileUpload('experienceLetter')}
                        fileName={uploadedFiles.experienceLetter?.name}
                        error={fileErrors.experienceLetter}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <FileUpload
                        label="Proof of Address"
                        onFileChange={handleFileUpload('proofOfAddress')}
                        fileName={uploadedFiles.proofOfAddress?.name}
                        error={fileErrors.proofOfAddress}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <FileUpload
                        label="Proof of Date of Birth"
                        onFileChange={handleFileUpload('proofOfDOB')}
                        fileName={uploadedFiles.proofOfDOB?.name}
                        error={fileErrors.proofOfDOB}
                      />
                    </div>
                    <div className="lg:col-span-6">
                      <FileUpload
                        label="Offer Letter"
                        onFileChange={handleFileUpload('offerLetter')}
                        fileName={uploadedFiles.offerLetter?.name}
                        error={fileErrors.offerLetter}
                      />
                    </div>
                  </>
                )}

                {/* Step 7: Attendance & Leave */}
                {/* {currentStep === 7 && (
                <>
                  <div className="lg:col-span-6">
                    <Label text="Leave Policy" />
                    <select
                      name="leaveEntitlement"
                      value={formData.leaveEntitlement}
                      onChange={handleInputChange}
                      className="form-input"
                    >
                      <option value="">Select Leave Policy</option>
                      <option value="Standard">Standard</option>
                      <option value="Flexible">Flexible</option>
                      <option value="Strict">Strict</option>
                    </select>
                  </div>
                  <div className="lg:col-span-6">
                    <Label text="Attendance ID" />
                    <input
                      type="text"
                      name="attendanceId"
                      value={formData.attendanceId}
                      onChange={handleInputChange}
                      placeholder="Enter Attendance ID"
                      className="form-input"
                    />
                  </div>
                  <div className="lg:col-span-6">
                    <Label text="Weekly Off" />
                    <select
                      name="weeklyOff"
                      value={formData.weeklyOff}
                      onChange={handleInputChange}
                      className="form-input"
                    >
                      <option value="">Select Weekly Off</option>
                      <option value="Sunday">Sunday</option>
                      <option value="Saturday">Saturday</option>
                      <option value="Friday">Friday</option>
                      <option value="Saturday-Sunday">Saturday-Sunday</option>
                    </select>
                  </div>
                  <div className="lg:col-span-6">
                    <Label text="Overtime Rules" />
                    <select
                      name="overtimeRules"
                      value={formData.overtimeRules}
                      onChange={handleInputChange}
                      className="form-input"
                    >
                      <option value="">Select Overtime Rules</option>
                      <option value="As per policy">As per policy</option>
                      <option value="Double pay">Double pay</option>
                      <option value="Compensatory off">Compensatory off</option>
                    </select>
                  </div>
                </>
              )} */}

                {/* Step 8: Permissions */}
                {currentStep === 7 && (
                  <div className="lg:col-span-12 space-y-8">
                    {/* System Role Selection */}
                    <div className="bg-default-50/50 dark:bg-default-100/10 rounded-3xl p-8 border border-default-200 dark:border-default-100 shadow-sm">
                      <div className="flex items-center gap-4 mb-6">
                        <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                          <LuShield className="size-6" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-default-900 dark:text-default-100">System Access</h3>
                          <p className="text-sm text-default-500">Define user role and basic account settings</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <Label text="User Role *" />
                          <select
                            name="role"
                            value={formData.role}
                            onChange={handleInputChange}
                            className={getFieldClassName('role')}
                            required
                          >
                            <option value="">Select Role</option>
                            <option value="Admin">Admin</option>
                            <option value="Manager">Manager</option>
                            <option value="Employee">Employee</option>
                            <option value="HR">HR</option>
                          </select>
                          <ErrorMessage field="role" />
                          <p className="text-[10px] text-default-400 mt-2 px-1">Role determines the primary access level and default module visibility.</p>
                        </div>
                      </div>
                    </div>

                    {/* Detailed Permissions */}
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="text-base font-bold text-default-900 dark:text-default-100">Module Permissions</h4>
                          <p className="text-sm text-default-500">Granular control over specific system capabilities</p>
                        </div>
                        {isAdmin && (
                          <div className="flex items-center gap-3 p-2 bg-amber-50 dark:bg-amber-500/10 rounded-xl border border-amber-100 dark:border-amber-500/20">
                            <LuTriangleAlert className="size-4 text-amber-500" />
                            <span className="text-[10px] font-bold text-amber-800 dark:text-amber-500 uppercase tracking-wider">Admin Override Active</span>
                          </div>
                        )}
                      </div>

                      {/* Jump to Module */}
                      <div className="relative group">
                        <Label text="Jump to Module" />
                        <Select
                          options={Object.keys(groupedPermissions).map(module => ({
                            value: module,
                            label: module
                          }))}
                          value={permissionSearch && Object.keys(groupedPermissions).includes(permissionSearch)
                            ? { value: permissionSearch, label: permissionSearch }
                            : null}
                          onChange={(opt) => setPermissionSearch(opt ? opt.value : '')}
                          isClearable
                          placeholder="Select Module..."
                          styles={selectStyles}
                          classNamePrefix="react-select"
                        />
                      </div>

                      <div className="space-y-4">
                        {Object.keys(groupedPermissions)
                          .filter(module => module.toLowerCase().includes(permissionSearch.toLowerCase()))
                          .map(module => (
                            <div key={module} className="bg-white dark:bg-default-50 rounded-2xl border border-default-200 dark:border-default-100 overflow-hidden hover:border-primary/20 transition-all duration-300 shadow-sm group">
                              <div className="px-6 py-4 bg-default-50/50 dark:bg-default-100/20 border-b border-default-100 dark:border-default-100 flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <div className="size-8 bg-white dark:bg-default-100 rounded-lg border border-default-200 dark:border-default-200 flex items-center justify-center text-default-600 dark:text-default-400 group-hover:text-primary group-hover:border-primary/30 transition-all">
                                    <LuShieldCheck className="size-4" />
                                  </div>
                                  <h5 className="font-bold text-default-800 dark:text-default-100 uppercase tracking-wide text-xs">{module}</h5>
                                </div>
                                <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-primary cursor-pointer hover:opacity-80">
                                  <input
                                    type="checkbox"
                                    className="size-4 rounded border-default-300 dark:border-default-200 text-primary focus:ring-primary/20 transition-all cursor-pointer"
                                    checked={groupedPermissions[module].every(perm => selectedPermissions[module]?.[perm.key])}
                                    onChange={e => {
                                      const checked = e.target.checked;
                                      const modulePermissions = {};
                                      groupedPermissions[module].forEach(perm => {
                                        modulePermissions[perm.key] = checked;
                                      });
                                      setSelectedPermissions(prev => ({
                                        ...prev,
                                        [module]: modulePermissions,
                                      }));
                                    }}
                                    disabled={!isAdmin}
                                  />
                                  Select All
                                </label>
                              </div>
                              <div className="p-6">
                                <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                                  {groupedPermissions[module].map(permission => {
                                    const isChecked = selectedPermissions[module]?.[permission.key] || false;
                                    return (
                                      <label
                                        key={permission.key}
                                        className={`flex flex-col gap-2 p-3 rounded-xl border transition-all cursor-pointer group/item
                                      ${isChecked
                                            ? 'bg-primary/5 border-primary/20 text-primary'
                                            : 'bg-white dark:bg-default-100 border-default-100 dark:border-default-200 text-default-600 dark:text-default-400 hover:border-default-300 dark:hover:border-default-300 hover:bg-default-50 dark:hover:bg-default-200'
                                          }`}
                                      >
                                        <div className="flex items-center gap-3">
                                          <div className={`size-5 rounded flex items-center justify-center transition-all shrink-0
                                        ${isChecked ? 'bg-primary text-white' : 'bg-default-100 dark:bg-default-200 text-transparent'}`}>
                                            <LuCheck className="size-3 stroke-[3]" />
                                          </div>
                                          <input
                                            type="checkbox"
                                            className="hidden"
                                            checked={isChecked}
                                            onChange={() => handleCheckboxChange(module, permission.key)}
                                            disabled={!isAdmin}
                                          />
                                          <span className="text-[11px] font-bold uppercase tracking-tight">{permission.label}</span>
                                        </div>
                                        {permission.description && (
                                          <p className="text-[10px] font-medium text-default-400 dark:text-default-500 leading-relaxed pl-8">{permission.description}</p>
                                        )}
                                      </label>
                                    );
                                  })}
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-default-100 dark:border-default-100 bg-default-50/50 dark:bg-default-50/80 flex items-center justify-between gap-3 sticky bottom-0 z-20 backdrop-blur-md">
            <div>
              {currentStep > 1 && (
                <button
                  type="button"
                  onClick={prevStep}
                  className="h-10 px-6 bg-white dark:bg-default-100 border border-default-200 dark:border-default-100 text-default-600 dark:text-default-400 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-default-50 dark:hover:bg-default-200 transition-all flex items-center gap-2 active:scale-95 shadow-sm"
                  disabled={loading}
                >
                  <LuArrowLeft className="size-4" />
                  Previous
                </button>
              )}
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                className="h-10 px-6 text-[10px] font-black text-default-500 dark:text-default-500 uppercase tracking-widest hover:bg-default-100 dark:hover:bg-default-100 rounded-xl transition-all active:scale-95"
                onClick={() => window.HSOverlay.close('#employeeAdd')}
                disabled={loading}
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleSaveDraft}
                className="h-10 px-6 text-[10px] font-black text-primary border border-primary/20 bg-primary/5 uppercase tracking-widest hover:bg-primary/10 rounded-xl transition-all active:scale-95"
                disabled={loading}
              >
                {loading ? 'Saving...' : 'Save Draft'}
              </button>

              {currentStep < steps.length ? (
                <button
                  type="button"
                  onClick={nextStep}
                  className="h-10 px-8 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all flex items-center gap-2 active:scale-95 shadow-lg shadow-primary/20"
                  disabled={loading}
                >
                  Next
                  <LuArrowRight className="size-4" />
                </button>
              ) : (
                <button
                  type="submit"
                  className="h-10 px-8 bg-success text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-success-600 transition-all active:scale-95 shadow-lg shadow-success/20"
                  disabled={loading}
                >
                  {loading ? 'Creating...' : 'Add Employee'}
                </button>
              )}
            </div>
          </div>
        </form>
      </div>


    </div>
  );
};

export default AddEmployeeData;
