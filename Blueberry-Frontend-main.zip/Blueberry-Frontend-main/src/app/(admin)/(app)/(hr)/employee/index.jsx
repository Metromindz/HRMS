// import PageBreadcrumb from '@/components/PageBreadcrumb';
// import PageMeta from '@/components/PageMeta';
// import EditEmployeeData from './components/EditEmployeeData';
// import AddEmployeeData from './components/AddEmployeeData';
// import EmployeeDelete from './components/EmployeeDelete';
// import EmployeeDetails from './components/EmployeeDetails';
// import EmployeeViewDetails from './components/EmployeeViewDetail';
// import { useEffect, useState } from 'react';
// import { useAuth } from '@/context/AuthContext';
// import api from '../../../../../config/api';

// const Index = () => {
//   const { hasPermission } = useAuth();
//   const [employees, setEmployees] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [pagination, setPagination] = useState({
//     total: 0,
//     currentPage: 1,
//     totalPages: 1,
//     limit: 10,
//   });


//   // Permission checks
//   const canCreate = hasPermission('employee.create');
//   const canEdit = hasPermission('employee.edit');
//   const canDelete = hasPermission('employee.delete');
//   const canView = hasPermission('employee.view');
//   const canViewOne = hasPermission('employee.view_one');
//   const canStatusChange = hasPermission('employee.status');
//   const canImport = hasPermission('employee.import');

//   // 👇 Fetch employees once on mount
//   useEffect(() => {
//     fetchEmployees();
//   }, []);

//   // 👇 Common function to fetch employees
//   const fetchEmployees = async (page = 1) => {
//     try {
//       setLoading(true);
//       const response = await api.get('/hr/employees', { params: { page, limit: 10 } });

//       if (response.data.success) {
//         setEmployees(response.data.employees);
//         setPagination(response.data.pagination);
//       }
//     } catch (error) {
//       console.error('Error fetching employees:', error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <>
//       <PageMeta title="Employee List" />
//       <main>
//         <EmployeeDetails
//           employees={employees}
//           loading={loading}
//           pagination={pagination}
//           fetchEmployees={fetchEmployees}
//           canCreate={canCreate}
//           canEdit={canEdit}
//           canDelete={canDelete}
//           canView={canView}
//           canViewOne={canViewOne}
//           canImport={canImport}
//           canStatusChange = {canStatusChange}
//         />
//       </main>
//       {canCreate && <AddEmployeeData onEmployeeAdded={fetchEmployees} />}
//       {canEdit && <EditEmployeeData onEmployeeUpdated={fetchEmployees} />}
//       {canDelete && <EmployeeDelete onEmployeeDeleted={fetchEmployees} />}
//       {canViewOne && <EmployeeViewDetails />}
//       {/* Modals will be rendered from EmployeeDetails component */}
//     </>
//   );
// };

// export default Index;


import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import EmployeeDetails from './components/EmployeeDetails';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import api from '../../../../../config/api';
import { LuUsers, LuUserCheck, LuUserX, LuUserMinus } from 'react-icons/lu';

const Index = () => {
  const { hasPermission } = useAuth();
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({
    total: 0,
    currentPage: 1,
    totalPages: 1,
    limit: 10,
  });

  const stats = useMemo(() => {
    const total = pagination.total || 0;
    const active = employees.filter(e => (e.status || e.employmentDetails?.employmentStatus) === 'active').length;
    const inactive = employees.filter(e => (e.status || e.employmentDetails?.employmentStatus) === 'inactive').length;
    const onLeave = employees.filter(e => (e.status || e.employmentDetails?.employmentStatus) === 'on_leave').length;
    return { total, active, inactive, onLeave };
  }, [employees, pagination.total]);

  // Permission checks
  const canCreate = hasPermission('employee.create');
  const canEdit = hasPermission('employee.edit');
  const canDelete = hasPermission('employee.delete');
  const canView = hasPermission('employee.view');
  const canViewOne = hasPermission('employee.view_one');
  const canStatusChange = hasPermission('employee.status');
  const canImport = hasPermission('employee.import');

  const fetchEmployees = useCallback(async (page = 1, search = '', department = '', designation = '') => {
    try {
      setLoading(true);
      const params = {
        page,
        limit: 10,
      };
      if (search && search.trim() !== '') {
        params.search = search.trim();
      }
      if (department) params.department = department;
      if (designation) params.designation = designation;

      const response = await api.get('/hr/employees', { params });

      if (response.data.success) {
        setEmployees(response.data.employees);
        setPagination(response.data.pagination);
      }
    } catch (error) {
      console.error('Error fetching employees:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchEmployees();
  }, [fetchEmployees]);

  return (
    <>
      <PageMeta title="Employee List" />
      <main>
        <PageBreadcrumb title="Employees" subtitle="HR Management" />

        <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5 mb-6">
          <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                <LuUsers className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Total Employees</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.total}</div>
              </div>
            </div>
          </div>
          <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-success/10 flex items-center justify-center text-success group-hover:scale-110 transition-transform duration-300">
                <LuUserCheck className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Active</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.active}</div>
              </div>
            </div>
          </div>
          <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-danger/10 flex items-center justify-center text-danger group-hover:scale-110 transition-transform duration-300">
                <LuUserX className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Inactive</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.inactive}</div>
              </div>
            </div>
          </div>
          <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-warning/10 flex items-center justify-center text-warning group-hover:scale-110 transition-transform duration-300">
                <LuUserMinus className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">On Leave</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.onLeave}</div>
              </div>
            </div>
          </div>
        </div>

        <EmployeeDetails
          employees={employees}
          loading={loading}
          pagination={pagination}
          fetchEmployees={fetchEmployees}
          canCreate={canCreate}
          canEdit={canEdit}
          canDelete={canDelete}
          canView={canView}
          canViewOne={canViewOne}
          canImport={canImport}
          canStatusChange={canStatusChange}
        />
      </main>
      {/* Modals will be rendered from EmployeeDetails component */}
    </>
  );
};

export default Index;
