import { useCallback, useEffect, useRef, useState } from 'react';
import {
  LuChevronLeft,
  LuChevronRight,
  LuEye,
  LuPlus,
  LuSearch,
  LuSquarePen,
  LuTrash2,
  LuUpload,
  // LuLoader2,
  LuLoader,
  LuDownload,
  LuFileSpreadsheet,
  LuX,
  LuInfo,
  LuKey,
  LuUsers,
  LuCheck,
  LuClock
} from 'react-icons/lu';
import { Link } from 'react-router';
import api from '../../../../../../config/api';
import AddEmployeeData from './AddEmployeeData';
import EditEmployeeData from './EditEmployeeData';
import EmployeeDelete from './EmployeeDelete';

const statusConfig = {
  active: {
    label: 'Active',
    className: 'bg-emerald-50 text-emerald-600 border-emerald-100'
  },
  inactive: {
    label: 'Inactive',
    className: 'bg-slate-50 text-slate-600 border-slate-100'
  },
  probation: {
    label: 'Probation',
    className: 'bg-amber-50 text-amber-600 border-amber-100'
  },
  permanent: {
    label: 'Permanent',
    className: 'bg-blue-50 text-blue-600 border-blue-100'
  },
  contract: {
    label: 'Contract',
    className: 'bg-purple-50 text-purple-600 border-purple-100'
  },
  'notice period': {
    label: 'Notice Period',
    className: 'bg-orange-50 text-orange-600 border-orange-100'
  },
  resigned: {
    label: 'Resigned',
    className: 'bg-rose-50 text-rose-600 border-rose-100'
  },
  terminated: {
    label: 'Terminated',
    className: 'bg-red-50 text-red-600 border-red-100'
  }
};

const EmployeeDetails = ({
  employees: propEmployees,
  loading: propLoading,
  pagination: propPagination,
  fetchEmployees: propFetchEmployees,
  canCreate,
  canEdit,
  canDelete,
  canViewOne,
  canImport,
  canStatusChange,
}) => {
  const [employees, setEmployees] = useState(propEmployees || []);

  const [loading, setLoading] = useState(propLoading || true);
  const [pagination, setPagination] = useState(
    propPagination || {
      total: 0,
      currentPage: 1,
      totalPages: 1,
      limit: 10,
    }
  );
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [updatingStatus, setUpdatingStatus] = useState({});
  const [bulkUploading, setBulkUploading] = useState(false);
  const [showInstructionsModal, setShowInstructionsModal] = useState(false);
  const [uploadResult, setUploadResult] = useState(null);
  const [showResultModal, setShowResultModal] = useState(false);
  const [statusMenuOpen, setStatusMenuOpen] = useState(null);

  const [searchTerm, setSearchTerm] = useState('');
  const didInitSearchFetch = useRef(false);


  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const fetchEmployeesInternal = useCallback(async (page = 1, search = '') => {
    try {
      setLoading(true);
      const params = { page, limit: 10 };
      if (search && search.trim() !== '') params.search = search.trim();

      const response = await api.get('/hr/employees', { params });

      if (response.data.success) {
        setEmployees(response.data.employees);
        setPagination(response.data.pagination);
      }
    } catch (err) {
      console.error('Error fetching employees:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchEmployeesFn = propFetchEmployees || fetchEmployeesInternal;

  useEffect(() => {
    if (!didInitSearchFetch.current) {
      didInitSearchFetch.current = true;
      return;
    }
    const delayDebounce = setTimeout(() => {
      fetchEmployeesFn(1, searchTerm);
    }, 500);

    return () => clearTimeout(delayDebounce);
  }, [fetchEmployeesFn, searchTerm]);

  useEffect(() => {
    if (propEmployees) setEmployees(propEmployees);
    if (propLoading !== undefined) setLoading(propLoading);
    if (propPagination) setPagination(propPagination);
  }, [propEmployees, propLoading, propPagination]);

  useEffect(() => {
    if (!propFetchEmployees) {
      fetchEmployeesInternal();
    }
  }, [fetchEmployeesInternal, propFetchEmployees]);



  //  useEffect(() => {
  //    const delayDebounceFn = setTimeout(() => {
  //      if (searchTerm) {
  //        fetchEmployees(1,searchTerm);
  //      }
  //    }, 500); // 500ms delay

  //    return () => clearTimeout(delayDebounceFn);
  //  }, [searchTerm]);

  // Handle bulk upload file selection
  const handleBulkUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file type
    const validTypes = [
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.oasis.opendocument.spreadsheet'
    ];

    const fileExtension = file.name.split('.').pop().toLowerCase();
    const validExtensions = ['xls', 'xlsx', 'csv'];

    if (!validTypes.includes(file.type) && !validExtensions.includes(fileExtension)) {
      alert('Please upload only Excel files (.xls, .xlsx, .csv)');
      event.target.value = ''; // Reset file input
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('File size should be less than 5MB');
      event.target.value = '';
      return;
    }

    setBulkUploading(true);
    setUploadResult(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await api.post('/hr/bulk-upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (response.data.success) {
        setUploadResult({
          success: true,
          message: response.data.message,
          uploaded: response.data.uploaded,
          failed: response.data.failed,
          failedRecords: response.data.failedRecords,
          totalRows: response.data.totalRows,
        });

        // Refresh employee list after successful upload
        fetchEmployeesFn(pagination.currentPage);

        // Show result modal
        setShowInstructionsModal(false);
        setShowResultModal(true);

      } else {
        setUploadResult({
          success: false,
          message: response.data.message || 'Upload failed',
        });
      }
    } catch (error) {
      console.error('Bulk upload error:', error);
      setUploadResult({
        success: false,
        message: error.response?.data?.message || 'Upload failed. Please try again.',
      });
    } finally {
      setBulkUploading(false);
      event.target.value = ''; // Reset file input
    }
  };

  // Download template function
  const downloadTemplate = async () => {
    try {
      const response = await api.get('/hr/download-template', {
        responseType: 'blob',
      });

      // Create blob and download link
      const blob = new Blob([response.data], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'employee_upload_template.xlsx';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      setShowInstructionsModal(false);
    } catch (error) {
      console.error('Template download error:', error);
      alert('Failed to download template. Please try again.');
    }
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      fetchEmployeesFn(newPage, searchTerm);
    }
  };

  const formatDate = dateString => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  const getCurrentStatus = (employee) => {
    return (employee?.status ||
      employee?.employmentDetails?.employmentStatus ||
      employee?.employmentDetails?.status ||
      '').toLowerCase();
  };

  const handleStatusUpdate = async (employeeId, newStatus) => {


    if (!employeeId || !newStatus) {
      console.error('Employee ID and status are required');
      return;
    }

    const employee = employees.find(emp => emp._id === employeeId);


    if (!employee) {
      console.error('Employee not found in local state');
      return;
    }

    setUpdatingStatus(prev => ({ ...prev, [employee._id]: true }));

    try {
      const response = await api.put(`/hr/updateStatus?employeeId=${encodeURIComponent(employee.employeeId)}&status=${encodeURIComponent(newStatus)}`);

      if (response.data.success) {
        setEmployees(prev => prev.map(emp => {
          if (emp._id === employee._id) {
            return {
              ...emp,
              status: newStatus,
              employmentDetails: {
                ...emp.employmentDetails,
                employmentStatus: newStatus
              }
            };
          }
          return emp;
        }));


      }
    } catch (error) {
      console.error('Error updating employee status:', error);
      fetchEmployeesFn(pagination.currentPage);
    } finally {
      setUpdatingStatus(prev => ({ ...prev, [employee._id]: false }));
    }
  };

  // Function to trigger file input from instructions modal
  const triggerFileInput = () => {
    const fileInput = document.getElementById('bulkUploadInput');
    if (fileInput) {
      fileInput.click();
    }
  };



  if (loading) {
    return (
      <div className="bg-white border border-default-200 rounded-xl overflow-hidden shadow-sm">
        <div className="py-32 text-center">
          <div className="flex flex-col items-center justify-center gap-6">
            <div className="relative">
              <div className="size-16 border-4 border-primary/10 border-t-primary rounded-full animate-spin" />
              <div className="absolute inset-0 size-16 border-4 border-transparent border-b-primary/30 rounded-full animate-spin duration-1000" />
            </div>
            <div className="flex flex-col gap-1">
              <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em] animate-pulse">Synchronizing Data</p>
              <p className="text-xs font-bold text-default-400 uppercase tracking-widest">Fetching organization workforce...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-default-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-500 animate-in fade-in zoom-in-95 duration-700">
      <div className="p-8 flex flex-wrap items-center justify-between gap-6 border-b border-default-100 bg-white/50 backdrop-blur-md sticky top-0 z-20">
        <div className="flex items-center gap-4">
          <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary border border-primary/10">
            <LuUsers className="size-6" />
          </div>
          <div className="flex flex-col">
            <h4 className="text-2xl font-black text-default-900 uppercase tracking-tight leading-none mb-1">Employee Directory</h4>
            <p className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Manage and monitor organization workforce</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="relative group min-w-[320px]">
            <input
              type="text"
              className="h-12 w-full bg-default-50 border border-default-200 rounded-xl ps-12 pe-4 py-3 text-sm font-bold text-default-900 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all duration-300 placeholder:text-default-400 group-hover:bg-white group-hover:border-default-300"
              placeholder="Search by ID, Name or Email..."
              value={searchTerm}
              onChange={handleSearchChange}
            />
            <div className="absolute inset-y-0 start-0 flex items-center ps-4.5 text-default-400 group-focus-within:text-primary transition-colors">
              <LuSearch className="size-5" />
            </div>
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute inset-y-0 end-0 flex items-center pe-4 text-default-400 hover:text-danger transition-colors"
              >
                <LuX className="size-4" />
              </button>
            )}
          </div>

          <div className="h-8 w-px bg-default-200 mx-2 hidden lg:block" />

          <div className="flex items-center gap-3">
            {canImport && (
              <>
                <input
                  type="file"
                  id="bulkUploadInput"
                  accept=".csv,.xlsx,.xls"
                  className="hidden"
                  onChange={handleBulkUpload}
                  disabled={bulkUploading}
                />
                <button
                  onClick={() => setShowInstructionsModal(true)}
                  className="h-12 px-6 bg-white border border-default-200 text-default-700 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-default-50 hover:border-default-300 transition-all flex items-center gap-2.5 active:scale-95 disabled:opacity-50 shadow-sm"
                  disabled={bulkUploading}
                >
                  {bulkUploading ? (
                    <LuLoader className="size-4 animate-spin" />
                  ) : (
                    <LuUpload className="size-4" />
                  )}
                  Bulk Upload
                </button>
              </>
            )}

            {canCreate && (
              <button
                className="h-12 px-6 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 hover:shadow-lg hover:shadow-primary/25 transition-all flex items-center gap-2.5 active:scale-95"
                data-hs-overlay="#employeeAdd"
              >
                <LuPlus className="size-4" />
                Add Employee
              </button>
            )}
          </div>
        </div>
      </div>

      {showInstructionsModal && (
        <div className="fixed inset-0 bg-default-900/40 backdrop-blur-sm flex items-center justify-center z-[100] p-4 animate-in fade-in duration-300">
          <div className="relative bg-white rounded-3xl w-full max-w-md mx-auto overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="absolute inset-0 bg-default-900/40 backdrop-blur-sm -z-10" onClick={() => setShowInstructionsModal(false)} />
            <div className="p-8">
              {/* Header */}
              <div className="flex justify-between items-center mb-8">
                <div className="flex items-center gap-4">
                  <div className="size-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                    <LuFileSpreadsheet className="size-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">Bulk Upload</h3>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Follow these instructions</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowInstructionsModal(false)}
                  className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all"
                >
                  <LuX className="size-5" />
                </button>
              </div>

              {/* Instructions */}
              <div className="space-y-6 mb-8">
                <div className="flex items-start gap-4">
                  <div className="size-8 bg-blue-500/10 rounded-lg flex items-center justify-center text-blue-600 shrink-0">
                    <LuInfo className="size-4" />
                  </div>
                  <div>
                    <h4 className="text-[10px] font-black text-default-900 uppercase tracking-widest mb-1">File Formats</h4>
                    <p className="text-xs font-bold text-default-500">Upload Excel (.xls, .xlsx) or CSV (.csv) files only.</p>
                  </div>
                </div>

                <div className="p-5 bg-default-50 rounded-xl border border-default-100">
                  <h5 className="text-[10px] font-black text-default-900 uppercase tracking-widest mb-4 flex items-center gap-2">
                    <span className="size-1.5 bg-primary rounded-full" />
                    Requirements
                  </h5>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3 text-xs font-bold text-default-600">
                      <div className="size-1 bg-default-300 rounded-full" />
                      Maximum file size: 5MB
                    </li>
                    <li className="flex items-center gap-3 text-xs font-bold text-default-600">
                      <div className="size-1 bg-default-300 rounded-full" />
                      Use the provided template format
                    </li>
                    <li className="flex items-center gap-3 text-xs font-bold text-default-600">
                      <div className="size-1 bg-default-300 rounded-full" />
                      Required fields must be filled
                    </li>
                  </ul>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={downloadTemplate}
                  className="h-12 bg-default-100 text-default-700 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-default-200 transition-all flex items-center justify-center gap-2 active:scale-95"
                >
                  <LuDownload className="size-4" />
                  Template
                </button>
                <button
                  onClick={triggerFileInput}
                  className="h-12 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all flex items-center justify-center gap-2 active:scale-95"
                  disabled={bulkUploading}
                >
                  <LuUpload className="size-4" />
                  Upload
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showResultModal && uploadResult && (
        <div className="fixed inset-0 bg-default-900/40 backdrop-blur-sm flex items-center justify-center z-[100] p-4 animate-in fade-in duration-300">
          <div className="relative bg-white rounded-3xl w-full max-w-md mx-auto overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="absolute inset-0 bg-default-900/40 backdrop-blur-sm -z-10" onClick={() => setShowResultModal(false)} />
            <div className="p-8">
              <div className="flex justify-between items-center mb-8">
                <div className="flex items-center gap-4">
                  <div className={`size-12 rounded-xl flex items-center justify-center ring-8 ${uploadResult.success ? 'bg-success/10 text-success ring-success/5' : 'bg-danger/10 text-danger ring-danger/5'
                    }`}>
                    {uploadResult.success ? <LuFileSpreadsheet className="size-6" /> : <LuInfo className="size-6" />}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">
                      {uploadResult.success ? 'Upload Success' : 'Upload Failed'}
                    </h3>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Processing Results</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowResultModal(false)}
                  className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all"
                >
                  <LuX className="size-5" />
                </button>
              </div>

              <div className="space-y-6">
                <p className="text-xs font-bold text-default-600 leading-relaxed">{uploadResult.message}</p>

                {uploadResult.success && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-4 bg-default-50 rounded-xl border border-default-100 text-center">
                        <p className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Total</p>
                        <p className="text-lg font-black text-default-900">{uploadResult.totalRows}</p>
                      </div>
                      <div className="p-4 bg-success/5 rounded-xl border border-success/10 text-center">
                        <p className="text-[10px] font-black text-success uppercase tracking-widest mb-1">Success</p>
                        <p className="text-lg font-black text-success">{uploadResult.uploaded}</p>
                      </div>
                      <div className="p-4 bg-danger/5 rounded-xl border border-danger/10 text-center">
                        <p className="text-[10px] font-black text-danger uppercase tracking-widest mb-1">Failed</p>
                        <p className="text-lg font-black text-danger">{uploadResult.failed}</p>
                      </div>
                    </div>

                    {uploadResult.failed > 0 && uploadResult.failedRecords && (
                      <div className="mt-6">
                        <h4 className="text-[10px] font-black text-default-900 uppercase tracking-widest mb-3">Failed Records</h4>
                        <div className="max-h-48 overflow-y-auto rounded-xl border border-default-200 overflow-hidden">
                          <table className="min-w-full text-xs">
                            <thead className="bg-default-50">
                              <tr>
                                <th className="px-4 py-3 text-left font-black text-default-500 uppercase tracking-widest">Row</th>
                                <th className="px-4 py-3 text-left font-black text-default-500 uppercase tracking-widest">Reason</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-default-100">
                              {uploadResult.failedRecords.slice(0, 10).map((record, index) => (
                                <tr key={index} className="hover:bg-default-50/50 transition-colors">
                                  <td className="px-4 py-3 font-black text-default-700">#{record.row}</td>
                                  <td className="px-4 py-3 font-bold text-danger">{record.reason}</td>
                                </tr>
                              ))}
                              {uploadResult.failedRecords.length > 10 && (
                                <tr>
                                  <td colSpan="2" className="px-4 py-3 text-center font-bold text-default-400 text-[10px] uppercase tracking-widest">
                                    + {uploadResult.failedRecords.length - 10} more errors
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <div className="pt-6 border-t border-default-100">
                  <button
                    onClick={() => setShowResultModal(false)}
                    className="w-full h-12 bg-default-900 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-default-800 transition-all active:scale-95"
                  >
                    Close Result
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}


      <div className="overflow-x-auto custom-scroll">
        <table className="min-w-full border-separate border-spacing-0">
          <thead>
            <tr className="bg-default-50/50">
              <th className="py-5 px-8 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em] border-b border-default-100">Employee Profile</th>
              <th className="py-5 px-8 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em] border-b border-default-100">Identity</th>
              <th className="py-5 px-8 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em] border-b border-default-100">Organization</th>
              <th className="py-5 px-8 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em] border-b border-default-100">Onboarding</th>
              <th className="py-5 px-8 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em] border-b border-default-100">Type</th>
              <th className="py-5 px-8 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em] border-b border-default-100">Lifecycle</th>
              <th className="py-5 px-8 text-right text-[10px] font-black text-default-500 uppercase tracking-[0.2em] border-b border-default-100">Operations</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-default-100">
            {employees.length > 0 ? (
              employees.map((emp) => {
                const currentStatus = getCurrentStatus(emp);
                const isUpdating = updatingStatus[emp._id];

                return (
                  <tr key={emp._id} className="hover:bg-default-50/50 transition-all duration-300 group">
                    <td className="py-5 px-8">
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <div className="size-11 rounded-xl bg-primary/10 flex items-center justify-center text-primary font-black text-xs border border-primary/10 group-hover:scale-110 group-hover:rotate-3 transition-all duration-500 overflow-hidden">
                            {emp.employeePersonal?.profilePhoto ? (
                              <img
                                src={emp.employeePersonal.profilePhoto}
                                alt={emp.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              emp.name?.charAt(0) || 'E'
                            )}
                          </div>
                          <div className={`absolute -bottom-1 -right-1 size-3.5 rounded-full border-2 border-white ${currentStatus === 'active' ? 'bg-emerald-500' :
                              currentStatus === 'probation' ? 'bg-amber-500' :
                                currentStatus === 'permanent' ? 'bg-blue-500' :
                                  currentStatus === 'contract' ? 'bg-purple-500' :
                                    currentStatus === 'notice period' ? 'bg-orange-500' :
                                      currentStatus === 'inactive' ? 'bg-slate-500' :
                                        'bg-rose-500'
                            } shadow-sm`}></div>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-sm font-black text-default-900 uppercase tracking-tight group-hover:text-primary transition-colors">{emp.name}</span>
                          <span className="text-[10px] font-bold text-default-400 uppercase tracking-widest mt-0.5">{emp.email}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-5 px-8">
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-default-600 uppercase tracking-widest">{emp.employeeId}</span>
                        <span className="text-[9px] font-black text-default-400 uppercase tracking-[0.2em] mt-1">ID CARD</span>
                      </div>
                    </td>
                    <td className="py-5 px-8">
                      <div className="flex flex-col gap-1">
                        <span className="text-xs font-black text-default-900 uppercase tracking-tight">{emp.employmentDetails?.department?.name || 'N/A'}</span>
                        <div className="flex items-center gap-1.5">
                          <span className="w-1 h-1 rounded-full bg-default-300" />
                          <span className="text-[10px] font-bold text-default-400 uppercase tracking-widest">{emp.employmentDetails?.designation?.name || 'N/A'}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-5 px-8">
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-default-600 uppercase tracking-widest">{formatDate(emp.employmentDetails?.dateOfJoining)}</span>
                        <span className="text-[9px] font-black text-default-400 uppercase tracking-[0.2em] mt-1">JOINED</span>
                      </div>
                    </td>
                    <td className="py-5 px-8">
                      <span className="px-3 py-1.5 rounded-xl bg-default-100 text-default-600 text-[10px] font-black uppercase tracking-widest border border-default-200/50">
                        {emp.employmentDetails?.employmentType || 'N/A'}
                      </span>
                    </td>
                    <td className="py-5 px-8">
                      {canStatusChange ? (
                        <div className="relative inline-block">
                          <button
                            type="button"
                            className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all flex items-center gap-2 ${statusConfig[currentStatus]?.className || 'bg-default-100 text-default-600 border-default-200'
                              }`}
                            onClick={() => !isUpdating && setStatusMenuOpen(statusMenuOpen === emp._id ? null : emp._id)}
                          >
                            <span>{statusConfig[currentStatus]?.label || currentStatus}</span>
                            {!isUpdating && <LuClock className="size-3 opacity-50" />}
                            {isUpdating && <LuLoader className="size-3 animate-spin" />}
                          </button>
                          {statusMenuOpen === emp._id && (
                            <div className="absolute left-0 top-full mt-2 z-50 w-48 rounded-xl bg-white border border-default-200 p-2 animate-in fade-in slide-in-from-top-3 shadow-lg z-[100]">
                              {Object.keys(statusConfig).map((status) => (
                                <button
                                  key={status}
                                  type="button"
                                  className={`flex items-center justify-between w-full text-left px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${currentStatus === status
                                      ? 'bg-primary text-white'
                                      : 'text-default-600 hover:bg-default-100'
                                    }`}
                                  onClick={async () => {
                                    await handleStatusUpdate(emp._id, status);
                                    setStatusMenuOpen(null);
                                  }}
                                >
                                  {statusConfig[status].label}
                                  {currentStatus === status && <LuCheck className="size-3.5" />}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${statusConfig[currentStatus]?.className || 'bg-default-100 text-default-600 border-default-200'
                          }`}>
                          {statusConfig[currentStatus]?.label || currentStatus}
                        </span>
                      )}
                    </td>
                    <td className="py-5 px-8 text-right">
                      <div className="flex items-center justify-end gap-2.5">
                        {canEdit && (
                          <button
                            className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all duration-300 shadow-sm active:scale-90"
                            onClick={async () => {
                              try {
                                const resp = await api.post("/hr/employees/send-password-link", {
                                  id: emp._id,
                                });
                                alert(resp.data.message || "Password setup link sent");
                              } catch (err) {
                                alert(err?.response?.data?.message || "Failed to send link");
                              }
                            }}
                            title="Send Password Link"
                          >
                            <LuKey className="size-4" />
                          </button>
                        )}
                        {canViewOne && (
                          <Link
                            to={`/employee/${emp._id}`}
                            className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all duration-300 shadow-sm active:scale-90"
                            title="View Details"
                          >
                            <LuEye className="size-4" />
                          </Link>
                        )}
                        {canEdit && (
                          <button
                            className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all duration-300 shadow-sm active:scale-90"
                            data-hs-overlay="#employeeEdit"
                            onClick={() => setSelectedEmployee(emp)}
                            title="Edit Employee"
                          >
                            <LuSquarePen className="size-4" />
                          </button>
                        )}
                        {canDelete && (
                          <button
                            className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-danger hover:bg-danger hover:text-white hover:border-danger transition-all duration-300 shadow-sm active:scale-90"
                            data-hs-overlay="#employeeDelete"
                            onClick={() => setSelectedEmployee(emp)}
                            title="Delete Employee"
                          >
                            <LuTrash2 className="size-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan="7" className="py-32 text-center">
                  <div className="flex flex-col items-center justify-center gap-6 animate-in fade-in duration-700">
                    <div className="size-20 bg-default-50 rounded-xl flex items-center justify-center border border-default-100 relative">
                      <LuUsers className="size-10 text-default-200" />
                      <div className="absolute -bottom-1 -right-1 size-6 bg-white rounded-lg border border-default-100 flex items-center justify-center">
                        <LuSearch className="size-3 text-default-400" />
                      </div>
                    </div>
                    <div className="flex flex-col gap-1">
                      <p className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">No employees discovered</p>
                      <p className="text-xs font-bold text-default-300 uppercase tracking-widest">Try adjusting your search filters</p>
                    </div>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-between p-8 border-t border-default-100 bg-default-50/30 gap-6">
        <div className="flex items-center gap-3">
          <div className="size-8 rounded-xl bg-primary/10 flex items-center justify-center text-primary border border-primary/10">
            <LuInfo className="size-4" />
          </div>
          <div className="text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">
            {employees.length > 0 ? (
              <>
                Displaying <span className="text-default-900 font-black">{(pagination.currentPage - 1) * pagination.limit + 1}</span> — <span className="text-default-900 font-black">{Math.min(pagination.currentPage * pagination.limit, pagination.total)}</span> of <span className="text-default-900 font-black">{pagination.total}</span> organization records
              </>
            ) : (
              "No records found in database"
            )}
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center bg-white border border-default-200 rounded-[1.25rem] p-1.5 shadow-sm">
            <button
              type="button"
              className="size-10 flex items-center justify-center rounded-xl transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600 active:scale-90"
              disabled={pagination.currentPage === 1}
              onClick={() => handlePageChange(pagination.currentPage - 1)}
            >
              <LuChevronLeft className="size-5" />
            </button>
            <div className="w-px h-6 bg-default-200 mx-2" />
            <div className="flex items-center px-4">
              <span className="text-[10px] font-black text-default-900 uppercase tracking-widest">
                Page {pagination.currentPage} <span className="text-default-400 mx-1">/</span> {pagination.totalPages || 1}
              </span>
            </div>
            <div className="w-px h-6 bg-default-200 mx-2" />
            <button
              type="button"
              className="size-10 flex items-center justify-center rounded-xl transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600 active:scale-90"
              disabled={pagination.currentPage === pagination.totalPages || pagination.totalPages === 0}
              onClick={() => handlePageChange(pagination.currentPage + 1)}
            >
              <LuChevronRight className="size-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Modal Components */}
      <AddEmployeeData onEmployeeAdded={() => fetchEmployeesFn(pagination.currentPage)} />
      <EditEmployeeData
        employee={selectedEmployee}
        onEmployeeUpdated={() => fetchEmployeesFn(pagination.currentPage)}
      />
      <EmployeeDelete
        employee={selectedEmployee}
        onEmployeeDeleted={() => fetchEmployeesFn(pagination.currentPage)}
      />
    </div>
  );
};

export default EmployeeDetails;