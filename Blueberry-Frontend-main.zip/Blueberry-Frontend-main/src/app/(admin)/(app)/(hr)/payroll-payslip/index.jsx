import PageBreadcrumb from "@/components/PageBreadcrumb";
import PageMeta from "@/components/PageMeta";
import { LuArrowLeft, LuPrinter } from "react-icons/lu";
import { Link, useParams } from "react-router";
import { useState, useEffect } from "react";
import api from "../../../../../config/api.js";

const Index = () => {
  const { id, month } = useParams();

  // const [searchParams] = useSearchParams();
  // const month = searchParams.get('month');




  const [payslip, setPayslip] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchPayslip = async () => {
    try {
      setLoading(true);
      const response = await api.get(`/payslip/employee/${id}/${month}`);


      if (response.data.success && response.data.data.length > 0) {
        if (month) {
          // Filter payslips by month to find the specific one
          const filteredPayslips = response.data.data.filter(
            slip => slip.payrollMonth.toLowerCase() === month.toLowerCase()
          );

          if (filteredPayslips.length > 0) {
            setPayslip(filteredPayslips[0]); // Get the specific month's payslip
          } else {
            setError(`No payslip found for ${month}`);
          }
        } else {
          // If no month specified, get the first payslip (existing behavior)
          setPayslip(response.data.data[0]);
        }
      } else {
        setError('No payslips found for this employee');
      }
    } catch (err) {
      setError('Failed to fetch payslip details');
      console.error('Error fetching payslip:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) {
      fetchPayslip();
    }
  }, [id, month]);

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const formatCurrency = (amount) => {
    return `$${amount.toLocaleString()}`;
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <>
        <PageMeta title="Payslip" />
        <main>
          <PageBreadcrumb title="Payslip" subtitle="Menu" />
          <div className="container text-center py-10">
            <div className="text-default-500">Loading payslip...</div>
          </div>
        </main>
      </>
    );
  }

  if (error || !payslip) {
    return (
      <>
        <PageMeta title="Payslip" />
        <main>
          <PageBreadcrumb title="Payslip" subtitle="Menu" />
          <div className="container text-center py-10">
            <div className="text-red-500">{error || 'Payslip not found'}</div>
            <Link to="/payroll-employee-salary" className="h-10 px-6 text-[10px] font-black uppercase tracking-widest bg-primary text-white rounded-xl transition-all active:scale-95 inline-flex items-center mt-3">
              Go Back
            </Link>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <PageMeta title="Payslip" />
      <main className="">
        <PageBreadcrumb title="Payslip" subtitle="Menu" />

        <div className="flex justify-between mb-6 container">
          <Link to="/payroll-employee-salary" className="h-10 px-6 text-[10px] font-black uppercase tracking-widest bg-primary text-white rounded-xl transition-all active:scale-95 flex items-center gap-1">
            <LuArrowLeft className="size-4" /> Go Back
          </Link>

          <button
            className="h-10 px-6 text-[10px] font-black uppercase tracking-widest bg-success text-white rounded-xl transition-all active:scale-95 flex items-center gap-1"
            onClick={handlePrint}
          >
            <LuPrinter className="size-4" /> Print
          </button>
        </div>

        <div className="max-w-4xl mx-auto bg-white rounded-2xl overflow-hidden border border-gray-200 print:shadow-none print:border-none">
          <div className="p-8 print:p-6">
            {/* Payslip Header */}
            <div className="flex justify-between items-start border-b pb-6 mb-6 print:pb-4 print:mb-4">
              {/* Left — Static Company Info */}
              <div>
                <h2 className="text-xl font-bold text-gray-800">Metromindz Pvt Ltd</h2>
                <p className="text-sm text-gray-600">Bangalore, India</p>
                <p className="text-sm text-gray-600">Phone: +91 0123 456 7890</p>
                <p className="text-sm text-gray-600">Email: metromindz@gmail.com</p>
              </div>

              {/* Right — Payslip Month */}
              <div className="text-right">
                <p className="text-sm text-gray-500">Payslip For the Month</p>
                <h2 className="text-xl font-bold text-gray-800">
                  {payslip.payrollMonth} {payslip.payrollYear}
                </h2>
              </div>
            </div>

            {/* Employee Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3 text-sm">
              <p className="text-gray-500">
                <strong className="text-gray-800">Generated Date:</strong> {formatDate(payslip.createdAt)}
              </p>
              <p className="text-gray-500">
                <strong className="text-gray-800">Payslip Month:</strong> {payslip.payrollMonth}
              </p>
              <p className="text-gray-500">
                <strong className="text-gray-800">Employee ID:</strong> {payslip.employeeId}
              </p>
              <p className="text-gray-500">
                <strong className="text-gray-800">Employee Name:</strong> {payslip.employeeName}
              </p>
              <p className="text-gray-500">
                <strong className="text-gray-800">Designation:</strong> {payslip.designation}
              </p>
              <p className="text-gray-500">
                <strong className="text-gray-800">Department:</strong> {payslip.department}
              </p>
              <p className="text-gray-500">
                <strong className="text-gray-800">UAN No:</strong> {payslip.uanNo || 'N/A'}
              </p>
              <p className="text-gray-500">
                <strong className="text-gray-800">ESI No:</strong> {payslip.esiNo || 'N/A'}
              </p>
              <p className="text-gray-500">
                <strong className="text-gray-800">Aadhaar No:</strong> {payslip.aadhaarNo || 'N/A'}
              </p>
            </div>

            {/* Attendance */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3 mt-8 text-sm border-t pt-4">
              <p className="text-gray-500">
                <strong className="text-gray-800">No. of Working Days:</strong> {payslip.totalWorkingDays}
              </p>
              <p className="text-gray-500">
                <strong className="text-gray-800">LOP Days:</strong> {payslip.lopDays || 0}
              </p>
              <p className="text-gray-500">
                <strong className="text-gray-800">Days Worked:</strong> {payslip.daysWorked || (payslip.totalWorkingDays - (payslip.lopDays || 0))}
              </p>
            </div>

            {/* Salary Table */}
            <div className="mt-10 overflow-x-auto">
              <table className="min-w-full border border-gray-300 text-sm">
                <thead className="bg-gray-100 border-b border-gray-300">
                  <tr className="text-gray-800">
                    <th className="px-4 py-2 text-left">Earnings</th>
                    <th className="px-4 py-2 text-left">Amount</th>
                    <th className="px-4 py-2 text-left">Deductions</th>
                    <th className="px-4 py-2 text-left">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {/* Dynamic rows based on earnings and deductions */}
                  {Array.from({ length: Math.max(payslip.earnings?.length || 0, payslip.deductions?.length || 0) }).map((_, index) => (
                    <tr key={index}>
                      <td className="px-4 py-2">
                        {payslip.earnings?.[index]?.key || ''}
                      </td>
                      <td className="px-4 py-2">
                        {payslip.earnings?.[index] ? formatCurrency(payslip.earnings[index].value) : ''}
                      </td>
                      <td className="px-4 py-2">
                        {payslip.deductions?.[index]?.key || ''}
                      </td>
                      <td className="px-4 py-2">
                        {payslip.deductions?.[index] ? formatCurrency(payslip.deductions[index].value) : ''}
                      </td>
                    </tr>
                  ))}

                  <tr className="bg-gray-50 font-semibold">
                    <td className="px-4 py-2">Gross Earnings</td>
                    <td className="px-4 py-2">{formatCurrency(payslip.totalEarnings)}</td>
                    <td className="px-4 py-2">Total Deductions</td>
                    <td className="px-4 py-2">{formatCurrency(payslip.totalDeductions)}</td>
                  </tr>

                  <tr className="font-semibold">
                    <td className="px-4 py-2">Total Net Payable</td>
                    <td className="px-4 py-2">{formatCurrency(payslip.netPay)}</td>
                    <td className="px-4 py-2"></td>
                    <td className="px-4 py-2"></td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Footer */}
            <div className="grid md:grid-cols-2 gap-6 mt-10 text-sm">
              <div className="text-gray-500">
                <p>
                  For any inquiries, please contact us at +(91) 0123 456 7890 or
                  email at metromindz@gmail.com
                </p>
                <p className="mt-2">Best Regards,</p>
                <p>Metromindz Private Limited</p>
              </div>

              <div className="flex flex-col items-center md:items-end">
                {/* <img src={signature} alt="signature" className="h-12 mb-1" /> */}
                {/* No digitalized signature is available for display. */}
                <p className="h-12 mt-2">No digitalized signature is available for display.</p>

                <h6 className="text-gray-800 font-semibold text-sm">Authorized Sign</h6>
              </div>
            </div>
          </div>
        </div>
      </main>
    </>
  );
};

export default Index;
