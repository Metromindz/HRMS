import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import EmployeeReport from './components/EmployeeReport';
import EmployeeReportTabel from './components/EmployeeReportTabel';
import DailyAttendanceTable from './components/DailyAttendanceTable';
import { useState } from 'react';

const Index = () => {
  const [activeTab, setActiveTab] = useState('monthly');
  const [dailyDate, setDailyDate] = useState(new Date().toISOString().split('T')[0]);
  
  // Monthly filter state
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  return <>
      <PageMeta title="Attendance Management" />
      <main>
        <PageBreadcrumb title="Attendance Management" subtitle="HR" />
        
        <div className="flex items-center gap-4 mb-6 border-b border-default-200">
          <button
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'monthly'
                ? 'border-primary text-primary'
                : 'border-transparent text-default-600 hover:text-default-900'
            }`}
            onClick={() => setActiveTab('monthly')}
          >
            Monthly Overview
          </button>
          <button
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'daily'
                ? 'border-primary text-primary'
                : 'border-transparent text-default-600 hover:text-default-900'
            }`}
            onClick={() => setActiveTab('daily')}
          >
            Daily Report
          </button>
        </div>

        {activeTab === 'monthly' ? (
          <>
            <EmployeeReport 
              type="monthly" 
              month={selectedMonth} 
              year={selectedYear} 
            />
            <EmployeeReportTabel 
              selectedMonth={selectedMonth}
              setSelectedMonth={setSelectedMonth}
              selectedYear={selectedYear}
              setSelectedYear={setSelectedYear}
            />
          </>
        ) : (
          <>
            <EmployeeReport 
              type="daily" 
              selectedDate={dailyDate} 
            />
            <DailyAttendanceTable 
              selectedDate={dailyDate} 
              onDateChange={setDailyDate} 
            />
          </>
        )}
      </main>
    </>;
};
export default Index;