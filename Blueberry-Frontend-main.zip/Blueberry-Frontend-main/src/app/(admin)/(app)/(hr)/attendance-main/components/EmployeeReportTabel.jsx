import { LuArrowBigUp, LuCheck, LuSearch, LuX } from 'react-icons/lu';
import { useNavigate } from 'react-router';
import { useState, useEffect } from 'react';
import api from '../../../../../../config/api';
import { useAuth } from '../../../../../../context/AuthContext';

const EmployeeReportTabel = ({ 
  selectedMonth, 
  setSelectedMonth, 
  selectedYear, 
  setSelectedYear 
}) => {
  const navigate = useNavigate();
  const { hasPermission, user } = useAuth();

  const [attendanceMatrix, setAttendanceMatrix] = useState({});
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [shifts, setShifts] = useState({});
  const [selectedShift, setSelectedShift] = useState('all');

  // Permission checks
  const canImport = hasPermission('attendance.import');
  const canPunchVeiw = hasPermission('attendance.punch.view');




  const fetchShifts = async () => {
    try {
      const response = await api.get('/shifts')
      if (response.data && response.data.shifts) {
        setShifts(response.data)
      }
    }
    catch (error) {
      console.error("Error in fetching", error)
    }
  }

  useEffect(() => {
    fetchShifts();
  }, []);

  useEffect(() => {
    fetchAttendanceMatrix();
  }, [selectedMonth, selectedYear, searchTerm, selectedShift]);

  const fetchAttendanceMatrix = async () => {
    try {
      setLoading(true);
      const response = await api.get('/attendance/matrix', {
        params: {
          month: selectedMonth,
          year: selectedYear,
          searchByName: searchTerm,
          searchByShift: selectedShift === 'all' ? '' : selectedShift
        },
      });

      if (response.data.success) {
        setAttendanceMatrix(response.data.matrix);
      }
    } catch (error) {
      console.error('Error fetching attendance matrix:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
  };

  const handleShiftChange = (e) => {
    setSelectedShift(e.target.value);
  };


  const handleBulkUpload = async event => {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await api.post('/attendance/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      if (response.data.success) {
        alert(
          `Upload completed! ${response.data.uploaded} records uploaded, ${response.data.failed} failed.`
        );
        fetchAttendanceMatrix(); // Refresh data
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Upload failed. Please try again.');
    }

    event.target.value = ''; // Reset file input
  };

  const getDaysInMonth = (month, year) => {
    return new Date(year, month, 0).getDate();
  };

  const getDayName = (day, month, year) => {
    const date = new Date(year, month - 1, day);
    return date.toLocaleDateString('en-US', { weekday: 'short' });
  };

  const renderAttendanceIcon = status => {
    switch (status) {
      case 'w': // Weekly Off
      case 'W':
      case 'weeklyOff':
        return <span className="text-primary font-bold">W</span>;

      case '✔':
      case 'present':
        return <LuCheck className="size-4 text-success" />;
      case '✖':
      case 'absent':
        return <LuX className="size-4 text-danger" />;
      case '½':
      case 'half_day':
        return <span className="text-warning font-bold">½</span>;
      case 'L':
      case 'on_leave':
        return <span className="text-info font-bold">L</span>;
      default:
        return <span className="text-gray-400">-</span>;
    }
  };

  // Remove client-side filtering since it's now done by the API
  const employees = Object.values(attendanceMatrix);
  const daysInMonth = getDaysInMonth(selectedMonth, selectedYear);

  return (
    <div className="bg-white border border-default-200 rounded-2xl overflow-hidden  ">
      <div className="p-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4 flex-1 min-w-[300px]">
            <div className="relative flex-1 max-w-sm">
              <input
                type="text"
                className="w-full bg-default-50 border-default-200 rounded-xl ps-11 h-11 text-sm focus:ring-primary focus:border-primary transition-all"
                placeholder="Search employees..."
                value={searchTerm}
                onChange={handleSearch}
              />
              <div className="absolute inset-y-0 start-0 flex items-center ps-4">
                <LuSearch className="size-4 text-default-400" />
              </div>
            </div>

            <div className="w-48">
              <select
                className="w-full bg-default-50 border-default-200 rounded-xl h-11 text-sm focus:ring-primary focus:border-primary transition-all px-4"
                value={selectedShift}
                onChange={handleShiftChange}
              >
                <option value="all">All Shifts</option>
                {shifts.shifts && shifts.shifts.map((shift) => (
                  <option key={shift._id} value={shift._id}>
                    {shift.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {canImport && (
              <div className="relative">
                <input
                  type="file"
                  id="bulkUploadInput"
                  accept=".csv, .xlsx, .xls"
                  className="hidden"
                  onChange={handleBulkUpload}
                />
                <label
                  htmlFor="bulkUploadInput"
                  className="h-11 px-5 bg-success text-white rounded-xl flex items-center gap-2 font-bold text-xs uppercase tracking-widest hover:bg-success/90 transition-all cursor-pointer"
                >
                  <LuArrowBigUp className="size-4" /> Bulk Upload
                </label>
              </div>
            )}

            <div className="flex items-center bg-default-50 border border-default-200 rounded-xl p-1">
              <select
                className="bg-transparent border-none h-9 text-xs font-bold uppercase tracking-widest focus:ring-0 px-3 cursor-pointer"
                value={selectedMonth}
                onChange={e => setSelectedMonth(Number(e.target.value))}
              >
                {Array.from({ length: 12 }, (_, i) => (
                  <option key={i + 1} value={i + 1}>
                    {new Date(0, i).toLocaleString('default', { month: 'long' })}
                  </option>
                ))}
              </select>
              <div className="w-px h-4 bg-default-200 mx-1" />
              <select
                className="bg-transparent border-none h-9 text-xs font-bold uppercase tracking-widest focus:ring-0 px-3 cursor-pointer"
                value={selectedYear}
                onChange={e => setSelectedYear(Number(e.target.value))}
              >
                {Array.from({ length: 5 }, (_, i) => {
                  const year = new Date().getFullYear() - 2 + i;
                  return (
                    <option key={year} value={year}>
                      {year}
                    </option>
                  );
                })}
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-default-200">
          <thead className="bg-default-50/50">
            <tr>
              <th
                scope="col"
                className="px-6 py-4 text-start text-xs font-black text-default-500 uppercase tracking-widest sticky left-0 bg-default-50 z-10 border-r border-default-100"
              >
                Employee Name
              </th>
              {Array.from({ length: daysInMonth }, (_, i) => {
                const dayNum = i + 1;
                const dayName = getDayName(dayNum, selectedMonth, selectedYear);
                return (
                  <th
                    key={dayNum}
                    scope="col"
                    className="px-3 py-4 text-center text-xs font-black text-default-500 uppercase tracking-widest min-w-[45px]"
                  >
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] opacity-60 font-bold">{dayName}</span>
                      <span className="text-default-900">{String(dayNum).padStart(2, '0')}</span>
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>

          <tbody className="divide-y divide-default-100">
            {loading ? (
              Array.from({ length: 10 }).map((_, i) => (
                <tr key={i} className="animate-pulse">
                  <td className="px-6 py-4 sticky left-0 bg-white border-r border-default-100">
                    <div className="h-4 bg-default-100 rounded-lg w-32"></div>
                  </td>
                  {Array.from({ length: daysInMonth }).map((_, j) => (
                    <td key={j} className="px-3 py-4">
                      <div className="h-4 w-4 bg-default-100 rounded-full mx-auto"></div>
                    </td>
                  ))}
                </tr>
              ))
            ) : employees.length === 0 ? (
              <tr>
                <td
                  colSpan={daysInMonth + 1}
                  className="px-6 py-12 text-center"
                >
                  <div className="flex flex-col items-center justify-center gap-2">
                    <div className="size-12 bg-default-50 rounded-full flex items-center justify-center">
                      <LuSearch className="size-6 text-default-300" />
                    </div>
                    <p className="text-sm font-bold text-default-500 uppercase tracking-widest">
                      {searchTerm ? `No employees found matching "${searchTerm}"` : 'No attendance data found'}
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              employees.map(employee => (
                <tr
                  key={employee.employeeId}
                  className="hover:bg-default-50/50 transition-colors"
                  onClick={() => {
                    if (canPunchVeiw || employee._id === user?._id) {
                      navigate(`/attendance/${employee.employeeId}?month=${selectedMonth}&year=${selectedYear}&fullMonth=1`);
                    }
                  }}
                >
                  <td
                    className={`px-6 py-4 text-sm font-bold text-default-700 sticky left-0 bg-white hover:bg-default-50 z-10 border-r border-default-100 ${
                      canPunchVeiw || employee._id === user?._id ? 'cursor-pointer' : ''
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className="size-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center text-xs font-black">
                        {(employee.name || 'Unknown').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                      </div>
                      {employee.name || 'Unknown Employee'}
                    </div>
                  </td>
                  {Array.from({ length: daysInMonth }, (_, day) => {
                    const dayNum = day + 1;
                    const dayData = employee.days[dayNum];
                    return (
                      <td key={dayNum} className="px-3 py-4 text-center">
                        <div className="flex items-center justify-center">
                          {renderAttendanceIcon(dayData?.status)}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default EmployeeReportTabel;
