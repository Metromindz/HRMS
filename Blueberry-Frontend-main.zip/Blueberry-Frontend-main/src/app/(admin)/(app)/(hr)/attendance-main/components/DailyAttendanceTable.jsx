import { useState, useEffect } from 'react';
import { LuSearch, LuCalendar, LuDownload } from 'react-icons/lu';
import api from '@/config/api';
import toast from 'react-hot-toast';
import { getUploadUrl } from '@/utils/uploadUrl';

const DailyAttendanceTable = ({ selectedDate: propSelectedDate, onDateChange }) => {
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState([]);
  const [internalDate, setInternalDate] = useState(new Date().toISOString().split('T')[0]);
  const [searchTerm, setSearchTerm] = useState('');

  const selectedDate = propSelectedDate || internalDate;

  useEffect(() => {
    fetchDailyReport();
  }, [selectedDate]);

  const handleDateChange = (e) => {
    const newDate = e.target.value;
    if (onDateChange) {
      onDateChange(newDate);
    } else {
      setInternalDate(newDate);
    }
  };

  const fetchDailyReport = async () => {
    try {
      setLoading(true);
      const response = await api.get('/attendance/daily', {
        params: { date: selectedDate }
      });

      if (response.data && response.data.success) {
        setReport(response.data.report);
      } else {
        setReport([]);
      }
    } catch (error) {
      console.error('Error fetching daily report:', error);
      toast.error('Failed to fetch daily report');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value.toLowerCase());
  };

  const filteredReport = report.filter(record =>
    (record.name || '').toLowerCase().includes(searchTerm) ||
    (record.employeeId || '').toLowerCase().includes(searchTerm) ||
    (record.department || '').toLowerCase().includes(searchTerm)
  );

  const exportToCSV = () => {
    if (!filteredReport.length) return;

    const headers = ['Employee ID', 'Name', 'Department', 'Designation', 'Check In', 'Check Out', 'Working Hours', 'Status'];
    const csvContent = [
      headers.join(','),
      ...filteredReport.map(row => [
        row.employeeId,
        `"${row.name}"`,
        `"${row.department}"`,
        `"${row.designation}"`,
        row.checkIn,
        row.checkOut,
        row.workingHours,
        row.status
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `Attendance_Report_${selectedDate}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'present': return 'text-success bg-success/10';
      case 'absent': return 'text-danger bg-danger/10';
      case 'half_day': return 'text-warning bg-warning/10';
      default: return 'text-default-500 bg-default-100';
    }
  };

  return (
    <div className="bg-white border border-default-200 rounded-2xl overflow-hidden mt-6">
      <div className="p-6 border-b border-default-100">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h3 className="text-lg font-semibold text-default-800">Daily Attendance Report</h3>

          <div className="flex items-center gap-3">
            <div className="relative">
              <input
                type="date"
                className="form-input pl-10"
                value={selectedDate}
                onChange={handleDateChange}
              />
              <LuCalendar className="absolute left-3 top-1/2 -translate-y-1/2 text-default-400" />
            </div>

            <button
              onClick={exportToCSV}
              disabled={!filteredReport.length}
              className="btn btn-sm border-default-200 hover:bg-default-50"
            >
              <LuDownload className="size-4 mr-2" /> Export CSV
            </button>
          </div>
        </div>

        <div className="mt-4 relative max-w-sm">
          <input
            type="text"
            className="form-input pl-10 w-full"
            placeholder="Search employee..."
            value={searchTerm}
            onChange={handleSearch}
          />
          <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-default-400" />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-default-200">
          <thead className="bg-default-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-default-500 uppercase tracking-wider">Employee</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-default-500 uppercase tracking-wider">Department</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-default-500 uppercase tracking-wider">Check In</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-default-500 uppercase tracking-wider">Check Out</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-default-500 uppercase tracking-wider">Hours</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-default-500 uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-default-200">
            {loading ? (
              <tr>
                <td colSpan="6" className="px-6 py-10 text-center text-default-500">
                  <div className="animate-spin inline-block w-6 h-6 border-2 border-current border-t-transparent rounded-full text-primary" role="status" aria-label="loading"></div>
                  <span className="sr-only">Loading...</span>
                </td>
              </tr>
            ) : filteredReport.length === 0 ? (
              <tr>
                <td colSpan="6" className="px-6 py-10 text-center text-default-500">
                  No attendance records found for this date.
                </td>
              </tr>
            ) : (
              filteredReport.map((record) => (
                <tr key={record._id} className="hover:bg-default-50/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-8 w-8 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold mr-3 overflow-hidden">
                        {record.profilePhoto ? (
                          <img src={getUploadUrl(record.profilePhoto)} alt={record.name} className="h-full w-full object-cover" />
                        ) : (
                          (record.name || 'U').charAt(0)
                        )}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-default-900">{record.name || 'Unknown'}</div>
                        <div className="text-xs text-default-500">{record.employeeId}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-default-600">
                    {record.department}
                    <div className="text-xs text-default-400">{record.designation}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-mono text-default-700">
                    {record.checkIn}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-mono text-default-700">
                    {record.checkOut}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-bold text-default-700">
                    {record.workingHours}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(record.status)} capitalize`}>
                      {record.status}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DailyAttendanceTable;
