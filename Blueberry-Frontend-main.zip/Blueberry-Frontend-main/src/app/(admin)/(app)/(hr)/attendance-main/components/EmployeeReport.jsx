import { useState, useEffect } from 'react';
import { LuBriefcase, LuUserCheck, LuUsers, LuUserX } from 'react-icons/lu';
import api from '../../../../../../config/api';

const EmployeeReport = ({ selectedDate, type = 'daily', month, year }) => {
  const [stats, setStats] = useState({
    totalEmployees: 0,
    presentToday: 0,
    absentToday: 0,
    workingDays: 0,
  });
  const [loading, setLoading] = useState(true);

  // Determine target date/month/year
  let targetYear, targetMonth, targetDay;
  
  if (type === 'daily') {
    if (selectedDate) {
      const parts = selectedDate.split('-');
      targetYear = parseInt(parts[0]);
      targetMonth = parseInt(parts[1]);
      targetDay = parseInt(parts[2]);
    } else {
      const now = new Date();
      targetYear = now.getFullYear();
      targetMonth = now.getMonth() + 1;
      targetDay = now.getDate();
    }
  } else {
    // Monthly mode
    targetYear = year || new Date().getFullYear();
    targetMonth = month || (new Date().getMonth() + 1);
    targetDay = null; // No specific day
  }

  useEffect(() => {
    fetchStats();
  }, [selectedDate, month, year, type]);

  const fetchStats = async () => {
    try {
      // Fetch monthly attendance data
      const response = await api.get('/attendance/monthly', {
        params: { month: targetMonth, year: targetYear },
      });

      if (response.data.success) {
        const attendance = response.data.attendance;
        let presentCount = 0;
        let absentCount = 0;

        if (type === 'daily') {
          // Calculate stats for the specific target date
          const targetDateAttendance = attendance.filter(record => {
            const recordDate = new Date(record.date);
            return recordDate.getDate() === targetDay;
          });
          presentCount = targetDateAttendance.filter(r => r.status === 'present').length;
          absentCount = targetDateAttendance.filter(r => r.status === 'absent').length;
        } else {
          // Monthly mode: Calculate Totals
          const totalPresent = attendance.filter(r => r.status === 'present').length;
          const totalAbsent = attendance.filter(r => r.status === 'absent').length;
          
          presentCount = totalPresent;
          absentCount = totalAbsent;
        }

        // Get unique employees
        const uniqueEmployees = new Set(attendance.map(r => r.employeeId));

        // Calculate working days in current month
        const daysInMonth = new Date(targetYear, targetMonth, 0).getDate();

        setStats({
          totalEmployees: uniqueEmployees.size,
          presentToday: presentCount,
          absentToday: absentCount,
          workingDays: daysInMonth,
        });
      }
    } catch (error) {
      console.error('Error fetching attendance stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const reports = [
    {
      id: 1,
      title: 'Total Employees',
      value: stats.totalEmployees,
      icon: LuUsers,
      color: 'info',
    },
    {
      id: 2,
      title: type === 'daily' ? "Absent Today" : "Total Absent Days",
      value: stats.absentToday,
      icon: LuUserX,
      color: 'danger',
    },
    {
      id: 3,
      title: type === 'daily' ? "Present Today" : "Total Present Days",
      value: stats.presentToday,
      icon: LuUserCheck,
      color: 'success',
    },
    {
      id: 4,
      title: 'Working Days',
      value: stats.workingDays,
      icon: LuBriefcase,
      color: 'primary',
    },
  ];

  if (loading) {
    return (
      <div className="grid lg:grid-cols-4 md:grid-cols-2 grid-cols-1 gap-6 mb-6">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="bg-white border border-default-200 rounded-2xl p-5    animate-pulse">
            <div className="flex items-center gap-4">
              <div className="size-14 bg-default-100 rounded-xl"></div>
              <div className="flex-1">
                <div className="h-6 bg-default-100 rounded w-12 mb-2"></div>
                <div className="h-3 bg-default-100 rounded w-24"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid lg:grid-cols-4 md:grid-cols-2 grid-cols-1 gap-6 mb-6">
      {reports.map(({ id, title, value, icon: Icon, color }) => {
        const colorMap = {
          info: { bg: 'bg-blue-100', text: 'text-blue-600' },
          danger: { bg: 'bg-red-100', text: 'text-red-600' },
          success: { bg: 'bg-green-100', text: 'text-green-600' },
          primary: { bg: 'bg-primary-100', text: 'text-primary-600' },
        };
        const { bg: bgColor, text: textColor } = colorMap[color] || colorMap.info;

        return (
          <div key={id} className="group bg-white border border-default-200 rounded-2xl p-5 transition-all duration-300 relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-1 h-full ${textColor.replace('text-', 'bg-')} opacity-0 group-hover:opacity-100 transition-opacity`} />
            <div className="flex items-center gap-4">
              <div className={`size-14 flex items-center justify-center rounded-xl ${bgColor} ${textColor} group-hover:scale-110 transition-transform`}>
                <Icon className="size-7" />
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-black text-default-900 leading-none mb-1">{value}</span>
                <span className="text-[10px] font-black text-default-500 uppercase tracking-widest leading-tight">{title}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
export default EmployeeReport;
