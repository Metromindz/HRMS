import { LuX, LuTrash2 } from 'react-icons/lu';

const HolidaysLeaveDeleteModal = ({ isOpen, onClose, onConfirm, holiday }) => {
  if (!isOpen || !holiday) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-default-900/40 backdrop-blur-sm animate-in fade-in duration-300" onClick={onClose} />
      <div className="relative bg-white dark:bg-default-50 rounded-3xl max-w-md w-full overflow-hidden border border-default-200 dark:border-default-100 animate-in zoom-in-95 duration-300">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-default-100 dark:border-default-100 bg-white/80 dark:bg-default-50/80 backdrop-blur-md sticky top-0 z-20">
          <div className="flex flex-col gap-1">
            <h3 className="text-xl font-black text-default-900 dark:text-default-100 uppercase tracking-tight">Delete Holiday</h3>
            <p className="text-[10px] font-bold text-default-500 dark:text-default-400 uppercase tracking-widest px-1">Permanent action required</p>
          </div>
          <button 
            type="button" 
            className="size-10 flex items-center justify-center bg-default-50 dark:bg-default-100 text-default-400 dark:text-default-500 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-90" 
            onClick={onClose}
          >
            <LuX className="size-5" />
          </button>
        </div>

        <div className="p-8">
          <div className="flex flex-col items-center text-center gap-6">
            <div className="size-20 bg-danger/10 rounded-3xl flex items-center justify-center text-danger animate-bounce">
              <LuTrash2 className="size-10" />
            </div>
            
            <div className="space-y-2">
              <h3 className="text-lg font-black text-default-900 dark:text-default-100 uppercase tracking-tight">Confirm Deletion</h3>
              <p className="text-sm font-bold text-default-500 dark:text-default-400 leading-relaxed px-4">
                Are you sure you want to delete <span className="text-danger">"{holiday.name}"</span>? This action cannot be undone.
              </p>
            </div>

            <div className="w-full p-4 bg-default-50 dark:bg-default-100 rounded-2xl border border-default-100 dark:border-default-100 flex items-center justify-between">
              <div className="text-left">
                <p className="text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-widest">Holiday Name</p>
                <p className="text-sm font-black text-default-900 dark:text-default-100 uppercase">{holiday.name}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-widest">Date</p>
                <p className="text-sm font-black text-default-900 dark:text-default-100 uppercase">
                  {holiday.date || 'N/A'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 p-6 border-t border-default-100 dark:border-default-100 bg-default-50/50 dark:bg-default-100/50">
          <button 
            type="button"
            onClick={onClose}
            className="flex-1 px-6 py-2.5 text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-widest hover:text-danger dark:hover:text-danger transition-colors"
          >
            Keep Holiday
          </button>
          <button 
            type="button"
            onClick={onConfirm}
            className="flex-1 h-10 px-6 text-[10px] font-black text-white bg-danger hover:bg-danger-600 rounded-xl transition-all active:scale-95 uppercase tracking-widest"
          >
            Confirm Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default HolidaysLeaveDeleteModal;