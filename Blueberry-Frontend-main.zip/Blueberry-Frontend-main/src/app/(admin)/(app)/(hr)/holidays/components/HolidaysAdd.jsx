import { useState } from 'react';
import { LuX, LuCalendar, LuPlus } from 'react-icons/lu';
import { toast } from 'react-hot-toast';

const HolidaysAdd = ({ isOpen, onClose, onSave }) => {
  const [formData, setFormData] = useState({
    type: '',
    name: '',
    date: ''
  });

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    const allowedTypes = ['Gazetted Holiday', 'Observance', 'Restricted Holiday', 'Season'];
    const type = formData.type?.trim() || '';
    const name = formData.name?.trim() || '';
    const date = formData.date?.trim() || '';
    if (!type) { toast.error('Holiday type is required'); return; }
    if (!allowedTypes.includes(type)) { toast.error('Invalid holiday type'); return; }
    if (!name) { toast.error('Holiday name is required'); return; }
    if (name.length < 2) { toast.error('Holiday name must be at least 2 characters'); return; }
    if (name.length > 80) { toast.error('Holiday name must be 80 characters or less'); return; }
    if (!date) { toast.error('Holiday date is required'); return; }
    if (Number.isNaN(new Date(date).getTime())) { toast.error('Enter a valid holiday date'); return; }
    onSave({ ...formData, type, name, date });
    setFormData({ type: '', name: '', date: '' });
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-default-900/40 backdrop-blur-sm animate-in fade-in duration-300" onClick={onClose} />
      
      <div className="relative bg-white dark:bg-default-50 rounded-3xl max-w-lg w-full overflow-hidden animate-in zoom-in-95 duration-300 border border-default-200 dark:border-default-100">
        <div className="px-8 py-6 border-b border-default-100 dark:border-default-100 flex items-center justify-between bg-white/80 dark:bg-default-50/80 sticky top-0 z-20 backdrop-blur-md">
          <div className="flex flex-col gap-1">
            <h3 className="text-xl font-black text-default-900 dark:text-default-100 uppercase tracking-tight">Add New Holiday</h3>
            <p className="text-[10px] font-bold text-default-500 dark:text-default-400 uppercase tracking-widest px-1">Configure company holiday details</p>
          </div>
          <button 
            type="button" 
            className="size-10 flex items-center justify-center bg-default-50 dark:bg-default-100 text-default-400 dark:text-default-500 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-90" 
            onClick={onClose}
          >
            <LuX className="size-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col">
          <div className="p-8">
            <div className="space-y-6">
              <div>
                <h4 className="text-[10px] font-black text-primary flex items-center gap-2 uppercase tracking-[0.2em] mb-4">
                  <span className="w-8 h-[2px] bg-primary"></span>
                  Holiday Details
                </h4>
                <div className="space-y-5">
                  <div>
                    <label htmlFor="type" className="block text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-widest mb-2 px-1">
                      Holiday Type *
                    </label>
                    <select
                      id="type"
                      name="type"
                      value={formData.type}
                      onChange={handleChange}
                      className="w-full h-12 bg-default-50 dark:bg-default-100 border border-default-200 dark:border-default-100 rounded-xl px-4 text-sm font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all"
                      required
                    >
                      <option value="" className="dark:bg-default-50">Select Type</option>
                      <option value="Gazetted Holiday" className="dark:bg-default-50">Gazetted Holiday</option>
                      <option value="Observance" className="dark:bg-default-50">Observance</option>
                      <option value="Restricted Holiday" className="dark:bg-default-50">Restricted Holiday</option>
                      <option value="Season" className="dark:bg-default-50">Season</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="name" className="block text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-widest mb-2 px-1">
                      Holiday Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="h-12 w-full bg-default-50 dark:bg-default-100 border border-default-200 dark:border-default-100 rounded-xl px-4 text-sm font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all placeholder:text-default-400 dark:placeholder:text-default-500"
                      placeholder="Enter Holiday Name"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="date" className="block text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-widest mb-2 px-1">
                      Holiday Date *
                    </label>
                    <div className="relative group">
                      <LuCalendar className="absolute left-4 top-1/2 -translate-y-1/2 size-4 text-default-400 dark:text-default-500 group-focus-within:text-primary transition-colors" />
                      <input 
                        type="date" 
                        id="date" 
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                        className="h-12 w-full bg-default-50 dark:bg-default-100 border border-default-200 dark:border-default-100 rounded-xl pl-12 pr-4 text-sm font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all" 
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="px-8 py-6 border-t border-default-100 dark:border-default-100 bg-default-50/50 dark:bg-default-100/50 flex items-center justify-between">
            <div className="text-[10px] font-bold text-default-400 dark:text-default-500 uppercase tracking-widest">
              * Fields are required
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-2.5 text-[10px] font-black text-default-500 dark:text-default-400 hover:text-danger dark:hover:text-danger transition-colors uppercase tracking-widest"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="h-10 px-8 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all active:scale-95 flex items-center gap-2 shadow-lg shadow-primary/20"
              >
                <LuPlus className="size-4" /> Add Holiday
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default HolidaysAdd;
