import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import {
  LuCheck,
  LuChevronLeft,
  LuChevronRight,
  LuListPlus,
  LuPlus,
  LuSearch,
  LuX,
} from 'react-icons/lu';
 

const LeaveTabel = ({ 
  leaveRequests, 
  loading, 
  message, 
  setMessage, 
  fetchLeaveRequests, 
  handleApproval, 
  canCreate, 
  pagination, 
  onPageChange,
  user
}) => {
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Handle search input change
  const handleSearch = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    // Call parent's fetch function with both status and search
    fetchLeaveRequests(statusFilter, value);
  };

  // Handle status filter change
  const handleStatusFilterChange = (e) => {
    const value = e.target.value;
    setStatusFilter(value);
    // Call parent's fetch function with both status and search
    fetchLeaveRequests(value, searchTerm);
  };

  // Clear message after a timeout
  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => {
        setMessage('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [message, setMessage]);

  
  
  const handlePrevious = () => {
    if (pagination?.page > 1) onPageChange?.(pagination.page - 1);
  };
  
  const handleNext = () => {
    if (pagination?.page < pagination?.totalPages) onPageChange?.(pagination.page + 1);
  };


  return (
    <div className="bg-white border border-default-200 rounded-2xl overflow-hidden">
      <div className="p-6 flex flex-wrap items-center justify-between gap-4 border-b border-default-200 bg-default-50/50">
        <div className="flex flex-col gap-1">
          <h4 className="text-xl font-black text-default-900 uppercase tracking-tight">Leave Requests</h4>
          <p className="text-xs font-bold text-default-500 uppercase tracking-widest">Monitor and process employee leave applications</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative group min-w-[250px]">
            <input
              type="text"
              className="w-full bg-white border-default-200 rounded-xl ps-11 pe-4 py-2.5 text-sm font-bold focus:border-primary focus:ring-primary transition-all group-hover:border-default-300"
              placeholder="Search by name..."
              value={searchTerm}
              onChange={handleSearch}
            />
            <div className="absolute inset-y-0 start-0 flex items-center ps-4 text-default-400 group-hover:text-primary transition-colors">
              <LuSearch className="size-4" />
            </div>
          </div>

          <div className="relative group min-w-[150px]">
            <select
              className="w-full appearance-none bg-white border-default-200 rounded-xl px-4 py-2.5 pr-10 text-sm font-bold focus:border-primary focus:ring-primary transition-all group-hover:border-default-300 cursor-pointer"
              value={statusFilter}
              onChange={handleStatusFilterChange}
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>
            <div className="absolute inset-y-0 end-0 flex items-center pe-4 pointer-events-none text-default-400 group-hover:text-primary transition-colors">
              <LuChevronRight className="size-4 rotate-90" />
            </div>
          </div>

          <div className="h-8 w-px bg-default-200 mx-1 hidden sm:block" />

          {canCreate && (
            <Link
              to="/create-leave"
              className="h-11 px-6 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all flex items-center gap-2 active:scale-95"
            >
              <LuPlus className="size-4" />
              Apply Leave
            </Link>
          )}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full table-fixed">
          <thead>
            <tr className="bg-default-50/50">
              <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">#</th>
              <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Employee</th>
              <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em] w-[360px]">Type & Reason</th>
              <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em] w-[240px]">Timeline</th>
              <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Manager</th>
              <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Status</th>
              <th className="py-4 px-6 text-right text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Actions</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-default-100 bg-white">
            {leaveRequests.length === 0 ? (
              <tr>
                <td colSpan="7" className="py-20 text-center">
                  <div className="flex flex-col items-center justify-center gap-3">
                    <div className="size-16 bg-default-50 rounded-2xl flex items-center justify-center">
                      <LuListPlus className="size-8 text-default-300" />
                    </div>
                    <p className="text-sm font-black text-default-400 uppercase tracking-widest">
                      {loading ? 'Loading requests...' : 'No leave requests found'}
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              leaveRequests.map((request, index) => (
                <tr key={request._id} className="hover:bg-default-50/50 transition-colors group">
                  <td className="py-4 px-6">
                    <span className="text-xs font-bold text-default-400">
                      {(((pagination?.page || 1) - 1) * (pagination?.limit || 10) + index + 1).toString().padStart(2, '0')}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex flex-col">
                      <span className="text-sm font-black text-default-900 leading-tight mb-0.5">{request.employeeName}</span>
                      <span className="text-[10px] font-black text-default-500 uppercase tracking-widest">EMP-{request.employeeId}</span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex flex-col gap-1.5 max-w-[360px]">
                      <span className="inline-flex items-center px-2.5 py-1 rounded-lg bg-default-100 text-default-700 text-[10px] font-black uppercase tracking-widest border border-default-200 w-fit">
                        {request.leaveName}
                      </span>
                      <span className="text-xs font-medium text-default-700 break-words line-clamp-2" title={request.reason}>
                        {request.reason || '—'}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 max-w-[240px]">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-black text-default-800 uppercase tracking-tight">
                          {new Date(request.fromDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}
                        </span>
                        <LuChevronRight className="size-3 text-default-400" />
                        <span className="text-xs font-black text-default-800 uppercase tracking-tight">
                          {new Date(request.toDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}
                        </span>
                      </div>
                      <span className="text-[10px] font-black text-primary uppercase tracking-widest bg-primary/10 px-2.5 py-1 rounded-full w-fit">
                        {request.numberOfDays} {request.numberOfDays === 1 ? 'Day' : 'Days'}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-xs font-black text-default-600 uppercase tracking-widest">{request.reportingManagerName}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                      request.status === 'approved' ? 'bg-success/10 text-success border-success/20' :
                      request.status === 'rejected' ? 'bg-danger/10 text-danger border-danger/20' :
                      'bg-warning/10 text-warning border-warning/20'
                    }`}>
                      {request.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    {request.status === 'pending' && (
                      (user?.role === 'superadmin' || user?.role === 'hr' || user?.role === 'HR') || 
                      ((user?.role === 'manager' || user?.role === 'Manager' || user?.role === 'Team Manager') && String(request.reportingManagerId) === String(user?._id))
                    ) ? (
                      <div className="flex items-center justify-end gap-2">
                        <button
                          className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-success hover:bg-success hover:text-white hover:border-success transition-all active:scale-90"
                          onClick={() => handleApproval(request.employeeId, request.leaveId, request.fromDate, request.toDate, 'approved')}
                          disabled={loading}
                          title="Approve"
                        >
                          <LuCheck className="size-5" />
                        </button>
                        <button
                          className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-danger hover:bg-danger hover:text-white hover:border-danger transition-all active:scale-90"
                          onClick={() => handleApproval(request.employeeId, request.leaveId, request.fromDate, request.toDate, 'rejected')}
                          disabled={loading}
                          title="Reject"
                        >
                          <LuX className="size-5" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-end gap-2 opacity-30 grayscale">
                        <div className="size-10 flex items-center justify-center bg-default-50 border border-default-200 rounded-xl text-default-400">
                          <LuCheck className="size-5" />
                        </div>
                        <div className="size-10 flex items-center justify-center bg-default-50 border border-default-200 rounded-xl text-default-400">
                          <LuX className="size-5" />
                        </div>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {message && (
        <div className={`mx-6 mt-4 p-4 rounded-xl font-bold text-xs uppercase tracking-widest border flex items-center gap-3 animate-in fade-in slide-in-from-top-2 ${
          message.toLowerCase().includes('success') ? 'bg-success/10 text-success border-success/20' : 'bg-danger/10 text-danger border-danger/20'
        }`}>
          <div className={`size-6 rounded-full flex items-center justify-center ${message.toLowerCase().includes('success') ? 'bg-success text-white' : 'bg-danger text-white'}`}>
            {message.toLowerCase().includes('success') ? <LuCheck className="size-3" /> : <LuX className="size-3" />}
          </div>
          {message}
        </div>
      )}

      <div className="flex flex-col sm:flex-row items-center justify-between p-6 border-t border-default-100 bg-default-50/50 gap-4">
        <div className="text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">
          Showing <span className="text-default-900">{((pagination?.page || 1) - 1) * (pagination?.limit || 10) + 1}</span> to <span className="text-default-900">{Math.min((pagination?.page || 1) * (pagination?.limit || 10), pagination?.total || 0)}</span> of <span className="text-default-900">{pagination?.total || 0}</span> Results
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center bg-white border border-default-200 rounded-xl p-1">
            <button
              type="button"
              className="size-10 flex items-center justify-center rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600 active:scale-90"
              disabled={pagination?.page === 1}
              onClick={handlePrevious}
            >
              <LuChevronLeft className="size-4" />
            </button>
            <div className="w-px h-4 bg-default-200 mx-1" />
            <button
              type="button"
              className="size-10 flex items-center justify-center rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600 active:scale-90"
              disabled={pagination?.page === pagination?.totalPages}
              onClick={handleNext}
            >
              <LuChevronRight className="size-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default LeaveTabel;
