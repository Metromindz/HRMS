import { LuCalendarCheck, LuCodepen, LuFileChartColumn, LuLoader } from 'react-icons/lu';

const LeaveCard = ({ leaveStats, loading }) => {
  // const [leaveStats, setLeaveStats] = useState({
  //   totalLeaveRequests: 0,
  //   totalApplications: 0,
  //   approved: 0,
  //   rejected: 0,
  //   pending: 0
  // });
  // const [loading, setLoading] = useState(true);

  // const fetchLeaveCounts = async () => {
  //   try {
  //     setLoading(true);
  //     const response = await api.get('/statistics/counts/leave');

  //     setLeaveStats(response.data.data);
  //   } catch (error) {
  //     console.error("Error fetching leave counts:", error);
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // useEffect(() => {
  //   fetchLeaveCounts();
  // }, []); 

  const leaveData = [
    {
      id: 1,
      title: 'Total Leave Requests',
      value: leaveStats.totalApplications.toString(),
      description: 'Total Leave Requests',
      icon: LuFileChartColumn,
      textColor: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    {
      id: 2,
      title: 'Approved Leaves',
      value: leaveStats.approved.toString(),
      description: 'Approved Leaves',
      icon: LuCalendarCheck,
      textColor: 'text-success',
      bgColor: 'bg-success/10'
    },
    {
      id: 3,
      title: 'Rejected Leaves',
      value: leaveStats.rejected.toString(),
      description: 'Rejected Leaves',
      icon: LuCodepen,
      textColor: 'text-secondary',
      bgColor: 'bg-secondary/10'
    },
    {
      id: 4,
      title: 'Pending Approval',
      value: leaveStats.pending.toString(),
      description: 'Pending Approval',
      icon: LuLoader,
      textColor: 'text-warning',
      bgColor: 'bg-warning/10'
    }
  ];

  if (loading) {
    return <div className="text-center p-8">Loading leave statistics...</div>;
  }

  return (
    <div className="grid lg:grid-cols-4 md:grid-cols-2 grid-cols-1 gap-6 mb-8">
      {leaveData.map(({ id, value, description, icon: Icon, textColor, bgColor }) => (
        <div key={id} className="group bg-white border border-default-200 rounded-2xl p-5 transition-all duration-300 relative overflow-hidden">
          <div className={`absolute top-0 left-0 w-1 h-full ${textColor.replace('text-', 'bg-')} opacity-0 group-hover:opacity-100 transition-opacity`} />
          <div className="flex items-center gap-4">
            <div className={`size-14 flex items-center justify-center rounded-xl ${bgColor} ${textColor} group-hover:scale-110 transition-transform`}>
              <Icon className="size-7" />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-black text-default-900 leading-none mb-1">{value}</span>
              <span className="text-[10px] font-black text-default-500 uppercase tracking-widest">{description}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default LeaveCard;
