import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import {
  LuCheck,
  LuChevronLeft,
  LuChevronRight,
  LuPlus,
  LuSearch,
  LuX,
} from 'react-icons/lu';
import api from '../../../../../../config/api.js';



const LeaveTabel = () => {
  const [leaveRequests, setLeaveRequests] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  const fetchAllLeaveRequests = async (status = 'all') => {
    try {
      setLoading(true);
      let url = '/leave-requests/all';
      if (status !== 'all') {
        url += `?status=${status}`;
      }

      const response = await api.get(url);
      if (response.status === 200) {
        setLeaveRequests(response.data.data || []);
      }
    } catch (error) {
      console.error('Error fetching leave requests:', error);
      setMessage('Error fetching leave requests');
    } finally {
      setLoading(false);
    }
  };

  const handleApproval = async (empId, leaveId, fromDate, toDate, status) => {
    try {
      setLoading(true);
      const response = await api.put('/leave-requests/approve', {
        empId,
        leaveId,
        fromDate,
        toDate,
        status,
      });

      if (response.status === 200) {
        setMessage(`Leave request ${status} successfully!`);
        fetchAllLeaveRequests();
      }
    } catch (error) {
      console.error('Error processing leave request:', error);
      setMessage(error.response?.data?.message || 'Error processing leave request');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllLeaveRequests(statusFilter);
  }, [statusFilter]);

  return (
    <div className="grid grid-cols-1 gap-5 mb-5">
      <div className="card">
        <div className="card-header flex justify-between items-center">
          <div className="relative">
            <input type="text" className="form-input form-input-sm ps-9" placeholder="Search ..." />
            <div className="absolute inset-y-0 start-0 flex items-center ps-3">
              <LuSearch className="size-4 text-default-500" />
            </div>
          </div>

          {/* <div>
            <Flatpickr
              options={{
                mode: 'single',
                dateFormat: 'd M, Y',
              }}
              className="text-sm form-input"
              placeholder="Select Date"
            />
          </div> */}

          <div>
            <select
              className="form-input form-input-sm"
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
              {/* <option value="partially_approved">Approved by HR</option> */}
            </select>
          </div>

          <div className="card-header flex justify-between items-center">
            <Link to="/create-leave" className="btn btn-sm bg-primary text-white flex items-center">
              <LuPlus className="size-4 me-1" /> Apply Leave
            </Link>

            {/* <button className="btn btn-sm bg-primary text-white flex items-center">
              <LuDownload className="size-4 me-1" /> Export
            </button> */}
          </div>
        </div>

        <div className="flex flex-col">
          <div className="overflow-x-auto">
            <div className="min-w-full inline-block align-middle">
              <div className="overflow-hidden">
                <table className="min-w-full divide-y divide-default-200">
                  <thead className="bg-default-150">
                    <tr className="text-sm font-normal text-default-500 whitespace-nowrap">
                      <th className="px-3.5 py-3 text-start">#</th>
                      <th className="px-3.5 py-3 text-start">Employee Name</th>
                      <th className="px-3.5 py-3 text-start">Leave Type</th>
                      <th className="px-3.5 py-3 text-start">Reason</th>
                      <th className="px-3.5 py-3 text-start">No Of Days</th>
                      <th className="px-3.5 py-3 text-start">From</th>
                      <th className="px-3.5 py-3 text-start">To</th>
                      <th className="px-3.5 py-3 text-start">Status</th>
                      <th className="px-3.5 py-3 text-start">Action</th>
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-default-200">
                    {leaveRequests.length === 0 ? (
                      <tr>
                        <td colSpan="9" className="text-center py-4">
                          {loading ? 'Loading...' : 'No pending leave requests'}
                        </td>
                      </tr>
                    ) : (
                      leaveRequests
                        .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)
                        .map((request, index) => (
                        <tr key={request._id} className="text-default-800 font-normal">
                          <td className="px-3.5 py-2.5 whitespace-nowrap text-sm">
                            {((currentPage - 1) * itemsPerPage + index + 1).toString().padStart(2, '0')}
                          </td>
                          <td className="px-3.5 py-2.5 whitespace-nowrap text-sm">
                            {request.employeeName}
                          </td>
                          <td className="px-3.5 py-2.5 whitespace-nowrap text-sm">
                            {request.leaveName}
                          </td>
                          <td className="px-3.5 py-2.5 whitespace-nowrap text-sm max-w-xs truncate">
                            {request.reason}
                          </td>
                          <td className="px-3.5 py-2.5 whitespace-nowrap text-sm">
                            {request.numberOfDays}
                          </td>
                          <td className="px-3.5 py-2.5 whitespace-nowrap text-sm">
                            {new Date(request.fromDate).toLocaleDateString()}
                          </td>
                          <td className="px-3.5 py-2.5 whitespace-nowrap text-sm">
                            {new Date(request.toDate).toLocaleDateString()}
                          </td>
                          <td className="px-3.5 py-2.5 whitespace-nowrap">
                            <span className={`inline-flex items-center gap-x-1.5 py-0.5 px-2.5 rounded text-xs font-medium ${
                              request.status === 'approved' ? 'bg-success/15 text-success' :
                              request.status === 'rejected' ? 'bg-danger/10 text-danger' :
                              'bg-warning/15 text-warning'
                            }`}>
                              {request.status}
                            </span>
                          </td>
                          <td className="px-3.5 py-2.5 whitespace-nowrap">
                            {request.status === 'pending' ? (
                              <div className="flex items-center gap-2">
                                <button
                                  className="btn size-8 bg-green-500 hover:bg-green-600 text-white"
                                  onClick={() =>
                                    handleApproval(
                                      request.employeeId,
                                      request.leaveId,
                                      request.fromDate,
                                      request.toDate,
                                      'approved'
                                    )
                                  }
                                  disabled={loading}
                                >
                                  <LuCheck className="size-4" />
                                </button>
                                <button
                                  className="btn size-8 bg-red-500 hover:bg-red-600 text-white"
                                  onClick={() =>
                                    handleApproval(
                                      request.employeeId,
                                      request.leaveId,
                                      request.fromDate,
                                      request.toDate,
                                      'rejected'
                                    )
                                  }
                                  disabled={loading}
                                >
                                  <LuX className="size-4" />
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <button
                                  className={`btn size-8 ${request.status === 'approved' ? 'bg-gray-300 text-gray-500' : 'bg-gray-200 text-gray-400'} cursor-not-allowed`}
                                  disabled
                                >
                                  <LuCheck className="size-4" />
                                </button>
                                <button
                                  className={`btn size-8 ${request.status === 'rejected' ? 'bg-gray-300 text-gray-500' : 'bg-gray-200 text-gray-400'} cursor-not-allowed`}
                                  disabled
                                >
                                  <LuX className="size-4" />
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {message && (
            <div
              className={`m-4 p-3 rounded ${message.includes('success') ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}
            >
              {message}
            </div>
          )}

          <div className="card-footer flex justify-between items-center">
            <p className="text-default-500 text-sm">
              Showing <b>{Math.min(currentPage * itemsPerPage, leaveRequests.length)}</b> of <b>{leaveRequests.length}</b> Results
            </p>
            <nav className="flex items-center gap-2" aria-label="Pagination">
              <button 
                className="btn btn-sm border bg-transparent border-default-200 text-default-600 hover:bg-primary/10 hover:text-primary"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <LuChevronLeft className="size-4 me-1" /> Prev
              </button>
              {Array.from({ length: Math.ceil(leaveRequests.length / itemsPerPage) }, (_, i) => i + 1).map(page => (
                <button 
                  key={page}
                  className={`btn size-7.5 ${currentPage === page ? 'bg-primary text-white' : 'bg-transparent border border-default-200 text-default-600 hover:bg-primary/10 hover:text-primary'}`}
                  onClick={() => setCurrentPage(page)}
                >
                  {page}
                </button>
              ))}
              <button 
                className="btn btn-sm border bg-transparent border-default-200 text-default-600 hover:bg-primary/10 hover:text-primary"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, Math.ceil(leaveRequests.length / itemsPerPage)))}
                disabled={currentPage === Math.ceil(leaveRequests.length / itemsPerPage)}
              >
                Next <LuChevronRight className="size-4 ms-1" />
              </button>
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
};
export default LeaveTabel;
