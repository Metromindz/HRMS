import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import { useAuth } from '@/context/AuthContext';
import { useEffect, useState } from 'react';
import api from '../../../../../config/api';
import LeaveCard from './components/LeaveCard';
import LeaveTabel from './components/LeaveTabel';
import Modal from './components/Modal';

const Index = () => {
  const { user, hasPermission, loading: authLoading } = useAuth();
  const [leaveRequests, setLeaveRequests] = useState([]);
  //for leave stats present in card
  const [leaveStats, setLeaveStats] = useState({
    totalLeaveRequests: 0,
    totalApplications: 0,
    approved: 0,
    rejected: 0,
    pending: 0
  });

  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 1,
  });

  const [statusFilter, setStatusFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [statsLoading, setStatsLoading] = useState(false);
  const [message, setMessage] = useState('');
  
  // Permission checks
  const canCreate = hasPermission('leave.create');
  const canView = hasPermission('leave.view') || user?.role === 'hr' || user?.role === 'HR' || user?.role === 'manager' || user?.role === 'Manager' || user?.role === 'Team Manager';
  const canStatus = hasPermission('leave.status') || user?.role === 'hr' || user?.role === 'HR' || user?.role === 'manager' || user?.role === 'Manager' || user?.role === 'Team Manager';

  const fetchLeaveStats = async () => {
    try {
      setStatsLoading(true);
      const response = await api.get('/statistics/counts/leave');
      if (response.status === 200) {
        setLeaveStats(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching leave stats:', error);
    } finally {
      setStatsLoading(false);
    }
  };

  // Modified fetchLeaveRequests to support pagination
  const fetchLeaveRequests = async (status = statusFilter, search = searchTerm, page = 1) => {
    if (!canView) return;
    
    try {
      setLoading(true);
      const params = new URLSearchParams();
      
      // Apply filters
      if (status !== 'all') {
        params.append('status', status);
      }
      
      if (search.trim() !== '') {
        params.append('searchByEmployee', search);
      }
      
      // Add pagination parameters
      params.append('page', page);
      params.append('limit', pagination.limit);
      
      // Update local state for filters
      if (status !== undefined) setStatusFilter(status);
      if (search !== undefined) setSearchTerm(search);
      
      const url = `/leave-requests/all?${params.toString()}`;
      const response = await api.get(url);
      
      if (response.status === 200) {
        setLeaveRequests(response.data.data || []);
        
        // Update pagination from API response
        if (response.data.pagination) {
          setPagination(prev => ({
            ...prev,
            page: response.data.pagination.page,
            total: response.data.pagination.total,
            totalPages: response.data.pagination.totalPages,
          }));
        } else {
          // Fallback if pagination data not in response
          setPagination(prev => ({
            ...prev,
            page: page,
            total: response.data.count || response.data.data?.length || 0,
            totalPages: Math.ceil((response.data.count || response.data.data?.length || 0) / prev.limit),
          }));
        }
      }
    } catch (error) {
      console.error('Error fetching leave requests:', error);
      setMessage('Error fetching leave requests');
      setLeaveRequests([]);
      setPagination(prev => ({
        ...prev,
        page: 1,
        total: 0,
        totalPages: 1,
      }));
    } finally {
      setLoading(false);
    }
  };

  // Handle page change from LeaveTabel component
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      fetchLeaveRequests(statusFilter, searchTerm, newPage);
    }
  };

  // Handle filter changes
  const handleFilterChange = (status = statusFilter, search = searchTerm) => {
    // Reset to page 1 when filters change
    fetchLeaveRequests(status, search, 1);
  };

  const handleApproval = async (empId, leaveId, fromDate, toDate, status) => {
    if (!canStatus) return;
    
    try {
      setLoading(true);
      const response = await api.put('/leave-requests/approve', {
        empId,
        leaveId,
        fromDate,
        toDate,
        status,
      });
      
      if (response.status === 200) {
        setMessage(`Leave request ${status} successfully!`);
        
        // Refresh data keeping current filters and page
        await Promise.all([
          fetchLeaveRequests(statusFilter, searchTerm, pagination.page),
          fetchLeaveStats()
        ]);
      }
    } catch (error) {
      console.error('Error processing leave request:', error);
      setMessage(error.response?.data?.message || 'Error processing leave request');
    } finally {
      setLoading(false);
    }
  };

  // Initial data fetch
  useEffect(() => {
    const fetchAllData = async () => {
      await Promise.all([
        fetchLeaveRequests('all', '', 1), // Start from page 1
        fetchLeaveStats()
      ]);
    };
    fetchAllData();
  }, []);

  // Clean up message after 3 seconds
  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => {
        setMessage('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  if (authLoading) {
    return (
      <div className="w-full h-full flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!canView) {
    return (
      <div className="card">
        <div className="card-body text-center py-10">
          <p className="text-red-600">You don't have permission to view leave management.</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <PageMeta title="Leave Manage (HR)" />
      <main>
        <PageBreadcrumb title="Employees Leave Management" subtitle="Menu" />
        <LeaveCard 
          leaveStats={leaveStats} 
          loading={statsLoading} 
        />
        <LeaveTabel 
          leaveRequests={leaveRequests}
          loading={loading}
          message={message}
          setMessage={setMessage}
          fetchLeaveRequests={handleFilterChange} // Pass the filter handler
          handleApproval={handleApproval}
          canCreate={canCreate}
          canStatus={canStatus}
          pagination={pagination}
          onPageChange={handlePageChange}
          statusFilter={statusFilter}
          searchTerm={searchTerm}
          user={user}
        />
        <Modal />
      </main>
    </>
  );
};

export default Index;
