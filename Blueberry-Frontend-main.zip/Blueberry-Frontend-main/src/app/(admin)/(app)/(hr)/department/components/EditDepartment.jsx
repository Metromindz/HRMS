import { useState, useEffect } from 'react';
import { LuX } from 'react-icons/lu';
import { toast } from 'react-hot-toast';

const EditDepartment = ({ isOpen, onClose, onSave, department }) => {
  const [formData, setFormData] = useState({ name: '' });

  useEffect(() => {
    if (department) {
      setFormData({ name: department.name || '' });
    }
  }, [department]);

  if (!isOpen) return null;

  const handleSubmit = e => {
    e.preventDefault();
    const name = formData.name?.trim() || '';
    if (!name) { toast.error('Department name is required'); return; }
    if (name.length < 2) { toast.error('Department name must be at least 2 characters'); return; }
    if (name.length > 60) { toast.error('Department name must be 60 characters or less'); return; }
    onSave({ ...formData, name, id: department._id });
  };

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-default-900/40 backdrop-blur-sm animate-in fade-in duration-300" onClick={onClose} />
      
      <div className="relative bg-white dark:bg-default-50 rounded-3xl max-w-lg w-full overflow-hidden animate-in zoom-in-95 duration-300 border border-default-200 dark:border-default-100">
        {/* Header */}
        <div className="px-8 py-6 border-b border-default-100 dark:border-default-100 flex items-center justify-between bg-white/80 dark:bg-default-50/80 sticky top-0 z-20 backdrop-blur-md">
          <div className="flex flex-col gap-1">
            <h3 className="text-xl font-black text-default-900 dark:text-default-100 uppercase tracking-tight">Edit Department</h3>
            <p className="text-[10px] font-bold text-default-500 dark:text-default-400 uppercase tracking-widest px-1">Update department details</p>
          </div>
          <button 
            type="button" 
            className="size-10 flex items-center justify-center bg-default-50 dark:bg-default-100 text-default-400 dark:text-default-500 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-90" 
            onClick={onClose}
          >
            <LuX className="size-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="p-8 space-y-6">
            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-primary flex items-center gap-2 uppercase tracking-[0.2em]">
                <span className="w-8 h-[2px] bg-primary"></span>
                Department Details
              </h4>
              
              <div className="space-y-2">
                <label htmlFor="name" className="text-[10px] font-black text-default-600 dark:text-default-400 uppercase tracking-widest ml-1">
                  Department Name
                </label>
                <input 
                  type="text" 
                  id="name" 
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className="h-12 w-full bg-default-50 dark:bg-default-100 border border-default-200 dark:border-default-200 rounded-xl px-4 text-sm font-bold text-default-900 dark:text-default-100 focus:outline-none focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all placeholder:text-default-400 dark:placeholder:text-default-500" 
                  placeholder="Enter department name" 
                  required
                />
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-default-100 dark:border-default-100 bg-default-50/50 dark:bg-default-100/50 flex items-center justify-end gap-3">
            <button 
              type="button"
              onClick={onClose}
              className="h-11 px-6 text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-widest hover:bg-default-100 dark:hover:bg-default-200 rounded-xl transition-all active:scale-95"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="h-11 px-8 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all active:scale-95"
            >
              Update Department
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditDepartment;
