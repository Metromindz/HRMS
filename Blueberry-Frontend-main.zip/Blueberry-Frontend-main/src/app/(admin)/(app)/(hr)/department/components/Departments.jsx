import { LuChevronLeft, LuChevronRight, LuPencil, LuPlus, LuTrash2 } from 'react-icons/lu';

const Departments = ({ departments, pagination, loading, canCreate, canEdit, canDelete, onAdd, onEdit, onDelete, onPageChange }) => {
  const displayDepartments = departments || [];

  const handlePrevious = () => {
    if (pagination?.page > 1) onPageChange?.(pagination.page - 1);
  };
  
  const handleNext = () => {
    if (pagination?.page < pagination?.totalPages) onPageChange?.(pagination.page + 1);
  };
  return (
    <div className="bg-white dark:bg-default-50 border border-default-200 dark:border-default-100 rounded-3xl overflow-hidden animate-in zoom-in-95 duration-300">
      <div className="p-6 flex flex-wrap items-center justify-between gap-4 border-b border-default-200 dark:border-default-100 sticky top-0 z-20 bg-white/80 dark:bg-default-50/80 backdrop-blur-md">
        <div className="flex flex-col">
          <h4 className="text-xl font-black text-default-900 dark:text-default-100 uppercase tracking-tight">Departments</h4>
          <p className="text-[10px] font-bold text-default-500 dark:text-default-400 uppercase tracking-widest px-1">Manage and organize company departments</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {canCreate && (
            <button
              onClick={onAdd}
              className="h-11 px-6 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all flex items-center gap-2 active:scale-95"
            >
              <LuPlus className="size-4" />
              Add Department
            </button>
          )}
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full">
          <thead>
            <tr className="bg-default-50 dark:bg-default-100">
              <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-[0.2em]">#</th>
              <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-[0.2em]">Department Name</th>
              <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-[0.2em]">Employees Count</th>
              <th className="py-4 px-6 text-right text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-[0.2em]">Actions</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-default-100 dark:divide-default-200 bg-white dark:bg-default-50">
            {loading ? (
              <tr>
                <td colSpan="4" className="py-20 text-center">
                  <div className="flex flex-col items-center justify-center gap-3">
                    <div className="size-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                    <p className="text-sm font-black text-default-400 uppercase tracking-widest">Loading departments...</p>
                  </div>
                </td>
              </tr>
            ) : displayDepartments.length === 0 ? (
              <tr>
                <td colSpan="4" className="py-20 text-center">
                  <div className="flex flex-col items-center justify-center gap-3">
                    <div className="size-16 bg-default-50 dark:bg-default-100 rounded-2xl flex items-center justify-center">
                      <LuPlus className="size-8 text-default-300 dark:text-default-500" />
                    </div>
                    <p className="text-sm font-black text-default-400 uppercase tracking-widest">No departments found</p>
                  </div>
                </td>
              </tr>
            ) : (
              displayDepartments.map((dept, index) => (
                <tr key={dept._id} className="hover:bg-default-50/50 dark:hover:bg-default-100/50 transition-colors group">
                  <td className="py-4 px-6">
                    <span className="text-xs font-bold text-default-400 dark:text-default-500">
                      {(((pagination?.page || 1) - 1) * (pagination?.limit || 10) + index + 1).toString().padStart(2, '0')}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-black text-default-900 dark:text-default-100 uppercase tracking-tight">{dept.name}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-[10px] font-black uppercase tracking-widest ring-4 ring-primary/5">
                      {dept.userCount || 0} {dept.userCount === 1 ? 'Employee' : 'Employees'}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <div className="flex items-center justify-end gap-3 transition-all duration-300">
                      {canEdit && (
                        <button
                          onClick={() => onEdit(dept)}
                          className="size-10 flex items-center justify-center bg-white dark:bg-default-100 border border-default-200 dark:border-default-100 rounded-xl text-default-600 dark:text-default-400 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                          title="Edit"
                        >
                          <LuPencil className="size-4" />
                        </button>
                      )}
                      {canDelete && (
                        <button
                          onClick={() => onDelete(dept)}
                          className="size-10 flex items-center justify-center bg-white dark:bg-default-100 border border-default-200 dark:border-default-100 rounded-xl text-danger hover:bg-danger hover:text-white hover:border-danger transition-all active:scale-90"
                          title="Delete"
                        >
                          <LuTrash2 className="size-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-between p-6 border-t border-default-100 dark:border-default-200 bg-default-50/50 dark:bg-default-100/50 gap-4">
        <div className="text-[10px] font-black text-default-500 dark:text-default-400 uppercase tracking-[0.2em]">
          Showing <span className="text-default-900 dark:text-default-100">{((pagination?.page || 1) - 1) * (pagination?.limit || 10) + 1}</span> to <span className="text-default-900 dark:text-default-100">{Math.min((pagination?.page || 1) * (pagination?.limit || 10), pagination?.total || 0)}</span> of <span className="text-default-900 dark:text-default-100">{pagination?.total || 0}</span> Results
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center bg-white dark:bg-default-100 border border-default-200 dark:border-default-200 rounded-xl p-1">
            <button
              type="button"
              className="size-10 flex items-center justify-center rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 dark:hover:bg-default-200 text-default-600 dark:text-default-400 active:scale-90"
              disabled={pagination?.page === 1}
              onClick={handlePrevious}
            >
              <LuChevronLeft className="size-4" />
            </button>
            <div className="w-px h-4 bg-default-200 dark:bg-default-300 mx-1" />
            <button
              type="button"
              className="size-10 flex items-center justify-center rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 dark:hover:bg-default-200 text-default-600 dark:text-default-400 active:scale-90"
              disabled={pagination?.page === pagination?.totalPages}
              onClick={handleNext}
            >
              <LuChevronRight className="size-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Departments;
