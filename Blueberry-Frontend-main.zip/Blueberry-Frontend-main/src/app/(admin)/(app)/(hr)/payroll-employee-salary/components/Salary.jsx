import { Link } from 'react-router';
import { useState, useEffect, useMemo } from 'react';
import { LuPlus, LuSearch, LuCalendar, LuTrendingUp, LuDollarSign, LuUsers } from 'react-icons/lu';
import api from '../../../../../../config/api.js';
import { useAuth } from '@/context/AuthContext';
import { getUploadUrl } from '@/utils/uploadUrl';

const Salary = () => {
  const { hasPermission } = useAuth();
  const [payslips, setPayslips] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [selectedMonth, setSelectedMonth] = useState(
    new Date().toLocaleString('default', { month: 'long' })
  );
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [searchTerm, setSearchTerm] = useState('');

  const canGenerate = hasPermission('payroll.generate.view');

  // Calculate stats based on filtered payslips
  const stats = useMemo(() => {
    const totalNetPay = payslips.reduce((acc, curr) => acc + (curr.netPay || 0), 0);
    const totalEarnings = payslips.reduce((acc, curr) => acc + (curr.totalEarnings || 0), 0);
    const uniqueEmployees = new Set(payslips.map(p => p.employeeId)).size;

    return [
      {
        label: 'Total Net Pay',
        value: `$${totalNetPay.toLocaleString('en-IN')}`,
        icon: LuDollarSign,
        color: 'primary',
        trend: 'Total disbursement'
      },
      {
        label: 'Gross Earnings',
        value: `$${totalEarnings.toLocaleString('en-IN')}`,
        icon: LuTrendingUp,
        color: 'success',
        trend: 'Before deductions'
      },
      {
        label: 'Employees Paid',
        value: uniqueEmployees,
        icon: LuUsers,
        color: 'warning',
        trend: 'Distinct records'
      },
      {
        label: 'Payroll Period',
        value: `${selectedMonth.substring(0, 3)} ${selectedYear}`,
        icon: LuCalendar,
        color: 'info',
        trend: 'Current selection'
      }
    ];
  }, [payslips, selectedMonth, selectedYear]);

  const fetchPayslips = async () => {
    try {
      setLoading(true);
      setError('');

      const params = new URLSearchParams();
      if (searchTerm.trim()) params.append('search', searchTerm.trim());
      if (selectedMonth && selectedMonth !== 'All Months') params.append('month', selectedMonth);
      if (selectedYear) params.append('year', selectedYear.toString());

      const response = await api.get(`/payslip?${params.toString()}`);

      if (response.data.success) {
        setPayslips(response.data.data || []);
      } else {
        setError(response.data.message || 'Failed to fetch payslips');
        setPayslips([]);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to fetch payslip records');
      setPayslips([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPayslips();
  }, [searchTerm, selectedMonth, selectedYear]);

  const formatCurrency = amount => {
    return `$${amount.toLocaleString('en-IN')}`;
  };

  const EmployeeRow = ({ payslip }) => (
    <tr className="hover:bg-default-50/50 transition-colors group">
      <td className="py-4 px-6">
        <span className="text-[11px] font-bold text-default-500 uppercase tracking-widest">
          {payslip.employeeId}
        </span>
      </td>
      <td className="py-4 px-6">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20 overflow-hidden group-hover:scale-110 transition-transform duration-300">
            {payslip.employee?.documents?.photograph || payslip.employee?.employeePersonal?.profilePhoto ? (
              <img src={getUploadUrl(payslip.employee.documents?.photograph || payslip.employee.employeePersonal?.profilePhoto)} alt={payslip.employeeName} className="h-full w-full object-cover" />
            ) : (
              <span className="text-sm font-bold text-primary uppercase">
                {payslip.employeeName.charAt(0)}
              </span>
            )}
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold text-default-900 leading-tight mb-0.5">{payslip.employeeName}</span>
            <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">{payslip.designation}</span>
          </div>
        </div>
      </td>
      <td className="py-4 px-6">
        <span className="text-[11px] font-bold text-default-600 uppercase tracking-widest">{payslip.department}</span>
      </td>
      <td className="py-4 px-6">
        <div className="px-3 py-1.5 rounded-lg bg-default-100 border border-default-200 text-[10px] font-black text-default-600 uppercase tracking-widest w-fit">
          {payslip.payrollMonth} {payslip.payrollYear}
        </div>
      </td>
      <td className="py-4 px-6">
        <span className="text-sm font-bold text-default-900">{formatCurrency(payslip.totalEarnings)}</span>
      </td>
      <td className="py-4 px-6">
        <span className="text-sm font-bold text-primary">{formatCurrency(payslip.netPay)}</span>
      </td>
      <td className="py-4 px-6 text-right">
        <Link
          to={`/payroll-payslip/${payslip.employeeId}/${payslip.payrollMonth}`}
          className="h-9 px-4 inline-flex items-center justify-center rounded-xl bg-primary/10 text-primary border border-primary/20 font-bold text-[10px] uppercase tracking-widest hover:bg-primary hover:text-white transition-all active:scale-95"
        >
          View Payslip
        </Link>
      </td>
    </tr>
  );

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5">
        {stats.map((stat, idx) => (
          <div key={idx} className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300 hover:shadow-sm">
            <div className="flex items-center gap-4">
              <div className={`size-12 rounded-xl bg-${stat.color}/10 flex items-center justify-center text-${stat.color} group-hover:scale-110 transition-transform duration-300`}>
                <stat.icon className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">{stat.label}</div>
                <div className="text-xl font-black text-default-900 leading-none">{stat.value}</div>
                <div className="text-[10px] font-medium text-default-400 mt-1">{stat.trend}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white border border-default-200 rounded-2xl overflow-hidden shadow-sm">
        {/* Header and Filters */}
        <div className="p-6 border-b border-default-200 bg-default-50/50">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="flex flex-col gap-1">
              <h4 className="text-xl font-black text-default-900 uppercase tracking-tight">Salary List</h4>
              <p className="text-xs font-bold text-default-500 uppercase tracking-widest">Employee payroll and disbursement history</p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <div className="relative group min-w-[250px]">
                <input
                  type="text"
                  className="w-full bg-white border-default-200 rounded-xl ps-11 pe-4 py-2.5 text-sm font-bold focus:border-primary focus:ring-primary transition-all group-hover:border-default-300 shadow-sm"
                  placeholder="Search ID or Name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="absolute inset-y-0 start-0 flex items-center ps-4 text-default-400 group-hover:text-primary transition-colors">
                  <LuSearch className="size-4" />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <select
                  className="appearance-none bg-white border-default-200 rounded-xl px-4 py-2.5 pe-10 text-sm font-bold focus:border-primary focus:ring-primary transition-all group-hover:border-default-300 cursor-pointer shadow-sm min-w-[140px]"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                >
                  <option value="All Months">All Months</option>
                  {Array.from({ length: 12 }, (_, i) => {
                    const monthName = new Date(0, i).toLocaleString('default', { month: 'long' });
                    return (
                      <option key={monthName} value={monthName}>{monthName.toUpperCase()}</option>
                    );
                  })}
                </select>

                <select
                  className="appearance-none bg-white border-default-200 rounded-xl px-4 py-2.5 pe-10 text-sm font-bold focus:border-primary focus:ring-primary transition-all group-hover:border-default-300 cursor-pointer shadow-sm min-w-[110px]"
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(Number(e.target.value))}
                >
                  {Array.from({ length: 5 }, (_, i) => {
                    const year = new Date().getFullYear() - 2 + i;
                    return (
                      <option key={year} value={year}>{year}</option>
                    );
                  })}
                </select>
              </div>

              {canGenerate && (
                <>
                  <div className="h-8 w-px bg-default-200 mx-1 hidden lg:block" />
                  <Link
                    to="/create-payslip"
                    className="h-11 px-6 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all flex items-center gap-2 active:scale-95 shadow-sm shadow-primary/20"
                  >
                    <LuPlus className="size-4" />
                    Generate Payslip
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Table Section */}
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-default-50/50 border-b border-default-200">
                <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Employee ID</th>
                <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Employee Info</th>
                <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Department</th>
                <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Payroll Period</th>
                <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Total Earnings</th>
                <th className="py-4 px-6 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Net Pay</th>
                <th className="py-4 px-6 text-right text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-default-100">
              {loading ? (
                <tr>
                  <td colSpan="7" className="py-20 text-center">
                    <div className="flex flex-col items-center justify-center gap-3">
                      <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
                      <p className="text-sm font-black text-default-400 uppercase tracking-widest">Fetching records...</p>
                    </div>
                  </td>
                </tr>
              ) : payslips.length > 0 ? (
                payslips.map(payslip => <EmployeeRow key={payslip._id} payslip={payslip} />)
              ) : (
                <tr>
                  <td colSpan="7" className="py-20 text-center">
                    <div className="flex flex-col items-center justify-center gap-4">
                      <div className="size-16 bg-default-50 rounded-2xl flex items-center justify-center">
                        <LuSearch className="size-8 text-default-300" />
                      </div>
                      <div className="flex flex-col items-center gap-1">
                        <p className="text-base font-bold text-default-900">No Records Found</p>
                        <p className="text-sm text-default-500">Try adjusting your filters or search term</p>
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {error && (
          <div className="mx-6 my-4 p-4 rounded-xl bg-danger/10 border border-danger/20 text-danger text-[11px] font-bold uppercase tracking-widest flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
            <LuTrendingUp className="size-4 rotate-180" />
            {error}
          </div>
        )}
      </div>
    </div>
  );
};

export default Salary;
