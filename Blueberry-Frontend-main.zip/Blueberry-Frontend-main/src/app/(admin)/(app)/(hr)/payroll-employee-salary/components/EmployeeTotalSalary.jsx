import { useState, useEffect, useMemo } from 'react';
import { LuWallet, LuPercent, LuGift, LuTrendingUp, LuShieldCheck } from 'react-icons/lu';
import api from '../../../../../../config/api.js';

const EmployeeTotalSalary = () => {
  const [payslips, setPayslips] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAll = async () => {
      try {
        setLoading(true);
        const response = await api.get('/payslip');
        if (response.data.success) {
          setPayslips(response.data.data || []);
        }
      } catch {
        setPayslips([]);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  const formatCurrency = (amount) =>
    `₹${Number(amount || 0).toLocaleString('en-IN')}`;

  const aggregated = useMemo(() => {
    let totalSalary = 0;
    let pfDeductions = 0;
    let bonusPaid = 0;
    let incentives = 0;
    let esiPaid = 0;

    for (const slip of payslips) {
      totalSalary += slip.netPay || 0;

      for (const d of slip.deductions || []) {
        const key = (d.key || '').toLowerCase();
        if (key === 'pf') pfDeductions += d.value || 0;
        if (key === 'esi') esiPaid += d.value || 0;
      }

      for (const e of slip.earnings || []) {
        const key = (e.key || '').toLowerCase();
        if (key.includes('bonus')) bonusPaid += e.value || 0;
        if (key.includes('incentive')) incentives += e.value || 0;
      }
    }

    return { totalSalary, pfDeductions, bonusPaid, incentives, esiPaid };
  }, [payslips]);

  const stats = [
    {
      title: 'Total Salary',
      value: formatCurrency(aggregated.totalSalary),
      icon: LuWallet,
      color: 'text-primary',
      bg: 'bg-primary/10',
      trend: 'Total dispersed'
    },
    {
      title: 'PF Deductions',
      value: formatCurrency(aggregated.pfDeductions),
      icon: LuPercent,
      color: 'text-danger',
      bg: 'bg-danger/10',
      trend: 'Total PF'
    },
    {
      title: 'Bonus Paid',
      value: formatCurrency(aggregated.bonusPaid),
      icon: LuGift,
      color: 'text-success',
      bg: 'bg-success/10',
      trend: 'Performance'
    },
    {
      title: 'Incentives',
      value: formatCurrency(aggregated.incentives),
      icon: LuTrendingUp,
      color: 'text-warning',
      bg: 'bg-warning/10',
      trend: 'Sales/Target'
    },
    {
      title: 'ESI Paid',
      value: formatCurrency(aggregated.esiPaid),
      icon: LuShieldCheck,
      color: 'text-info',
      bg: 'bg-info/10',
      trend: 'Insurance'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 mb-8">
      {stats.map((stat, idx) => (
        <div key={idx} className="group bg-white border border-default-200 rounded-2xl p-5 transition-all duration-300 relative overflow-hidden">
          <div className={`absolute top-0 left-0 w-1 h-full ${stat.color.replace('text-', 'bg-')} opacity-0 group-hover:opacity-100 transition-opacity`} />
          <div className="flex items-center gap-4">
            <div className={`size-12 flex items-center justify-center rounded-xl ${stat.bg} ${stat.color} group-hover:scale-110 transition-transform`}>
              <stat.icon className="size-6" />
            </div>
            <div className="flex flex-col">
              {loading ? (
                <div className="h-5 w-20 bg-default-100 rounded animate-pulse mb-1" />
              ) : (
                <span className="text-xl font-black text-default-900 leading-none mb-1">{stat.value}</span>
              )}
              <span className="text-[10px] font-black text-default-500 uppercase tracking-widest">{stat.title}</span>
            </div>
          </div>
          <div className="mt-4 flex items-center justify-between border-t border-default-100 pt-3">
            <span className="text-[10px] font-bold text-default-400 uppercase tracking-wider">{stat.trend}</span>
            <div className={`size-1.5 rounded-full ${stat.color.replace('text-', 'bg-')} animate-pulse`} />
          </div>
        </div>
      ))}
    </div>
  );
};

export default EmployeeTotalSalary;