import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import DeleteModal from '../../designation/components/DeleteModal';
import AddDesignation from '../../designation/components/AddDesignation';
import Designations from '../../designation/components/Designations';
import EditDesignation from '../../designation/components/EditDesignation';
import api from '@/config/api';
import { LuAward, LuCircleCheck, LuLayoutGrid, LuShieldAlert } from 'react-icons/lu';
import { toast } from 'react-hot-toast';

const DesignationsTab = () => {
  const { hasPermission } = useAuth();
  const [designations, setDesignations] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDesignation, setSelectedDesignation] = useState(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });  

  // Pagination State
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 1,
  });

  // Permission checks
  const canCreate = hasPermission('designation.create');
  const canEdit = hasPermission('designation.edit');
  const canDelete = hasPermission('designation.delete');

  // Clear message after 3 seconds
  useEffect(() => {
    if (message.text) {
      const timer = setTimeout(() => setMessage({ type: '', text: '' }), 3000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  // Fetch designations on component mount
  useEffect(() => {
    fetchDesignations(pagination.page);
    fetchDepartments();
  }, [pagination.page]);

  const fetchDesignations = async (page = pagination.page) => {
    try {
      setLoading(true);
      const response = await api.get(`/designation?page=${page}&limit=${pagination.limit}`);
      const data = response.data;

      setDesignations(data.designations || []);
      
      const paginationData = {
        total: data.total ,
        totalPages: data.totalPages ,
        page: data.page,
        limit: 10,
      };
      setPagination(prev => ({
        ...prev,
        ...paginationData,
      }));
    } catch (error) {
      console.error('Failed to fetch designations:', error);
      setMessage({ type: 'error', text: 'Failed to fetch designations' });
    } finally {
      setLoading(false);
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await api.get('/department?limit=100');
      setDepartments(response.data.departments || []);
    } catch (error) {
      console.error('Failed to fetch departments:', error);
    }
  };

  const handleAddDesignation = async designationData => {
    try {
      const response = await api.post('/designation', designationData);
      if (response.status === 200 || response.status === 201) {
        await fetchDesignations(1);
        setIsAddModalOpen(false);
        setMessage({ type: 'success', text: 'Designation added successfully!' });
        toast.success('Designation added successfully');
      }
    } catch (error) {
      console.error('Failed to add designation:', error);
      setMessage({
        type: 'error',
        text: error?.response?.data?.message || 'An unknown error occurred.',
      });
      toast.error(error?.response?.data?.message || 'Failed to add designation');
      setIsAddModalOpen(false);
    }
  };

  const handleEditDesignation = async designationData => {
    try {
      const response = await api.put(`/designation/${designationData.id}`, designationData);
      if (response.status === 200) {
        await fetchDesignations(pagination.page);
        setIsEditModalOpen(false);
        setSelectedDesignation(null);
        setMessage({ type: 'success', text: 'Designation updated successfully!' });
        toast.success('Designation updated successfully');
      }
    } catch (error) {
      console.error('Failed to edit designation:', error);
      setMessage({ type: 'error', text: 'Failed to update designation' });
      toast.error(error?.response?.data?.message || 'Failed to update designation');
    }
  };

  const handleDeleteDesignation = async id => {
    try {
      const response = await api.delete(`/designation/${id}`);
      if (response.status === 200) {
        await fetchDesignations(pagination.page);
        setIsDeleteModalOpen(false);
        setSelectedDesignation(null);
        setMessage({ type: 'success', text: 'Designation deleted successfully!' });
        toast.success('Designation deleted successfully');
      }
    } catch (error) {
      console.error('Failed to delete designation:', error);
      setMessage({ type: 'error', text: 'Failed to delete designation' });
      toast.error(error?.response?.data?.message || 'Failed to delete designation');
    }
  };

  const handlePageChange = newPage => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      setPagination(prev => ({ ...prev, page: newPage }));
    }
  };

  const stats = useMemo(() => {
    const total = pagination.total || 0;
    const active = designations.filter(d => d.status === 'active').length;
    const uniqueDepts = new Set(designations.map(d => d.department?._id || d.department)).size;
    const inactive = designations.filter(d => d.status === 'inactive').length;
    return { total, active, uniqueDepts, inactive };
  }, [designations, pagination.total]);

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5 mb-6">
        <div className="group bg-white dark:bg-default-50 rounded-xl p-5 border border-default-200 dark:border-default-100 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
              <LuAward className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Total Designations</div>
              <div className="text-2xl font-black text-default-900 dark:text-default-100 leading-none">{stats.total}</div>
            </div>
          </div>
        </div>

        <div className="group bg-white dark:bg-default-50 rounded-xl p-5 border border-default-200 dark:border-default-100 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-success/10 flex items-center justify-center text-success group-hover:scale-110 transition-transform duration-300">
              <LuCircleCheck className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Active</div>
              <div className="text-2xl font-black text-default-900 dark:text-default-100 leading-none">{stats.active}</div>
            </div>
          </div>
        </div>

        <div className="group bg-white dark:bg-default-50 rounded-xl p-5 border border-default-200 dark:border-default-100 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-warning/10 flex items-center justify-center text-warning group-hover:scale-110 transition-transform duration-300">
              <LuLayoutGrid className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Departments</div>
              <div className="text-2xl font-black text-default-900 dark:text-default-100 leading-none">{stats.uniqueDepts}</div>
            </div>
          </div>
        </div>

        <div className="group bg-white dark:bg-default-50 rounded-xl p-5 border border-default-200 dark:border-default-100 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-danger/10 flex items-center justify-center text-danger group-hover:scale-110 transition-transform duration-300">
              <LuShieldAlert className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Inactive</div>
              <div className="text-2xl font-black text-default-900 dark:text-default-100 leading-none">{stats.inactive}</div>
            </div>
          </div>
        </div>
      </div>

      {message.text && (
        <div
          className={`mb-4 p-4 rounded-md ${
            message.type === 'success'
              ? 'bg-green-100 border border-green-400 text-green-700'
              : 'bg-red-100 border border-red-400 text-red-700'
          }`}
        >
          {message.text}
        </div>
      )}

      <Designations
        designations={designations}
        loading={loading}
        canCreate={canCreate}
        canEdit={canEdit}
        canDelete={canDelete}
        onAdd={() => setIsAddModalOpen(true)}
        onEdit={designation => {
          setSelectedDesignation(designation);
          setIsEditModalOpen(true);
        }}
        onDelete={designation => {
          setSelectedDesignation(designation);
          setIsDeleteModalOpen(true);
        }}
        pagination={pagination}
        onPageChange={handlePageChange}
      />

      {canCreate && (
        <AddDesignation
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onSave={handleAddDesignation}
          departments={departments}
        />
      )}

      {canEdit && (
        <EditDesignation
          isOpen={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            setSelectedDesignation(null);
          }}
          onSave={handleEditDesignation}
          designation={selectedDesignation}
          departments={departments}
        />
      )}

      {canDelete && (
        <DeleteModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            setIsDeleteModalOpen(false);
            setSelectedDesignation(null);
          }}
          onConfirm={() => selectedDesignation && handleDeleteDesignation(selectedDesignation._id)}
          designation={selectedDesignation}
        />
      )}
    </div>
  );
};

export default DesignationsTab;
