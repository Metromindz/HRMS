import { useState } from 'react';
import ReactQuill from 'react-quill-new';
import 'react-quill-new/dist/quill.snow.css';
import { LuX, LuSave, LuPaperclip } from 'react-icons/lu';
import api from '@/config/api';
import toast from 'react-hot-toast';
import Flatpickr from 'react-flatpickr';

/**
 * CreateAnnouncement Component
 * 
 * Modal form for creating new announcements.
 * 
 * Features:
 * - Rich Text Editor: Uses ReactQuill for description.
 * - Dynamic Targeting: Conditional fields based on selected audience (Department/Role).
 * - Date Picking: Flatpickr for publish/expiry dates.
 */
const CreateAnnouncement = ({ isOpen, onClose, onSave, departments }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'General',
    priority: 'Medium',
    targetAudience: {
      type: 'All',
      department: '',
      role: ''
    },
    publishDate: new Date(),
    expiryDate: null,
    attachments: [] // Placeholder for now
  });

  const [loading, setLoading] = useState(false);
  const [fieldErrors, setFieldErrors] = useState({});

  // Configuration options
  const categories = ['Policy', 'Event', 'Holiday', 'Urgent', 'General'];
  const priorities = ['High', 'Medium', 'Low'];
  const audienceTypes = ['All', 'Department', 'Role'];
  const roles = ['admin', 'hr', 'employee', 'manager']; // Assuming these roles exist

  const clearFieldError = (path) => {
    if (!fieldErrors[path]) return;
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next[path];
      return next;
    });
  };

  const getPlainTextFromHtml = (html) => {
    if (!html) return '';
    return String(html)
      .replace(/<[^>]*>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const validate = () => {
    const errors = {};

    const title = formData.title?.trim() || '';
    if (!title) errors.title = 'Title is required';
    else if (title.length < 3) errors.title = 'Title must be at least 3 characters';
    else if (title.length > 120) errors.title = 'Title must be at most 120 characters';

    const descriptionText = getPlainTextFromHtml(formData.description);
    if (!descriptionText) errors.description = 'Description is required';
    else if (descriptionText.length > 5000) errors.description = 'Description is too long';

    if (!categories.includes(formData.category)) errors.category = 'Invalid category';
    if (!priorities.includes(formData.priority)) errors.priority = 'Invalid priority';
    if (!audienceTypes.includes(formData.targetAudience?.type)) errors['targetAudience.type'] = 'Invalid audience type';

    if (formData.targetAudience?.type === 'Department') {
      if (!formData.targetAudience?.department) errors['targetAudience.department'] = 'Department is required';
    }
    if (formData.targetAudience?.type === 'Role') {
      if (!formData.targetAudience?.role) errors['targetAudience.role'] = 'Role is required';
      else if (!roles.includes(formData.targetAudience.role)) errors['targetAudience.role'] = 'Invalid role';
    }

    const publishDate = formData.publishDate ? new Date(formData.publishDate) : null;
    if (publishDate && Number.isNaN(publishDate.getTime())) errors.publishDate = 'Publish date is invalid';

    const expiryDate = formData.expiryDate ? new Date(formData.expiryDate) : null;
    if (expiryDate && Number.isNaN(expiryDate.getTime())) errors.expiryDate = 'Expiry date is invalid';
    if (publishDate && expiryDate && expiryDate < publishDate) errors.expiryDate = 'Expiry date must be after publish date';

    setFieldErrors(errors);
    const firstError = Object.values(errors)[0];
    if (firstError) toast.error(firstError);
    return Object.keys(errors).length === 0;
  };

  /**
   * Handle form field changes.
   * Supports nested state updates for 'targetAudience'.
   */
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      clearFieldError(`${parent}.${child}`);
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: value
        }
      }));
    } else {
      clearFieldError(name);
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleDescriptionChange = (value) => {
    clearFieldError('description');
    setFormData(prev => ({ ...prev, description: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);

    // Create a deep copy of formData to modify for the payload
    const payload = JSON.parse(JSON.stringify(formData));
    payload.title = payload.title?.trim();

    // Sanitize targetAudience
    if (payload.targetAudience.type === 'All') {
      delete payload.targetAudience.department;
      delete payload.targetAudience.role;
    } else if (payload.targetAudience.type === 'Department') {
      delete payload.targetAudience.role;
      // Ensure department is not empty string (though required prop should handle this)
      if (!payload.targetAudience.department) delete payload.targetAudience.department;
    } else if (payload.targetAudience.type === 'Role') {
      delete payload.targetAudience.department;
      // Ensure role is not empty string
      if (!payload.targetAudience.role) delete payload.targetAudience.role;
    }

    try {
      await api.post('/announcements', payload);
      toast.success('Announcement created successfully');
      onSave();
      onClose();
    } catch (error) {
      console.error(error);
      toast.error(error.response?.data?.message || 'Error creating announcement');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">

        {/* Header */}
        <div className="px-6 py-4 border-b border-default-100 flex items-center justify-between bg-default-50/50">
          <div>
            <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">Create Announcement</h3>
            <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Publish new updates to the team</p>
          </div>
          <button
            onClick={onClose}
            className="size-8 flex items-center justify-center rounded-lg bg-white border border-default-200 text-default-500 hover:text-danger hover:border-danger transition-all"
          >
            <LuX className="size-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto custom-scrollbar">
          <form onSubmit={handleSubmit} className="space-y-6">

            {/* Title */}
            <div>
              <label className="block text-xs font-bold text-default-700 uppercase tracking-wide mb-2">Title <span className="text-danger">*</span></label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleChange}
                required
                className={`w-full px-4 py-3 rounded-xl border bg-default-50 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-semibold ${fieldErrors.title ? 'border-danger' : 'border-default-200'}`}
                placeholder="Enter announcement title"
              />
              {fieldErrors.title && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.title}</div>}
            </div>

            {/* Description (Rich Text) */}
            <div>
              <label className="block text-xs font-bold text-default-700 uppercase tracking-wide mb-2">Description <span className="text-danger">*</span></label>
              <div className={`bg-white rounded-xl border overflow-hidden ${fieldErrors.description ? 'border-danger' : 'border-default-200'}`}>
                <ReactQuill
                  theme="snow"
                  value={formData.description}
                  onChange={handleDescriptionChange}
                  className="h-64 mb-12"
                  modules={{
                    toolbar: [
                      [{ 'header': [1, 2, false] }],
                      ['bold', 'italic', 'underline', 'strike', 'blockquote'],
                      [{ 'list': 'ordered' }, { 'list': 'bullet' }, { 'indent': '-1' }, { 'indent': '+1' }],
                      ['link', 'image'],
                      ['clean']
                    ],
                  }}
                />
              </div>
              {fieldErrors.description && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.description}</div>}
            </div>

            {/* Grid for other fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

              {/* Category */}
              <div>
                <label className="block text-xs font-bold text-default-700 uppercase tracking-wide mb-2">Category <span className="text-danger">*</span></label>
                <select
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 rounded-xl border bg-default-50 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-semibold ${fieldErrors.category ? 'border-danger' : 'border-default-200'}`}
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
                {fieldErrors.category && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.category}</div>}
              </div>

              {/* Priority */}
              <div>
                <label className="block text-xs font-bold text-default-700 uppercase tracking-wide mb-2">Priority <span className="text-danger">*</span></label>
                <select
                  name="priority"
                  value={formData.priority}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 rounded-xl border bg-default-50 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-semibold ${fieldErrors.priority ? 'border-danger' : 'border-default-200'}`}
                >
                  {priorities.map(p => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
                {fieldErrors.priority && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.priority}</div>}
              </div>

              {/* Target Audience Type */}
              <div>
                <label className="block text-xs font-bold text-default-700 uppercase tracking-wide mb-2">Target Audience <span className="text-danger">*</span></label>
                <select
                  name="targetAudience.type"
                  value={formData.targetAudience.type}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 rounded-xl border bg-default-50 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-semibold ${fieldErrors['targetAudience.type'] ? 'border-danger' : 'border-default-200'}`}
                >
                  {audienceTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
                {fieldErrors['targetAudience.type'] && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors['targetAudience.type']}</div>}
              </div>

              {/* Specific Audience Selection */}
              {formData.targetAudience.type === 'Department' && (
                <div>
                  <label className="block text-xs font-bold text-default-700 uppercase tracking-wide mb-2">Select Department <span className="text-danger">*</span></label>
                  <select
                    name="targetAudience.department"
                    value={formData.targetAudience.department}
                    onChange={handleChange}
                    required
                    className={`w-full px-4 py-3 rounded-xl border bg-default-50 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-semibold ${fieldErrors['targetAudience.department'] ? 'border-danger' : 'border-default-200'}`}
                  >
                    <option value="">Select Department</option>
                    {departments?.map(dept => (
                      <option key={dept._id} value={dept._id}>{dept.name}</option>
                    ))}
                  </select>
                  {fieldErrors['targetAudience.department'] && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors['targetAudience.department']}</div>}
                </div>
              )}

              {formData.targetAudience.type === 'Role' && (
                <div>
                  <label className="block text-xs font-bold text-default-700 uppercase tracking-wide mb-2">Select Role <span className="text-danger">*</span></label>
                  <select
                    name="targetAudience.role"
                    value={formData.targetAudience.role}
                    onChange={handleChange}
                    required
                    className={`w-full px-4 py-3 rounded-xl border bg-default-50 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-semibold ${fieldErrors['targetAudience.role'] ? 'border-danger' : 'border-default-200'}`}
                  >
                    <option value="">Select Role</option>
                    {roles.map(role => (
                      <option key={role} value={role}>{role}</option>
                    ))}
                  </select>
                  {fieldErrors['targetAudience.role'] && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors['targetAudience.role']}</div>}
                </div>
              )}

              {/* Publish Date */}
              <div>
                <label className="block text-xs font-bold text-default-700 uppercase tracking-wide mb-2">Publish Date</label>
                <Flatpickr
                  className={`w-full px-4 py-3 rounded-xl border bg-default-50 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-semibold ${fieldErrors.publishDate ? 'border-danger' : 'border-default-200'}`}
                  value={formData.publishDate}
                  onChange={([date]) => {
                    clearFieldError('publishDate');
                    setFormData(prev => ({ ...prev, publishDate: date }));
                  }}
                  options={{ dateFormat: 'Y-m-d H:i' }}
                />
                {fieldErrors.publishDate && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.publishDate}</div>}
              </div>

              {/* Expiry Date */}
              <div>
                <label className="block text-xs font-bold text-default-700 uppercase tracking-wide mb-2">Expiry Date (Optional)</label>
                <Flatpickr
                  className={`w-full px-4 py-3 rounded-xl border bg-default-50 focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-semibold ${fieldErrors.expiryDate ? 'border-danger' : 'border-default-200'}`}
                  value={formData.expiryDate}
                  onChange={([date]) => {
                    clearFieldError('expiryDate');
                    setFormData(prev => ({ ...prev, expiryDate: date }));
                  }}
                  options={{ dateFormat: 'Y-m-d' }}
                  placeholder="Select expiry date"
                />
                {fieldErrors.expiryDate && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.expiryDate}</div>}
              </div>

            </div>

            {/* Attachments Placeholder */}
            <div>
              <label className="block text-xs font-bold text-default-700 uppercase tracking-wide mb-2">Attachments</label>
              <div className="border-2 border-dashed border-default-200 rounded-xl p-6 flex flex-col items-center justify-center text-default-400 hover:border-primary hover:text-primary transition-all cursor-pointer bg-default-50">
                <LuPaperclip className="size-8 mb-2" />
                <span className="text-sm font-semibold">Click to upload files (Coming Soon)</span>
              </div>
            </div>

          </form>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-default-100 bg-default-50/50 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl text-xs font-bold text-default-500 hover:bg-default-100 transition-all uppercase tracking-wider"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="px-6 py-2.5 rounded-xl bg-primary text-white text-xs font-bold hover:bg-primary-600 transition-all shadow-lg shadow-primary/20 uppercase tracking-wider flex items-center gap-2"
          >
            {loading ? 'Publishing...' : <><LuSave className="size-4" /> Publish Announcement</>}
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreateAnnouncement;
