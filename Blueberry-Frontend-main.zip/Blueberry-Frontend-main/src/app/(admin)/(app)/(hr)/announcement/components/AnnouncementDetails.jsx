import { useState } from 'react';
import { LuX, LuCalendar, LuUser, LuCircleCheck, LuMegaphone } from 'react-icons/lu';
import { format } from 'date-fns';
import api from '@/config/api';
import toast from 'react-hot-toast';

const AnnouncementDetails = ({ isOpen, onClose, announcement }) => {
  const [loading, setLoading] = useState(false);

  if (!isOpen || !announcement) return null;

  const handleAcknowledge = async () => {
    setLoading(true);
    try {
      await api.post(`/announcements/${announcement._id}/acknowledge`);
      toast.success('Acknowledged successfully');
      // Update local state or re-fetch if needed
    } catch (error) {
      toast.error(error.response?.data?.message || 'Error acknowledging');
    } finally {
      setLoading(false);
    }
  };

  const priorityColor = {
    'High': 'text-danger bg-danger/10 border-danger/20',
    'Medium': 'text-warning bg-warning/10 border-warning/20',
    'Low': 'text-success bg-success/10 border-success/20'
  }[announcement.priority] || 'text-default-600 bg-default-100 border-default-200';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-300">
      <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl animate-in zoom-in-95 duration-300 border border-default-200">
        
        {/* Header */}
        <div className="relative h-32 bg-gradient-to-r from-primary/20 to-secondary/20 flex items-center justify-center">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 size-10 flex items-center justify-center rounded-full bg-white/50 hover:bg-white text-default-600 hover:text-danger transition-all backdrop-blur-md shadow-sm"
          >
            <LuX className="size-5" />
          </button>
          
          <div className="absolute -bottom-10 left-8 size-20 rounded-2xl bg-white shadow-lg p-1">
            <div className="size-full rounded-xl bg-primary/10 flex items-center justify-center text-primary">
              <LuMegaphone className="size-10" />
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="pt-14 px-8 pb-8 overflow-y-auto custom-scrollbar flex-grow">
          <div className="flex items-center gap-3 mb-4 flex-wrap">
            <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border ${priorityColor}`}>
              {announcement.priority} Priority
            </span>
            <span className="px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest bg-default-100 text-default-600 border border-default-200">
              {announcement.category}
            </span>
            <span className="text-xs font-bold text-default-400 flex items-center gap-1.5 ml-auto">
              <LuCalendar className="size-3.5" />
              {format(new Date(announcement.publishDate), 'MMM dd, yyyy')}
            </span>
          </div>

          <h2 className="text-2xl font-black text-default-900 mb-6 leading-tight">
            {announcement.title}
          </h2>

          <div 
            className="prose prose-sm max-w-none text-default-600 mb-8"
            dangerouslySetInnerHTML={{ __html: announcement.description }}
          />

          <div className="flex items-center gap-4 py-4 border-t border-default-100">
            <div className="size-10 rounded-full bg-default-100 flex items-center justify-center text-default-400">
              <LuUser className="size-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-default-500 uppercase tracking-wide">Posted By</p>
              <p className="text-sm font-bold text-default-900">{announcement.createdBy?.name || 'Admin'}</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-default-100 bg-default-50/50 flex justify-end">
          <button 
            onClick={handleAcknowledge}
            disabled={loading}
            className="px-6 py-3 rounded-xl bg-primary text-white text-xs font-bold uppercase tracking-widest hover:bg-primary-600 transition-all shadow-lg shadow-primary/20 flex items-center gap-2"
          >
            {loading ? 'Processing...' : <><LuCircleCheck className="size-4" /> Acknowledge Read</>}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AnnouncementDetails;
