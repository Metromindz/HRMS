import { useState, useEffect } from 'react';
import { LuPlus, LuSearch } from 'react-icons/lu';
import { useAuth } from '@/context/AuthContext';
import api from '@/config/api';
import AnnouncementList from './components/AnnouncementList';
import CreateAnnouncement from './components/CreateAnnouncement';
import AnnouncementDetails from './components/AnnouncementDetails';
import toast from 'react-hot-toast';

const AnnouncementPage = () => {
  const { user } = useAuth();

  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState(null);
  const [departments, setDepartments] = useState([]);
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');

  const canCreate =
    user?.role === 'superadmin' ||
    user?.role === 'hr' ||
    user?.permissions?.includes('announcement.create');

  useEffect(() => {
    fetchAnnouncements();
    if (canCreate) fetchDepartments();
  }, [canCreate]);

  const fetchAnnouncements = async () => {
    setLoading(true);
    try {
      const endpoint = canCreate ? '/announcements/all' : '/announcements';
      const res = await api.get(endpoint);
      setAnnouncements(res.data.data || []);
    } catch {
      toast.error('Failed to fetch announcements');
    } finally {
      setLoading(false);
    }
  };

  const fetchDepartments = async () => {
    try {
      const res = await api.get('/department');
      setDepartments(res.data.departments || []);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreateSave = () => {
    fetchAnnouncements();
  };

  const categories = ['All', 'Policy', 'Event', 'Holiday', 'Urgent', 'General'];

  const filteredAnnouncements = announcements.filter((a) => {
    const matchCategory = filter === 'All' || a.category === filter;
    const matchSearch =
      a.title?.toLowerCase().includes(search.toLowerCase()) ||
      a.description?.toLowerCase().includes(search.toLowerCase());
    return matchCategory && matchSearch;
  });

  return (
    <div className="w-full p-6 space-y-6 bg-gray-50 min-h-screen">

      {/* HEADER WITH GRADIENT */}
      <div className="relative overflow-hidden rounded-3xl bg-white border border-default-200 p-8  ">
        <div className="absolute top-0 right-0 -mt-16 -mr-16 size-64 bg-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -mb-16 -ml-16 size-48 bg-secondary/10 rounded-full blur-3xl"></div>

        <div className="relative flex flex-col md:flex-row justify-between gap-6 items-start md:items-center">
          <div className="flex items-center gap-5">
            <div className="p-4 bg-gradient-to-br from-primary/20 to-primary/5 text-primary rounded-2xl shadow-inner border border-primary/10">
              <span className="text-3xl">📢</span>
            </div>
            <div>
              <h1 className="text-3xl font-black text-default-900 tracking-tight mb-1">
                Announcements
              </h1>
              <p className="text-base font-medium text-default-500">
                Stay updated with the latest news, policies, and company events
              </p>
            </div>
          </div>

          {canCreate && (
            <button
              onClick={() => setIsCreateOpen(true)}
              className="px-6 py-3 bg-gradient-to-r from-primary to-primary-600 text-white font-bold rounded-xl shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-0.5 transition-all duration-300 flex items-center gap-2"
            >
              <LuPlus className="size-5" />
              <span>Create Announcement</span>
            </button>
          )}
        </div>
      </div>

      {/* SEARCH + FILTER CONTROLS */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-5 bg-white p-4 rounded-2xl border border-default-200  ">

        {/* Search */}
        <div className="relative w-full xl:w-96 group">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-default-400 group-focus-within:text-primary transition-colors">
            <LuSearch className="size-5" />
          </div>
          <input
            type="text"
            placeholder="Search announcements..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-default-50/50 border border-default-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all placeholder:text-default-400"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-default-400 uppercase tracking-widest mr-2 hidden sm:block">Filter by:</span>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-5 py-2 rounded-xl text-xs font-bold transition-all duration-300 border ${filter === cat
                  ? 'bg-default-900 text-white border-default-900 shadow-md shadow-default-900/20'
                  : 'bg-white text-default-600 border-default-200 hover:bg-default-50 hover:border-default-300'
                  }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ANNOUNCEMENT LIST */}
      <div className="relative min-h-[400px]">
        <AnnouncementList
          announcements={filteredAnnouncements}
          loading={loading}
          onView={setSelectedAnnouncement}
        />

        {/* EMPTY STATE (Overlay) */}
        {!loading && filteredAnnouncements.length === 0 && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-12 text-center bg-white/50 backdrop-blur-sm rounded-3xl z-10">
            <div className="size-20 rounded-3xl bg-default-100 flex items-center justify-center text-default-400 mb-5 shadow-inner">
              <span className="text-4xl opacity-50">📭</span>
            </div>
            <h3 className="text-xl font-black text-default-800 tracking-tight">No Announcements Found</h3>
            <p className="text-default-500 font-medium mt-2 max-w-sm">
              {search || filter !== 'All'
                ? "Try adjusting your search or filters to find what you're looking for."
                : "There are no announcements to display at this time."}
            </p>
            {(search || filter !== 'All') && (
              <button
                onClick={() => { setSearch(''); setFilter('All'); }}
                className="mt-6 px-6 py-2 bg-default-100 text-default-700 font-bold rounded-xl hover:bg-default-200 transition-colors border border-default-200  "
              >
                Clear Filters
              </button>
            )}
          </div>
        )}
      </div>

      {/* MODALS */}
      {canCreate && (
        <CreateAnnouncement
          isOpen={isCreateOpen}
          onClose={() => setIsCreateOpen(false)}
          onSave={handleCreateSave}
          departments={departments}
        />
      )}

      <AnnouncementDetails
        isOpen={!!selectedAnnouncement}
        onClose={() => setSelectedAnnouncement(null)}
        announcement={selectedAnnouncement}
      />
    </div>
  );
};

export default AnnouncementPage;
