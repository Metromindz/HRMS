import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import api from '../../../../../config/api';
import PunchDetails from './components/PunchDetails';
import PunchWorkDetails from './components/PunchWorkDetails';
import PunchWork from './components/PunchWork';

const Index = () => {
  const location = useLocation();

  // Extract user ID from session storage token
  const getUserIdFromToken = () => {
    const token = sessionStorage.getItem('token');
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.id || payload.userId || payload._id;
    } catch (error) {
      console.error('Error parsing token:', error);
      return null;
    }
  };

  const userId = getUserIdFromToken();
  const searchParams = new URLSearchParams(location.search);
  const [month, setMonth] = useState(searchParams.get('month') || new Date().getMonth() + 1);
  const [year, setYear] = useState(searchParams.get('year') || new Date().getFullYear());

  const [employee, setEmployee] = useState(null);
  const [summary, setSummary] = useState(null);
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');




  const fetchAttendanceData = async () => {
    if (!userId) return;

    setLoading(true);
    setError('');

    try {
      const response = await api.get(`/attendance/employee/${userId}?month=${month}&year=${year}`);

      if (response.data && response.data.success) {
        setEmployee(response.data.employee);
        setSummary(response.data.summary);

        // Transform attendance array to records format
        const transformedRecords = transformAttendanceToRecords(
          response.data.attendance,
          response.data.employee?.name || 'Unknown'
        );
        setRecords(transformedRecords);
      } else {
        setRecords([]);
      }
    } catch (error) {
      console.error('Error fetching attendance details:', error);
      setError('Failed to fetch attendance details');
    } finally {
      setLoading(false);
    }
  };

  const transformAttendanceToRecords = (attendanceArray, employeeName) => {
    if (!attendanceArray || !Array.isArray(attendanceArray)) return [];

    return attendanceArray.map(attendance => {
      const attendanceDate = new Date(attendance.date);
      const dayName = attendanceDate.toLocaleDateString('en-US', { weekday: 'short' });
      const dateStr = attendanceDate.toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });

      // Format time from 24hr to 12hr format
      const formatTime = timeStr => {
        if (!timeStr) return '--';
        const [hours, minutes] = timeStr.split(':');
        const hour = parseInt(hours);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const displayHour = hour % 12 || 12;
        return `${displayHour}:${minutes} ${ampm}`;
      };

      // Convert minutes to hours format
      const minutesToHours = minutes => {
        if (!minutes) return '0.00 Hrs';
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return `${hours}.${mins.toString().padStart(2, '0')} Hrs`;
      };

      return {
        _id: attendance._id,
        employeeId: attendance.employeeId,
        userName: employeeName,
        date: dateStr,
        day: dayName,
        inTime: formatTime(attendance.inTime),
        outTime: formatTime(attendance.outTime),
        mealBreak: minutesToHours(attendance.breakMinutes),
        workHours: minutesToHours(attendance.workingMinutes),
        overtime: minutesToHours(attendance.overtimeMinutes),
        status: attendance.status || 'present',
      };
    });
  };

  // Add callback function for month/year change
  const handleMonthYearChange = (newMonth, newYear) => {
    setMonth(newMonth);
    setYear(newYear);
  };

  useEffect(() => {
    if (userId) {
      fetchAttendanceData();
    }
  }, [userId, month, year]);

  return (
    <>
      <PageMeta title="Punch Details" />
      <main>
        <PageBreadcrumb title="Punch Details (Monthly)" subtitle="Menu" />
        <div className="flex flex-col gap-5">
          {/* Pass month, year, and callback function to PunchDetails */}
          <PunchDetails
            employee={employee}
            summary={summary}
            month={month}
            year={year}
            onMonthYearChange={handleMonthYearChange}
          />

          <PunchWorkDetails summary={summary} />

          <PunchWork
            records={records}
            loading={loading}
            error={error}
            onRetry={fetchAttendanceData}
            hasRecords={records.length > 0}
          />
        </div>
      </main>
    </>
  );
};

export default Index;
