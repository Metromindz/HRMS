import { LuClock, LuOctagonX, LuRefreshCw } from 'react-icons/lu';

const PunchWorkDetails = ({ summary }) => {
  const workDetails = [
    {
      id: 1,
      value: summary?.approvedOvertimeHours || 0,
      label: 'Approved OT',
      icon: LuClock,
      color: 'text-success',
      bg: 'bg-success/10',
      trend: 'Approved hours'
    },
    {
      id: 2,
      value: summary?.rejectedOvertimeHours || 0,
      label: 'Rejected OT',
      icon: LuOctagonX,
      color: 'text-danger',
      bg: 'bg-danger/10',
      trend: 'Rejected hours'
    },
    {
      id: 3,
      value: summary?.pendingOvertimeHours || 0,
      label: 'Pending OT',
      icon: LuRefreshCw,
      color: 'text-warning',
      bg: 'bg-warning/10',
      trend: 'Awaiting review'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {workDetails.map((detail) => {
        const Icon = detail.icon;
        return (
          <div key={detail.id} className="group bg-white border border-default-200 rounded-2xl p-5 transition-all duration-300 relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-1 h-full ${detail.color.replace('text-', 'bg-')} opacity-0 group-hover:opacity-100 transition-opacity`} />
            <div className="flex items-center gap-4">
              <div className={`size-12 flex items-center justify-center rounded-xl ${detail.bg} ${detail.color} group-hover:scale-110 transition-transform`}>
                <Icon className="size-6" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-black text-default-900 leading-none mb-1">
                  {detail.value} <span className="text-xs font-bold text-default-400">Hrs</span>
                </span>
                <span className="text-[10px] font-black text-default-500 uppercase tracking-widest">{detail.label}</span>
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between border-t border-default-100 pt-3">
              <span className="text-[10px] font-bold text-default-400 uppercase tracking-wider">{detail.trend}</span>
              <div className={`size-1.5 rounded-full ${detail.color.replace('text-', 'bg-')} animate-pulse`} />
            </div>
          </div>
        );
      })}
    </div>
  );
};
export default PunchWorkDetails;
