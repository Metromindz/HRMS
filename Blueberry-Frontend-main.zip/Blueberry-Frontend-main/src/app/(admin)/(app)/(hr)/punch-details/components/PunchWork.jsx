import { useState } from 'react';
import { LuCheck, LuChevronLeft, LuChevronRight, LuX, LuFileSearch } from 'react-icons/lu';

const PunchWork = ({ records = [], loading = false, error = '', onRetry }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerPage = 10;
  
  // Calculate total pages
  const totalPages = Math.ceil(records.length / recordsPerPage);

  return (
    <div className="bg-white border border-default-200 rounded-[2rem] overflow-hidden shadow-sm">
      <div className="px-8 py-6 border-b border-default-200 bg-white flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-col">
          <h4 className="text-xl font-black text-default-900 uppercase tracking-tight">Attendance Records</h4>
          <p className="text-[10px] font-black text-default-400 uppercase tracking-widest mt-1">Detailed daily punch-in/out logs</p>
        </div>
        <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-default-500 bg-default-50 px-4 py-2 rounded-xl border border-default-200">
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          Showing {records.length} Logs
        </div>
      </div>

      {/* Loading State */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-24 gap-4">
          <div className="size-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin"></div>
          <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Loading attendance data...</span>
        </div>
      ) : error ? (
        /* Error State */
        <div className="p-8">
          <div className="bg-danger/5 border border-danger/20 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-2xl bg-danger/10 flex items-center justify-center text-danger">
                <LuX className="size-6" />
              </div>
              <div>
                <p className="text-sm font-bold text-danger leading-tight">Sync Error</p>
                <p className="text-xs text-danger/70 mt-1">{error}</p>
              </div>
            </div>
            {onRetry && (
              <button
                onClick={onRetry}
                className="btn h-11 px-6 bg-danger text-white hover:bg-danger-600 transition-all rounded-xl font-bold uppercase tracking-widest text-[10px]"
              >
                Retry Sync
              </button>
            )}
          </div>
        </div>
      ) : records.length === 0 ? (
        /* No Records State */
        <div className="flex flex-col items-center justify-center py-24 px-4 opacity-30">
          <div className="size-20 bg-default-50 rounded-[2rem] flex items-center justify-center text-default-400 mb-6">
            <LuFileSearch className="size-10" />
          </div>
          <h3 className="text-base font-black text-default-900 uppercase tracking-tight mb-1">No Records Found</h3>
          <p className="text-[10px] font-black text-default-400 uppercase tracking-widest">No logs available for this period</p>
        </div>
      ) : (
        /* Data Table */
        <div className="flex flex-col">
          <div className="overflow-x-auto custom-scroll">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-default-50/50">
                  <th className="px-8 py-5 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Date</th>
                  <th className="px-8 py-5 text-left text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Day</th>
                  <th className="px-8 py-5 text-center text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Check In</th>
                  <th className="px-8 py-5 text-center text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Check Out</th>
                  <th className="px-8 py-5 text-center text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Work Hours</th>
                  <th className="px-8 py-5 text-center text-[10px] font-black text-default-500 uppercase tracking-widest border-b border-default-100">Overtime</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-default-100">
                {records
                  .slice((currentPage - 1) * recordsPerPage, currentPage * recordsPerPage)
                  .map((record, index) => (
                    <tr key={index} className="hover:bg-default-50/50 transition-colors group">
                      <td className="px-8 py-5">
                        <span className="text-sm font-bold text-default-900 group-hover:text-primary transition-colors">{record.date}</span>
                      </td>
                      <td className="px-8 py-5">
                        <span className="px-3 py-1 rounded-xl bg-default-100 text-[10px] font-black text-default-700 uppercase tracking-widest border border-default-200">
                          {record.day}
                        </span>
                      </td>
                      <td className="px-8 py-5 text-center">
                        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-success/5 text-success border border-success/10 text-xs font-bold">
                          <LuCheck className="size-3.5" />
                          {record.inTime}
                        </div>
                      </td>
                      <td className="px-8 py-5 text-center">
                        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-danger/5 text-danger border border-danger/10 text-xs font-bold">
                          <LuX className="size-3.5" />
                          {record.outTime}
                        </div>
                      </td>
                      <td className="px-8 py-5 text-center">
                        <span className="px-3 py-1.5 rounded-xl bg-primary/5 text-primary border border-primary/10 text-xs font-black uppercase tracking-widest">
                          {record.workHours}
                        </span>
                      </td>
                      <td className="px-8 py-5 text-center">
                        <span className={`text-xs font-bold ${record.overtime !== '00:00' ? 'text-primary' : 'text-default-400'}`}>
                          {record.overtime}
                        </span>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="px-8 py-6 border-t border-default-200 flex items-center justify-between bg-default-50/30">
              <p className="text-[10px] font-black text-default-400 uppercase tracking-widest">
                Page {currentPage} of {totalPages}
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="size-10 flex items-center justify-center rounded-xl border border-default-200 bg-white text-default-600 hover:bg-primary hover:text-white hover:border-primary disabled:opacity-50 transition-all shadow-sm"
                >
                  <LuChevronLeft className="size-5" />
                </button>
                <div className="flex items-center gap-1">
                  {[...Array(totalPages)].map((_, i) => (
                    <button
                      key={i + 1}
                      onClick={() => setCurrentPage(i + 1)}
                      className={`size-10 rounded-xl text-xs font-bold transition-all ${
                        currentPage === i + 1
                          ? 'bg-primary text-white shadow-lg shadow-primary/25 translate-y-[-1px]'
                          : 'bg-white border border-default-200 text-default-600 hover:bg-default-50'
                      }`}
                    >
                      {i + 1}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className="size-10 flex items-center justify-center rounded-xl border border-default-200 bg-white text-default-600 hover:bg-primary hover:text-white hover:border-primary disabled:opacity-50 transition-all shadow-sm"
                >
                  <LuChevronRight className="size-5" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PunchWork;
