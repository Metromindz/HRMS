import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Link } from "react-router";
import PageMeta from '@/components/PageMeta';
import api from '../../../config/api';

import logoLight from '@/assets/images/logo-light.png';
import logoDark from '@/assets/images/logo.png';

const Index = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const validatePassword = (password) => {
  if (password.length < 8) {
    return "Password must be at least 8 characters long";
  }

  if (!/[A-Z]/.test(password)) {
    return "Password must contain at least one uppercase letter";
  }

  if (!/[a-z]/.test(password)) {
    return "Password must contain at least one lowercase letter";
  }

  if (!/[0-9]/.test(password)) {
    return "Password must contain at least one number";
  }

  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    return "Password must contain at least one special character";
  }

  return null; // ✅ valid password
};


  const handleSubmit = async () => {
    setError("");

    // 🔒 Token check
    if (!token) {
      setError("Invalid or missing password setup link");
      return;
    }

    // 🔑 Password validation
    if (!password || !confirmPassword) {
      setError("Both password fields are required");
      return;
    }

    if (password !== confirmPassword) {
      setError("Password and Confirm Password do not match");
      return;
    }

 const validationError = validatePassword(password);
  if (validationError) {
    setError(validationError);
    return;
  }

    try {
      setLoading(true);

      await api.patch("/hr/set-password", {
        token,
        password
      });

      alert("Password set successfully. You can now login.");
      window.location.href = "/login";

    } catch (err) {
      setError(
        err.response?.data?.message || "Failed to set password"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <PageMeta title="Create Password" />

      <div className="relative min-h-screen w-full flex justify-center items-center py-16 md:py-10">
        <div className="card md:w-lg w-screen z-10">
          <div className="text-center px-10 py-12">
            <Link to="/index" className="flex justify-center">
              <img src={logoDark} alt="logo dark" className="h-6 flex dark:hidden" width={111} />
              <img src={logoLight} alt="logo light" className="h-6 hidden dark:flex" width={111} />
            </Link>

            <div className="mt-8">
              <h4 className="mb-2 text-primary text-xl font-semibold">
                Set a New Password
              </h4>
              <p className="text-base/normal mb-8 text-default-500">
                Your new password should be distinct from any of your prior passwords
              </p>
            </div>

            {error && (
              <p className="text-red-500 text-sm mb-4">{error}</p>
            )}

            <form onSubmit={(e) => e.preventDefault()}>
              <div className="text-start">
                <label className="inline-block mb-2 text-sm text-default-800 font-medium">
                  Password
                </label>
                <input
                  type="password"
                  className="form-input"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>

              <div className="text-start mt-4">
                <label className="inline-block mb-2 text-sm text-default-800 font-medium">
                  Confirm Password
                </label>
                <input
                  type="password"
                  className="form-input"
                  placeholder="Confirm Password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>

              <div className="mt-8">
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={loading}
                  className="btn bg-primary text-white w-full"
                >
                  {loading ? "Setting Password..." : "Set Password"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Index;
