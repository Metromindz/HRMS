# Blueberry ERP - HR Management System

Blueberry is a comprehensive HR and Enterprise Resource Planning (ERP) solution built with a modern tech stack. It features a robust Node.js backend and a highly responsive React frontend.

## Project Structure

- **Blueberry-Backend-main**: Node.js/Express server handling authentication, database operations, and business logic.
- **Blueberry-Frontend-main**: Vite-powered React application with Tailwind CSS for a modern, responsive UI.

---

## 🚀 Getting Started

### Prerequisites

- Node.js (v18 or higher recommended)
- MongoDB (Atlas or local instance)
- npm or yarn

### 1. Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd Blueberry-Backend-main
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Configure environment variables:
   Create a `.env` file in the root of `Blueberry-Backend-main` (or update the existing one):
   ```env
   PORT = 5002
   MONGO_URI = your_mongodb_connection_string
   JWT_SECRET = your_jwt_secret
36→   FRONTEND_URL = "http://localhost:5174"
   EMAIL_USER = your_email@gmail.com
   EMAIL_PASS = your_email_app_password
   ```
4. Start the server:
   ```bash
   # For development (with nodemon)
   npm run dev

   # For production
   npm start
   ```

### 2. Frontend Setup

1. Navigate to the frontend directory:
   ```bash
   cd Blueberry-Frontend-main
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Configure environment variables:
   Create a `.env` file in the root of `Blueberry-Frontend-main`:
   ```env
   VITE_API_BASE_URL = http://localhost:5002/api
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```
5.68→5. Open your browser and navigate to `http://localhost:5174`.

---

## 🛠 Technical Documentation

### Backend Architecture

The backend follows a standard MVC-inspired pattern:

- **Controllers**: Located in `src/controllers/`, these handle the logic for various modules like HR, Attendance, Leaves, and Tasks.
- **Models**: Mongoose schemas defined in `src/models/` for MongoDB data structure.
- **Routes**: API endpoints defined in `src/routes/`.
- **Middleware**: Authentication and file upload handling in `src/middleware/`.
- **Utils**: Helper functions for calculations, file handling, and time management in `src/utils/`.

#### Key Modules:
- **Auth**: JWT-based authentication with role-based access control.
- **HR**: Employee management, documents, and compliance.
- **Attendance**: Real-time tracking and summary generation.
- **Leave Management**: Requests, balances, and approval workflows.
-### Project/Task
Collaborative task management and tracking.

### Announcement Hub Module

**Overview**: Centralized system for HR/Admins to publish updates and employees to view them.

**Key Features**:
- **Role-Based Access**: Admins/HR can create; Employees can view.
- **Targeting**: Announcements can be targeted to All, specific Departments, or specific Roles.
- **Rich Text**: Support for formatted content via `react-quill-new`.
- **Acknowledgment**: Tracking of user read receipts.

**Backend Logic**:
- **Model (`Announcement.js`)**: Stores title, rich text description, priority, category, and targeting rules.
- **Controller (`announcementController.js`)**:
  - `createAnnouncement`: Handles creation and notification logic.
  - `getAnnouncements`: Implements the filtering logic to ensure users only see announcements targeted to them (matching Role/Department or 'All').
- **Routes (`announcementRoutes.js`)**: Protected by JWT authentication and granular permission checks (`announcement.create`, `announcement.view`).

**Frontend Logic**:
- **`AnnouncementPage`**: Main container. Checks permissions to conditionally render the "Create" button. Fetches personalized feed for employees or full list for admins.
- **`CreateAnnouncement`**: Modal form with `react-quill-new` integration for rich text and dynamic targeting fields.
- **`AnnouncementList`**: Visual presentation with priority color coding and category badges.

### Frontend Architecture

The frontend is built for performance and scalability:

- **Vite**: Ultra-fast build tool and dev server.
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development.
- **React Router**: For client-side routing and layout management.
- **State Management**: Handled via React hooks and context where necessary.
- **API Integration**: Centralized Axios instance in `src/config/api.js`.

#### UI Components:
- **metromindz**: A customized design system with consistent rounded containers (`rounded-[2rem]`) and primary color accents.
- **StepProgress**: Standardized multi-step form indicators.
- **FileUpload**: Unified file upload component with validation.

---

## 📦 Available Scripts

### Backend
- `npm start`: Starts the production server.
- `npm run dev`: Starts the server with nodemon for development.
- `npm test`: Runs the test suite using Jest.

### Frontend
- `npm run dev`: Starts the Vite development server.
- `npm run build`: Generates a production-ready build in the `dist/` folder.
- `npm run preview`: Previews the production build locally.
- `npm run format`: Formats code using Prettier.

---

## 📄 License

This project is licensed under the ISC License.
