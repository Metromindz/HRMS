import { Link } from 'react-router';
import SimplebarClient from '@/components/client-wrapper/SimplebarClient';
import AppMenu from './AppMenu';
import HoverToggle from './HoverToggle';
// import logoDark from '@/assets/images/logo-dark.png';
import logoDark from '@/assets/images/logo.png';
import logoLight from '@/assets/images/logo-light.png';
// import logoSm from '@/assets/images/logo-sm.png';
import logoSm from '@/assets/images/Favicon.svg';


const Sidebar = () => {
  return (
    <aside id="app-menu" className="app-menu">
      <Link
        className="logo-box sticky top-0 flex min-h-topbar-height items-center justify-start px-6 backdrop-blur-md bg-white/80 dark:bg-zinc-900/80 z-50 border-b border-default-100"
      >
        <div className="logo-light flex items-center gap-2">
          <img src={logoSm} className="logo-sm h-8 w-8" alt="Small logo" />
          <img src={logoLight} className="logo-lg h-8 object-contain" alt="Light logo" />
        </div>

        <div className="logo-dark flex items-center gap-2">
          <img src={logoSm} className="logo-sm h-8 w-8" alt="Small logo" />
          <img src={logoDark} className="logo-lg h-8 object-contain" alt="Dark logo" />
        </div>
      </Link>

      <HoverToggle />

      <div className="relative min-h-0 flex-grow">
        <SimplebarClient className="size-full">
          <AppMenu />
        </SimplebarClient>
      </div>
    </aside>
  );
};
export default Sidebar;
