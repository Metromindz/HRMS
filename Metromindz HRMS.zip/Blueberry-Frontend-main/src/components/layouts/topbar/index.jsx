import avatar1 from '@/assets/images/user/avatar-1.png';
import avatar3 from '@/assets/images/user/avatar-3.png';
import { Link } from 'react-router';
import SimpleBar from 'simplebar-react';
import SidenavToggle from './SidenavToggle';
import { LuBellRing, LuClock, LuLogOut, LuMoveRight } from 'react-icons/lu';
import { useAuth } from '@/context/AuthContext';
import api from '../../../config/api';
import { useState, useEffect } from 'react';

// const tabs = [{
//   id: 'tabsViewall',
//   title: 'View all',
//   active: true
// }];

const profileMenu = [{
  icon: <LuLogOut className="size-4" />,
  label: 'Sign Out',
  to: '/login'
}];

const Topbar = () => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [profileImage, setProfileImage] = useState(avatar1);
   

  const { user } = useAuth(); 
  const isSuperAdmin = user?.role === "superadmin";
  
  // Format date to display time
  const formatTime = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

 
  const fetchEmployeeProfile = async () => {
    try {
      if (!user?._id) {
        setProfileImage(avatar1);
        return;
      }
      const response = await api.get(`/hr/employees/${user._id}`);
      if (response.data?.success) {
        const employeeData = response.data?.employee?.employeePersonal?.profilePhoto;
        setProfileImage(employeeData || avatar1);
      } else {
        setProfileImage(avatar1);
      }
    } catch (error) {
      console.error('Error fetching employee profile:', error);
      setProfileImage(avatar1);
    }
  };

  useEffect(() => {
      fetchEmployeeProfile();
  }, [user?.employeeId]); 
  // Calculate time ago
  const getTimeAgo = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    
    let interval = Math.floor(seconds / 31536000);
    if (interval >= 1) return interval + ' year' + (interval > 1 ? 's' : '');
    
    interval = Math.floor(seconds / 2592000);
    if (interval >= 1) return interval + ' month' + (interval > 1 ? 's' : '');
    
    interval = Math.floor(seconds / 604800);
    if (interval >= 1) return interval + ' week' + (interval > 1 ? 's' : '');
    
    interval = Math.floor(seconds / 86400);
    if (interval >= 1) return interval + ' day' + (interval > 1 ? 's' : '');
    
    interval = Math.floor(seconds / 3600);
    if (interval >= 1) return interval + ' hour' + (interval > 1 ? 's' : '');
    
    interval = Math.floor(seconds / 60);
    if (interval >= 1) return interval + ' min' + (interval > 1 ? 's' : '');
    
    return Math.floor(seconds) + ' sec';
  };
  
  // Get icon based on notification type
  // const getIconForType = (type) => {
  //   switch(type) {
  //     // case 'employee_status_update':
  //     //   return <LuHeart className="size-3.5 fill-orange-500" />;
  //     case 'employee_status_update':
  //       return <LuMessagesSquare className="size-3.5 text-blue-500" />;
  //     case 'purchase':
  //       return <LuShoppingBag className="size-5 text-danger" />;
  //     case 'follow':
  //       return <LuGem className="size-3.5 text-green-500" />;
  //     default:
  //       return <LuBellRing className="size-3.5 text-gray-500" />;
  //   }
  // };
  
  // Fetch notifications
  const fetchNotifications = async () => {
    if (isSuperAdmin) return; // Don't fetch for superadmin
    
    try {
      setLoading(true);
      const response = await api.get('/notifications');
      
      if (response.data && response.data.notifications) {
        const notificationsData = response.data.notifications.map(notification => ({
          ...notification,
          formattedTime: formatTime(notification.createdAt),
          timeAgo: getTimeAgo(notification.createdAt),
          // icon: getIconForType(notification.type),
          // Use default avatar for now, you can customize based on createdBy if needed
          avatar: avatar3
        }));
        
        setNotifications(notificationsData);
        
        // Calculate unread count (notifications where user hasn't read)
        const unread = notificationsData.filter(n => !n.isRead || !n.isRead.includes(user?.id)).length;
        setUnreadCount(unread);
      }
    } catch (error) {
      console.error('Error fetching notifications:', error);
    } finally {
      setLoading(false);
    }
  };
  
  // Fetch notifications on component mount
  useEffect(() => {
    fetchNotifications();
    
    // Optional: Set up polling for new notifications every 30 seconds
    const interval = setInterval(fetchNotifications, 120000);
    
    return () => clearInterval(interval);
  }, [user?.id]); // Re-fetch when user changes
  
  // Mark notification as read
  const markAsRead = async (notificationId) => {
    try {
 await api.patch(`/notifications/read?notificationId=${notificationId}`);

      // Update local state
      setNotifications(prev => prev.map(n => 
        n._id === notificationId 
          ? { ...n, isRead: [...(n.isRead || []), user?.id] }
          : n
      ));
      
      // Update unread count
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };
  
  // Handle notification click
  const handleNotificationClick = (notification) => {
    // Mark as read when clicked
    if (!notification.isRead || !notification.isRead.includes(user?.id)) {
      markAsRead(notification._id);
    }
    
    // You can add navigation logic here based on notification type
    // For example:
    // if (notification.type === 'employee_status_update') {
    //   navigate(`/employees/${notification.data.employeeId}`);
    // }
  };

  return (
    <div className="app-header min-h-topbar-height flex items-center sticky top-0 z-30 bg-(--topbar-background) border-b border-default-200">
      <div className="w-full flex items-center justify-between px-6">
        <div className="flex items-center gap-5">
          <SidenavToggle />

          {/* <div className="lg:flex hidden items-center relative">
            <div className="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
              <TbSearch className="text-base" />
            </div>
            <input type="search" id="topbar-search" className="form-input px-12 text-sm rounded border-transparent focus:border-transparent w-60" placeholder="Search ..." />
          </div> */}
        </div>

        <div className="flex items-center gap-3">
          {!isSuperAdmin && (
            <div className="topbar-item hs-dropdown [--auto-close:inside] relative inline-flex">
              <button type="button" className="hs-dropdown-toggle btn btn-icon size-8 hover:bg-default-150 rounded-full relative">
                <LuBellRing className="size-4.5" />
                {unreadCount > 0 && (
                  <span className="absolute end-0 top-0 size-1.5 bg-primary/90 rounded-full"></span>
                )}
              </button>

              <div className="hs-dropdown-menu max-w-100 p-0">
                <div className="p-4 border-b border-default-200 flex items-center gap-2">
                  <h3 className="text-base text-default-800">Notifications</h3>
                  {notifications.length > 0 && (
                    <span className="size-5 font-semibold bg-orange-500 rounded text-white flex items-center justify-center text-xs">
                      {unreadCount}
                    </span>
                  )}
                </div>

                {/* <nav className="flex gap-x-1 bg-default-150 p-2 border-b border-default-200" role="tablist">
                  {tabs.map((tab, i) => (
                    <button 
                      key={i} 
                      data-hs-tab={`#${tab.id}`} 
                      type="button" 
                      className={`hs-tab-active:bg-card hs-tab-active:text-primary py-0.5 px-4 rounded font-semibold inline-flex items-center gap-x-2 border-b-2 border-transparent text-xs whitespace-nowrap text-default-500 hover:text-blue-600 ${tab.active ? 'active' : ''}`}
                    >
                      {tab.title}
                    </button>
                  ))}
                </nav> */}

                <SimpleBar className="h-80">
                  {loading ? (
                    <div className="flex justify-center items-center h-40">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    </div>
                  ) : notifications.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-40 text-default-500">
                      <LuBellRing className="size-10 mb-2 opacity-50" />
                      <p className="text-sm">No notifications yet</p>
                    </div>
                  ) : (
                    <div id="tabsViewall">
                      {notifications.map((notification, index) => (
                        <Link 
                          key={notification._id || index} 
                          to="#" 
                          className="flex gap-3 p-4 items-start hover:bg-default-150"
                          onClick={() => handleNotificationClick(notification)}
                        >
                          <div className="relative">
                            <div className="size-10 rounded-md bg-default-100 flex justify-center items-center">
                              <img src={profileImage || avatar1} alt="avatar" className="rounded-md" />
                            </div>
                            {notification.icon && (
                              <div className="absolute bottom-0 -end-0.5">
                                {notification.icon}
                              </div>
                            )}
                          </div>
                          
                          <div className="flex justify-between w-full text-sm">
                            <div>
                              <h6 className="mb-1 font-medium text-default-800">
                                {notification.title}
                              </h6>
                              <p className="mb-2 text-default-600">
                                {notification.message}
                              </p>
                              <p className="flex items-center gap-1 text-default-500 text-xs">
                                <LuClock className="size-3.5" /> 
                                <span>{notification.formattedTime}</span>
                              </p>
                              
                              {/* Display additional data if available */}
                              {/* {notification.data && (
                                <div className="mt-2 p-2 bg-default-50 text-default-500 rounded text-xs">
                                  {notification.data.employeeName && (
                                    <p>Employee: {notification.data.employeeName}</p>
                                  )}
                                  {notification.data.previousStatus && notification.data.newStatus && (
                                    <p>
                                      Status: {notification.data.previousStatus} → {notification.data.newStatus}
                                    </p>
                                  )}
                                </div>
                              )} */}
                            </div>
                            
                            <div className="flex flex-col items-end gap-2">
                              <div className="text-xs text-default-500">
                                {notification.timeAgo}
                              </div>
                              
                              {/* Show unread indicator */}
                              {(!notification.isRead || !notification.isRead.includes(user?.id)) && (
                                <div className="w-1.5 h-1.5 bg-primary rounded-full"></div>
                              )}
                            </div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                </SimpleBar>

                <div className="flex items-left justify-between p-4 border-t border-default-200 gap-3">
                  <Link to="#!" className="text-sm font-medium text-default-900">
                    Check all your Notifications
                  </Link>

                  <button 
                    type="button" 
                    className="btn btn-sm text-white bg-primary"
                    onClick={fetchNotifications}
                  >
                    Refresh <LuMoveRight className="size-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          <div className="topbar-item hs-dropdown relative inline-flex">
            <button className="cursor-pointer bg-pink-100 rounded-full">
              <img src={profileImage || avatar1} alt="user" className="hs-dropdown-toggle rounded-full size-9.5" />
            </button>

            <div className="hs-dropdown-menu min-w-48">
              {isSuperAdmin ? (
                <div className="p-2">
                  <Link className="flex gap-3">
                    <div className="relative inline-block">
                      <img src={avatar1} alt="user" className="size-12 rounded" />
                      <span className="-top-1 -end-1 absolute w-2.5 h-2.5 bg-green-400 border-2 border-white rounded-full"></span>
                    </div>
                    <div>
                      <h6 className="mb-1 text-sm font-semibold text-default-800">Super Admin</h6>
                      <p className="text-default-500">superadmin</p>
                    </div>
                  </Link>
                </div>
              ) : (
                <div className="p-2">
                  <Link className="flex gap-3">
                    <div className="relative inline-block">
                      <img src={profileImage || avatar1} alt="user" className="size-12 rounded" />
                      <span className="-top-1 -end-1 absolute w-2.5 h-2.5 bg-green-400 border-2 border-white rounded-full"></span>
                    </div>
                    <div>
                      <h6 className="mb-1 text-sm font-semibold text-default-800">{user?.name}</h6>
                      <p className="text-default-500">{user?.employmentDetails?.designation?.name}</p>
                    </div>
                  </Link>
                </div>
              )}

              <div className="border-t border-default-200 -mx-2 my-2"></div>

              <div className="flex flex-col gap-y-1">
                {profileMenu.map((item, i) => (
                  item.divider ? (
                    <div key={i} className="border-t border-default-200 -mx-2 my-1"></div>
                  ) : (
                    <Link 
                      key={i} 
                      to={item.to || '#!'} 
                      className="flex items-center gap-x-3.5 py-1.5 px-3 text-default-600 hover:bg-default-150 rounded font-medium"
                    >
                      {item.icon}
                      {item.label}
                      {item.badge && (
                        <span className="size-4.5 font-semibold bg-danger rounded text-white flex items-center justify-center text-xs">
                          {item.badge}
                        </span>
                      )}
                    </Link>
                  )
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Topbar;
