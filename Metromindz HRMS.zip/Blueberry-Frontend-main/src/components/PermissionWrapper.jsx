// import { useAuth } from '@/context/AuthContext';

// // Component-level permission wrapper
// export const PermissionWrapper = ({ children, roles = [], permissions = [], fallback = null }) => {
//   const { user, hasPermission } = useAuth();

//   if (!user) return fallback;

//   // Check role access
//   const hasRole = roles.length === 0 || roles.includes(user.role);

//   // Check permission access
//   const hasRequiredPermission =
//     permissions.length === 0 || permissions.some(permission => hasPermission(permission));

//   return hasRole && hasRequiredPermission ? children : fallback;
// };

// // Hook for permission checks
// export const usePermissions = () => {
//   const { user, hasPermission } = useAuth();

//   const checkRole = roles => {
//     if (!user || !roles.length) return false;
//     return roles.includes(user.role);
//   };

//   const checkPermission = permissions => {
//     if (!user || !permissions.length) return false;
//     return permissions.some(permission => hasPermission(permission));
//   };

//   const checkAccess = (roles = [], permissions = []) => {
//     const hasRole = roles.length === 0 || checkRole(roles);
//     const hasRequiredPermission = permissions.length === 0 || checkPermission(permissions);
//     return hasRole && hasRequiredPermission;
//   };

//   return {
//     user,
//     checkRole,
//     checkPermission,
//     checkAccess,
//     hasPermission,
//     isSuperAdmin: user?.role === 'superadmin',
//     isUser: user?.role !== 'superadmin', // All roles except superadmin
//   };
// };
