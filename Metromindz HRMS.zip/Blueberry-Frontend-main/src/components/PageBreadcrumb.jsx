const PageBreadcrumb = ({
  title,
}) => {
  return <div className="flex items-center md:justify-between flex-wrap gap-2 mb-4 print:hidden">
      <h4 className="text-default-900 text-lg font-semibold">{title}</h4>
    </div>;
};
export default PageBreadcrumb;
