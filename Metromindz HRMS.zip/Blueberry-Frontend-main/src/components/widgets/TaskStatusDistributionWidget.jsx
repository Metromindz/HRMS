import { useMemo, useCallback } from 'react';
import ApexChartClient from '@/components/client-wrapper/ApexChartClient';
import {
  LayoutDashboard,
  Circle,
  Timer,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  MoreHorizontal,
  TrendingUp,
  Layers
} from 'lucide-react';

const TaskStatusDistributionWidget = ({ taskStatus }) => {
  const taskStatusOptions = useMemo(() => {
    if (!taskStatus) return null;

    const categories = ['Task Distribution'];

    return {
      series: [
        { name: 'To Do', data: [taskStatus.todo || 0] },
        { name: 'In Progress', data: [taskStatus.in_progress || 0] },
        { name: 'Completed', data: [taskStatus.completed || 0] },
        { name: 'Pending', data: [taskStatus.pending || 0] },
        { name: 'Overdue', data: [taskStatus.overdue || 0] },
      ],
      chart: {
        type: 'bar',
        height: 200,
        stacked: true,
        toolbar: { show: false },
        parentHeightOffset: 0,
        fontFamily: 'inherit',
        animations: {
          enabled: true,
          easing: 'easeinout',
          speed: 800,
          animateGradually: { enabled: true, delay: 150 },
          dynamicAnimation: { enabled: true, speed: 350 }
        }
      },
      plotOptions: {
        bar: {
          horizontal: false,
          borderRadius: 8,
          columnWidth: '45%',
          dataLabels: { position: 'center' }
        }
      },
      dataLabels: {
        enabled: true,
        formatter: (val) => val > 0 ? val : '',
        style: {
          fontSize: '12px',
          fontWeight: 700,
          colors: ['#fff']
        }
      },
      xaxis: {
        categories,
        axisBorder: { show: false },
        axisTicks: { show: false },
        labels: { show: false },
        crosshairs: { show: false }
      },
      yaxis: {
        show: false,
        max: (max) => max * 1.2 // Add headroom for labels
      },
      colors: ['#8b5cf6', '#3b82f6', '#22c55e', '#f59e0b', '#ef4444'],
      legend: {
        show: false // We'll build custom legend
      },
      fill: {
        opacity: 1,
        type: 'gradient',
        gradient: {
          shade: 'light',
          type: 'vertical',
          shadeIntensity: 0.3,
          inverseColors: false,
          opacityFrom: 1,
          opacityTo: 0.8,
          stops: [0, 100]
        }
      },
      grid: {
        show: false,
        padding: { top: 0, right: 0, bottom: 0, left: 0 }
      },
      tooltip: {
        enabled: true,
        shared: true,
        intersect: false,
        y: {
          formatter: (val) => `${val} tasks`
        }
      }
    };
  }, [taskStatus]);

  const getChartOptions = useCallback((options) => () => options, []);

  // Build custom legend with stats
  const legendItems = useMemo(() => {
    if (!taskStatus) return [];

    const items = [
      {
        key: 'todo',
        label: 'To Do',
        value: taskStatus.todo || 0,
        color: 'bg-violet-500',
        textColor: 'text-violet-600',
        bgColor: 'bg-violet-50',
        borderColor: 'border-violet-200',
        icon: Circle,
        gradient: 'from-violet-500 to-purple-600'
      },
      {
        key: 'in_progress',
        label: 'In Progress',
        value: taskStatus.in_progress || 0,
        color: 'bg-blue-500',
        textColor: 'text-blue-600',
        bgColor: 'bg-blue-50',
        borderColor: 'border-blue-200',
        icon: Timer,
        gradient: 'from-blue-500 to-blue-600'
      },
      {
        key: 'completed',
        label: 'Completed',
        value: taskStatus.completed || 0,
        color: 'bg-emerald-500',
        textColor: 'text-emerald-600',
        bgColor: 'bg-emerald-50',
        borderColor: 'border-emerald-200',
        icon: CheckCircle2,
        gradient: 'from-emerald-500 to-teal-600'
      },
      {
        key: 'pending',
        label: 'Pending',
        value: taskStatus.pending || 0,
        color: 'bg-amber-500',
        textColor: 'text-amber-600',
        bgColor: 'bg-amber-50',
        borderColor: 'border-amber-200',
        icon: AlertCircle,
        gradient: 'from-amber-500 to-orange-600'
      },
      {
        key: 'overdue',
        label: 'Overdue',
        value: taskStatus.overdue || 0,
        color: 'bg-rose-500',
        textColor: 'text-rose-600',
        bgColor: 'bg-rose-50',
        borderColor: 'border-rose-200',
        icon: AlertTriangle,
        gradient: 'from-rose-500 to-pink-600'
      },
    ];

    const total = items.reduce((acc, item) => acc + item.value, 0);

    return items.map(item => ({
      ...item,
      percent: total > 0 ? Math.round((item.value / total) * 100) : 0
    }));
  }, [taskStatus]);

  // Calculate completion rate
  const completionRate = useMemo(() => {
    if (!taskStatus) return 0;
    const total = (taskStatus.todo || 0) +
      (taskStatus.in_progress || 0) +
      (taskStatus.completed || 0) +
      (taskStatus.pending || 0) +
      (taskStatus.overdue || 0);
    const completed = taskStatus.completed || 0;
    return total > 0 ? Math.round((completed / total) * 100) : 0;
  }, [taskStatus]);

  if (!taskStatusOptions) return null;

  return (
    <div className="relative w-full h-full">
      {/* Ambient glow */}
      <div className="absolute -inset-1 bg-gradient-to-br from-violet-100/40 via-blue-50/30 to-emerald-50/20 rounded-3xl blur-2xl opacity-60" />

      <div className="relative h-full bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 overflow-hidden flex flex-col">

        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-white to-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-500/25">
              <Layers className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">Task Distribution</h3>
              <p className="text-[11px] text-slate-500 font-medium">Status breakdown</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Completion rate badge */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 rounded-lg border border-emerald-100">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              <span className="text-xs font-bold text-emerald-700">{completionRate}% done</span>
            </div>
            <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-400 hover:text-slate-600">
              <MoreHorizontal className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 flex flex-col">
          {/* Stacked Bar Chart */}
          <div className="flex-1 min-h-[180px] relative">
            <ApexChartClient
              getOptions={getChartOptions(taskStatusOptions)}
              series={taskStatusOptions.series}
              type="bar"
              height={200}
            />
          </div>

          {/* Custom Legend Grid */}
          <div className="grid grid-cols-5 gap-2 mt-4 pt-4 border-t border-slate-100">
            {legendItems.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={item.key}
                  className={`flex flex-col items-center p-2.5 rounded-xl border ${item.borderColor} ${item.bgColor} transition-all duration-300 hover:shadow-sm group cursor-pointer`}
                >
                  <div className={`p-1.5 rounded-lg bg-white/80 mb-2 group-hover:scale-110 transition-transform`}>
                    <Icon className={`w-4 h-4 ${item.textColor}`} />
                  </div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-0.5">
                    {item.label}
                  </span>
                  <span className={`text-lg font-bold ${item.textColor}`}>
                    {item.value}
                  </span>
                  <span className="text-[9px] font-medium text-slate-400 mt-0.5">
                    {item.percent}%
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskStatusDistributionWidget;