import { useState, useEffect, useMemo, useCallback } from 'react';
import api from '@/config/api';
import ApexChartClient from '@/components/client-wrapper/ApexChartClient';
import { 
  Users, 
  RefreshCw, 
  TrendingUp,
  UserCheck,
  UserX,
  Briefcase,
  FileText,
  AlertTriangle,
  Ban,
  Clock
} from 'lucide-react';

const WorkforceOverviewWidget = () => {
  const [statistics, setStatistics] = useState({});
  const [loading, setLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [hoveredSegment, setHoveredSegment] = useState(null);
  const [lastUpdatedAt, setLastUpdatedAt] = useState(null);

  const fetchStatistics = useCallback(async ({ showLoader = false } = {}) => {
    if (showLoader) setLoading(true);
    try {
      const res = await api.get('/statistics/counts');
      if (res.data.success) {
        const data = res.data.data || {};
        const safeNumber = (value) => {
          const n = Number(value);
          return Number.isFinite(n) && n >= 0 ? n : 0;
        };
        setStatistics({
          totalActive: safeNumber(data.totalActive),
          totalInactive: safeNumber(data.totalInactive),
          totalProbation: safeNumber(data.totalProbation),
          totalPermanent: safeNumber(data.totalPermanent),
          totalContract: safeNumber(data.totalContract),
          totalResigned: safeNumber(data.totalResigned),
          totalTerminated: safeNumber(data.totalTerminated),
          totalNotice: safeNumber(data.totalNotice),
        });
        setLastUpdatedAt(new Date());
      }
    } catch (err) {
      console.error('Failed to fetch workforce statistics:', err);
      setStatistics({});
    } finally {
      setLoading(false);
    }
  }, []);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchStatistics();
    setIsRefreshing(false);
  };

  useEffect(() => {
    fetchStatistics({ showLoader: true });
    const intervalId = setInterval(() => {
      fetchStatistics();
    }, 3000000);

    return () => clearInterval(intervalId);
  }, [fetchStatistics]);

  // Enhanced workforce categories with icons and colors
  const workforceCategories = [
    { 
      key: 'totalActive', 
      label: 'Active', 
      icon: UserCheck,
      color: '#22c55e', 
      gradient: 'from-emerald-500 to-teal-600',
      bg: 'bg-emerald-50',
      text: 'text-emerald-600',
      border: 'border-emerald-200',
      description: 'Currently working'
    },
    { 
      key: 'totalInactive', 
      label: 'Inactive', 
      icon: UserX,
      color: '#94a3b8', 
      gradient: 'from-slate-400 to-slate-600',
      bg: 'bg-slate-50',
      text: 'text-slate-600',
      border: 'border-slate-200',
      description: 'Not currently active'
    },
    { 
      key: 'totalProbation', 
      label: 'Probation', 
      icon: Clock,
      color: '#f59e0b', 
      gradient: 'from-amber-500 to-orange-600',
      bg: 'bg-amber-50',
      text: 'text-amber-600',
      border: 'border-amber-200',
      description: 'Under evaluation'
    },
    { 
      key: 'totalPermanent', 
      label: 'Permanent', 
      icon: Briefcase,
      color: '#3b82f6', 
      gradient: 'from-blue-500 to-indigo-600',
      bg: 'bg-blue-50',
      text: 'text-blue-600',
      border: 'border-blue-200',
      description: 'Full-time employees'
    },
    { 
      key: 'totalContract', 
      label: 'Contract', 
      icon: FileText,
      color: '#8b5cf6', 
      gradient: 'from-violet-500 to-purple-600',
      bg: 'bg-violet-50',
      text: 'text-violet-600',
      border: 'border-violet-200',
      description: 'Contract-based'
    },
    { 
      key: 'totalResigned', 
      label: 'Resigned', 
      icon: Ban,
      color: '#ef4444', 
      gradient: 'from-rose-500 to-pink-600',
      bg: 'bg-rose-50',
      text: 'text-rose-600',
      border: 'border-rose-200',
      description: 'Voluntarily left'
    },
    { 
      key: 'totalTerminated', 
      label: 'Terminated', 
      icon: AlertTriangle,
      color: '#111827', 
      gradient: 'from-slate-800 to-black',
      bg: 'bg-slate-100',
      text: 'text-slate-800',
      border: 'border-slate-300',
      description: 'Employment ended'
    },
    { 
      key: 'totalNotice', 
      label: 'On Notice', 
      icon: Clock,
      color: '#f97316', 
      gradient: 'from-orange-500 to-red-600',
      bg: 'bg-orange-50',
      text: 'text-orange-600',
      border: 'border-orange-200',
      description: 'Serving notice period'
    },
  ];

  const availableCategories = useMemo(() => {
    return workforceCategories
      .map((cat) => ({ ...cat, value: Number(statistics?.[cat.key] || 0) }))
      .filter((cat) => Number.isFinite(cat.value) && cat.value > 0);
  }, [statistics]);

  const chartOptions = useMemo(() => {
    const source = availableCategories.length > 0 ? availableCategories : workforceCategories.map(cat => ({ ...cat, value: 0 }));
    const series = source.map(cat => cat.value);
    const total = series.reduce((a, b) => a + b, 0);

    return {
      series,
      options: {
        chart: {
          type: 'donut',
          height: 260,
          toolbar: { show: false },
          parentHeightOffset: 0,
          fontFamily: 'inherit',
          animations: {
            enabled: true,
            easing: 'easeinout',
            speed: 800,
            animateGradually: { enabled: true, delay: 150 },
            dynamicAnimation: { enabled: true, speed: 350 }
          }
        },
        labels: source.map(c => c.label),
        colors: source.map(c => c.color),
        legend: { 
          show: false // Custom legend built below
        },
        dataLabels: { 
          enabled: false 
        },
        stroke: { 
          show: true,
          width: 2,
          colors: ['#ffffff']
        },
        plotOptions: {
          pie: {
            donut: {
              size: '60%',
              labels: {
                show: true,
                total: {
                  show: true,
                  label: 'Workforce',
                  fontSize: '12px',
                  fontWeight: 600,
                  color: '#94a3b8',
                  formatter: () => total,
                },
                value: {
                  fontSize: '28px',
                  fontWeight: 700,
                  color: '#1e293b',
                }
              }
            },
            expandOnClick: true,
          }
        },
        tooltip: {
          enabled: true,
          y: {
            formatter: (val, { seriesIndex }) => {
              const category = source[seriesIndex];
              const pct = total > 0 ? Math.round((val / total) * 100) : 0;
              return `${val} ${category.label.toLowerCase()} (${pct}%)`;
            }
          }
        }
      }
    };
  }, [availableCategories]);

  // Build legend items with actual data
  const legendItems = useMemo(() => {
    const total = availableCategories.reduce((acc, cat) => acc + cat.value, 0);
    return availableCategories.map((cat, index) => {
      const value = cat.value;
      const percent = total > 0 ? Math.round((value / total) * 100) : 0;
      
      return {
        ...cat,
        value,
        percent,
        Icon: cat.icon,
        index,
      };
    });
  }, [availableCategories]);

  // Calculate key metrics
  const metrics = useMemo(() => {
    const total = availableCategories.reduce((acc, cat) => acc + cat.value, 0);
    const active = Number(statistics?.totalActive || 0);
    const utilization = total > 0 ? Math.round((active / total) * 100) : 0;
    
    return { total, active, utilization };
  }, [availableCategories, statistics]);

  if (loading) {
    return (
      <div className="relative w-full h-full">
        <div className="absolute -inset-1 bg-gradient-to-br from-emerald-100/50 via-blue-50/30 to-violet-50/20 rounded-3xl blur-2xl opacity-40" />
        <div className="relative h-full bg-white/80 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 p-6 animate-pulse">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-200" />
              <div className="space-y-2">
                <div className="h-4 w-32 bg-slate-200 rounded" />
                <div className="h-3 w-24 bg-slate-100 rounded" />
              </div>
            </div>
          </div>
          <div className="grid grid-cols-12 gap-6 items-center">
            <div className="col-span-12 xl:col-span-7 flex justify-center">
              <div className="w-48 h-48 rounded-full bg-slate-100 border-8 border-slate-50" />
            </div>
            <div className="col-span-12 xl:col-span-5 space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-10 w-full bg-slate-100 rounded-xl" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!chartOptions) return null;

  const hasData = legendItems.length > 0 && metrics.total > 0;

  return (
    <div className="relative w-full h-full">
      {/* Ambient glow */}
      <div className="absolute -inset-1 bg-gradient-to-br from-emerald-100/40 via-blue-50/30 to-violet-50/20 rounded-3xl blur-2xl opacity-60" />
      
      <div className="relative h-full bg-white/90 backdrop-blur-xl rounded-3xl shadow-xl shadow-slate-200/50 border border-white/50 overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-white to-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/25">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">Workforce Overview</h3>
              <p className="text-[11px] text-slate-500 font-medium">Employee distribution</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {metrics && (
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 rounded-lg border border-emerald-100">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                <span className="text-xs font-bold text-emerald-700">{metrics.utilization}% active</span>
              </div>
            )}
            <button 
              onClick={handleRefresh}
              className={`p-2 hover:bg-slate-100 rounded-lg transition-all text-slate-400 hover:text-slate-600 ${isRefreshing ? 'animate-spin' : ''}`}
              disabled={isRefreshing}
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 flex flex-col">
          {/* Metrics Row */}
          {metrics && (
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100">
                <div className="flex items-center gap-2 mb-1">
                  <Users className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-[10px] font-bold text-emerald-600 uppercase">Total</span>
                </div>
                <p className="text-lg font-bold text-emerald-900">{metrics.total}</p>
              </div>
              <div className="p-3 rounded-xl bg-blue-50 border border-blue-100">
                <div className="flex items-center gap-2 mb-1">
                  <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                  <span className="text-[10px] font-bold text-blue-600 uppercase">Active</span>
                </div>
                <p className="text-lg font-bold text-blue-900">{metrics.active}</p>
              </div>
              <div className="p-3 rounded-xl bg-violet-50 border border-violet-100">
                <div className="flex items-center gap-2 mb-1">
                  <TrendingUp className="w-3.5 h-3.5 text-violet-600" />
                  <span className="text-[10px] font-bold text-violet-600 uppercase">Utilization</span>
                </div>
                <p className="text-lg font-bold text-violet-900">{metrics.utilization}%</p>
              </div>
            </div>
          )}

          <div className="grid grid-cols-12 gap-6 items-center flex-1">
            {/* Donut Chart */}
            <div className="col-span-12 xl:col-span-7 flex justify-center">
              <div className="relative w-full max-w-[260px]">
                {hasData ? (
                  <ApexChartClient
                    getOptions={() => chartOptions.options}
                    series={chartOptions.series}
                    type="donut"
                    height={260}
                  />
                ) : (
                  <div className="h-[260px] rounded-2xl border border-dashed border-slate-200 bg-slate-50/40 flex items-center justify-center px-6 text-center">
                    <p className="text-sm font-semibold text-slate-500">No workforce distribution data available</p>
                  </div>
                )}
              </div>
            </div>

            {/* Custom Legend */}
            <div className="col-span-12 xl:col-span-5">
              <h6 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">
                Distribution
              </h6>
              <div className="space-y-2 max-h-[280px] overflow-y-auto custom-scrollbar pr-1">
                {legendItems.map((item) => {
                  const Icon = item.Icon;
                  return (
                    <div 
                      key={item.key}
                      className={`flex items-center justify-between p-3 rounded-xl border transition-all duration-300 cursor-pointer group ${
                        hoveredSegment === item.index 
                          ? 'bg-slate-50 border-slate-300 shadow-sm' 
                          : `${item.bg} ${item.border} hover:shadow-sm`
                      }`}
                      onMouseEnter={() => setHoveredSegment(item.index)}
                      onMouseLeave={() => setHoveredSegment(null)}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-1.5 rounded-lg bg-white/80 group-hover:scale-110 transition-transform`}>
                          <Icon className={`w-4 h-4 ${item.text}`} />
                        </div>
                        <div>
                          <p className={`text-sm font-semibold ${item.text}`}>{item.label}</p>
                          <p className="text-[10px] text-slate-500">{item.description}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold text-slate-700">{item.value}</p>
                        <p className="text-[10px] font-medium text-slate-400">{item.percent}%</p>
                      </div>
                    </div>
                  );
                })}
                {!hasData && (
                  <div className="p-4 rounded-xl border border-dashed border-slate-200 bg-slate-50 text-xs font-semibold text-slate-500 text-center">
                    No active workforce segments to display
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50/50 flex justify-end">
          <span className="text-xs font-medium text-slate-400">
            Updated {lastUpdatedAt ? lastUpdatedAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--:--'}
          </span>
        </div>
      </div>
    </div>
  );
};

export default WorkforceOverviewWidget;
