import { TrendingDown, TrendingUp } from 'lucide-react';

/**
 * DashboardStatsWidget - A standardized statistics display component
 * 
 * @param {Array} cards - Array of stat card objects
 * @param {boolean} loading - Loading state
 * @param {string} gridClass - CSS grid classes
 * @param {boolean} showDelta - Whether to show delta/trend indicators
 * @param {function} getDeltaInfo - Function to get delta info (key) => { pct: number, up: boolean }
 * @param {string} variant - 'default' | 'detailed'
 */
const DashboardStatsWidget = ({
  cards = [],
  loading = false,
  gridClass = 'grid gap-4 lg:grid-cols-4 sm:grid-cols-2 grid-cols-1',
  showDelta = false,
  getDeltaInfo,
  variant = 'default',
}) => {
  if (!cards?.length) return null;

  // Standardized color mapping from legacy classes to new system
  const colorMap = {
    // Blue variants
    'bg-blue-500/10': { bg: 'bg-blue-50', border: 'border-blue-100', text: 'text-blue-600', accent: 'bg-blue-500', gradient: 'from-blue-500 to-indigo-600' },
    'bg-primary/10': { bg: 'bg-blue-50', border: 'border-blue-100', text: 'text-blue-600', accent: 'bg-blue-500', gradient: 'from-blue-500 to-indigo-600' },
    
    // Emerald/Green variants
    'bg-emerald-500/10': { bg: 'bg-emerald-50', border: 'border-emerald-100', text: 'text-emerald-600', accent: 'bg-emerald-500', gradient: 'from-emerald-500 to-teal-600' },
    'bg-success/10': { bg: 'bg-emerald-50', border: 'border-emerald-100', text: 'text-emerald-600', accent: 'bg-emerald-500', gradient: 'from-emerald-500 to-teal-600' },
    'bg-green-500/10': { bg: 'bg-emerald-50', border: 'border-emerald-100', text: 'text-emerald-600', accent: 'bg-emerald-500', gradient: 'from-emerald-500 to-teal-600' },
    
    // Violet/Purple variants
    'bg-violet-500/10': { bg: 'bg-violet-50', border: 'border-violet-100', text: 'text-violet-600', accent: 'bg-violet-500', gradient: 'from-violet-500 to-purple-600' },
    'bg-purple-500/10': { bg: 'bg-violet-50', border: 'border-violet-100', text: 'text-violet-600', accent: 'bg-violet-500', gradient: 'from-violet-500 to-purple-600' },
    
    // Amber/Orange variants
    'bg-amber-500/10': { bg: 'bg-amber-50', border: 'border-amber-100', text: 'text-amber-600', accent: 'bg-amber-500', gradient: 'from-amber-500 to-orange-600' },
    'bg-orange-500/10': { bg: 'bg-orange-50', border: 'border-orange-100', text: 'text-orange-600', accent: 'bg-orange-500', gradient: 'from-orange-500 to-red-600' },
    'bg-warning/10': { bg: 'bg-amber-50', border: 'border-amber-100', text: 'text-amber-600', accent: 'bg-amber-500', gradient: 'from-amber-500 to-orange-600' },
    
    // Rose/Red variants
    'bg-rose-500/10': { bg: 'bg-rose-50', border: 'border-rose-100', text: 'text-rose-600', accent: 'bg-rose-500', gradient: 'from-rose-500 to-pink-600' },
    'bg-danger/10': { bg: 'bg-rose-50', border: 'border-rose-100', text: 'text-rose-600', accent: 'bg-rose-500', gradient: 'from-rose-500 to-pink-600' },
    'bg-red-500/10': { bg: 'bg-rose-50', border: 'border-rose-100', text: 'text-rose-600', accent: 'bg-rose-500', gradient: 'from-rose-500 to-pink-600' },
    
    // Pink variants
    'bg-pink-500/10': { bg: 'bg-pink-50', border: 'border-pink-100', text: 'text-pink-600', accent: 'bg-pink-500', gradient: 'from-pink-500 to-rose-600' },
    
    // Slate/Gray variants
    'bg-slate-500/10': { bg: 'bg-slate-50', border: 'border-slate-100', text: 'text-slate-600', accent: 'bg-slate-500', gradient: 'from-slate-500 to-slate-600' },
    'bg-gray-500/10': { bg: 'bg-slate-50', border: 'border-slate-100', text: 'text-slate-600', accent: 'bg-slate-500', gradient: 'from-slate-500 to-slate-600' },
    'bg-default-100': { bg: 'bg-slate-50', border: 'border-slate-100', text: 'text-slate-600', accent: 'bg-slate-500', gradient: 'from-slate-500 to-slate-600' },
    
    // Cyan/Sky variants
    'bg-cyan-500/10': { bg: 'bg-sky-50', border: 'border-sky-100', text: 'text-sky-600', accent: 'bg-sky-500', gradient: 'from-sky-500 to-cyan-600' },
    'bg-sky-500/10': { bg: 'bg-sky-50', border: 'border-sky-100', text: 'text-sky-600', accent: 'bg-sky-500', gradient: 'from-sky-500 to-cyan-600' },
    
    // Indigo variants
    'bg-indigo-500/10': { bg: 'bg-indigo-50', border: 'border-indigo-100', text: 'text-indigo-600', accent: 'bg-indigo-500', gradient: 'from-indigo-500 to-violet-600' },
    
    // Teal variants
    'bg-teal-500/10': { bg: 'bg-teal-50', border: 'border-teal-100', text: 'text-teal-600', accent: 'bg-teal-500', gradient: 'from-teal-500 to-emerald-600' },
  };

  /**
   * Get standardized color scheme from legacy class name
   */
  const getStandardColors = (bgColor) => {
    // Direct match
    if (colorMap[bgColor]) return colorMap[bgColor];
    
    // Try to extract color from class name
    const match = bgColor?.match(/bg-(\w+)-/);
    if (match) {
      const colorName = match[1];
      const fallback = Object.entries(colorMap).find(([key]) => key.includes(colorName));
      if (fallback) return fallback[1];
    }
    
    // Default fallback
    return { 
      bg: 'bg-slate-50', 
      border: 'border-slate-100', 
      text: 'text-slate-600', 
      accent: 'bg-slate-500',
      gradient: 'from-slate-500 to-slate-600'
    };
  };

  /**
   * Skeleton loader for loading state
   */
  const SkeletonCard = ({ variant }) => (
    <div className={`rounded-2xl border border-slate-100 bg-white p-5 animate-pulse ${variant === 'detailed' ? 'h-32' : 'h-28'}`}>
      <div className="flex items-start justify-between">
        <div className="space-y-3 flex-1">
          <div className="h-3 w-20 bg-slate-100 rounded" />
          <div className="h-8 w-16 bg-slate-100 rounded" />
          {variant === 'detailed' && <div className="h-3 w-24 bg-slate-100 rounded" />}
        </div>
        <div className="w-11 h-11 rounded-xl bg-slate-100" />
      </div>
    </div>
  );

  // Loading state
  if (loading) {
    return (
      <div className={gridClass}>
        {cards.map((_, idx) => (
          <SkeletonCard key={idx} variant={variant} />
        ))}
      </div>
    );
  }

  return (
    <div className={gridClass}>
      {cards.map((card) => {
        const Icon = card.icon;
        const info = showDelta && getDeltaInfo ? getDeltaInfo(card.key) : null;
        const isPositive = info?.up;
        const colors = getStandardColors(card.bgColor);

        // ========== DETAILED VARIANT ==========
        if (variant === 'detailed') {
          return (
            <div 
              key={card.label} 
              className={`
                relative p-5 rounded-2xl border ${colors.border} ${colors.bg} 
                transition-all duration-300 
                hover:shadow-lg hover:shadow-slate-200/50 hover:-translate-y-0.5 
                group cursor-pointer
              `}
            >
              {/* Hover gradient overlay */}
              <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${colors.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-300`} />
              
              <div className="relative flex items-start justify-between">
                <div className="space-y-1 min-w-0 flex-1">
                  {/* Label */}
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider truncate">
                    {card.label}
                  </p>
                  
                  {/* Value */}
                  <p className="text-2xl font-bold text-slate-900 tracking-tight">
                    {card.value}
                  </p>
                  
                  {/* Delta/Trend */}
                  {info && (
                    <div className={`
                      flex items-center gap-1.5 mt-2 
                      ${isPositive ? 'text-emerald-600' : 'text-rose-600'}
                    `}>
                      {isPositive ? (
                        <TrendingUp className="w-3.5 h-3.5" />
                      ) : (
                        <TrendingDown className="w-3.5 h-3.5" />
                      )}
                      <span className="text-xs font-semibold">
                        {isPositive ? '+' : ''}{info.pct}%
                      </span>
                      <span className="text-xs text-slate-400 ml-1">vs last period</span>
                    </div>
                  )}
                </div>
                
                {/* Icon */}
                <div className={`
                  w-11 h-11 rounded-xl ${colors.bg} border ${colors.border}
                  flex items-center justify-center 
                  transition-all duration-300 
                  group-hover:scale-110 group-hover:shadow-md
                  shrink-0 ml-3
                `}>
                  {Icon ? (
                    <Icon className={`w-5 h-5 ${colors.text}`} />
                  ) : (
                    <div className="w-5 h-5 rounded bg-slate-200" />
                  )}
                </div>
              </div>
              
              {/* Description */}
              {card.description && (
                <p className="relative mt-3 text-xs font-medium text-slate-500 leading-relaxed line-clamp-2">
                  {card.description}
                </p>
              )}
            </div>
          );
        }

        // ========== DEFAULT VARIANT ==========
        return (
          <div 
            key={card.label} 
            className={`
              relative p-5 rounded-2xl border ${colors.border} bg-white
              transition-all duration-300 
              hover:shadow-lg hover:shadow-slate-200/50 hover:-translate-y-0.5 
              group cursor-pointer
            `}
          >
            {/* Subtle hover gradient */}
            <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${colors.gradient} opacity-0 group-hover:opacity-[0.02] transition-opacity duration-300`} />
            
            <div className="relative flex items-center justify-between">
              <div className="min-w-0 flex-1">
                {/* Label */}
                <p className="text-xs font-medium text-slate-500 mb-1 truncate">
                  {card.label}
                </p>
                
                {/* Value + Delta */}
                <div className="flex items-baseline gap-2 flex-wrap">
                  <h4 className="text-2xl font-bold text-slate-900 tracking-tight">
                    {card.value}
                  </h4>
                  
                  {info && (
                    <span className={`
                      flex items-center gap-0.5 text-xs font-semibold 
                      ${isPositive ? 'text-emerald-600' : 'text-rose-600'}
                    `}>
                      {isPositive ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : (
                        <TrendingDown className="w-3 h-3" />
                      )}
                      <span>{`${isPositive ? '+' : ''}${info.pct}%`}</span>
                    </span>
                  )}
                </div>
              </div>
              
              {/* Icon */}
              <div className={`
                w-11 h-11 rounded-xl ${colors.bg} border ${colors.border}
                flex items-center justify-center 
                transition-all duration-300 
                group-hover:scale-110
                shrink-0 ml-3
              `}>
                {Icon ? (
                  <Icon className={`w-5 h-5 ${colors.text}`} />
                ) : (
                  <div className="w-5 h-5 rounded bg-slate-200" />
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default DashboardStatsWidget;