// Upcoming birthdays
import User1 from '@/assets/images/user/avatar-11.png';
import { useState, useEffect } from 'react';
import SimplebarClient from '@/components/client-wrapper/SimplebarClient';
import { Link } from 'react-router';
import { LuCalendar, LuGift, LuCake, LuSparkles } from 'react-icons/lu';
import api from '@/config/api';
import { getUploadUrl } from '@/utils/uploadUrl';

const UpcomingBirthdaysWidget = () => {
  const [birthdays, setBirthdays] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBirthdays = async () => {
      try {
        const response = await api.get('/dashboard/upcoming-birthdays');
        if (response.data.success) {
          setBirthdays(response.data.data);
        }
      } catch (error) {
        console.error('Error fetching birthdays:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchBirthdays();
  }, []);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    const isToday = date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth();

    if (isToday) return 'Today';
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getDaysUntil = (dateString) => {
    const date = new Date(dateString);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    date.setHours(0, 0, 0, 0);

    const diffTime = date - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    return `In ${diffDays} days`;
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-6 py-5 border-b border-slate-100 bg-gradient-to-r from-rose-50/50 to-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-100 flex items-center justify-center text-rose-600">
            <LuCake className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-900">Upcoming Birthdays</h3>
            <p className="text-sm text-slate-500">Celebrate your team</p>
          </div>
        </div>
        <div className="w-8 h-8 rounded-lg bg-rose-100 flex items-center justify-center">
          <LuSparkles className="w-4 h-4 text-rose-500" />
        </div>
      </div>

      {/* Content */}
      <SimplebarClient className="flex-1 min-h-0">
        <div className="p-4">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-12 gap-3">
              <div className="w-10 h-10 border-4 border-rose-100 border-t-rose-500 rounded-full animate-spin" />
              <p className="text-sm text-slate-500 font-medium">Loading birthdays...</p>
            </div>
          ) : birthdays.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
              <div className="w-16 h-16 rounded-full bg-slate-50 flex items-center justify-center mb-3">
                <LuCalendar className="w-8 h-8 text-slate-300" />
              </div>
              <p className="text-sm font-semibold text-slate-900 mb-1">No upcoming birthdays</p>
              <p className="text-xs text-slate-500">Check back later for upcoming celebrations</p>
            </div>
          ) : (
            <div className="space-y-3">
              {birthdays.map((person, index) => {
                const isToday = getDaysUntil(person.birthday) === 'Today';

                return (
                  <div
                    key={index}
                    className={`group flex items-center gap-4 p-4 rounded-xl border transition-all duration-300 ${isToday
                        ? 'bg-gradient-to-r from-rose-50 to-amber-50 border-rose-200 shadow-sm'
                        : 'bg-white border-slate-200 hover:border-rose-200 hover:shadow-sm'
                      }`}
                  >
                    {/* Avatar */}
                    <div className="relative shrink-0">
                      <div className={`w-12 h-12 rounded-full overflow-hidden ring-2 ${isToday ? 'ring-rose-300 ring-offset-2' : 'ring-slate-100'
                        }`}>
                        <img
                          src={getUploadUrl(person.profilePhoto) || User1}
                          alt={person.fullName}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      {isToday && (
                        <div className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 rounded-full flex items-center justify-center border-2 border-white">
                          <LuGift className="w-2.5 h-2.5 text-white" />
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <h4 className={`text-sm font-semibold truncate ${isToday ? 'text-rose-900' : 'text-slate-900 group-hover:text-rose-600'
                        } transition-colors`}>
                        <Link to="#" className="hover:underline decoration-rose-400 underline-offset-2">
                          {person.fullName}
                        </Link>
                      </h4>
                      <p className="text-xs text-slate-500 truncate mt-0.5">{person.email}</p>
                    </div>

                    {/* Date Badge */}
                    <div className={`shrink-0 flex flex-col items-end gap-1`}>
                      <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold ${isToday
                          ? 'bg-rose-500 text-white shadow-sm shadow-rose-200'
                          : 'bg-rose-50 text-rose-700'
                        }`}>
                        <LuCalendar className="w-3.5 h-3.5" />
                        {formatDate(person.birthday)}
                      </div>
                      <span className={`text-[10px] font-medium ${isToday ? 'text-rose-600' : 'text-slate-400'
                        }`}>
                        {getDaysUntil(person.birthday)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </SimplebarClient>
    </div>
  );
};

export default UpcomingBirthdaysWidget;