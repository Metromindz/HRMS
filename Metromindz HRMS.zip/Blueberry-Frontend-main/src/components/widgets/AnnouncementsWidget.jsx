import { useState, useEffect } from 'react';
import { LuMegaphone, LuArrowRight, LuCalendar } from 'react-icons/lu';
import { Link } from 'react-router';
import api from '@/config/api';

const AnnouncementsWidget = () => {
    const [announcements, setAnnouncements] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchRecentAnnouncements = async () => {
            try {
                const res = await api.get('/announcements');
                // Get top 3 most recent
                setAnnouncements((res.data.data || []).slice(0, 3));
            } catch (err) {
                console.error('Failed to fetch announcements:', err);
            } finally {
                setLoading(false);
            }
        };
        fetchRecentAnnouncements();
    }, []);

    // Priority color helper
    const getPriorityStyles = (priority) => {
        switch (priority) {
            case 'High': return 'bg-danger/10 text-danger';
            case 'Medium': return 'bg-warning/10 text-warning';
            case 'Low': return 'bg-success/10 text-success';
            default: return 'bg-default-100 text-default-600';
        }
    };

    return (
        <div className="card h-full border border-default-200 shadow-sm rounded-xl bg-white overflow-hidden flex flex-col">
            <div className="card-header border-b border-default-200 p-4 flex justify-between items-center bg-gradient-to-r from-primary/10 to-transparent">
                <h4 className="text-lg font-black text-default-900 flex items-center gap-2 tracking-tight">
                    <div className="p-1.5 bg-primary/20 text-primary rounded-lg">
                        <LuMegaphone size={18} />
                    </div>
                    Company News
                </h4>
            </div>

            <div className="card-body p-0 overflow-y-auto flex-grow max-h-[400px]">
                {loading ? (
                    <div className="p-5 space-y-4">
                        {[1, 2, 3].map((i) => (
                            <div key={i} className="animate-pulse flex gap-3">
                                <div className="size-10 rounded-xl bg-default-100 shrink-0"></div>
                                <div className="space-y-2 flex-grow">
                                    <div className="h-4 bg-default-100 rounded w-3/4"></div>
                                    <div className="h-3 bg-default-100 rounded w-1/2"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : announcements.length > 0 ? (
                    <div className="divide-y divide-default-100">
                        {announcements.map((notif) => (
                            <div key={notif._id} className="p-4 hover:bg-default-50 transition-colors group cursor-pointer">
                                <div className="flex gap-3">
                                    <div className={`mt-0.5 px-1.5 py-0.5 rounded text-[9px] font-black uppercase tracking-widest shrink-0 h-fit ${getPriorityStyles(notif.priority)}`}>
                                        {notif.priority.charAt(0)}
                                    </div>
                                    <div className="flex-grow min-w-0">
                                        <h5 className="text-sm font-bold text-default-900 mb-1 truncate group-hover:text-primary transition-colors">
                                            {notif.title}
                                        </h5>
                                        <p className="text-xs text-default-500 line-clamp-2 mb-2 leading-relaxed" dangerouslySetInnerHTML={{ __html: notif.description }}></p>
                                        <div className="flex items-center gap-1.5 text-[10px] font-bold text-default-400 uppercase tracking-widest">
                                            <LuCalendar size={12} className="text-primary/60" />
                                            {new Date(notif.publishDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center p-8 text-center text-default-400 h-full">
                        <div className="size-12 bg-default-50 rounded-full flex items-center justify-center mb-3">
                            <span className="text-xl opacity-50">📭</span>
                        </div>
                        <p className="text-sm font-bold text-default-600">No recent news</p>
                        <p className="text-xs mt-1">Check back later for updates</p>
                    </div>
                )}
            </div>

            <div className="card-footer p-3 border-t border-default-200 text-center bg-default-50/50">
                <Link to="/announcement" className="text-primary text-xs font-bold uppercase tracking-widest hover:underline flex items-center justify-center gap-1 group">
                    View All <LuArrowRight className="size-3 group-hover:translate-x-1 transition-transform" />
                </Link>
            </div>
        </div>
    );
};

export default AnnouncementsWidget;
