const PageMeta = ({
  title
}) => {
  return <title>
      {title ? `${title} | Metromindz ERP` : ' Metromindz ERP'}
    </title>;
};
export default PageMeta;