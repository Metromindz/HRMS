export const getLandingPage = (user) => {
  if (user.role === 'superadmin') return '/dashboard';
  if (user.permissions.includes('dashboard.view')) return '/dashboard';
  return '/my-profile';
};
