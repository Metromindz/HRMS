import { Navigate, Route, Routes } from 'react-router-dom';
import { layoutsRoutes, singlePageRoutes } from './Routes';
import PageWrapper from '@/components/PageWrapper';
import ProtectedRoute from '@/components/ProtectedRoute';
import { useAuth } from '@/context/AuthContext';

const AppRoutes = () => {
  const { user } = useAuth();
  
  const filteredRoutes = layoutsRoutes.filter(route => {
    if (route.excludeRoles && user?.role && route.excludeRoles.includes(user.role)) {
      return false;
    }
    
    // Superadmin has access to all routes
    if (user?.role === 'superadmin') return true;
    
    // Check permissions for regular users
    if (route.permissions && user?.permissions) {
      return route.permissions.some(p => user.permissions.includes(p));
    }
    
    // Allow routes without permissions
    return true;
  });

  return <>
      <Routes>
        {filteredRoutes.map(route => (
          <Route 
            key={route.name} 
            path={route.path} 
            element={
              <ProtectedRoute>
                <PageWrapper>{route.element}</PageWrapper>
              </ProtectedRoute>
            } 
          />
        ))}

        {singlePageRoutes.map(route => <Route key={route.name} path={route.path} element={route.element} />)}
        <Route path="*" element={<Navigate to="/404" replace />} />
      </Routes>
    </>;
};
export default AppRoutes;