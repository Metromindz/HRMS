import { lazy } from 'react';

// admin Ecommerce

// const Cart = lazy(() => import('@/app/(admin)/(app)/(ecommerce)/cart'));
// const Checkout = lazy(() => import('@/app/(admin)/(app)/(ecommerce)/checkout'));
// const OrderOverview = lazy(() => import('@/app/(admin)/(app)/(ecommerce)/order-overview'));
// const Orders = lazy(() => import('@/app/(admin)/(app)/(ecommerce)/orders'));
// const ProductCreate = lazy(() => import('@/app/(admin)/(app)/(ecommerce)/product-create'));
// const ProductGrid = lazy(() => import('@/app/(admin)/(app)/(ecommerce)/product-grid'));
// const ProductList = lazy(() => import('@/app/(admin)/(app)/(ecommerce)/product-list'));
// const ProductOverview = lazy(() => import('@/app/(admin)/(app)/(ecommerce)/product-overview'));
// const Sellers = lazy(() => import('@/app/(admin)/(app)/(ecommerce)/sellers'));

// admin Hr

const Attendances = lazy(() => import('@/app/(admin)/(app)/(hr)/attendance'));
const AttemdanceMain = lazy(() => import('@/app/(admin)/(app)/(hr)/attendance-main'));
const CreateLeave = lazy(() => import('@/app/(admin)/(app)/(hr)/create-leave'));
const CreateLeaveEmployee = lazy(() => import('@/app/(admin)/(app)/(hr)/create-leave-employee'));
const CreatePayslip = lazy(() => import('@/app/(admin)/(app)/(hr)/create-payslip'));
const Department = lazy(() => import('@/app/(admin)/(app)/(hr)/department'));
const Designations = lazy(() => import('@/app/(admin)/(app)/(hr)/designation'));
const Employee = lazy(() => import('@/app/(admin)/(app)/(hr)/employee'));
const EmployeeDetail = lazy(() => import('@/app/(admin)/(app)/(hr)/employee/detail'));
const Holidays = lazy(() => import('@/app/(admin)/(app)/(hr)/holidays'));
const Leave = lazy(() => import('@/app/(admin)/(app)/(hr)/leave'));
const LeaveEmployee = lazy(() => import('@/app/(admin)/(app)/(hr)/leave-employee'));
const PayrollEmplyoeeSalary = lazy(
  () => import('@/app/(admin)/(app)/(hr)/payroll-employee-salary')
);
const PayRollSlip = lazy(() => import('@/app/(admin)/(app)/(hr)/payroll-payslip'));
const SalesEstimate = lazy(() => import('@/app/(admin)/(app)/(hr)/sales-estimates'));
const SalesExpense = lazy(() => import('@/app/(admin)/(app)/(hr)/sales-expenses'));
const SalePayment = lazy(() => import('@/app/(admin)/(app)/(hr)/sales-payments'));
const Profile = lazy(() => import('@/app/(admin)/(app)/profile'));
const MasterSettings = lazy(() => import('@/app/(admin)/(app)/(hr)/master-settings'));
const PayrollSetting = lazy(() => import('@/app/(admin)/(app)/(hr)/payroll-setting'));
const LeaveSetting = lazy(() => import('@/app/(admin)/(app)/(hr)/leave-setting'));
const PunchDetails = lazy(() => import('@/app/(admin)/(app)/(hr)/punch-details'));
const PayslipDetails = lazy(() => import('@/app/(admin)/(app)/(users)/Payslip'));
const Company = lazy(() => import('@/app/(admin)/(app)/(company)'));
const Projects = lazy(() => import('@/app/(admin)/(app)/(projects)'));
const Tasks = lazy(() => import('@/app/(admin)/(app)/(tasks)'));
const Leads = lazy(() => import('@/app/(admin)/(app)/(leads)'));
const MyExpenses = lazy(() => import('@/app/(admin)/(app)/my-expenses/index'));
const ExpenseApprovals = lazy(() => import('@/app/(admin)/(app)/expense-approvals/index'));
// admin invoice

const InvoiceAddNew = lazy(() => import('@/app/(admin)/(app)/(invoice)/add-new'));
const InvoiceList = lazy(() => import('@/app/(admin)/(app)/(invoice)/list'));
const InvoiceOverview = lazy(() => import('@/app/(admin)/(app)/(invoice)/overview'));
const Announcement = lazy(() => import('@/app/(admin)/(app)/(hr)/announcement'));

// USers

const UserGrid = lazy(() => import('@/app/(admin)/(app)/(users)/users-grid'));
const UserList = lazy(() => import('@/app/(admin)/(app)/(users)/users-list'));
const MailBox = lazy(() => import('@/app/(admin)/(app)/mailbox'));
const Notes = lazy(() => import('@/app/(admin)/(app)/notes'));
const AllNotifications = lazy(() => import('@/app/(admin)/(app)/notifications'));
const UserApplyLeave = lazy(() => import('@/app/(admin)/(app)/(users)/apply-leave'));
const UserAppliedLeave = lazy(() => import('@/app/(admin)/(app)/(users)/applied-leave'));

// dashboard
const Analytics = lazy(() => import('@/app/(admin)/(dashboards)/analytics'));
const Email = lazy(() => import('@/app/(admin)/(dashboards)/email'));
const Hr = lazy(() => import('@/app/(admin)/(dashboards)/hr'));
const Ecommerce = lazy(() => import('@/app/(admin)/(dashboards)/index'));

// layouts
const DarkMode = lazy(() => import('@/app/(admin)/(layouts)/dark-mode'));
const RTL = lazy(() => import('@/app/(admin)/(layouts)/rtl-mode'));
const SideNavCompact = lazy(() => import('@/app/(admin)/(layouts)/sidenav-compact'));
const SideNavDark = lazy(() => import('@/app/(admin)/(layouts)/sidenav-dark'));
const SideNavHidden = lazy(() => import('@/app/(admin)/(layouts)/sidenav-hidden'));
const SideNavHover = lazy(() => import('@/app/(admin)/(layouts)/sidenav-hover'));
const SideNavHoverActive = lazy(() => import('@/app/(admin)/(layouts)/sidenav-hover-active'));
const SideOffcanvas = lazy(() => import('@/app/(admin)/(layouts)/sidenav-offcanvas'));
const SideNavSmall = lazy(() => import('@/app/(admin)/(layouts)/sidenav-small'));

//Pages

const Faq = lazy(() => import('@/app/(admin)/(pages)/faqs'));
const Pricing = lazy(() => import('@/app/(admin)/(pages)/pricing'));
const Starter = lazy(() => import('@/app/(admin)/(pages)/starter'));
const Timeline = lazy(() => import('@/app/(admin)/(pages)/timeline'));

//auth
const BasicCreatePassword = lazy(() => import('@/app/(auth)/basic-create-password'));
const BasicLogin = lazy(() => import('@/app/(auth)/basic-login'));
const UserLogin = lazy(() => import('@/app/(auth)/user-login'));
const BasicRegister = lazy(() => import('@/app/(auth)/basic-register'));
const BasicResetPassword = lazy(() => import('@/app/(auth)/basic-reset-password'));
const BasicVerifyEmail = lazy(() => import('@/app/(auth)/basic-verify-email'));
const BasicLogout = lazy(() => import('@/app/(auth)/basic-logout'));
const BasicTwoStep = lazy(() => import('@/app/(auth)/basic-two-steps'));
const BoxedCreatePassword = lazy(() => import('@/app/(auth)/boxed-create-password'));
const BoxedLogin = lazy(() => import('@/app/(auth)/boxed-login'));
const BoxedRegister = lazy(() => import('@/app/(auth)/boxed-register'));
const BoxedResetPassword = lazy(() => import('@/app/(auth)/boxed-reset-password'));
const BoxedLogout = lazy(() => import('@/app/(auth)/boxed-logout'));
const BoxedTwoStep = lazy(() => import('@/app/(auth)/boxed-two-steps'));
const CoverCreatePassword = lazy(() => import('@/app/(auth)/cover-create-password'));
const CoverLogin = lazy(() => import('@/app/(auth)/cover-login'));
const CoverRegister = lazy(() => import('@/app/(auth)/cover-register'));
const CoverResetPassword = lazy(() => import('@/app/(auth)/cover-reset-password'));
const CoverLogout = lazy(() => import('@/app/(auth)/cover-logout'));
const CoverTwoStep = lazy(() => import('@/app/(auth)/cover-two-steps'));
const CoverVerifyEmail = lazy(() => import('@/app/(auth)/cover-verify-email'));
const ModernCreatePassword = lazy(() => import('@/app/(auth)/modern-create-password'));
const ModernLogin = lazy(() => import('@/app/(auth)/modern-login'));
const ModernRegister = lazy(() => import('@/app/(auth)/modern-register'));
const ModernResetPassword = lazy(() => import('@/app/(auth)/modern-reset-password'));
const ModernLogout = lazy(() => import('@/app/(auth)/modern-logout'));
const ModernTwoStep = lazy(() => import('@/app/(auth)/modern-two-steps'));
const ModernVerifyEmail = lazy(() => import('@/app/(auth)/modern-verify-email'));

//  landing

const OnePageLanding = lazy(() => import('@/app/(landing)/onepage-landing'));
const ProductLanding = lazy(() => import('@/app/(landing)/product-landing'));

//Other
const Error404 = lazy(() => import('@/app/(others)/404'));
const CommingSoon = lazy(() => import('@/app/(others)/coming-soon'));
const Maintenance = lazy(() => import('@/app/(others)/maintenance'));
const Offline = lazy(() => import('@/app/(others)/offline'));

const CompanyDetailView = lazy(() => import('@/app/(admin)/(app)/(company)/[id]/page'));

export const layoutsRoutes = [
  {
    path: '/my-profile',
    name: 'Profile',
    element: <Profile />,
  },
  {
    path: '/',
    name: 'HR',
    element: <Hr />,
  },
  // {
  //   path: '/index',
  //   name: 'Ecommerce',
  //   element: <Ecommerce />
  // },
  // {
  //   path: '/cart',
  //   name: 'Cart',
  //   element: <Cart />,
  // },
  // {
  //   path: '/checkout',
  //   name: 'Checkout',
  //   element: <Checkout />,
  // },
  // {
  //   path: '/order-overview',
  //   name: 'OrderOverview',
  //   element: <OrderOverview />,
  // },
  // {
  //   path: '/orders',
  //   name: 'Orders',
  //   element: <Orders />,
  // },
  // {
  //   path: '/product-create',
  //   name: 'ProductCreate',
  //   element: <ProductCreate />,
  // },
  // {
  //   path: '/product-grid',
  //   name: 'ProductGrid',
  //   element: <ProductGrid />,
  // },
  // {
  //   path: '/product-list',
  //   name: 'ProductList',
  //   element: <ProductList />,
  // },
  // {
  //   path: '/product-overview',
  //   name: 'ProductOverview',
  //   element: <ProductOverview />,
  // },
  // {
  //   path: '/sellers',
  //   name: 'Sellers',
  //   element: <Sellers />,
  // },
  {
    path: '/announcement',
    name: 'Announcement',
    element: <Announcement />,
  },
  {
    path: '/my-expenses',
    name: 'MyExpenses',
    element: <MyExpenses />,
    excludeRoles: ['admin', 'superadmin'],
  },
  {
    path: '/expense-approvals',
    name: 'ExpenseApprovals',
    element: <ExpenseApprovals />,
    permissions: ['expense.approve'],
  },
  {
    path: '/attendance/:id',
    name: 'Attendances',
    element: <Attendances />,
    permissions: ['attendance.punch.view'],
  },
  {
    path: '/punch',
    name: 'Punch',
    element: <PunchDetails />,
    // permissions: ['attendance.punch.view'],
  },
  {
    path: '/payslip',
    name: 'Payslip',
    element: <PayslipDetails />,
  },
  {
    path: '/company',
    name: 'Company',
    element: <Company />,
    permissions: ['company.view'],
  },
  {
    path: '/company/:id',
    name: 'Company Detail View',
    element: <CompanyDetailView />,
    permissions: ['company.overview'],
  },
  {
    path: '/projects',
    name: 'Projects',
    element: <Projects />,
    permissions: ['project.view'],
  },
  {
    path: '/tasks',
    name: 'Tasks',
    element: <Tasks />,
    permissions: ['task.view'],
  },
  {
    path: '/leads',
    name: 'Leads',
    element: <Leads />,
    permissions: ['lead.view'],
  },
  {
    path: '/announcement',
    name: 'Announcement',
    element: <Announcement />,
  },
  {
    path: '/master-settings',
    name: 'MasterSettings',
    element: <MasterSettings />,
    permissions: [
      'holiday.view',
      'department.view',
      'designation.view',
      'grade.view',
      'leave.view',
    ],
  },

  {
    path: '/attendance-main',
    name: 'AttemdanceMain',
    element: <AttemdanceMain />,
    permissions: ['attendance.calendar.view'],
  },
  {
    path: '/create-leave',
    name: 'CreateLeave',
    element: <CreateLeave />,
  },
  {
    path: '/create-leave-employee',
    name: 'CreateLeaveEmployee',
    element: <CreateLeaveEmployee />,
  },
  {
    path: '/create-payslip',
    name: 'CreatePayslip',
    element: <CreatePayslip />,
    permissions: ['payroll.generate.view'],
  },
  {
    path: '/grade-setting',
    name: 'GradeSetting',
    element: <PayrollSetting />,
    permissions: ['grade.view'],
  },
  {
    path: '/leave-setting',
    name: 'leaveSetting',
    element: <LeaveSetting />,
    permissions: ['leave.view'],
  },
  {
    path: '/department',
    name: 'Department',
    element: <Department />,
    permissions: ['department.view'],
  },
  {
    path: '/designation',
    name: 'Designation',
    element: <Designations />,
    permissions: ['designation.view'],
  },
  {
    path: '/employee',
    name: 'Employee',
    element: <Employee />,
    permissions: ['employee.view'],
  },
  {
    path: '/employee/:id',
    name: 'Employee Detail',
    element: <EmployeeDetail />,
    permissions: ['employee.view_one'],
  },
  {
    path: '/holidays',
    name: 'Holidays',
    element: <Holidays />,
    permissions: ['holiday.view'],
  },
  {
    path: '/leave',
    name: 'Leave',
    element: <Leave />,
    permissions: ['leave.view'],
  },
  {
    path: '/leave-employee',
    name: 'LeaveEmployee',
    element: <LeaveEmployee />,
  },
  {
    path: '/payroll-employee-salary',
    name: 'PayrollEmplyoeeSalary',
    element: <PayrollEmplyoeeSalary />,
    permissions: ['payroll.salary.view'],
  },
  {
    path: '/payroll-payslip/:id/:month',
    name: 'PayRollSlip',
    element: <PayRollSlip />,
    permissions: ['payroll.salary.view'],
  },
  {
    path: '/sales-estimates',
    name: 'SalesEstimate',
    element: <SalesEstimate />,
  },
  {
    path: '/sales-expenses',
    name: 'SalesExpense',
    element: <SalesExpense />,
  },
  {
    path: '/sales-payments',
    name: 'SalePayment',
    element: <SalePayment />,
  },
  {
    path: '/add-new',
    name: 'InvoiceAddNew',
    element: <InvoiceAddNew />,
  },
  {
    path: '/list',
    name: 'InvoiceList',
    element: <InvoiceList />,
  },
  {
    path: '/overview',
    name: 'InvoiceOverview',
    element: <InvoiceOverview />,
  },
  {
    path: '/users-grid',
    name: 'UserGrid',
    element: <UserGrid />,
  },
  {
    path: '/users-list',
    name: 'UserList',
    element: <UserList />,
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    element: <Hr />,
  },
  {
    path: '/notifications',
    name: 'AllNotifications',
    element: <AllNotifications />,
  },
  {
    path: '/mailbox',
    name: 'MailBox',
    element: <MailBox />,
  },
  {
    path: '/notes',
    name: 'Notes',
    element: <Notes />,
  },

  {
    path: '/apply-leave',
    name: 'UserApplyLeave',
    element: <UserApplyLeave />,
  },
  {
    path: '/applied-leave',
    name: 'UserAppliedLeave',
    element: <UserAppliedLeave />
  },
  {
    path: '/analytics',
    name: 'Analytics',
    element: <Analytics />,
  },
  {
    path: '/',
    name: 'Ecommerce',
    element: <Ecommerce />,
  },
  {
    path: '/email',
    name: 'Email',
    element: <Email />,
  },
  {
    path: '/hr',
    name: 'Hr',
    element: <Hr />,
  },
  {
    path: '/dark-mode',
    name: 'DarkMode',
    element: <DarkMode />,
  },
  {
    path: '/rtl-mode',
    name: 'RtlMode',
    element: <RTL />,
  },
  {
    path: '/sidenav-compact',
    name: 'SideNavCompact',
    element: <SideNavCompact />,
  },
  {
    path: '/sidenav-dark',
    name: 'SideNavDark',
    element: <SideNavDark />,
  },
  {
    path: '/sidenav-hidden',
    name: 'SideNavHidden',
    element: <SideNavHidden />,
  },
  {
    path: '/sidenav-hover',
    name: 'SideNavHover',
    element: <SideNavHover />,
  },
  {
    path: '/sidenav-offcanvas',
    name: 'SideNavOffcanvas',
    element: <SideOffcanvas />,
  },
  {
    path: '/sidenav-small',
    name: 'SideNavSmall',
    element: <SideNavSmall />,
  },
  {
    path: '/sidenav-hover-active',
    name: 'SideNavHoverActive',
    element: <SideNavHoverActive />,
  },
  {
    path: '/faqs',
    name: 'Faqs',
    element: <Faq />,
  },
  {
    path: '/pricing',
    name: 'Pricing',
    element: <Pricing />,
  },
  {
    path: '/starter',
    name: 'Starter',
    element: <Starter />,
  },
  {
    path: '/timeline',
    name: 'Timeline',
    element: <Timeline />,
  },
];
export const singlePageRoutes = [
  {
    path: '/admin-login',
    name: 'BasicLogin',
    element: <BasicLogin />,
  },
  {
    path: '/login',
    name: 'UserLogin',
    element: <UserLogin />,
  },
  {
    path: '/basic-register',
    name: 'BasicRegister',
    element: <BasicRegister />,
  },
  {
    path: '/basic-create-password',
    name: 'BasicCreatePassword',
    element: <BasicCreatePassword />,
  },
  {
    path: '/basic-reset-password',
    name: 'BasicResetPassword',
    element: <BasicResetPassword />,
  },
  {
    path: '/basic-verify-email',
    name: 'BasicVerifyEmail',
    element: <BasicVerifyEmail />,
  },
  {
    path: '/basic-logout',
    name: 'BasicLogout',
    element: <BasicLogout />,
  },
  {
    path: '/basic-two-steps',
    name: 'BasicTwoStep',
    element: <BasicTwoStep />,
  },
  {
    path: '/boxed-login',
    name: 'BoxedLogin',
    element: <BoxedLogin />,
  },
  {
    path: '/boxed-register',
    name: 'BoxedRegister',
    element: <BoxedRegister />,
  },
  {
    path: '/boxed-create-password',
    name: 'BoxedCreatePassword',
    element: <BoxedCreatePassword />,
  },
  {
    path: '/boxed-reset-password',
    name: 'BoxedResetPassword',
    element: <BoxedResetPassword />,
  },
  {
    path: '/boxed-logout',
    name: 'BoxedLogout',
    element: <BoxedLogout />,
  },
  {
    path: '/boxed-two-steps',
    name: 'BoxedTwoStep',
    element: <BoxedTwoStep />,
  },
  {
    path: '/cover-login',
    name: 'CoverLogin',
    element: <CoverLogin />,
  },
  {
    path: '/cover-register',
    name: 'CoverRegister',
    element: <CoverRegister />,
  },
  {
    path: '/cover-create-password',
    name: 'CoverCreatePassword',
    element: <CoverCreatePassword />,
  },
  {
    path: '/cover-reset-password',
    name: 'CoverResetPassword',
    element: <CoverResetPassword />,
  },
  {
    path: '/cover-logout',
    name: 'CoverLogout',
    element: <CoverLogout />,
  },
  {
    path: '/cover-two-steps',
    name: 'CoverTwoStep',
    element: <CoverTwoStep />,
  },
  {
    path: '/cover-verify-email',
    name: 'CoverVerifyEmail',
    element: <CoverVerifyEmail />,
  },
  {
    path: '/modern-create-password',
    name: 'ModernCreatePassword',
    element: <ModernCreatePassword />,
  },
  {
    path: '/modern-login',
    name: 'ModernLogin',
    element: <ModernLogin />,
  },
  {
    path: '/modern-register',
    name: 'ModernRegister',
    element: <ModernRegister />,
  },
  {
    path: '/modern-reset-password',
    name: 'ModernResetPassword',
    element: <ModernResetPassword />,
  },
  {
    path: '/modern-logout',
    name: 'ModernLogout',
    element: <ModernLogout />,
  },
  {
    path: '/modern-verify-email',
    name: 'ModernVerifyEmail',
    element: <ModernVerifyEmail />,
  },
  {
    path: '/modern-two-steps',
    name: 'ModernTwoStep',
    element: <ModernTwoStep />,
  },
  {
    path: '/onepage-landing',
    name: 'OnePageLanding',
    element: <OnePageLanding />,
  },
  {
    path: '/product-landing',
    name: 'ProductLanding',
    element: <ProductLanding />,
  },
  {
    path: '/404',
    name: '404',
    element: <Error404 />,
  },
  {
    path: '/coming-soon',
    name: 'ComingSoon',
    element: <CommingSoon />,
  },
  {
    path: '/maintenance',
    name: 'Maintenance',
    element: <Maintenance />,
  },
  {
    path: '/offline',
    name: 'Offline',
    element: <Offline />,
  },
];
