import api from '@/config/api';

export const leaveService = {
  // Get all leave types
  getAll: async () => {
    const response = await api.get('/leaves');
    return response.data;
  },

  // Create a new leave type
  create: async (leaveData) => {
    const response = await api.post('/leaves', leaveData);
    return response.data;
  },

  // Update a leave type
  update: async (id, leaveData) => {
    const response = await api.put(`/leaves/${id}`, leaveData);
    return response.data;
  },

  // Delete a leave type
  delete: async (id) => {
    const response = await api.delete(`/leaves/${id}`);
    return response.data;
  },

  // Get single leave type
  getById: async (id) => {
    const response = await api.get(`/leaves/${id}`);
    return response.data;
  }
};