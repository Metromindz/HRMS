import api from '../config/api';

export const shiftService = {
  getAll: async () => {
    const response = await api.get('/shifts');
    return response.data.shifts;
  },

  getDefault: async () => {
    const response = await api.get('/shifts/default');
    return response.data.shift;
  },

  create: async (data) => {
    const response = await api.post('/shifts', data);
    return response.data;
  },

  update: async (id, data) => {
    const response = await api.put(`/shifts/${id}`, data);
    return response.data;
  },

  delete: async (id) => {
    const response = await api.delete(`/shifts/${id}`);
    return response.data;
  }
};