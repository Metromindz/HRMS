import api from '@/config/api';

export const gradeService = {
  // Get all grades
  getAll: async () => {
    const response = await api.get('/grades');
    return response.data;
  },

  // Create a new grade
  create: async (gradeData) => {
    const response = await api.post('/grades', gradeData);
    return response.data;
  },

  // Update a grade
  update: async (id, gradeData) => {
    const response = await api.put(`/grades/${id}`, gradeData);
    return response.data;
  },

  // Delete a grade
  delete: async (id) => {
    const response = await api.delete(`/grades/${id}`);
    return response.data;
  },

  // Bulk upsert grades
  bulkUpsert: async (gradesArray) => {
    const response = await api.post('/grades/bulk', gradesArray);
    return response.data;
  },

  // Transform frontend form data to backend format
  transformToBackend: (formData) => {
     const filteredExtraAllowances = formData.extraAllowances
      ?.filter(ea => 
        ea.name && ea.name.trim() !== '' && 
        ea.amount && parseFloat(ea.amount) > 0
      )
      .map(ea => ({
        name: ea.name.trim(),
        amount: parseFloat(ea.amount) || 0
      })) || [];

      return{
    grade: formData.grade,
    basic: { 
      value: parseFloat(formData.basic) || 0, 
      unit: formData.basicUnit 
    },
    hra: { 
      value: parseFloat(formData.hra) || 0, 
      unit: formData.hraUnit  
    },
    pfEnabled: formData.pfEnabled,
    pfPercent: parseFloat(formData.pfPercent) ,
    esiEnabled: formData.esiEnabled,
    esiPercent: parseFloat(formData.esiPercent) ,
    medical: parseFloat(formData.medical) || 0,
    pt: parseFloat(formData.pt) || 0,
    tds: parseFloat(formData.tds) || 0,
    specialAllowance: parseFloat(formData.specialAllowance) || 0,
    conveyanceAllowance: parseFloat(formData.conveyance) || 0,
    extraAllowances: filteredExtraAllowances,
  }},

  // Transform backend data to frontend format
  transformToFrontend: (backendData) => ({
    id: backendData._id,
    grade: backendData.grade,
    basic: backendData.basic?.value || '',
    hra: backendData.hra?.value || '',
    pfEnabled: backendData.pfEnabled || false,
    pfPercent: backendData.pfPercent ,
    esiEnabled: backendData.esiEnabled || false,
    esiPercent: backendData.esiPercent ,
    medical: backendData.medical || '',
    pt: backendData.pt || '',
    tds: backendData.tds || '',
    specialAllowance: backendData.specialAllowance || '',
    conveyance: backendData.conveyanceAllowance || '',
    extraAllowances: backendData.extraAllowances || []
  })
};