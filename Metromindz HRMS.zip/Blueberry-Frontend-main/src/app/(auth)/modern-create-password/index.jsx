import modernImg from '@/assets/images/auth-modern.png';
import Logo from '../../../assets/images/logo-dark-1.png';
import modern from '@/assets/images/modern.svg';
import IconifyIcon from '@/components/client-wrapper/IconifyIcon';
import PageMeta from '@/components/PageMeta';
import { Link } from 'react-router';

const Index = () => {
  return <>
      <PageMeta title="Create Password" />
      <div className="relative flex flex-row w-full overflow-hidden bg-gradient-to-r from-blue-900 h-screen to-blue-800 dark:to-blue-900 dark:from-blue-950">
        <div className="absolute inset-0 opacity-20">
          <img src={modern} alt="" />
        </div>

        <div className="mx-4 m-4 w-160 py-14 px-10 bg-card flex justify-center rounded-md text-center relative z-10">
          <div className="flex flex-col h-full">
            <div className="my-auto">
              <div className="mt-8">
                <h4 className="mb-2 text-primary text-xl font-semibold">Set a New Password</h4>
                <p className="text-base mb-8 text-default-500">
                  Your new password should be distinct from any of your prior passwords
                </p>
              </div>

              <form action="#">
                <div className="text-start mb-3">
                  <label htmlFor="Email" className="inline-block mb-2 text-sm text-default-800 font-medium">
                    Existing Password
                  </label>
                  <input type="text" id="Email" className="form-input" placeholder="Enter Existing Password" />
                </div>

                <div className="text-start">
                  <label htmlFor="Email" className="inline-block mb-2 text-sm text-default-800 font-medium">
                    New Password
                  </label>
                  <input type="text" id="Email" className="form-input" placeholder="Enter New Password" />
                </div>

                <div className="text-start mt-4">
                  <label htmlFor="Email" className="inline-block mb-2 text-sm text-default-800 font-medium">
                    Confirm New Password
                  </label>
                  <input type="text" id="Email" className="form-input" placeholder="Confirm New Password" />
                </div>

                <div className="mt-8">
                  <button type="button" className="btn bg-secondary text-white w-full">
                    Update Password
                  </button>
                </div>

                <div className="mt-8">
                  {/* <button type="button" className="btn bg-primary text-white w-full">
                    Back to Dashboard
                  </button> */}

                  <Link to="/" className="btn bg-primary text-white flex items-center">
                    Back to Dashboard
                  </Link>
                </div>
              </form>
            </div>

            <div className="mt-5 flex justify-center">
              <span className="text-sm text-default-500 flex gap-1">
                <IconifyIcon icon="lucide:copyright" className="w-4 h-4 align-middle" />
                2025 Metromindz Private Limited.
              </span>
            </div>
          </div>
        </div>

        <div className="relative z-10 flex items-center justify-center min-h-screen px-10 py-14 grow">
          <div>
            <Link to="/" className="index">
              <img src={Logo} alt="" className="mb-14 mx-auto block" />
            </Link>

            <img src={modernImg} alt="" className="mx-auto rounded-xl block object-cover w-md" />
          </div>
        </div>
      </div>
    </>;
};
export default Index;
