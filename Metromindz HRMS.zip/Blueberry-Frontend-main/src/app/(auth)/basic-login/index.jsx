import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '@/context/AuthContext';
import logoDark from '@/assets/images/logo.png';
import logoLight from '@/assets/images/logo-light.png';
import authBg from '@/assets/images/auth-bg.jpg'; // Using the same background
import { LuEye, LuEyeOff } from 'react-icons/lu';
import PageMeta from '@/components/PageMeta';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Pagination } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/pagination';

const Index = () => {
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const savedCredentials = localStorage.getItem('rememberedAdminCredentials');
    if (savedCredentials) {
      const parsed = JSON.parse(savedCredentials);
      setCredentials(parsed);
      setRememberMe(true);
    }
  }, []);

  const handleSubmit = async e => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (rememberMe) {
        localStorage.setItem('rememberedAdminCredentials', JSON.stringify(credentials));
      } else {
        localStorage.removeItem('rememberedAdminCredentials');
      }

      const data = await login(credentials);
      navigate(data.landingPage);
    } catch (error) {
      setError(error.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <PageMeta title="Super Admin Login" />
      <div className="min-h-screen bg-default-50 flex items-center justify-center p-4">
        <div className="w-full max-w-[1400px] bg-white rounded-2xl shadow-xl overflow-hidden grid lg:grid-cols-2 min-h-[600px]">

          {/* Left Side - Carousel */}
          <div className="hidden lg:block relative bg-primary/5">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/80 to-primary/60 mix-blend-multiply z-10" />
            <img
              src={authBg}
              alt="Background"
              className="absolute inset-0 w-full h-full object-cover"
            />

            <div className="relative z-20 h-full flex flex-col justify-between p-12 text-white">
              <div>
                <img src={logoLight} alt="MetroMindz" className="h-12 w-auto" />
              </div>

              <div className="max-w-md">
                <Swiper
                  modules={[Autoplay, Pagination]}
                  spaceBetween={30}
                  centeredSlides={true}
                  autoplay={{
                    delay: 3500,
                    disableOnInteraction: false,
                  }}
                  pagination={{
                    clickable: true,
                    bulletClass: 'swiper-pagination-bullet !bg-white/50 !opacity-100',
                    bulletActiveClass: 'swiper-pagination-bullet-active !bg-white !w-6 transition-all duration-300'
                  }}
                  className="pb-12"
                >
                  <SwiperSlide>
                    <h2 className="text-3xl font-bold mb-4">Welcome Back!</h2>
                    <p className="text-lg text-white/90">
                      Streamline your HR processes and manage employee data efficiently with MetroMindz ERP.
                    </p>
                  </SwiperSlide>
                  <SwiperSlide>
                    <h2 className="text-3xl font-bold mb-4">Smart Management</h2>
                    <p className="text-lg text-white/90">
                      Access payroll, attendance, and leave management all in one centralized platform.
                    </p>
                  </SwiperSlide>
                  <SwiperSlide>
                    <h2 className="text-3xl font-bold mb-4">Secure & Reliable</h2>
                    <p className="text-lg text-white/90">
                      Your data is safe with us. Experience enterprise-grade security for your organization.
                    </p>
                  </SwiperSlide>
                </Swiper>
              </div>

              <div className="flex gap-4 text-sm text-white/70">
                <span>© {new Date().getFullYear()} MetroMindz</span>
                <span>Privacy Policy</span>
                <span>Terms of Service</span>
              </div>
            </div>
          </div>

          {/* Right Side - Login Form */}
          <div className="flex items-center justify-center p-8 md:p-12">
            <div className="w-full max-w-md space-y-8">
              <div className="text-center lg:text-left">
                <img src={logoDark} alt="Logo" className="h-10 mx-auto lg:hidden mb-8" />
                <h1 className="text-3xl font-bold text-gray-900">Super Admin</h1>
                <p className="mt-2 text-gray-600">Enter your credentials to access the admin panel.</p>
              </div>

              <form onSubmit={handleSubmit} className="mt-8 space-y-6">
                {error && (
                  <div className="p-4 rounded-lg bg-red-50 border border-red-200 text-red-600 text-sm">
                    {error}
                  </div>
                )}

                <div className="space-y-6">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      Email Address
                    </label>
                    <div className="mt-1">
                      <input
                        id="email"
                        name="email"
                        type="email"
                        required
                        className="block w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors bg-gray-50 focus:bg-white"
                        placeholder="admin@company.com"
                        value={credentials.email}
                        onChange={e => setCredentials({ ...credentials, email: e.target.value })}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between">
                      <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                        Password
                      </label>
                    </div>
                    <div className="mt-1 relative">
                      <input
                        id="password"
                        name="password"
                        type={showPassword ? "text" : "password"}
                        required
                        className="block w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors bg-gray-50 focus:bg-white pr-10"
                        placeholder="••••••••"
                        value={credentials.password}
                        onChange={e => setCredentials({ ...credentials, password: e.target.value })}
                      />
                      <button
                        type="button"
                        className="absolute inset-y-0 right-0 flex items-center pr-3 text-gray-400 hover:text-gray-600"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <LuEyeOff className="h-5 w-5" />
                        ) : (
                          <LuEye className="h-5 w-5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <input
                      id="remember-me"
                      name="remember-me"
                      type="checkbox"
                      className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                      checked={rememberMe}
                      onChange={e => setRememberMe(e.target.checked)}
                    />
                    <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-700 cursor-pointer">
                      Remember me
                    </label>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
                >
                  {loading ? (
                    <span className="flex items-center gap-2">
                      <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Signing in...
                    </span>
                  ) : (
                    'Sign In'
                  )}
                </button>


              </form>
            </div>
          </div>
        </div>

        {/* Background Pattern */}
        <div className="fixed inset-0 pointer-events-none -z-10">
          <svg
            className="absolute inset-0 h-full w-full stroke-gray-200 [mask-image:radial-gradient(100%_100%_at_top_right,white,transparent)]"
            aria-hidden="true"
          >
            <defs>
              <pattern
                id="grid-pattern"
                width="40"
                height="40"
                patternUnits="userSpaceOnUse"
                x="50%"
                y="-1"
              >
                <path d="M.5 40V.5H40" fill="none" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" strokeWidth="0" fill="url(#grid-pattern)" />
          </svg>
        </div>
      </div>
    </>
  );
};

export default Index;
