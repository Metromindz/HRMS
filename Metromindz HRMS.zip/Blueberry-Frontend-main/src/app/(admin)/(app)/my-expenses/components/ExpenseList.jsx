import { useState, useEffect, useMemo } from 'react';
import { LuPlus, LuSearch, LuSquarePen, LuTrash2, LuEye, LuList, LuCheck, LuClock, LuCircleX } from 'react-icons/lu';
import { FiCheckCircle, FiXCircle, FiClock } from 'react-icons/fi';
import api from '@/config/api';
import ExpenseForm from './ExpenseForm';
import { toast } from 'react-hot-toast';

const ExpenseList = () => {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editExpense, setEditExpense] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const stats = useMemo(() => {
    const totalExpenses = expenses.length;
    const approved = expenses.filter(e => e.status === 'Approved').length;
    const pending = expenses.filter(e => e.status === 'Pending').length;
    const rejected = expenses.filter(e => e.status === 'Rejected').length;
    return { totalExpenses, approved, pending, rejected };
  }, [expenses]);

  const fetchExpenses = async () => {
    try {
      setLoading(true);
      const response = await api.get('/expenses/my');
      if (response.data.success) {
        setExpenses(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching expenses:', error);
      toast.error('Failed to load expenses');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchExpenses();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this expense?')) {
      try {
        const response = await api.delete(`/expenses/${id}`);
        if (response.data.success) {
          toast.success('Expense deleted successfully');
          fetchExpenses();
        }
      } catch (error) {
        toast.error(error.response?.data?.message || 'Failed to delete expense');
      }
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Approved': return 'bg-success/10 text-success';
      case 'Rejected': return 'bg-danger/10 text-danger';
      default: return 'bg-warning/10 text-warning';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'Approved': return <FiCheckCircle className="size-3.5 me-1" />;
      case 'Rejected': return <FiXCircle className="size-3.5 me-1" />;
      default: return <FiClock className="size-3.5 me-1" />;
    }
  };

  const filteredExpenses = expenses.filter(exp =>
    (exp.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      exp.category.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (statusFilter ? exp.status === statusFilter : true)
  );

  return (
    <>
      <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5 mb-6">
        <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
              <LuList className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Total Expenses</div>
              <div className="text-2xl font-black text-default-900 leading-none">{stats.totalExpenses}</div>
            </div>
          </div>
        </div>
        <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-2xl bg-warning/10 flex items-center justify-center text-warning group-hover:scale-110 transition-transform duration-300">
              <LuClock className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Pending</div>
              <div className="text-2xl font-black text-default-900 leading-none">{stats.pending}</div>
            </div>
          </div>
        </div>
        <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-2xl bg-success/10 flex items-center justify-center text-success group-hover:scale-110 transition-transform duration-300">
              <LuCheck className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Approved</div>
              <div className="text-2xl font-black text-default-900 leading-none">{stats.approved}</div>
            </div>
          </div>
        </div>
        <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-2xl bg-danger/10 flex items-center justify-center text-danger group-hover:scale-110 transition-transform duration-300">
              <LuCircleX className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Rejected</div>
              <div className="text-2xl font-black text-danger leading-none">{stats.rejected}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-4 border border-default-200 mb-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3 flex-wrap flex-1 min-w-0">
            <div className="relative flex-1 max-w-xs min-w-[200px]">
              <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-default-400" />
              <input
                type="text"
                className="form-input pl-10 h-11 w-full rounded-2xl border-default-200 focus:border-primary focus:ring-primary bg-default-50/50 text-sm font-medium transition-all"
                placeholder="Search expenses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="w-full sm:w-auto min-w-[150px]">
              <select
                className="form-select h-11 w-full rounded-2xl border-default-200 focus:border-primary focus:ring-primary bg-default-50/50 text-sm font-medium transition-all"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="">All Status</option>
                <option value="Pending">Pending</option>
                <option value="Approved">Approved</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>
          </div>

          <button
            className="btn bg-primary text-white flex items-center gap-2 px-6 h-11 rounded-2xl font-bold uppercase tracking-widest transition-all hover:bg-primary-600"
            onClick={() => {
              setEditExpense(null);
              setIsModalOpen(true);
            }}
          >
            <LuPlus className="size-4" />
            Add Expense
          </button>
        </div>
      </div>

      <div className="card">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-default-200">
            <thead className="bg-default-50">
              <tr>
                <th className="px-6 py-3 text-start text-xs font-bold text-default-500 uppercase">Date</th>
                <th className="px-6 py-3 text-start text-xs font-bold text-default-500 uppercase">Title</th>
                <th className="px-6 py-3 text-start text-xs font-bold text-default-500 uppercase">Category</th>
                <th className="px-6 py-3 text-start text-xs font-bold text-default-500 uppercase">Amount</th>
                <th className="px-6 py-3 text-start text-xs font-bold text-default-500 uppercase">Status</th>
                <th className="px-6 py-3 text-end text-xs font-bold text-default-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-default-200">
              {loading ? (
                <tr>
                  <td colSpan="6" className="px-6 py-4 text-center text-default-500">Loading...</td>
                </tr>
              ) : filteredExpenses.length === 0 ? (
                <tr>
                  <td colSpan="6" className="px-6 py-4 text-center text-default-500">No expenses found</td>
                </tr>
              ) : (
                filteredExpenses.map((expense) => (
                  <tr key={expense._id} className="hover:bg-default-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-default-700">
                      {new Date(expense.date).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-default-900">
                      {expense.title}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-default-700">
                      <span className="px-2 py-1 rounded-md bg-default-100">{expense.category}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-default-900">
                      ₹{expense.amount.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(expense.status)}`}>
                        {getStatusIcon(expense.status)}
                        {expense.status}
                      </span>
                      {expense.reimbursementStatus === 'Processed' && (
                        <span className="ms-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-info/10 text-info">
                          Reimbursed
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-end text-sm font-medium">
                      <div className="flex justify-end gap-2">
                        {expense.receiptUrl && (
                          <a
                            href={expense.receiptUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1.5 text-info hover:bg-info/10 rounded-md transition-all"
                            title="View Receipt"
                          >
                            <LuEye className="size-4" />
                          </a>
                        )}
                        {expense.status === 'Pending' && (
                          <>
                            <button
                              className="p-1.5 text-primary hover:bg-primary/10 rounded-md transition-all"
                              onClick={() => {
                                setEditExpense(expense);
                                setIsModalOpen(true);
                              }}
                              title="Edit"
                            >
                              <LuSquarePen className="size-4" />
                            </button>
                            <button
                              className="p-1.5 text-danger hover:bg-danger/10 rounded-md transition-all"
                              onClick={() => handleDelete(expense._id)}
                              title="Delete"
                            >
                              <LuTrash2 className="size-4" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {isModalOpen && (
          <ExpenseForm
            expense={editExpense}
            onClose={() => setIsModalOpen(false)}
            onSuccess={() => {
              setIsModalOpen(false);
              fetchExpenses();
            }}
          />
        )}
      </div>
    </>
  );
};

export default ExpenseList;
