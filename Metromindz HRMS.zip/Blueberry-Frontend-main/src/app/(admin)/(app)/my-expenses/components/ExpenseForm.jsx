import { useState, useEffect } from 'react';
import { LuX, LuUpload } from 'react-icons/lu';
import api from '@/config/api';
import { toast } from 'react-hot-toast';

const ExpenseForm = ({ expense, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    title: '',
    category: 'Travel',
    amount: '',
    date: new Date().toISOString().split('T')[0],
    description: '',
  });
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [fieldErrors, setFieldErrors] = useState({});

  const categories = ['Travel', 'Food', 'Accommodation', 'Office Supplies', 'Communication', 'Others'];

  const clearFieldError = (field) => {
    if (!fieldErrors[field]) return;
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };

  const validate = () => {
    const errors = {};

    const title = formData.title?.trim() || '';
    if (!title) errors.title = 'Title is required';
    else if (title.length < 3) errors.title = 'Title must be at least 3 characters';
    else if (title.length > 120) errors.title = 'Title must be at most 120 characters';

    if (!categories.includes(formData.category)) errors.category = 'Invalid category';

    const amountNumber = Number(formData.amount);
    if (formData.amount === '' || formData.amount === null || formData.amount === undefined) errors.amount = 'Amount is required';
    else if (!Number.isFinite(amountNumber)) errors.amount = 'Amount must be a number';
    else if (amountNumber <= 0) errors.amount = 'Amount must be greater than 0';
    else if (amountNumber > 1000000000) errors.amount = 'Amount is too large';

    const date = formData.date ? new Date(`${formData.date}T00:00:00`) : null;
    if (!date || Number.isNaN(date.getTime())) errors.date = 'Date is required';
    else {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (date > today) errors.date = 'Date cannot be in the future';
    }

    const description = formData.description?.trim() || '';
    if (description.length > 2000) errors.description = 'Description is too long';

    if (file) {
      const maxSizeBytes = 5 * 1024 * 1024;
      const isPdf = file.type === 'application/pdf';
      const isImage = file.type?.startsWith('image/');
      if (!isPdf && !isImage) errors.receipt = 'Receipt must be an image or PDF';
      else if (file.size > maxSizeBytes) errors.receipt = 'Receipt must be 5MB or less';
    }

    setFieldErrors(errors);
    const firstError = Object.values(errors)[0];
    if (firstError) toast.error(firstError);
    return Object.keys(errors).length === 0;
  };

  useEffect(() => {
    if (expense) {
      setFormData({
        title: expense.title,
        category: expense.category,
        amount: expense.amount,
        date: new Date(expense.date).toISOString().split('T')[0],
        description: expense.description || '',
      });
    }
  }, [expense]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);

    const data = new FormData();
    Object.keys(formData).forEach(key => {
      data.append(key, key === 'title' || key === 'description' ? String(formData[key] || '').trim() : formData[key]);
    });
    if (file) {
      data.append('receipt', file);
    }

    try {
      let response;
      if (expense) {
        response = await api.put(`/expenses/${expense._id}`, data);
      } else {
        response = await api.post('/expenses', data);
      }

      if (response.data.success) {
        toast.success(`Expense ${expense ? 'updated' : 'submitted'} successfully`);
        onSuccess();
      }
    } catch (error) {
      toast.error(error.response?.data?.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-default-100 bg-default-50/50">
          <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">
            {expense ? 'Edit Expense' : 'Add New Expense'}
          </h3>
          <button onClick={onClose} className="p-2 hover:bg-default-200 rounded-full transition-all">
            <LuX className="size-5 text-default-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="col-span-2">
              <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Title</label>
              <input
                type="text"
                required
                className={`form-input w-full rounded-xl ${fieldErrors.title ? 'border-danger' : ''}`}
                placeholder="e.g. Flight to London"
                value={formData.title}
                onChange={(e) => {
                  clearFieldError('title');
                  setFormData({ ...formData, title: e.target.value });
                }}
              />
              {fieldErrors.title && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.title}</div>}
            </div>

            <div>
              <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Category</label>
              <select
                className={`form-select w-full rounded-xl ${fieldErrors.category ? 'border-danger' : ''}`}
                value={formData.category}
                onChange={(e) => {
                  clearFieldError('category');
                  setFormData({ ...formData, category: e.target.value });
                }}
              >
                {categories.map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
              {fieldErrors.category && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.category}</div>}
            </div>

            <div>
              <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Amount</label>
              <div className="relative">
                <span className="absolute inset-y-0 start-0 flex items-center ps-3 text-default-500">$</span>
                <input
                  type="number"
                  required
                  min="0"
                  step="0.01"
                  className={`form-input w-full ps-7 rounded-xl ${fieldErrors.amount ? 'border-danger' : ''}`}
                  placeholder="0.00"
                  value={formData.amount}
                  onChange={(e) => {
                    clearFieldError('amount');
                    setFormData({ ...formData, amount: e.target.value });
                  }}
                />
              </div>
              {fieldErrors.amount && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.amount}</div>}
            </div>

            <div className="col-span-2">
              <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Date</label>
              <input
                type="date"
                required
                className={`form-input w-full rounded-xl ${fieldErrors.date ? 'border-danger' : ''}`}
                value={formData.date}
                onChange={(e) => {
                  clearFieldError('date');
                  setFormData({ ...formData, date: e.target.value });
                }}
              />
              {fieldErrors.date && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.date}</div>}
            </div>

            <div className="col-span-2">
              <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Description</label>
              <textarea
                className={`form-input w-full rounded-xl ${fieldErrors.description ? 'border-danger' : ''}`}
                rows="3"
                placeholder="Brief details about the expense..."
                value={formData.description}
                onChange={(e) => {
                  clearFieldError('description');
                  setFormData({ ...formData, description: e.target.value });
                }}
              />
              {fieldErrors.description && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.description}</div>}
            </div>

            <div className="col-span-2">
              <label className="block text-xs font-black text-default-600 uppercase tracking-widest mb-2">Receipt (Optional)</label>
              <div className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-2xl hover:border-primary transition-all cursor-pointer group relative ${fieldErrors.receipt ? 'border-danger' : 'border-default-200'}`}>
                <div className="space-y-1 text-center">
                  <LuUpload className="mx-auto size-10 text-default-400 group-hover:text-primary transition-all" />
                  <div className="flex text-sm text-default-600">
                    <label className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-primary-600">
                      <span>{file ? file.name : 'Upload a file'}</span>
                      <input 
                        type="file" 
                        className="sr-only" 
                        accept="image/*,.pdf"
                        onChange={(e) => {
                          clearFieldError('receipt');
                          setFile(e.target.files?.[0] || null);
                        }}
                      />
                    </label>
                  </div>
                  <p className="text-xs text-default-400">PNG, JPG, PDF up to 5MB</p>
                </div>
              </div>
              {fieldErrors.receipt && <div className="mt-1 text-xs font-semibold text-danger">{fieldErrors.receipt}</div>}
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 rounded-xl border border-default-200 text-sm font-black text-default-700 uppercase tracking-widest hover:bg-default-50 transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-6 py-3 rounded-xl bg-primary text-white text-sm font-black uppercase tracking-widest hover:bg-primary-600 transition-all shadow-lg shadow-primary/20 disabled:opacity-50"
            >
              {loading ? 'Processing...' : (expense ? 'Update' : 'Submit')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ExpenseForm;
