import { useEffect, useState } from 'react';
import Flatpickr from 'react-flatpickr';
import { LuArrowBigLeft, LuPlus } from 'react-icons/lu';
import { Link, useNavigate } from 'react-router';
import api from '../../../../../../config/api.js';
import toast from 'react-hot-toast';

const ApplyingLeave = () => {
  const navigate = useNavigate();
  const [leaveType, setLeaveType] = useState([]);
  const [activeTab, setActiveTab] = useState('leave'); // 'leave' or 'wfh'
  const [formData, setFormData] = useState({
    employeeName: '',
    employeeId: '',
    leaveId: '',
    fromDate: '',
    toDate: '',
    numberOfDays: 0,
    reason: '',
  });
  const [leaveBalance, setLeaveBalance] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [fieldErrors, setFieldErrors] = useState({});

  const gettingLeaveTypes = async () => {
    try {
      const res = await api.get('/leaves');
      if (res.status === 200) {
        setLeaveType(res.data || []);
      }
    } catch (error) {
      console.error('Error in fetching the leave Types', error);
    }
  };

  const wfhOption = leaveType.find(l => l.category === 'WFH' || l.leaveName === 'Work From Home');
  const leaveOptions = leaveType.filter(l => l.category !== 'WFH' && l.leaveName !== 'Work From Home');

  useEffect(() => {
    if (activeTab === 'wfh' && wfhOption) {
      setFormData(prev => ({ ...prev, leaveId: wfhOption._id }));
    } else if (activeTab === 'leave') {
       // Reset if switching back to leave, but only if current leaveId was the WFH one
       if (formData.leaveId === wfhOption?._id) {
          setFormData(prev => ({ ...prev, leaveId: '' }));
       }
    }
  }, [activeTab, wfhOption]);

  const getLeaveBalance = async () => {
    try {
      const res = await api.get(`/leave-balance/${formData.employeeId}`);
      if (res.status === 200) {
        setLeaveBalance(res.data.data);
      }
    } catch (error) {
      console.error('Error fetching leave balance', error);
    }
  };

  const calculateDays = (fromDate, toDate) => {
    if (fromDate && toDate) {
      const start = new Date(fromDate);
      const end = new Date(toDate);
      if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end < start) {
        setFormData(prev => ({ ...prev, numberOfDays: 0 }));
        return;
      }
      const diffTime = end - start;
      const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24)) + 1;
      setFormData(prev => ({ ...prev, numberOfDays: diffDays }));
    }
  };

  const getRemainingLeaves = () => {
    if (!leaveBalance || !formData.leaveId) return '0';
    const selectedLeave = leaveBalance.leaveBalances?.find(lb => lb.leaveId === formData.leaveId);
    return selectedLeave ? selectedLeave.yearlyRemaining : '0';
  };

  const resetForm = () => {
    setFormData({
      employeeName: formData.employeeName, // keep name
      employeeId: formData.employeeId,     // keep ID
      leaveId: activeTab === 'wfh' ? (wfhOption?._id || '') : '',
      fromDate: '',
      toDate: '',
      numberOfDays: 0,
      reason: '',
    });
    // setMessage('');
  };

  const clearFieldError = (field) => {
    if (!fieldErrors[field]) return;
    setFieldErrors((prev) => {
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };

  const validate = (currentData) => {
    const errors = {};

    if (!currentData.employeeId) errors.employeeId = 'Employee ID is required';
    if (!currentData.employeeName) errors.employeeName = 'Employee name is required';

    if (!currentData.leaveId) errors.leaveId = 'Leave type is required';

    if (!currentData.fromDate) errors.fromDate = 'From date is required';
    if (!currentData.toDate) errors.toDate = 'To date is required';

    if (currentData.fromDate && currentData.toDate) {
      const start = new Date(currentData.fromDate);
      const end = new Date(currentData.toDate);
      if (Number.isNaN(start.getTime())) errors.fromDate = 'From date is invalid';
      if (Number.isNaN(end.getTime())) errors.toDate = 'To date is invalid';
      if (!errors.fromDate && !errors.toDate && end < start) errors.toDate = 'To date must be after from date';
    }

    const reason = currentData.reason?.trim() || '';
    if (!reason) errors.reason = 'Reason is required';
    else if (reason.length < 5) errors.reason = 'Reason must be at least 5 characters';
    else if (reason.length > 500) errors.reason = 'Reason must be at most 500 characters';

    if (!currentData.numberOfDays || currentData.numberOfDays <= 0) errors.numberOfDays = 'Select a valid date range';

    if (activeTab === 'leave' && currentData.leaveId) {
      const remaining = Number(getRemainingLeaves());
      if (Number.isFinite(remaining) && remaining > 0 && currentData.numberOfDays > remaining) {
        errors.numberOfDays = `Requested days exceed remaining balance (${remaining})`;
      }
    }

    setFieldErrors(errors);
    const firstError = Object.values(errors)[0];
    if (firstError) {
      setMessage(firstError);
      toast.error(firstError);
    }
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async () => {
    let currentData = { ...formData };

    if (!currentData.employeeId) {
      // Attempt to fetch details if missing
      const employee = await fetchEmployeeDetails();
      if (employee) {
        currentData.employeeId = employee.employeeId;
        currentData.employeeName = employee.name;
        // Update state as well for UI consistency
        setFormData(prev => ({
           ...prev,
           employeeName: employee.name,
           employeeId: employee.employeeId,
        }));
      } else {
         setMessage('Unable to fetch employee details. Please try again.');
         toast.error('Unable to fetch employee details. Please try again.');
         return;
      }
    }
    
    // Check WFH
    if (activeTab === 'wfh' && !currentData.leaveId) {
        const wfh = leaveType.find(l => l.category === 'WFH' || l.leaveName === 'Work From Home');
        if (wfh) {
           currentData.leaveId = wfh._id;
        } else {
           setMessage('Error: "Work From Home" leave type not configured. Please contact HR.');
           toast.error('Error: "Work From Home" leave type not configured. Please contact HR.');
           return;
        }
    }
    currentData.reason = currentData.reason?.trim() || '';
    calculateDays(currentData.fromDate, currentData.toDate);
    currentData.numberOfDays = currentData.fromDate && currentData.toDate
      ? (() => {
        const start = new Date(currentData.fromDate);
        const end = new Date(currentData.toDate);
        if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end < start) return 0;
        return Math.floor((end - start) / (1000 * 60 * 60 * 24)) + 1;
      })()
      : 0;

    if (!validate(currentData)) return;

    setLoading(true);
    setMessage('');

    try {
      const response = await api.post('/leave-requests', {
        empId: currentData.employeeId,
        employeeName: currentData.employeeName,
        leaveId: currentData.leaveId,
        fromDate: currentData.fromDate,
        toDate: currentData.toDate,
        reason: currentData.reason,
      });

      if (response.status === 200 || response.status === 201) {
        setMessage('Leave request submitted successfully!');
        toast.success('Leave request submitted successfully!');
        resetForm();
        getLeaveBalance();
        setTimeout(() => {
          navigate('/applied-leave');
        }, 3000);
      }
    } catch (error) {
      console.error('Error submitting leave request:', error);
      const msg = error.response?.data?.message || 'Error submitting leave request';
      setMessage(msg);
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  const fetchEmployeeDetails = async () => {
    // Extract user ID from session storage token
    const getUserIdFromToken = () => {
      const token = sessionStorage.getItem('token');
      if (!token) return null;

      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.id || payload.userId || payload._id;
      } catch (error) {
        console.error('Error parsing token:', error);
        return null;
      }
    };
    const token = sessionStorage.getItem('token');
    const userId = getUserIdFromToken();


    try {
      const response = await api.get(`/hr/employees/${userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.status === 200) {
        const employee = response.data.employee;
        setFormData(prev => ({
          ...prev,
          employeeName: employee.name,
          employeeId: employee.employeeId,
        }));
        return employee;
      }
    } catch (error) {
      console.error('Error fetching employee details:', error);
    }
    return null;
  };

  useEffect(() => {
    fetchEmployeeDetails();
    gettingLeaveTypes();
  }, []);

  useEffect(() => {
    if (formData.employeeId) {
      getLeaveBalance();
    }
  }, [formData.employeeId]);

  return (
    <div className="grid lg:grid-cols-4 grid-cols-1 gap-6">
      <div className="lg:col-span-3 col-span-1">
        <div className="bg-white border border-default-200 rounded-[2rem] overflow-hidden shadow-sm">
          <div className="px-8 py-6 border-b border-default-200 bg-white flex flex-col gap-6">
            <div className="flex items-center justify-between w-full">
              <div className="flex flex-col">
                <h4 className="text-xl font-black text-default-900 uppercase tracking-tight">
                  {activeTab === 'leave' ? 'Apply Leave' : 'Work From Home Request'}
                </h4>
                <p className="text-[10px] font-black text-default-400 uppercase tracking-widest mt-1">Submit your request</p>
              </div>
              <Link
                to="/applied-leave"
                className="size-11 flex items-center justify-center rounded-2xl bg-default-50 text-default-600 hover:bg-primary hover:text-white transition-all border border-default-200 hover:border-primary active:scale-95"
              >
                <LuArrowBigLeft className="size-6" />
              </Link>
            </div>

            <div className="flex items-center gap-1 bg-default-50 p-1.5 rounded-xl w-fit border border-default-200">
              <button
                onClick={() => setActiveTab('leave')}
                className={`px-6 py-2.5 text-xs font-black uppercase tracking-wider rounded-lg transition-all ${activeTab === 'leave'
                    ? 'bg-white shadow-sm text-primary ring-1 ring-black/5'
                    : 'text-default-500 hover:text-default-900 hover:bg-default-100'
                  }`}
              >
                Apply Leave
              </button>
              <div className="w-px h-4 bg-default-200 mx-1"></div>
              <button
                onClick={() => setActiveTab('wfh')}
                className={`px-6 py-2.5 text-xs font-black uppercase tracking-wider rounded-lg transition-all ${activeTab === 'wfh'
                    ? 'bg-white shadow-sm text-primary ring-1 ring-black/5'
                    : 'text-default-500 hover:text-default-900 hover:bg-default-100'
                  }`}
              >
                Work From Home
              </button>
            </div>
          </div>

          <div className="p-8">
            <div className="grid md:grid-cols-2 grid-cols-1 gap-6 mb-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  Employee Name
                </label>
                <input
                  type="text"
                  className="w-full bg-default-50 border-default-200 rounded-2xl px-5 py-3.5 text-sm font-bold text-default-600 cursor-not-allowed border-2 focus:ring-0"
                  value={formData.employeeName}
                  disabled
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  Employee ID
                </label>
                <input
                  type="text"
                  className="w-full bg-default-50 border-default-200 rounded-2xl px-5 py-3.5 text-sm font-bold text-default-600 cursor-not-allowed border-2 focus:ring-0"
                  value={formData.employeeId}
                  disabled
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  {activeTab === 'leave' ? 'Select Leave Type *' : 'Request Type'}
                </label>
                {activeTab === 'leave' ? (
                  <select
                    className={`w-full bg-white border-default-200 rounded-2xl px-5 py-3.5 text-sm font-bold text-default-900 focus:border-primary transition-all border-2 focus:ring-0 appearance-none cursor-pointer ${fieldErrors.leaveId ? 'border-danger' : ''}`}
                    value={formData.leaveId}
                    onChange={e => {
                      clearFieldError('leaveId');
                      setFormData({ ...formData, leaveId: e.target.value });
                    }}
                  >
                    <option value="">Select Type</option>
                    {leaveOptions.map(type => (
                      <option key={type._id} value={type._id}>
                        {type.leaveName?.toUpperCase() || type.name?.toUpperCase()}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    className="w-full bg-default-50 border-default-200 rounded-2xl px-5 py-3.5 text-sm font-bold text-default-600 cursor-not-allowed border-2 focus:ring-0"
                    value="WORK FROM HOME"
                    readOnly
                    disabled
                  />
                )}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  Number of Days
                </label>
                <input
                  type="number"
                  className={`w-full bg-default-50 border-default-200 rounded-2xl px-5 py-3.5 text-sm font-bold text-default-600 cursor-not-allowed border-2 focus:ring-0 ${fieldErrors.numberOfDays ? 'border-danger' : ''}`}
                  value={formData.numberOfDays}
                  readOnly
                />
                {fieldErrors.numberOfDays && <div className="text-xs font-semibold text-danger ps-1">{fieldErrors.numberOfDays}</div>}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  From Date *
                </label>
                <div className="relative group">
                  <Flatpickr
                    className={`w-full bg-white border-default-200 rounded-2xl px-5 py-3.5 text-sm font-bold text-default-900 focus:border-primary transition-all border-2 focus:ring-0 group-hover:border-default-300 ${fieldErrors.fromDate ? 'border-danger' : ''}`}
                    placeholder="DD-MM-YYYY"
                    options={{
                      dateFormat: 'Y-m-d',
                      minDate: 'today',
                    }}
                    value={formData.fromDate}
                    onChange={([date]) => {
                      const formattedDate = date.toISOString().split('T')[0];
                      clearFieldError('fromDate');
                      setFormData({ ...formData, fromDate: formattedDate });
                      calculateDays(formattedDate, formData.toDate);
                    }}
                  />
                </div>
                {fieldErrors.fromDate && <div className="text-xs font-semibold text-danger ps-1">{fieldErrors.fromDate}</div>}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  To Date *
                </label>
                <div className="relative group">
                  <Flatpickr
                    className={`w-full bg-white border-default-200 rounded-2xl px-5 py-3.5 text-sm font-bold text-default-900 focus:border-primary transition-all border-2 focus:ring-0 group-hover:border-default-300 ${fieldErrors.toDate ? 'border-danger' : ''}`}
                    placeholder="DD-MM-YYYY"
                    options={{
                      dateFormat: 'Y-m-d',
                      minDate: formData.fromDate || 'today',
                    }}
                    value={formData.toDate}
                    onChange={([date]) => {
                      const formattedDate = date.toISOString().split('T')[0];
                      clearFieldError('toDate');
                      setFormData({ ...formData, toDate: formattedDate });
                      calculateDays(formData.fromDate, formattedDate);
                    }}
                  />
                </div>
                {fieldErrors.toDate && <div className="text-xs font-semibold text-danger ps-1">{fieldErrors.toDate}</div>}
              </div>
            </div>

            <div className="space-y-2 mb-8">
              <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                Reason for Leave *
              </label>
              <textarea
                className={`w-full bg-white border-default-200 rounded-2xl px-5 py-4 text-sm font-bold text-default-900 focus:border-primary transition-all border-2 focus:ring-0 min-h-[120px] resize-none ${fieldErrors.reason ? 'border-danger' : ''}`}
                rows="4"
                placeholder="Enter detailed reason here..."
                value={formData.reason}
                onChange={e => {
                  clearFieldError('reason');
                  setFormData({ ...formData, reason: e.target.value });
                }}
              ></textarea>
              {fieldErrors.reason && <div className="text-xs font-semibold text-danger ps-1">{fieldErrors.reason}</div>}
            </div>

            {message && (
              <div className={`mb-6 p-5 rounded-2xl flex items-center gap-4 border ${message.includes('successfully')
                  ? 'bg-success/5 border-success/20 text-success'
                  : 'bg-danger/5 border-danger/20 text-danger'
                }`}>
                <div className={`size-10 rounded-xl flex items-center justify-center shrink-0 ${message.includes('successfully') ? 'bg-success/10' : 'bg-danger/10'
                  }`}>
                  {message.includes('successfully') ? <LuPlus className="size-5" /> : <LuPlus className="size-5 rotate-45" />}
                </div>
                <p className="text-sm font-bold tracking-tight">{message}</p>
              </div>
            )}

            <div className="flex justify-end gap-4">
              <button
                type="button"
                onClick={() => navigate('/applied-leave')}
                className="h-12 px-8 rounded-2xl border-2 border-default-200 text-[10px] font-black uppercase tracking-widest text-default-600 hover:bg-default-50 transition-all active:scale-95"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSubmit}
                disabled={loading}
                className="h-12 px-10 rounded-2xl bg-primary text-white text-[10px] font-black uppercase tracking-widest hover:bg-primary-600 shadow-lg shadow-primary/25 transition-all disabled:opacity-50 active:scale-95 flex items-center gap-2"
              >
                {loading ? (
                  <div className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <LuPlus className="size-4" />
                )}
                {loading ? 'Submitting...' : 'Submit Request'}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="lg:col-span-1 col-span-1 space-y-6">
        <div className="bg-white border border-default-200 rounded-[2rem] overflow-hidden shadow-sm">
          <div className="px-8 py-6 border-b border-default-200 bg-white">
            <h4 className="text-sm font-black text-default-900 uppercase tracking-widest">Leave Balance</h4>
          </div>
          <div className="p-8 space-y-4">
            {leaveBalance?.leaveBalances
              ?.filter(lb => lb.leaveName?.toLowerCase() !== 'work from home')
              ?.map((lb, idx) => (
                <div key={idx} className="group p-5 rounded-2xl bg-default-50 border border-default-200 hover:border-primary/30 transition-all">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">{lb.leaveName}</span>
                    <span className="text-sm font-black text-primary">{lb.yearlyRemaining}</span>
                  </div>
                  <div className="w-full h-1.5 bg-default-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all duration-1000"
                      style={{ width: `${(lb.yearlyRemaining / (lb.yearlyRemaining + (lb.yearlyRemaining * 0.5))) * 100}%` }}
                    />
                  </div>
                  <div className="mt-2 flex justify-between text-[9px] font-bold text-default-400 uppercase tracking-widest">
                    <span>Available</span>
                    <span>Days</span>
                  </div>
                </div>
              ))}
            {!leaveBalance && (
              <div className="py-12 text-center opacity-40">
                <LuPlus className="size-8 mx-auto mb-3 text-default-300" />
                <p className="text-[10px] font-black text-default-400 uppercase tracking-widest">No balance data</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default ApplyingLeave;
