import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import Appliedleave from './components/Appliedleave';

const Index = () => {
  return <>
      <PageMeta title="Applied Leave" />
      <main>
        <PageBreadcrumb title="Applied Leave" subtitle="Menu" />
        <Appliedleave />
      </main>
    </>;
};
export default Index;