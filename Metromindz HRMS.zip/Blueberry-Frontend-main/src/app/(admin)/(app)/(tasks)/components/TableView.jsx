import React from 'react';
import {
    LuListTodo,
    LuPlay,
    LuCheck,
    LuOctagonAlert,
    LuSearch,
    LuTag,
    LuList,
    LuLayoutGrid,
    LuPlus,
    LuDownload,
    LuEye,
    LuPause,
    LuSquare,
    LuPencil,
    LuTrash2,
    LuClock
} from 'react-icons/lu';
import AsyncSelect from 'react-select/async';

const TableView = ({
    stats,
    setSearch,
    debouncedSearch,
    priority,
    setPriority,
    priorities,
    status,
    setStatus,
    statuses,
    selectedProjectFilter,
    setSelectedProjectFilter,
    setProjectId,
    loadProjectOptions,
    canExport,
    exportData,
    viewMode,
    setViewMode,
    canCreate,
    setEditItem,
    setModalOpen,
    loading,
    items,
    page,
    limit,
    total,
    priorityPillClass,
    statusPillClass,
    formatDuration,
    getLiveSeconds,
    canEdit,
    statusMenuOpen,
    setStatusMenuOpen,
    updateRowStatus,
    setViewItem,
    setViewModalOpen,
    handleStart,
    handlePause,
    handleEnd,
    canDelete,
    confirmDelete,
    dragOverColumn,
    handleDragOver,
    handleDragLeave,
    handleDrop,
    renderKanbanCard,
    setPage,
    setLimit,
}) => {
    return (
        <>
            <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5 mb-6">
                <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
                    <div className="flex items-center gap-4">
                        <div className="size-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                            <LuListTodo className="size-6" />
                        </div>
                        <div>
                            <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Total Tasks</div>
                            <div className="text-2xl font-black text-default-900 leading-none">{stats?.totalTasks || 0}</div>
                        </div>
                    </div>
                </div>
                <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
                    <div className="flex items-center gap-4">
                        <div className="size-12 rounded-2xl bg-warning/10 flex items-center justify-center text-warning group-hover:scale-110 transition-transform duration-300">
                            <LuPlay className="size-6" />
                        </div>
                        <div>
                            <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">In Progress</div>
                            <div className="text-2xl font-black text-default-900 leading-none">{stats?.active || 0}</div>
                        </div>
                    </div>
                </div>
                <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
                    <div className="flex items-center gap-4">
                        <div className="size-12 rounded-2xl bg-success/10 flex items-center justify-center text-success group-hover:scale-110 transition-transform duration-300">
                            <LuCheck className="size-6" />
                        </div>
                        <div>
                            <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Completed</div>
                            <div className="text-2xl font-black text-default-900 leading-none">{stats?.done || 0}</div>
                        </div>
                    </div>
                </div>
                <div className="group bg-white rounded-2xl p-5 border border-default-200 transition-all duration-300">
                    <div className="flex items-center gap-4">
                        <div className="size-12 rounded-2xl bg-danger/10 flex items-center justify-center text-danger group-hover:scale-110 transition-transform duration-300">
                            <LuOctagonAlert className="size-6" />
                        </div>
                        <div>
                            <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Overdue</div>
                            <div className="text-2xl font-black text-danger leading-none">{stats?.overdue || 0}</div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-default-200 mb-6">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                    <div className="flex items-center gap-3 flex-wrap flex-1 min-w-0">
                        <div className="relative flex-1 max-w-xs min-w-[200px]">
                            <LuSearch className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-default-400" />
                            <input
                                type="text"
                                className="form-input pl-10 h-11 w-full rounded-2xl border-default-200 focus:border-primary focus:ring-primary bg-default-50/50 text-sm font-medium transition-all"
                                placeholder="Search tasks by title..."
                                onChange={(e) => {
                                    setSearch(e.target.value);
                                    debouncedSearch(e.target.value);
                                }}
                            />
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="relative group">
                                <LuTag className="absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-default-400" />
                                <select
                                    className="form-select pl-9 h-11 rounded-2xl border-default-200 focus:border-primary focus:ring-primary bg-default-50/50 text-sm font-semibold text-default-700 min-w-[130px] transition-all cursor-pointer"
                                    value={priority}
                                    onChange={(e) => {
                                        setPriority(e.target.value);
                                        setPage(1);
                                    }}
                                >
                                    <option value="">Priority</option>
                                    {priorities.map((p) => (
                                        <option key={p} value={p}>{p}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="relative group">
                                <LuListTodo className="absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-default-400" />
                                <select
                                    className="form-select pl-9 h-11 rounded-2xl border-default-200 focus:border-primary focus:ring-primary bg-default-50/50 text-sm font-semibold text-default-700 min-w-[130px] transition-all cursor-pointer"
                                    value={status}
                                    onChange={(e) => {
                                        setStatus(e.target.value);
                                        setPage(1);
                                    }}
                                >
                                    <option value="">Status</option>
                                    {statuses.map((s) => (
                                        <option key={s.value} value={s.value}>{s.label}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="relative group w-[180px]">
                                <AsyncSelect
                                    className="text-xs font-semibold"
                                    classNamePrefix="react-select"
                                    cacheOptions
                                    defaultOptions
                                    loadOptions={loadProjectOptions}
                                    value={selectedProjectFilter}
                                    onChange={(opt) => {
                                        setSelectedProjectFilter(opt);
                                        setProjectId(opt?.value || '');
                                        setPage(1);
                                    }}
                                    placeholder="All Projects"
                                    isClearable
                                    styles={{
                                        control: (base) => ({
                                            ...base,
                                            minHeight: '2.75rem',
                                            height: '2.75rem',
                                            borderRadius: '1rem',
                                            borderColor: '#e5e7eb',
                                            backgroundColor: 'rgba(249, 250, 251, 0.5)',
                                            fontSize: '0.875rem',
                                            fontWeight: 600,
                                            paddingLeft: '0.5rem'
                                        }),
                                        menu: (base) => ({
                                            ...base,
                                            fontSize: '0.875rem',
                                            zIndex: 9999
                                        })
                                    }}
                                />
                            </div>
                        </div>

                        {canExport && (
                            <div className="flex items-center gap-2 border-l border-default-200 pl-3 ml-1">
                                <button
                                    type="button"
                                    className="h-11 px-4 flex items-center gap-2 rounded-2xl border border-default-200 hover:bg-default-50 text-default-700 transition-all text-sm font-bold active:scale-95"
                                    onClick={() => exportData('csv')}
                                    title="Export CSV"
                                >
                                    <LuDownload className="size-4" /> <span className="hidden xl:inline">CSV</span>
                                </button>
                                <button
                                    type="button"
                                    className="h-11 px-4 flex items-center gap-2 rounded-2xl border border-default-200 hover:bg-default-50 text-default-700 transition-all text-sm font-bold active:scale-95"
                                    onClick={() => exportData('xlsx')}
                                    title="Export Excel"
                                >
                                    <LuDownload className="size-4" /> <span className="hidden xl:inline">Excel</span>
                                </button>
                            </div>
                        )}
                    </div>

                    <div className="flex items-center gap-3">
                        <div className="flex items-center p-1 bg-default-100 rounded-2xl">
                            <button
                                type="button"
                                className={`size-10 flex items-center justify-center rounded-xl transition-all ${viewMode === 'list' ? 'bg-white text-primary' : 'text-default-500 hover:text-default-900'}`}
                                onClick={() => setViewMode('list')}
                                title="List view"
                            >
                                <LuList className="size-5" />
                            </button>
                            <button
                                type="button"
                                className={`size-10 flex items-center justify-center rounded-xl transition-all ${viewMode === 'grid' ? 'bg-white text-primary' : 'text-default-500 hover:text-default-900'}`}
                                onClick={() => setViewMode('grid')}
                                title="Kanban view"
                            >
                                <LuLayoutGrid className="size-5" />
                            </button>
                        </div>

                        {canCreate && (
                            <button
                                type="button"
                                className="h-11 px-6 flex items-center gap-2 bg-primary text-white rounded-2xl hover:bg-primary-600 transition-all font-bold active:scale-95"
                                onClick={() => {
                                    setEditItem(null);
                                    setModalOpen(true);
                                }}
                            >
                                <LuPlus className="size-5" /> <span className="hidden sm:inline">Add Task</span>
                            </button>
                        )}
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-2xl border border-default-200 overflow-hidden">
                <div className="p-0">
                    {viewMode === 'list' ? (
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-default-200">
                                <thead>
                                    <tr className="bg-default-50/50">
                                        <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Sl No</th>
                                        <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Task Details</th>
                                        <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Priority</th>
                                        <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Team</th>
                                        <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Timeline</th>
                                        <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Status</th>
                                        <th className="py-4 px-6 text-left text-[11px] font-bold text-default-400 uppercase tracking-widest">Time Spent</th>
                                        <th className="py-4 px-6 text-right text-[11px] font-bold text-default-400 uppercase tracking-widest">Actions</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-default-200 bg-white">
                                    {loading ? (
                                        <tr>
                                            <td className="py-16 px-6 text-center" colSpan={7}>
                                                <div className="flex flex-col items-center gap-3">
                                                    <div className="size-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                                                    <span className="text-sm text-default-500 font-bold">Fetching tasks...</span>
                                                </div>
                                            </td>
                                        </tr>
                                    ) : items.length === 0 ? (
                                        <tr>
                                            <td className="py-16 px-6 text-center" colSpan={7}>
                                                <div className="flex flex-col items-center gap-3 text-default-300">
                                                    <LuListTodo className="size-16 opacity-10" />
                                                    <span className="text-sm font-bold">No tasks found in this view</span>
                                                </div>
                                            </td>
                                        </tr>
                                    ) : (
                                        items.map((t, idx) => (
                                            <tr key={t._id} className="hover:bg-default-50/50 transition-colors group">
                                                <td className="py-4 px-6 text-sm text-default-500 font-bold">{(page - 1) * limit + idx + 1}</td>
                                                <td className="py-4 px-6">
                                                    <div className="flex flex-col min-w-0">
                                                        <span className="text-[10px] font-black text-primary uppercase tracking-widest mb-1 truncate max-w-[200px] opacity-70 group-hover:opacity-100 transition-opacity">{t.project?.name}</span>
                                                        <span className="text-sm font-bold text-default-900 truncate max-w-[300px] group-hover:text-primary transition-colors">{t.title}</span>
                                                    </div>
                                                </td>
                                                <td className="py-4 px-6">
                                                    <span className={`${priorityPillClass(t.priority)} text-[10px] uppercase tracking-wider`}>{t.priority}</span>
                                                </td>
                                                <td className="py-4 px-6">
                                                    <div className="flex -space-x-2.5 overflow-hidden">
                                                        {(t.assignees || []).slice(0, 3).map((d, i) => {
                                                            const photo = d.documents?.photograph || d.employeePersonal?.profilePhoto;
                                                            return (
                                                                <div key={i} className="size-8 rounded-full bg-white p-0.5 border border-default-100" title={d.name}>
                                                                    {photo ? (
                                                                        <img src={photo} alt={d.name} className="size-full rounded-full object-cover" />
                                                                    ) : (
                                                                        <div className="size-full rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-black text-primary uppercase">
                                                                            {d.name.charAt(0)}
                                                                        </div>
                                                                    )}
                                                                </div>
                                                            );
                                                        })}
                                                        {(t.assignees || []).length > 3 && (
                                                            <div className="size-8 rounded-full bg-white p-0.5 border border-default-100">
                                                                <div className="size-full rounded-full bg-default-100 flex items-center justify-center text-[10px] font-black text-default-600 uppercase">
                                                                    +{(t.assignees || []).length - 3}
                                                                </div>
                                                            </div>
                                                        )}
                                                        {(t.assignees || []).length === 0 && <span className="text-[11px] text-default-400 font-medium italic">Unassigned</span>}
                                                    </div>
                                                </td>
                                                <td className="py-4 px-6">
                                                    <div className="flex flex-col gap-1.5">
                                                        <div className="flex items-center gap-2">
                                                            <div className="size-1.5 rounded-full bg-success/50" />
                                                            <span className="text-[11px] font-bold text-default-600">{t.startDate ? new Date(t.startDate).toLocaleDateString() : 'N/A'}</span>
                                                        </div>
                                                        <div className="flex items-center gap-2">
                                                            <div className="size-1.5 rounded-full bg-danger/50" />
                                                            <span className="text-[11px] font-bold text-default-600">{t.dueDate ? new Date(t.dueDate).toLocaleDateString() : 'N/A'}</span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="py-4 px-6">
                                                    <div className="relative inline-block">
                                                        <button
                                                            type="button"
                                                            className={`${statusPillClass(t.status)} text-[10px] uppercase tracking-wider transition-all flex items-center gap-2 group/btn`}
                                                            onClick={() => canEdit && setStatusMenuOpen(statusMenuOpen === t._id ? null : t._id)}
                                                        >
                                                            <span>{statuses.find((s) => s.value === t.status)?.label || t.status}</span>
                                                            {canEdit && <LuClock className="size-3 opacity-50 group-hover/btn:opacity-100 transition-opacity" />}
                                                        </button>
                                                        {canEdit && statusMenuOpen === t._id && (
                                                            <div className="absolute left-0 top-full mt-2 z-50 w-48 rounded-2xl bg-white border border-default-200 p-2 animate-in fade-in slide-in-from-top-3">
                                                                <div className="px-3 py-2 mb-1.5 text-[9px] font-black text-default-400 uppercase tracking-[0.2em]">Change Status</div>
                                                                {statuses.map((s) => (
                                                                    <button
                                                                        key={s.value}
                                                                        type="button"
                                                                        className={`flex items-center justify-between w-full text-left px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${t.status === s.value ? 'bg-primary text-white' : 'text-default-600 hover:bg-default-100'}`}
                                                                        onClick={async () => {
                                                                            await updateRowStatus(t._id, s.value);
                                                                            setStatusMenuOpen(null);
                                                                        }}
                                                                    >
                                                                        {s.label}
                                                                        {t.status === s.value && <LuCheck className="size-3.5" />}
                                                                    </button>
                                                                ))}
                                                            </div>
                                                        )}
                                                    </div>
                                                </td>
                                                <td className="py-4 px-6">
                                                    <div className="flex items-center gap-2 text-[11px] font-bold text-default-600">
                                                        <LuClock className="size-3.5 text-default-400" />
                                                        <span>{formatDuration(getLiveSeconds(t))}</span>
                                                    </div>
                                                </td>
                                                <td className="py-4 px-6 text-right">
                                                    <div className="flex items-center justify-end gap-1.5 transition-all">
                                                        <button
                                                            type="button"
                                                            className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                                                            onClick={() => {
                                                                setViewItem(t);
                                                                setViewModalOpen(true);
                                                            }}
                                                            title="View Details"
                                                        >
                                                            <LuEye className="size-4" />
                                                        </button>
                                                        {canEdit && (
                                                            <>
                                                                <button
                                                                    type="button"
                                                                    className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-success hover:text-white hover:border-success transition-all active:scale-90 disabled:opacity-40"
                                                                    onClick={() => handleStart(t)}
                                                                    disabled={!!t.timerStartAt || t.status === 'done'}
                                                                    title="Start"
                                                                >
                                                                    <LuPlay className="size-4" />
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-warning hover:text-white hover:border-warning transition-all active:scale-90 disabled:opacity-40"
                                                                    onClick={() => handlePause(t)}
                                                                    disabled={!t.timerStartAt}
                                                                    title="Pause"
                                                                >
                                                                    <LuPause className="size-4" />
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-danger hover:text-white hover:border-danger transition-all active:scale-90 disabled:opacity-40"
                                                                    onClick={() => handleEnd(t)}
                                                                    disabled={t.status === 'done'}
                                                                    title="End"
                                                                >
                                                                    <LuSquare className="size-4" />
                                                                </button>
                                                            </>
                                                        )}
                                                        {canEdit && (
                                                            <button
                                                                type="button"
                                                                className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                                                                onClick={() => {
                                                                    setEditItem(t);
                                                                    setModalOpen(true);
                                                                }}
                                                                title="Edit Task"
                                                            >
                                                                <LuPencil className="size-4" />
                                                            </button>
                                                        )}
                                                        {canDelete && (
                                                            <button
                                                                type="button"
                                                                className="size-10 flex items-center justify-center bg-white border border-default-200 rounded-xl text-danger hover:bg-danger hover:text-white hover:border-danger transition-all active:scale-90"
                                                                onClick={() => confirmDelete(t._id)}
                                                                title="Delete Task"
                                                            >
                                                                <LuTrash2 className="size-4" />
                                                            </button>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    ) : (
                        <div className="p-4 bg-default-50/30 overflow-x-auto">
                            {loading ? (
                                <div className="py-24 text-center flex flex-col items-center gap-3">
                                    <div className="size-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                                    <span className="text-sm text-default-500 font-bold">Loading Kanban Board...</span>
                                </div>
                            ) : (
                                <div className="flex items-start gap-4 min-w-max pb-4">
                                    {statuses.map((s) => {
                                        const statusTasks = items.filter((t) => t.status === s.value);

                                        // Styling specific to status columns
                                        const getStatusColors = (statusVal) => {
                                            switch (statusVal) {
                                                case 'todo': return 'bg-default-100 text-default-700 border-default-200';
                                                case 'in_progress': return 'bg-primary/10 text-primary border-primary/20';
                                                case 'paused': return 'bg-warning/10 text-warning border-warning/20';
                                                case 'blocked': return 'bg-danger/10 text-danger border-danger/20';
                                                case 'done': return 'bg-success/10 text-success border-success/20';
                                                default: return 'bg-default-100 text-default-600 border-default-200';
                                            }
                                        };

                                        return (
                                            <div
                                                key={s.value}
                                                className={`w-[320px] flex-shrink-0 flex flex-col bg-default-50/50 rounded-2xl border ${dragOverColumn === s.value ? 'border-primary shadow-sm bg-primary/5' : 'border-default-200'} transition-all duration-300 max-h-[75vh]`}
                                                onDragOver={(e) => handleDragOver(e, s.value)}
                                                onDragLeave={handleDragLeave}
                                                onDrop={(e) => handleDrop(e, s.value)}
                                            >
                                                <div className="p-3 border-b border-default-200 flex items-center justify-between sticky top-0 bg-default-50/95 backdrop-blur z-10 rounded-t-2xl">
                                                    <div className="flex items-center gap-2">
                                                        <span className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest ${getStatusColors(s.value)}`}>
                                                            {s.label}
                                                        </span>
                                                    </div>
                                                    <span className="text-xs font-bold text-default-400 bg-white px-2 py-0.5 rounded-full shadow-sm border border-default-100">
                                                        {statusTasks.length}
                                                    </span>
                                                </div>

                                                <div className="p-3 overflow-y-auto flex-1 custom-scrollbar min-h-[150px]">
                                                    {statusTasks.length === 0 ? (
                                                        <div className="h-full min-h-[100px] flex items-center justify-center border-2 border-dashed border-default-200 rounded-xl bg-default-50/50">
                                                            <span className="text-xs font-bold text-default-400">Drop tasks here</span>
                                                        </div>
                                                    ) : (
                                                        statusTasks.map(renderKanbanCard)
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    )}

                    <div className="flex items-center justify-between px-6 py-5 bg-default-50/50 border-t border-default-200">
                        <div className="text-xs font-bold text-default-500 uppercase tracking-widest">
                            Showing <span className="text-default-900">{(page - 1) * limit + 1}</span> - <span className="text-default-900">{Math.min(page * limit, total)}</span> of <span className="text-default-900">{total}</span>
                        </div>
                        <div className="flex items-center gap-5">
                            <div className="flex items-center gap-2">
                                <button
                                    type="button"
                                    className="h-10 px-5 text-xs font-black text-default-700 bg-white border border-default-200 rounded-xl hover:bg-default-50 disabled:opacity-40 disabled:cursor-not-allowed transition-all    active:scale-95 uppercase tracking-widest"
                                    disabled={page === 1}
                                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                                >
                                    Prev
                                </button>
                                <button
                                    type="button"
                                    className="h-10 px-5 text-xs font-black text-default-700 bg-white border border-default-200 rounded-xl hover:bg-default-50 disabled:opacity-40 disabled:cursor-not-allowed transition-all    active:scale-95 uppercase tracking-widest"
                                    disabled={page * limit >= total}
                                    onClick={() => setPage((p) => p + 1)}
                                >
                                    Next
                                </button>
                            </div>
                            <div className="flex items-center gap-3 border-l border-default-200 pl-5">
                                <span className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em]">Limit</span>
                                <select
                                    className="form-select h-10 w-20 rounded-xl border-default-200 bg-white text-xs font-black text-default-700 focus:border-primary focus:ring-primary    cursor-pointer"
                                    value={limit}
                                    onChange={(e) => {
                                        setLimit(parseInt(e.target.value));
                                        setPage(1);
                                    }}
                                >
                                    <option value={10}>10</option>
                                    <option value={20}>20</option>
                                    <option value={50}>50</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default TableView;
