import { useEffect, useState } from 'react';
import { useAuth } from '../../../../../context/AuthContext';
import api from '../../../../../config/api';

const Activities = () => {
  const { user } = useAuth();

  const [leaveBalance, setLeaveBalance] = useState({});

  const getLeaveBalance = async () => {
    try {
      const res = await api.get(`/leave-balance/${user.employeeId}`);
      if (res.status === 200) {
        setLeaveBalance(res.data.data);

      }
    } catch (error) {
      console.error('Error fetching leave balance', error);
    }
  };

  useEffect(() => {
    getLeaveBalance();
  }, []);

  return (
    <div className="grid lg:grid-cols-4 grid-cols-1 mb-5 gap-5">
      <div className="lg:col-start-6">
        <div className="card">
          <div className="card-body">
            <h6 className="text-center mb-4">Leave Balance</h6>
            <div className="flex flex-nowrap overflow-x-auto gap-4 pb-2">
              {leaveBalance.leaveBalances && leaveBalance.leaveBalances.length > 0 ? (
                leaveBalance.leaveBalances.map((balance, index) => (
                  <div
                    key={index}
                    className="flex-shrink-0 px-4 text-center border-r border-default-200 last:border-r-0 min-w-[100px]"
                  >
                    <h6 className="mb-1 font-bold">
                      <span className="counter-value text-default-800 text-lg">
                        {balance.yearlyRemaining || 0}
                      </span>
                    </h6>
                    <p className="text-default-500 text-sm whitespace-nowrap">
                      {balance.leaveName}
                    </p>
                  </div>
                ))
              ) : (
                // Fallback when no data is available
                <div className="text-center text-default-500 w-full">
                  No leave balance data available
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Activities;