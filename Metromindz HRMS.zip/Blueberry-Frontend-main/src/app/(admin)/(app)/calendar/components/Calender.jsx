import { Calendar } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin, { Draggable } from '@fullcalendar/interaction';
import listPlugin from '@fullcalendar/list';
import timeGridPlugin from '@fullcalendar/timegrid';
import { useEffect, useRef, useState, useMemo } from 'react';
import { LuLayoutDashboard, LuSquareCheck, LuClock, LuCalendar, LuPlus, LuChevronLeft, LuChevronRight, LuMenu, LuX, LuCircleCheck } from "react-icons/lu";
import EventModal from './EventModal';
import api from '../../../../../config/api';

// Modern color palette matching the application theme
const COLORS = {
  primary: '#6366f1',      // Indigo 500
  primaryLight: '#818cf8', // Indigo 400
  primaryDark: '#4f46e5',  // Indigo 600
  secondary: '#ec4899',    // Pink 500
  success: '#10b981',      // Emerald 500
  warning: '#f59e0b',      // Amber 500
  danger: '#ef4444',       // Red 500
  info: '#06b6d4',         // Cyan 500
  dark: '#1e293b',         // Slate 800
  gray: '#64748b',         // Slate 500
  light: '#f8fafc',        // Slate 50
  white: '#ffffff',
  border: '#e2e8f0',       // Slate 200
  task: '#6366f1',
  holiday: '#f59e0b',
  completed: '#10b981',
  inProgress: '#f59e0b',
  todo: '#64748b'
};

const CalendarApp = ({ tasks, holidays: propHolidays, onTaskClick, onRefresh }) => {
  const calendarRef = useRef(null);
  const externalEventsRef = useRef(null);
  const [calendarObj, setCalendarObj] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [newEventData, setNewEventData] = useState(null);
  const [holidays, setHolidays] = useState([]);
  const [taskEvents, setTaskEvents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentView, setCurrentView] = useState('dayGridMonth');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date());

  // Responsive sidebar handling
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setSidebarOpen(false);
      } else {
        setSidebarOpen(true);
      }
    };

    // Initial check
    handleResize();

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Filter tasks for selected date (Daily Agenda)
  const dailyTasks = useMemo(() => {
    if (!Array.isArray(tasks)) return [];
    
    const yyyyMmDd = selectedDate.toISOString().split('T')[0];
    
    return tasks.filter(t => {
      const start = t.startDate ? t.startDate.split('T')[0] : null;
      const due = t.dueDate ? t.dueDate.split('T')[0] : null;
      
      if (!start) return false;
      if (due) return yyyyMmDd >= start && yyyyMmDd <= due;
      return yyyyMmDd === start;
    });
  }, [tasks, selectedDate]);

  // Filter holidays for selected date
  const dailyHolidays = useMemo(() => {
    if (!Array.isArray(holidays)) return [];
    const yyyyMmDd = selectedDate.toISOString().split('T')[0];
    return holidays.filter(h => {
        const hDate = h.date ? h.date.split('T')[0] : null;
        return hDate === yyyyMmDd;
    });
  }, [holidays, selectedDate]);

  const selectedDateStr = useMemo(() => {
    return selectedDate.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  }, [selectedDate]);

  // Enhanced task mapping with status-based colors
  const mapTasksToEvents = (list) =>
    (list || [])
      .map((task) => {
        const start = task.startDate || task.dueDate;
        if (!start) return null;
        
        // Dynamic color based on status
        let statusColor = COLORS.task;
        let statusBorder = COLORS.task;
        
        switch(task.status?.toLowerCase()) {
          case 'completed':
          case 'done':
            statusColor = COLORS.completed;
            statusBorder = COLORS.completed;
            break;
          case 'paused':
            statusColor = COLORS.info;
            statusBorder = COLORS.info;
            break;
          case 'in-progress':
          case 'in_progress':
          case 'progress':
            statusColor = COLORS.inProgress;
            statusBorder = COLORS.inProgress;
            break;
          case 'todo':
          case 'pending':
          default:
            statusColor = COLORS.todo;
            statusBorder = COLORS.todo;
            break;
        }

        // Priority indicator
        const priority = task.priority?.toLowerCase();
        const priorityIcon = priority === 'high' ? '🔴' : priority === 'medium' ? '🟡' : '🟢';

        return {
          id: task._id,
          title: `${priorityIcon} ${task.title}`,
          start,
          end: task.dueDate || task.startDate || undefined,
          backgroundColor: statusColor,
          borderColor: statusBorder,
          textColor: '#ffffff',
          classNames: ['task-event', `status-${task.status?.toLowerCase()?.replace(/\s+/g, '-')}`],
          extendedProps: {
            status: task.status,
            priority: task.priority,
            projectName: task.project?.name || '',
            type: 'task',
            description: task.description,
            assignee: task.assignee?.name || 'Unassigned',
            originalTitle: task.title,
            sourceTask: task
          },
        };
      })
      .filter(Boolean);

  const fetchHolidays = async () => {
    if (propHolidays) return;
    try {
      setLoading(true);
      const response = await api.get('/holiday/getAllholidays');
      
      if (response.data.success && Array.isArray(response.data.data)) {
        const holidayEvents = response.data.data.map(holiday => ({
          id: holiday._id,
          title: `🎉 ${holiday.name}`,
          date: holiday.date,
          backgroundColor: COLORS.holiday,
          borderColor: COLORS.holiday,
          textColor: '#ffffff',
          classNames: ['holiday-event'],
          extendedProps: {
            description: holiday.description,
            type: 'holiday',
            isHoliday: true
          }
        }));
        setHolidays(holidayEvents);
      }
    } catch (error) {
      console.error('Error fetching holidays:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchTasksForCalendar = async () => {
    try {
      const response = await api.get('/tasks/calendar');
      if (response.data.success && Array.isArray(response.data.items)) {
        const events = mapTasksToEvents(response.data.items);
        setTaskEvents(events);
      }
    } catch (error) {
      console.error('Error fetching tasks for calendar:', error);
    }
  };

  useEffect(() => {
    if (propHolidays) {
      const holidayEvents = propHolidays.map(holiday => ({
        id: holiday._id,
        title: `🎉 ${holiday.name}`,
        date: holiday.date,
        backgroundColor: COLORS.holiday,
        borderColor: COLORS.holiday,
        textColor: '#ffffff',
        classNames: ['holiday-event'],
        extendedProps: {
          description: holiday.description,
          type: 'holiday',
          isHoliday: true
        }
      }));
      setHolidays(holidayEvents);
    } else {
      fetchHolidays();
    }
  }, [propHolidays]);

  useEffect(() => {
    if (!Array.isArray(tasks)) {
      fetchTasksForCalendar();
      const handleTasksUpdated = () => fetchTasksForCalendar();
      window.addEventListener('tasks-calendar-updated', handleTasksUpdated);
      return () => window.removeEventListener('tasks-calendar-updated', handleTasksUpdated);
    }
  }, [tasks]);

  useEffect(() => {
    if (Array.isArray(tasks)) {
      const events = mapTasksToEvents(tasks);
      setTaskEvents(events);
    }
  }, [tasks]);

  // Custom view switcher
  const switchView = (viewName) => {
    if (calendarObj) {
      calendarObj.changeView(viewName);
      setCurrentView(viewName);
    }
  };

  useEffect(() => {
    if (!calendarRef.current) return;
    
    if (externalEventsRef.current) {
      new Draggable(externalEventsRef.current, {
        itemSelector: '.external-event',
        eventData: eventEl => ({
          title: eventEl.innerText,
          classNames: eventEl.getAttribute('data-class')?.split(' ') || [],
          backgroundColor: eventEl.getAttribute('data-color') || COLORS.primary,
          borderColor: eventEl.getAttribute('data-color') || COLORS.primary,
        })
      });
    }

    const calendar = new Calendar(calendarRef.current, {
      timeZone: 'local',
      editable: true,
      droppable: true,
      selectable: true,
      weekNumbers: true,
      weekNumberFormat: { week: 'numeric' },
      initialView: 'dayGridMonth',
      themeSystem: 'standard',
      plugins: [dayGridPlugin, timeGridPlugin, listPlugin, interactionPlugin],
      
      headerToolbar: false,
      
      events: [...holidays, ...taskEvents],
      
      eventDisplay: 'block',
      eventTimeFormat: {
        hour: '2-digit',
        minute: '2-digit',
        meridiem: 'short'
      },
      
      slotDuration: '00:30:00',
      slotMinTime: '08:00:00',
      slotMaxTime: '20:00:00',
      
      businessHours: {
        daysOfWeek: [1, 2, 3, 4, 5],
        startTime: '09:00',
        endTime: '18:00',
      },
      
      dateClick: info => {
        // Update selected date for sidebar
        const clickedDate = new Date(info.dateStr);
        setSelectedDate(clickedDate);
      },

      select: info => {
        setNewEventData({
            date: info.startStr,
            allDay: info.allDay
        });
        setSelectedEvent(null);
        setShowModal(true);
      },

      eventReceive: info => {
        // Remove the temporary event added by FullCalendar
        info.event.remove();
        
        // Open modal to create a real task
        setNewEventData({
            date: info.event.startStr,
            allDay: info.event.allDay
        });
        setSelectedEvent(null);
        setShowModal(true);
      },
      
      eventClick: info => {
        const isTask = info.event.extendedProps?.type === 'task';
        if (isTask && onTaskClick) {
          onTaskClick(info.event.id, info.event);
          return;
        }
        setShowModal(true);
        setSelectedEvent(info.event);
        setNewEventData(null);
      },
      
      drop: info => {
        const checkbox = document.getElementById('drop-remove');
        if (checkbox?.checked) {
          info.draggedEl.parentNode?.removeChild(info.draggedEl);
        }
      },
      
      eventDragStart: (info) => {
        info.el.style.opacity = '0.7';
        info.el.style.transform = 'scale(1.05)';
      },
      
      eventDragStop: (info) => {
        info.el.style.opacity = '1';
        info.el.style.transform = 'scale(1)';
      },
      
      eventResizeStart: (info) => {
        info.el.style.zIndex = '1000';
      },
      
      loading: (isLoading) => {
        setLoading(isLoading);
      },
      
      dayCellClassNames: (arg) => {
        const classes = ['calendar-day-cell'];
        if (arg.isToday) classes.push('fc-day-today-custom');
        if (arg.isPast) classes.push('fc-day-past');
        if (arg.isFuture) classes.push('fc-day-future');
        return classes;
      },
      
      eventContent: (arg) => {
        const isHoliday = arg.event.extendedProps?.isHoliday;
        const isTask = arg.event.extendedProps?.type === 'task';
        
        if (isHoliday) {
          return {
            html: `
              <div class="fc-event-holiday">
                <span class="holiday-icon">🎉</span>
                <span class="holiday-title">${arg.event.title.replace('🎉 ', '')}</span>
              </div>
            `
          };
        }
        
        if (isTask) {
          const priority = arg.event.extendedProps?.priority;
          const projectName = arg.event.extendedProps?.projectName;
          
          return {
            html: `
              <div class="fc-event-task">
                <div class="task-header">
                  <span class="task-title">${arg.event.extendedProps?.originalTitle || arg.event.title}</span>
                  ${priority ? `<span class="task-priority priority-${priority.toLowerCase()}"></span>` : ''}
                </div>
                ${projectName ? `<div class="task-project">${projectName}</div>` : ''}
                ${arg.timeText ? `<div class="task-time">${arg.timeText}</div>` : ''}
              </div>
            `
          };
        }
        
        return true;
      }
    });

    calendar.render();
    setCalendarObj(calendar);
    
    return () => calendar.destroy();
  }, [holidays, taskEvents]);

  return (
    <div className="flex h-full w-full overflow-hidden bg-default-50 font-sans text-default-900">
      {/* CSS Overrides for FullCalendar */}
      <style>{`
        /* Header cells */
        .fc-col-header-cell {
          background: ${COLORS.light} !important;
          padding: 12px 4px !important;
          font-weight: 600 !important;
          color: ${COLORS.gray} !important;
          text-transform: uppercase;
          font-size: 12px;
          letter-spacing: 0.5px;
          border-bottom: 2px solid ${COLORS.border} !important;
        }

        /* Day cells */
        .fc-day-today-custom {
          background: linear-gradient(135deg, rgba(99, 102, 241, 0.05) 0%, rgba(99, 102, 241, 0.02) 100%) !important;
        }

        .fc-day-today-custom .fc-daygrid-day-number {
          background: ${COLORS.primary} !important;
          color: white !important;
          width: 28px;
          height: 28px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 8px;
          font-weight: 700;
        }

        .fc-daygrid-day-number {
          font-size: 13px;
          color: ${COLORS.dark};
          padding: 8px !important;
          margin: 4px;
        }

        /* Events */
        .fc-event {
          border-radius: 6px !important;
          border: none !important;
          box-shadow: 0 1px 2px rgba(0,0,0,0.05) !important;
          font-size: 12px !important;
          padding: 2px 4px !important;
          margin: 2px !important;
          transition: all 0.2s ease !important;
        }

        .fc-event:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 6px rgba(0,0,0,0.1) !important;
          z-index: 50 !important;
        }

        .fc-event-task {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .task-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 4px;
        }

        .task-title {
          font-weight: 600;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .task-priority {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          flex-shrink: 0;
        }

        .priority-high { background: #ef4444; }
        .priority-medium { background: #f59e0b; }
        .priority-low { background: #10b981; }

        .task-project {
          font-size: 10px;
          opacity: 0.9;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .task-time {
          font-size: 10px;
          opacity: 0.8;
          font-weight: 500;
        }

        .fc-event-holiday {
          display: flex;
          align-items: center;
          gap: 4px;
          font-weight: 600;
        }

        /* Time grid improvements */
        .fc-timegrid-slot {
          height: 48px !important;
        }

        .fc-timegrid-axis {
          color: ${COLORS.gray} !important;
          font-size: 11px !important;
          font-weight: 500 !important;
        }

        /* Loading spinner */
        .loading-spinner {
          width: 40px;
          height: 40px;
          border: 3px solid ${COLORS.border};
          border-top-color: ${COLORS.primary};
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`
          fixed lg:relative z-50 h-full w-80 bg-white border-r border-default-200 
          flex flex-col transition-transform duration-300 ease-in-out shadow-2xl lg:shadow-none
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        <div className="p-6 border-b border-default-100 flex items-center justify-between bg-gradient-to-br from-primary-600 to-primary-700 text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="size-10 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center">
              <LuCalendar className="size-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-black uppercase tracking-tight">Calendar</h2>
              <p className="text-[10px] font-bold text-white/70 uppercase tracking-widest">Task Management</p>
            </div>
          </div>
          <button 
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <LuX className="size-5" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scroll p-6 space-y-8">
          
          {/* Daily Agenda */}
          <div>
            <div className="flex items-center justify-between mb-4">
               <h3 className="text-xs font-black text-default-400 uppercase tracking-widest flex items-center gap-2">
                 <LuCircleCheck className="size-4" /> Daily Agenda
               </h3>
               <span className="text-[10px] font-bold bg-primary/10 text-primary px-2 py-1 rounded-lg">
                 {selectedDateStr}
               </span>
            </div>
            
            <div className="space-y-3">
               {dailyTasks.length === 0 ? (
                   <div className="p-6 rounded-2xl border border-dashed border-default-200 text-center flex flex-col items-center gap-2">
                       <div className="size-8 rounded-full bg-default-100 flex items-center justify-center text-default-400">
                          <LuCircleCheck className="size-4" />
                       </div>
                       <span className="text-xs font-bold text-default-400">No tasks for this day</span>
                   </div>
               ) : (
                   dailyTasks.map(task => (
                       <div key={task._id} className="p-4 rounded-2xl bg-default-50 border-l-4 border-primary hover:bg-white hover:shadow-md transition-all group cursor-pointer border border-default-100/50">
                          <div className="flex justify-between items-start mb-2">
                             <span className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider ${
                               task.status === 'done' || task.status === 'completed' ? 'bg-success/10 text-success' : 
                               (task.status === 'in_progress' || task.status === 'in-progress') ? 'bg-primary/10 text-primary' : 
                               'bg-warning/10 text-warning'
                             }`}>
                                {task.status.replace(/_/g, ' ')}
                             </span>
                             <span className="text-[10px] font-bold text-default-400 flex items-center gap-1">
                                <LuClock className="size-3" /> All Day
                             </span>
                          </div>
                          <h4 className="text-sm font-bold text-default-900 mb-1 group-hover:text-primary transition-colors line-clamp-2">
                            {task.title}
                          </h4>
                          <p className="text-xs text-default-500 line-clamp-1 font-medium">{task.project?.name}</p>
                       </div>
                   ))
               )}
            </div>
          </div>

          {/* Holidays */}
          <div>
             <h3 className="text-xs font-black text-default-400 uppercase tracking-widest mb-4 flex items-center gap-2">
               <LuCalendar className="size-4" /> Holidays & Events
             </h3>
             <div className="space-y-3">
                {dailyHolidays.length === 0 ? (
                    <div className="p-4 rounded-2xl border border-dashed border-default-200 text-center flex flex-col items-center gap-2">
                        <span className="text-[10px] font-bold text-default-400">No holidays</span>
                    </div>
                ) : (
                    dailyHolidays.map(holiday => (
                        <div key={holiday._id} className="flex items-center gap-4 p-4 rounded-2xl bg-white border border-default-100 hover:border-primary/30 transition-all shadow-sm">
                           <div className="size-10 rounded-2xl bg-warning/10 flex items-center justify-center text-warning shrink-0">
                              <LuCalendar className="size-5" />
                           </div>
                           <div>
                              <h4 className="text-sm font-bold text-default-900 line-clamp-1">{holiday.name}</h4>
                              <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Holiday</p>
                           </div>
                        </div>
                    ))
                )}
             </div>
          </div>

          {/* Quick Add / External Events */}
          <div ref={externalEventsRef}>
            <h3 className="text-xs font-black text-default-400 uppercase tracking-widest mb-4 flex items-center gap-2">
              <LuPlus className="size-4" /> Quick Add Tasks
            </h3>
            <div className="space-y-3">
              <div className="external-event p-4 bg-white border border-default-200 rounded-2xl cursor-grab hover:border-primary hover:shadow-md transition-all group flex items-center gap-3" data-color={COLORS.primary}>
                <div className="size-8 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                  <LuSquareCheck className="size-4" />
                </div>
                <div>
                  <div className="text-sm font-bold text-default-900">New Task</div>
                  <div className="text-[10px] text-default-400 font-medium">Drag to calendar</div>
                </div>
              </div>

              <div className="external-event p-4 bg-white border border-default-200 rounded-2xl cursor-grab hover:border-secondary hover:shadow-md transition-all group flex items-center gap-3" data-color={COLORS.secondary}>
                <div className="size-8 rounded-full bg-secondary/10 flex items-center justify-center text-secondary group-hover:scale-110 transition-transform">
                  <LuLayoutDashboard className="size-4" />
                </div>
                <div>
                  <div className="text-sm font-bold text-default-900">Milestone</div>
                  <div className="text-[10px] text-default-400 font-medium">Major project event</div>
                </div>
              </div>

              <div className="external-event p-4 bg-white border border-default-200 rounded-2xl cursor-grab hover:border-info hover:shadow-md transition-all group flex items-center gap-3" data-color={COLORS.info}>
                <div className="size-8 rounded-full bg-info/10 flex items-center justify-center text-info group-hover:scale-110 transition-transform">
                  <LuClock className="size-4" />
                </div>
                <div>
                  <div className="text-sm font-bold text-default-900">Meeting</div>
                  <div className="text-[10px] text-default-400 font-medium">Schedule a call</div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full min-w-0 bg-default-50/50">
        {/* Header */}
        <header className="bg-white border-b border-default-200 px-6 py-4 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 -ml-2 hover:bg-default-100 rounded-xl transition-colors text-default-600"
            >
              <LuMenu className="size-6" />
            </button>
            
            <div className="flex bg-default-100 p-1 rounded-xl">
              <button 
                className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${currentView === 'dayGridMonth' ? 'bg-white text-primary shadow-sm' : 'text-default-500 hover:text-default-700'}`}
                onClick={() => switchView('dayGridMonth')}
              >
                Month
              </button>
              <button 
                className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${currentView === 'timeGridWeek' ? 'bg-white text-primary shadow-sm' : 'text-default-500 hover:text-default-700'}`}
                onClick={() => switchView('timeGridWeek')}
              >
                Week
              </button>
              <button 
                className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${currentView === 'timeGridDay' ? 'bg-white text-primary shadow-sm' : 'text-default-500 hover:text-default-700'}`}
                onClick={() => switchView('timeGridDay')}
              >
                Day
              </button>
              <button 
                className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${currentView === 'listWeek' ? 'bg-white text-primary shadow-sm' : 'text-default-500 hover:text-default-700'}`}
                onClick={() => switchView('listWeek')}
              >
                List
              </button>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <h1 className="text-xl font-black text-default-900 hidden md:block">
              {calendarObj?.view?.title || 'Calendar'}
            </h1>
            
            <div className="flex items-center gap-2">
              <button 
                onClick={() => calendarObj?.prev()}
                className="size-10 flex items-center justify-center rounded-xl border border-default-200 text-default-600 hover:border-primary hover:text-primary bg-white transition-all shadow-sm"
              >
                <LuChevronLeft className="size-5" />
              </button>
              <button 
                onClick={() => calendarObj?.today()}
                className="px-6 h-10 rounded-xl bg-primary text-white text-sm font-bold uppercase tracking-wider hover:bg-primary-600 transition-all shadow-lg shadow-primary/20"
              >
                Today
              </button>
              <button 
                onClick={() => calendarObj?.next()}
                className="size-10 flex items-center justify-center rounded-xl border border-default-200 text-default-600 hover:border-primary hover:text-primary bg-white transition-all shadow-sm"
              >
                <LuChevronRight className="size-5" />
              </button>
            </div>
          </div>
        </header>

        {/* Calendar Grid */}
        <main className="flex-1 p-6 overflow-hidden relative">
          <div className="bg-white rounded-3xl border border-default-200 shadow-sm h-full overflow-hidden p-4">
            {loading && (
              <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-50 flex items-center justify-center">
                <div className="loading-spinner"></div>
              </div>
            )}
            <div ref={calendarRef} id="calendar" style={{ height: '100%' }}></div>
          </div>
        </main>
      </div>

      {/* Event Modal */}
      {showModal && (
        <EventModal
          show={showModal}
          event={selectedEvent}
          newEventData={newEventData}
          calendarObj={calendarObj}
          onClose={() => setShowModal(false)}
          onSaved={() => {
            if (onRefresh) onRefresh();
            setShowModal(false);
          }}
        />
      )}
    </div>
  );
};

export default CalendarApp;
