import { useState, useEffect } from 'react';
import {
  LuInfo, LuCalendar, LuWallet, LuUser, LuBuilding2, LuPlus, LuTrash2,
  LuRotateCcw, LuEye, LuCheck, LuTrendingUp, LuTrendingDown,
  LuCalculator, LuFileText, LuChevronRight
} from 'react-icons/lu';
import api from '../../../../../../config/api.js';
import PreviewPayslipModal from './PreviewPayslipModal';
import { toast } from 'react-hot-toast';
import { getUploadUrl } from '@/utils/uploadUrl';

const CreatesSlip = () => {
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [, setLeaveTypes] = useState([]);

  const handlePayslipSuccess = () => {
    // Reset form after successful generation
    resetForm();
    setPreviewModal(false);
  };

  const [previewModal, setPreviewModal] = useState(false);

  const [earningsRows, setEarningsRows] = useState([{ key: '', value: '' }]);
  const [deductionsRows, setDeductionsRows] = useState([{ key: '', value: '' }]);

  const [formData, setFormData] = useState({
    payrollMonth: '',
    payrollYear: '',
    employeeId: '',
    employeeName: '',
    department: '',
    designation: '',
    joiningDate: '',
    uanNo: '',
    esiNo: '',
    aadhaarNo: '',
    bankName: '',
    bankAccountNumber: '',
    totalWorkingDays: '',
    totalWorkedDays: '',
    casualLeave: 0,
    lopDays: 0,
    leaveId: '',
  });

  const fetchLeaveTypes = async () => {
    try {
      const response = await api.get('/leaves');
      if (response.status === 200) {
        setLeaveTypes(response.data || []);
      }
    } catch (error) {
      console.error('Error fetching leave types:', error);
    }
  };

  const deleteEarningsRow = (index) => {
    if (earningsRows.length > 1) {
      const updated = earningsRows.filter((_, i) => i !== index);
      setEarningsRows(updated);
    } else {
      setEarningsRows([{ key: '', value: '' }]);
    }
  };

  const deleteDeductionsRow = (index) => {
    if (deductionsRows.length > 1) {
      const updated = deductionsRows.filter((_, i) => i !== index);
      setDeductionsRows(updated);
    } else {
      setDeductionsRows([{ key: '', value: '' }]);
    }
  };

  const fetchEmployees = async () => {
    try {
      const response = await api.get('/hr/employees');
      if (response.data.success) {
        const filteredEmployees = response.data.employees.filter(emp => emp.role !== 'superadmin');
        setEmployees(filteredEmployees);
      }
    } catch (error) {
      console.error('Error fetching employees:', error);
    }
  };

  const getMonthNumber = monthName => {
    const months = {
      January: 1, February: 2, March: 3, April: 4, May: 5, June: 6,
      July: 7, August: 8, September: 9, October: 10, November: 11, December: 12,
    };
    return months[monthName];
  };

  const fetchLeaveBalance = async (employeeId, month) => {
    try {
      const monthNumber = month ? getMonthNumber(month) : null;
      const params = {};
      if (monthNumber) {
        params.month = monthNumber;
      }

      const response = await api.get(`/leave-balance/${employeeId}`, {
        params: params
      });

      if (response.data) {
        const leaveData = response.data;
        let totalLopDays = 0;
        let totalCasualLeave = 0;

        if (month && leaveData.data.leaveBalances) {
          const monthNumber = getMonthNumber(month);
          leaveData.data.leaveBalances.forEach(balance => {
            if (balance.monthlyUsage && Array.isArray(balance.monthlyUsage)) {
              const monthlyData = balance.monthlyUsage.find(usage => usage.month === monthNumber);
              if (monthlyData) {
                if (monthlyData.lopDays > 0) {
                  totalLopDays += monthlyData.lopDays;
                }
              }
            }
          });
        }

        let workingDays = 0
        if (month) {
          const year = new Date().getFullYear();
          const monthNumber = getMonthNumber(month);
          workingDays = getDaysInMonth(monthNumber, year);
        }

        setFormData(prev => ({
          ...prev,
          totalWorkingDays: workingDays,
          totalWorkedDays: workingDays - totalLopDays,
          casualLeave: totalCasualLeave,
          lopDays: totalLopDays,
        }));
      }
    } catch (error) {
      console.error('Error fetching leave balance:', error);
    }
  };

  const getDaysInMonth = (month, year) => {
    return new Date(year, month, 0).getDate();
  };

  const fetchEmployeeDetails = async employeeId => {
    try {
      const response = await api.get(`/hr/employees/${employeeId}`);
      if (response.data.success) {
        const emp = response.data.employee;
        setSelectedEmployee(emp);
        setFormData(prev => ({
          ...prev,
          employeeId: emp.employeeId || '',
          employeeName: emp.name || '',
          department: emp?.employmentDetails?.department?.name || emp.department || '',
          designation: emp?.employmentDetails?.designation?.name || emp.designation || '',
          joiningDate: emp?.employmentDetails?.dateOfJoining
            ? new Date(emp?.employmentDetails?.dateOfJoining).toLocaleDateString('en-CA')
            : '',
          uanNo: emp.uanNo || emp?.statutoryCompliance?.pfNumber || '',
          esiNo: emp?.statutoryCompliance?.esiNumber || emp.personalDetails?.esiNo || '',
          aadhaarNo: emp.aadhaarNo || emp?.statutoryCompliance?.aadhaarNumber || '',
          bankName: emp.bankName || emp.bankDetails?.bankName || '',
          bankAccountNumber: emp.bankAccountNumber || emp.bankDetails?.accountNumber || '',
        }));

        if (emp.employeeId && formData.payrollMonth) {
          fetchLeaveBalance(emp.employeeId, formData.payrollMonth);
        }
      }
    } catch (error) {
      console.error('Error fetching employee details:', error);
    }
  };

  const addEarningsRow = () => {
    setEarningsRows([...earningsRows, { key: '', value: '' }]);
  };

  const addDeductionRow = () => {
    setDeductionsRows([...deductionsRows, { key: '', value: '' }]);
  };

  const updateEarningsRow = (index, field, value) => {
    const updated = [...earningsRows];
    updated[index][field] = value;
    setEarningsRows(updated);
  };

  const updateDeductionsRow = (index, field, value) => {
    const updated = [...deductionsRows];
    updated[index][field] = value;
    setDeductionsRows(updated);
  };

  const handleEmployeeChange = e => {
    const employeeId = e.target.value;
    if (employeeId) {
      fetchEmployeeDetails(employeeId);
    }
  };

  const resetForm = () => {
    setFormData({
      payrollMonth: '',
      payrollYear: '',
      employeeId: '',
      employeeName: '',
      department: '',
      designation: '',
      joiningDate: '',
      uanNo: '',
      esiNo: '',
      aadhaarNo: '',
      bankName: '',
      bankAccountNumber: '',
      totalWorkingDays: '',
      totalWorkedDays: '',
      casualLeave: 0,
      lopDays: 0,
    });
    setEarningsRows([{ key: '', value: '' }]);
    setDeductionsRows([{ key: '', value: '' }]);
    setSelectedEmployee(null);
    setMessage('');
  };

  const previewPayslip = () => {
    const setError = (msg) => {
      setMessage(msg);
      toast.error(msg);
    };
    if (!formData.employeeId || !formData.payrollMonth || !formData.payrollYear) {
      setError('Please select employee, payroll month, and payroll year');
      return;
    }

    const validation = isValidPayrollMonth(
      formData.payrollMonth,
      Number(formData.payrollYear)
    );

    if (!validation.valid) {
      setError(validation.message);
      return;
    }

    if (formData.payrollMonth) {
      const validation = isValidPayrollMonth(formData.payrollMonth, formData.payrollYear);
      if (!validation.valid) {
        setError(validation.message);
        return;
      }
    }

    setMessage('');
    setPreviewModal(true);
  }

  const generatePayslip = async () => {
    const setError = (msg) => {
      setMessage(msg);
      toast.error(msg);
    };
    if (!formData.employeeId || !formData.payrollMonth || !formData.payrollYear) {
      setError('Please select employee, payroll month, and payroll year');
      return;
    }

    const validation = isValidPayrollMonth(
      formData.payrollMonth,
      Number(formData.payrollYear)
    );

    if (!validation.valid) {
      setError(validation.message);
      return;
    }

    const totalWorkingDays = Number(formData.totalWorkingDays || 0);
    const totalWorkedDays = Number(formData.totalWorkedDays || 0);
    const lopDays = Number(formData.lopDays || 0);
    if (!Number.isFinite(totalWorkingDays) || totalWorkingDays < 0) { setError('Total working days must be 0 or more'); return; }
    if (!Number.isFinite(totalWorkedDays) || totalWorkedDays < 0) { setError('Total worked days must be 0 or more'); return; }
    if (totalWorkingDays > 31) { setError('Total working days must be 31 or less'); return; }
    if (totalWorkedDays > totalWorkingDays) { setError('Total worked days cannot exceed total working days'); return; }
    if (!Number.isFinite(lopDays) || lopDays < 0) { setError('LOP days must be 0 or more'); return; }
    if (lopDays > totalWorkingDays) { setError('LOP days cannot exceed total working days'); return; }

    const invalidRow = [...earningsRows, ...deductionsRows].find(row => (row.key && !row.value) || (!row.key && row.value));
    if (invalidRow) { setError('Each earnings/deductions row needs both name and value'); return; }

    const earnings = earningsRows.filter(row => row.key && row.value);
    const deductions = deductionsRows.filter(row => row.key && row.value);
    if (earnings.some(r => (parseFloat(r.value) || 0) < 0) || deductions.some(r => (parseFloat(r.value) || 0) < 0)) {
      setError('Earnings and deductions values must be 0 or more');
      return;
    }

    setLoading(true);
    setMessage('');

    try {
      const payslipData = {
        ...formData,
        manualLopDays: formData.lopDays,
        manualTotalWorkingDays: formData.totalWorkingDays,
        earnings: earnings.map(row => ({
          key: row.key,
          value: parseFloat(row.value) || 0,
        })),
        deductions: deductions.map(row => ({
          key: row.key,
          value: parseFloat(row.value) || 0,
        })),
      };
      const response = await api.post('/payslip', payslipData);

      if (response.data.success) {
        setMessage('Payslip generated successfully!');
        toast.success('Payslip generated successfully');
        setFormData({
          payrollMonth: '',
          payrollYear: '',
          employeeId: '',
          employeeName: '',
          department: '',
          designation: '',
          joiningDate: '',
          uanNo: '',
          esiNo: '',
          aadhaarNo: '',
          bankName: '',
          bankAccountNumber: '',
          totalWorkingDays: 0,
          totalWorkedDays: 0,
          casualLeave: 0,
          lopDays: 0,
        });
        setSelectedEmployee(null);
        setEarningsRows([{ key: '', value: '' }]);
        setDeductionsRows([{ key: '', value: '' }]);
      }
    } catch (error) {
      setError(error.response?.data?.message || 'Error generating payslip');
      console.error('Error generating payslip:', error);
    } finally {
      setLoading(false);
    }
  };

  const isValidPayrollMonth = (month, year) => {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();
    const monthNames = {
      January: 1, February: 2, March: 3, April: 4, May: 5, June: 6,
      July: 7, August: 8, September: 9, October: 10, November: 11, December: 12
    };
    const selectedMonthNumber = monthNames[month];

    if (!selectedMonthNumber) {
      return { valid: false, message: "Invalid month selected" };
    }

    if (year > currentYear) {
      return {
        valid: false,
        message: `Cannot generate payslip for ${month} ${year}. Future year is not allowed.`
      };
    }

    if (year === currentYear && selectedMonthNumber > currentMonth) {
      return {
        valid: false,
        message: `Cannot generate payslip for ${month} ${year}. Future month is not allowed.`
      };
    }
    return { valid: true };
  };

  useEffect(() => {
    fetchEmployees();
    fetchLeaveTypes();
  }, []);

  return (
    <div className="min-h-screen bg-default-50/50 p-4 lg:p-8">
      <div className="max-w-[1600px] mx-auto space-y-8">

        {/* Enhanced Header with Breadcrumbs */}
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-2 text-sm text-default-400">
            <span className="hover:text-default-600 cursor-pointer">Payroll</span>
            <LuChevronRight className="size-4" />
            <span className="text-default-900 font-medium">Payslip Generator</span>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold text-default-900 tracking-tight">Generate Payslip</h1>
              <p className="text-default-500 max-w-xl">Calculate monthly compensation, manage deductions, and generate compliant payslips for your workforce.</p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={resetForm}
                className="px-4 py-2.5 rounded-xl border border-default-200 bg-white text-default-600 font-medium hover:bg-default-50 hover:border-default-300 transition-all flex items-center gap-2 shadow-sm"
              >
                <LuRotateCcw className="size-4" />
                <span className="hidden sm:inline">Reset Form</span>
              </button>
              <button
                onClick={previewPayslip}
                disabled={loading || !selectedEmployee}
                className="px-6 py-2.5 rounded-xl bg-primary text-white font-semibold hover:bg-primary-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5"
              >
                <LuEye className="size-4" />
                Preview & Generate
              </button>
            </div>
          </div>
        </div>

        {/* Alert Message */}
        {message && (
          <div className="bg-danger/10 border-l-4 border-danger px-6 py-4 rounded-r-xl flex items-start gap-3 animate-in slide-in-from-top-2">
            <LuInfo className="size-5 text-danger shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-danger">Attention Required</h4>
              <p className="text-sm text-danger/80 mt-1">{message}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-12 gap-8">

          {/* LEFT: Main Configuration Area (8 Cols) */}
          <div className="col-span-12 xl:col-span-8 space-y-6">

            {/* Step 1: Context Selection - Clean Card Design */}
            <section className="bg-white rounded-2xl shadow-sm border border-default-200 overflow-hidden">
              <div className="px-6 py-5 border-b border-default-100 flex items-center justify-between bg-default-50/30">
                <div className="flex items-center gap-3">
                  <div className="size-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                    <LuCalendar className="size-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-default-900">Payroll Period</h2>
                    <p className="text-sm text-default-500">Select processing month and employee</p>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-wider">Step 1</span>
              </div>

              <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-6">
                <div className="md:col-span-4 space-y-2">
                  <label className="text-sm font-semibold text-default-700">Payroll Month</label>
                  <select
                    className="w-full px-4 py-3 rounded-xl border border-default-200 bg-default-50/50 focus:bg-white focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none appearance-none cursor-pointer hover:border-default-300"
                    value={formData.payrollMonth}
                    onChange={() => {/* same logic */ }}
                  >
                    {/* ... options ... */}
                  </select>
                </div>

                <div className="md:col-span-3 space-y-2">
                  <label className="text-sm font-semibold text-default-700">Year</label>
                  <select
                    className="w-full px-4 py-3 rounded-xl border border-default-200 bg-default-50/50 focus:bg-white focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none appearance-none cursor-pointer hover:border-default-300"
                    value={formData.payrollYear}
                    onChange={() => {/* same logic */ }}
                  >
                    {/* ... options ... */}
                  </select>
                </div>

                <div className="md:col-span-5 space-y-2">
                  <label className="text-sm font-semibold text-default-700 flex items-center gap-2">
                    <LuUser className="size-4 text-default-400" />
                    Select Employee
                  </label>
                  <div className="relative">
                    <select
                      className="w-full px-4 py-3 rounded-xl border border-default-200 bg-white focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none appearance-none cursor-pointer font-medium text-default-900 hover:border-default-300 pr-10"
                      onChange={handleEmployeeChange}
                      value={selectedEmployee?._id || ''}
                    >
                      <option value="">Search employee...</option>
                      {employees.map(emp => (
                        <option key={emp._id} value={emp._id}>{emp.name} — {emp.employeeId}</option>
                      ))}
                    </select>
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-default-400">
                      <LuChevronRight className="size-5 rotate-90" />
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Step 2: Salary Components - Split Design */}
            <section className="bg-white rounded-2xl shadow-sm border border-default-200 overflow-hidden">
              <div className="px-6 py-5 border-b border-default-100 flex items-center justify-between bg-default-50/30">
                <div className="flex items-center gap-3">
                  <div className="size-10 rounded-xl bg-success/10 flex items-center justify-center text-success">
                    <LuCalculator className="size-5" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-default-900">Salary Components</h2>
                    <p className="text-sm text-default-500">Configure earnings and deductions</p>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full bg-success/10 text-success text-xs font-bold uppercase tracking-wider">Step 2</span>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-default-200">

                {/* Earnings Column */}
                <div className="p-6 space-y-4">
                  <div className="flex items-center justify-between pb-4 border-b border-default-100">
                    <div className="flex items-center gap-2">
                      <LuTrendingUp className="size-5 text-success" />
                      <h3 className="font-bold text-default-900">Earnings</h3>
                      <span className="px-2 py-0.5 rounded-full bg-success/10 text-success text-xs font-bold">
                        +{earningsRows.length}
                      </span>
                    </div>
                    <button
                      onClick={addEarningsRow}
                      className="text-sm font-semibold text-primary hover:text-primary-600 flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-primary/5 transition-colors"
                    >
                      <LuPlus className="size-4" /> Add
                    </button>
                  </div>

                  <div className="space-y-3">
                    {earningsRows.map((row, index) => (
                      <div key={index} className="group flex gap-3 items-center p-3 rounded-xl bg-default-50/50 border border-transparent hover:border-default-200 hover:bg-white transition-all">
                        <div className="flex-1 space-y-1">
                          <input
                            type="text"
                            placeholder="Component name (e.g., Basic, HRA)"
                            className="w-full bg-transparent text-sm font-medium text-default-900 placeholder:text-default-400 outline-none"
                            value={row.key}
                            onChange={(e) => updateEarningsRow(index, 'key', e.target.value)}
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-default-400 font-medium">$</span>
                          <input
                            type="number"
                            placeholder="0.00"
                            className="w-24 bg-white text-right font-semibold text-default-900 rounded-lg border border-default-200 px-3 py-2 focus:border-success focus:ring-2 focus:ring-success/20 outline-none transition-all"
                            value={row.value}
                            onChange={(e) => updateEarningsRow(index, 'value', e.target.value)}
                          />
                          {index > 0 && (
                            <button
                              onClick={() => deleteEarningsRow(index)}
                              className="opacity-0 group-hover:opacity-100 p-2 text-default-300 hover:text-danger hover:bg-danger/10 rounded-lg transition-all"
                            >
                              <LuTrash2 className="size-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="pt-4 border-t border-default-100 flex justify-between items-center text-success">
                    <span className="text-sm font-medium">Total Earnings</span>
                    <span className="text-xl font-bold">
                      ${earningsRows.reduce((a, b) => a + (Number(b.value) || 0), 0).toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Deductions Column */}
                <div className="p-6 space-y-4 bg-default-50/30">
                  <div className="flex items-center justify-between pb-4 border-b border-default-200">
                    <div className="flex items-center gap-2">
                      <LuTrendingDown className="size-5 text-danger" />
                      <h3 className="font-bold text-default-900">Deductions</h3>
                      <span className="px-2 py-0.5 rounded-full bg-danger/10 text-danger text-xs font-bold">
                        -{deductionsRows.length}
                      </span>
                    </div>
                    <button
                      onClick={addDeductionRow}
                      className="text-sm font-semibold text-primary hover:text-primary-600 flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-primary/5 transition-colors"
                    >
                      <LuPlus className="size-4" /> Add
                    </button>
                  </div>

                  <div className="space-y-3">
                    {deductionsRows.map((row, index) => (
                      <div key={index} className="group flex gap-3 items-center p-3 rounded-xl bg-white border border-default-200 hover:border-danger/30 hover:shadow-sm transition-all">
                        <div className="flex-1 space-y-1">
                          <input
                            type="text"
                            placeholder="Deduction name (e.g., PF, Tax)"
                            className="w-full bg-transparent text-sm font-medium text-default-900 placeholder:text-default-400 outline-none"
                            value={row.key}
                            onChange={(e) => updateDeductionsRow(index, 'key', e.target.value)}
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-default-400 font-medium">$</span>
                          <input
                            type="number"
                            placeholder="0.00"
                            className="w-24 bg-default-50 text-right font-semibold text-default-900 rounded-lg border border-default-200 px-3 py-2 focus:border-danger focus:ring-2 focus:ring-danger/20 outline-none transition-all"
                            value={row.value}
                            onChange={(e) => updateDeductionsRow(index, 'value', e.target.value)}
                          />
                          {index > 0 && (
                            <button
                              onClick={() => deleteDeductionsRow(index)}
                              className="opacity-0 group-hover:opacity-100 p-2 text-default-300 hover:text-danger hover:bg-danger/10 rounded-lg transition-all"
                            >
                              <LuTrash2 className="size-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="pt-4 border-t border-default-200 flex justify-between items-center text-danger">
                    <span className="text-sm font-medium">Total Deductions</span>
                    <span className="text-xl font-bold">
                      ${deductionsRows.reduce((a, b) => a + (Number(b.value) || 0), 0).toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Net Pay Summary Bar */}
              <div className="px-6 py-5 bg-default-900 text-white flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="flex items-center gap-3">
                  <div className="size-10 rounded-xl bg-white/10 flex items-center justify-center">
                    <LuWallet className="size-5" />
                  </div>
                  <div>
                    <p className="text-xs text-white/60 uppercase tracking-wider font-semibold">Estimated Net Pay</p>
                    <p className="text-xs text-white/40">Before statutory adjustments</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold tracking-tight">
                    ${(
                      earningsRows.reduce((a, b) => a + (Number(b.value) || 0), 0) -
                      deductionsRows.reduce((a, b) => a + (Number(b.value) || 0), 0)
                    ).toLocaleString()}
                  </p>
                </div>
              </div>
            </section>

            {/* Attendance Section - Inline with Salary */}
            <section className="bg-white rounded-2xl shadow-sm border border-default-200 p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="size-10 rounded-xl bg-warning/10 flex items-center justify-center text-warning">
                  <LuCheck className="size-5" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-default-900">Attendance & LOP</h2>
                  <p className="text-sm text-default-500">Adjust for leave without pay</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-default-700">Working Days</label>
                  <div className="relative">
                    <input
                      type="number"
                      className="w-full px-4 py-3 rounded-xl border border-default-200 bg-default-50 font-bold text-default-900 text-center"
                      value={formData.totalWorkingDays}
                      readOnly
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-default-400 font-medium">days</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-default-700">Present Days</label>
                  <div className="relative">
                    <input
                      type="number"
                      className="w-full px-4 py-3 rounded-xl border border-success/30 bg-success/5 font-bold text-success text-center focus:ring-4 focus:ring-success/10 outline-none transition-all"
                      value={formData.totalWorkedDays}
                      onChange={e => setFormData({ ...formData, totalWorkedDays: e.target.value })}
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-success font-medium">worked</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-default-700 text-danger">LOP Days</label>
                  <div className="relative">
                    <input
                      type="number"
                      className="w-full px-4 py-3 rounded-xl border border-danger/30 bg-danger/5 font-bold text-danger text-center focus:ring-4 focus:ring-danger/10 outline-none transition-all"
                      value={formData.lopDays}
                      onChange={e => setFormData({ ...formData, lopDays: e.target.value })}
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-danger font-medium">deduct</span>
                  </div>
                </div>
              </div>
            </section>
          </div>

          {/* RIGHT: Employee Profile & Summary (4 Cols) */}
          <div className="col-span-12 xl:col-span-4 space-y-6">

            {/* Employee Profile Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-default-200 overflow-hidden sticky top-6">
              <div className="h-24 bg-gradient-to-br from-primary to-primary-600 relative">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
              </div>

              <div className="px-6 pb-6">
                <div className="relative -mt-12 mb-4 flex justify-between items-end">
                  <div className="size-24 rounded-2xl bg-white p-1 shadow-lg">
                    <div className="size-full rounded-xl bg-default-100 flex items-center justify-center text-3xl font-bold text-default-400 overflow-hidden">
                      {selectedEmployee?.documents?.photograph || selectedEmployee?.employeePersonal?.profilePhoto ? (
                        <img
                          src={getUploadUrl(selectedEmployee.documents?.photograph || selectedEmployee.employeePersonal?.profilePhoto)}
                          alt={formData.employeeName}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        formData.employeeName?.charAt(0) || '?'
                      )}
                    </div>
                  </div>
                  {selectedEmployee && (
                    <span className="mb-2 px-3 py-1 rounded-full bg-success/10 text-success text-xs font-bold border border-success/20">
                      Active
                    </span>
                  )}
                </div>

                <div className="space-y-1 mb-6">
                  <h3 className="text-xl font-bold text-default-900">{formData.employeeName || 'Select Employee'}</h3>
                  <p className="text-default-500 flex items-center gap-2">
                    <LuBuilding2 className="size-4" />
                    {formData.designation || 'No designation'} • {formData.employeeId || '---'}
                  </p>
                </div>

                {selectedEmployee ? (
                  <div className="space-y-4 pt-6 border-t border-default-100">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 rounded-xl bg-default-50 border border-default-100">
                        <p className="text-xs text-default-400 mb-1">Joining Date</p>
                        <p className="text-sm font-semibold text-default-900">{formData.joiningDate || '---'}</p>
                      </div>
                      <div className="p-3 rounded-xl bg-default-50 border border-default-100">
                        <p className="text-xs text-default-400 mb-1">Department</p>
                        <p className="text-sm font-semibold text-default-900">{formData.department || '---'}</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center py-2 border-b border-default-50">
                        <span className="text-sm text-default-500">Bank Account</span>
                        <span className="text-sm font-medium text-default-900 font-mono">{formData.bankAccountNumber || '---'}</span>
                      </div>
                      <div className="flex justify-between items-center py-2 border-b border-default-50">
                        <span className="text-sm text-default-500">UAN</span>
                        <span className="text-sm font-medium text-default-900 font-mono">{formData.uanNo || '---'}</span>
                      </div>
                      <div className="flex justify-between items-center py-2">
                        <span className="text-sm text-default-500">PAN</span>
                        <span className="text-sm font-medium text-default-900 font-mono">{formData.panNo || '---'}</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="py-8 text-center border-t border-default-100">
                    <div className="size-16 rounded-full bg-default-50 flex items-center justify-center mx-auto mb-3">
                      <LuUser className="size-8 text-default-300" />
                    </div>
                    <p className="text-sm text-default-400">Select an employee to view details</p>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Stats */}
            {selectedEmployee && (
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-2xl shadow-sm border border-default-200">
                  <p className="text-xs text-default-400 mb-1">Gross Salary</p>
                  <p className="text-lg font-bold text-success">
                    ${earningsRows.reduce((a, b) => a + (Number(b.value) || 0), 0).toLocaleString()}
                  </p>
                </div>
                <div className="bg-white p-4 rounded-2xl shadow-sm border border-default-200">
                  <p className="text-xs text-default-400 mb-1">Net Payable</p>
                  <p className="text-lg font-bold text-primary">
                    ${(
                      earningsRows.reduce((a, b) => a + (Number(b.value) || 0), 0) -
                      deductionsRows.reduce((a, b) => a + (Number(b.value) || 0), 0)
                    ).toLocaleString()}
                  </p>
                </div>
              </div>
            )}

            {/* Help Card */}
            <div className="bg-primary/5 rounded-2xl p-6 border border-primary/10">
              <div className="flex items-start gap-3">
                <LuFileText className="size-5 text-primary shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-primary mb-1">Compliance Note</h4>
                  <p className="text-xs text-primary/70 leading-relaxed">
                    Ensure PF, ESI, and Professional Tax are calculated as per current statutory rates before generating final payslip.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Preview Modal */}
        {previewModal && (
          <PreviewPayslipModal
            isOpen={previewModal}
            onClose={() => setPreviewModal(false)}
            formData={formData}
            earnings={earningsRows.filter(r => r.key && r.value)}
            deductions={deductionsRows.filter(r => r.key && r.value)}
            onConfirm={generatePayslip}
            loading={loading}
            onSuccess={handlePayslipSuccess}
            employeeId={formData.employeeId}
            extraEarnings={earningsRows}
            extraDeductions={deductionsRows}
          />
        )}
      </div>
    </div >
  );
};

export default CreatesSlip;
