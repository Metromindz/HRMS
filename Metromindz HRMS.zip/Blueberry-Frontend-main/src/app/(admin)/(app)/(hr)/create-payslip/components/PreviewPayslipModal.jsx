// PreviewPayslipModal.jsx
import { useState, useEffect } from 'react';
// import { LuX, LuPrinter, LuLoader2 } from 'react-icons/lu';
import api from '../../../../../../config/api.js';
import { LuX } from 'react-icons/lu';

const PreviewPayslipModal = ({
  isOpen,
  onClose,
  formData,
  onSuccess,
  extraEarnings,
  extraDeductions
}) => {
  const [payslipData, setPayslipData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');





  // Fetch preview data when modal opens
  useEffect(() => {
    if (isOpen && formData.employeeId && formData.payrollMonth && formData.payrollYear) {
      fetchPayslipPreview();
    }
  }, [isOpen, formData]);

  const fetchPayslipPreview = async () => {
    try {
      setLoading(true);
      setError('');

      const response = await api.post('/payslip/preview', {
        employeeId: formData.employeeId,
        payrollMonth: formData.payrollMonth,
        payrollYear: formData.payrollYear,
        generationDate: new Date(),
        extraEarnings, extraDeductions,
      });

      if (response.data.success) {
        setPayslipData(response.data.data);
      } else {
        setError(response.data.message || 'Failed to fetch preview data');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Error fetching preview data');
      console.error('Error fetching payslip preview:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    if (!amount && amount !== 0) return '$0';
    return `$${parseFloat(amount).toLocaleString('en-IN')}`;
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const filteredEarnings = extraEarnings.filter(item =>
    item.key?.trim() && item.value !== "" && item.value !== null
  );

  const filteredDeductions = extraDeductions.filter(item =>
    item.key?.trim() && item.value !== "" && item.value !== null
  );


  const generatePayslip = async () => {
    if (!formData.employeeId || !formData.payrollMonth) {
      setError('Please select employee and payroll month');
      return;
    }

    // Use the preview data for generation
    if (!payslipData) {
      setError('No payslip data available for generation');
      return;
    }

    setLoading(true);




    try {
      // Prepare data for generation using the preview data
      const generationData = {
        employeeId: formData.employeeId,
        employeeName: formData.employeeName,
        department: formData.department,
        designation: formData.designation,
        payrollMonth: formData.payrollMonth,
        payrollYear: new Date().getFullYear(),
        generationDate: new Date().toISOString(),

        // Bank details
        bankName: formData.bankName,
        bankAccountNumber: formData.bankAccountNumber,

        // Employee identification
        uanNo: formData.uanNo,
        esiNo: formData.esiNo,
        aadhaarNo: formData.aadhaarNo,

        // Attendance data
        totalWorkingDays: formData.totalWorkingDays,
        lopDays: formData.lopDays || 0,
        daysWorked: formData.totalWorkedDays,

        earnings: filteredEarnings,
        deductions: filteredDeductions,
        joiningDate: formData.joiningDate
      };



      // Call the actual generation endpoint
      const response = await api.post('/payslip', generationData);

      // Or if your endpoint is just '/payslip' as in your commented code:
      // const response = await api.post('/payslip', generationData);

      if (response.data.success) {
        setMessage('Payslip generated successfully!');
        // setGenerationSuccess(true);

        setTimeout(() => {
          // Call onSuccess callback if provided
          setMessage('');
          if (onSuccess) {
            onSuccess();
          } else {
            onClose(); // Fallback to regular close
          }
        }, 2000);
      } else {
        setError(response.data.message || 'Failed to generate payslip');
      }
    } catch (error) {
      setError(error.response?.data?.message || 'Error generating payslip');
      console.error('Error generating payslip:', error);
    } finally {
      setLoading(false);
    }
  };

  // const handlePrint = () => {
  //   const printContent = document.getElementById('payslip-preview-content');
  //   const printWindow = window.open('', '_blank');
  //   printWindow.document.write(`
  //     <!DOCTYPE html>
  //     <html>
  //       <head>
  //         <title>Payslip Preview - ${formData.employeeName}</title>
  //         <style>
  //           body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
  //           .payslip-container { max-width: 800px; margin: 0 auto; }
  //           .header { display: flex; justify-content: space-between; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px; }
  //           .company-info h2 { margin: 0 0 10px 0; }
  //           .month-info { text-align: right; }
  //           table { width: 100%; border-collapse: collapse; margin: 20px 0; }
  //           th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }
  //           th { background-color: #f5f5f5; }
  //           .summary { background-color: #f9f9f9; padding: 15px; margin: 20px 0; border-radius: 5px; }
  //           .footer { display: flex; justify-content: space-between; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; }
  //           @media print {
  //             button { display: none; }
  //             body { padding: 0; }
  //           }
  //         </style>
  //       </head>
  //       <body>
  //         <div class="payslip-container">
  //           ${printContent.innerHTML}
  //         </div>
  //         <script>
  //           window.onload = function() {
  //             window.print();
  //             window.close();
  //           }
  //         </script>
  //       </body>
  //     </html>
  //   `);
  //   printWindow.document.close();
  // };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/50" onClick={onClose}></div>

      {/* Modal */}
      <div className="flex min-h-full items-center justify-center p-4">
        <div className="relative w-full max-w-5xl bg-white rounded-2xl">
          {/* Modal Header */}
          <div className="sticky top-0 z-10 flex items-center justify-between border-b bg-white p-4 rounded-t-xl">
            <div>
              <h2 className="text-xl font-bold text-gray-800">Payslip Preview</h2>
              {/* <p className="text-sm text-gray-600">Preview before generating payslip</p> */}
            </div>
            <div className="flex items-center gap-3">
              {/* <button
                onClick={handlePrint}
                className="btn btn-sm bg-green-600 text-white flex items-center gap-1"
                disabled={loading || !payslipData}
              >
                <LuPrinter className="size-4" /> Print
              </button> */}
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <LuX className="size-5" />
              </button>
            </div>
          </div>

          {/* Modal Content */}
          <div className="p-6 max-h-[calc(100vh-200px)] overflow-y-auto">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-20">
                {/* <LuLoader2 className="size-12 text-primary animate-spin mb-4" /> */}
                <p className="text-gray-600">Loading payslip preview...</p>
              </div>
            ) : message ? (
              <div className="text-center py-10">
                <div className="text-green-500 mb-4">✓ {message}</div>
              </div>
            ) : error ? (
              <div className="text-center py-10">
                <div className="text-red-500 mb-4">{error}</div>
                <button
                  onClick={fetchPayslipPreview}
                  className="h-10 px-6 text-[10px] font-black uppercase tracking-widest bg-primary text-white rounded-xl transition-all active:scale-95"
                >
                  Try Again
                </button>
              </div>
            ) : payslipData ? (
              <div id="payslip-preview-content">
                <div className="max-w-4xl mx-auto bg-white rounded-2xl overflow-hidden border border-gray-200">
                  <div className="p-8">
                    {/* Payslip Header */}
                    <div className="flex justify-between items-start border-b pb-6 mb-6">
                      {/* Left — Static Company Info */}
                      <div>
                        <h2 className="text-xl font-bold text-gray-800">Metromindz Pvt Ltd</h2>
                        <p className="text-sm text-gray-600">Bangalore, India</p>
                        <p className="text-sm text-gray-600">Phone: +91 0123 456 7890</p>
                        <p className="text-sm text-gray-600">Email: metromindz@gmail.com</p>
                      </div>

                      {/* Right — Payslip Month */}
                      <div className="text-right">
                        <p className="text-sm text-gray-500">Payslip For the Month</p>
                        <h2 className="text-xl font-bold text-gray-800">
                          {payslipData.payrollMonth} {payslipData.payrollYear || new Date().getFullYear()}
                        </h2>
                        <p className="text-sm text-gray-500 mt-1">
                          Generated: {formatDate(payslipData.generationDate || new Date())}
                        </p>
                      </div>
                    </div>

                    {/* Employee Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3 text-sm">
                      <p className="text-gray-500">
                        <strong className="text-gray-800">Employee ID:</strong> {payslipData.employeeId || formData.employeeId}
                      </p>
                      <p className="text-gray-500">
                        <strong className="text-gray-800">Employee Name:</strong> {payslipData.employeeName || formData.employeeName}
                      </p>
                      <p className="text-gray-500">
                        <strong className="text-gray-800">Designation:</strong> {payslipData.designation || formData.designation}
                      </p>
                      <p className="text-gray-500">
                        <strong className="text-gray-800">Department:</strong> {payslipData.department || formData.department}
                      </p>
                      <p className="text-gray-500">
                        <strong className="text-gray-800">Joining Date:</strong> {formatDate(formData.joiningDate)}
                      </p>
                      <p className="text-gray-500">
                        <strong className="text-gray-800">UAN No:</strong> {payslipData.uanNo || formData.uanNo || 'N/A'}
                      </p>
                      <p className="text-gray-500">
                        <strong className="text-gray-800">ESI No:</strong> {payslipData.esiNo || formData.esiNo || 'N/A'}
                      </p>
                      <p className="text-gray-500">
                        <strong className="text-gray-800">Aadhaar No:</strong> {payslipData.aadhaarNo || formData.aadhaarNo || 'N/A'}
                      </p>
                      <p className="text-gray-500">
                        <strong className="text-gray-800">Bank Name:</strong> {formData.bankName || 'N/A'}
                      </p>
                      <p className="text-gray-500">
                        <strong className="text-gray-800">Account No:</strong> {formData.bankAccountNumber || 'N/A'}
                      </p>
                    </div>

                    {/* Attendance */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8 p-4 bg-gray-50 rounded-lg">
                      <div className="text-center">
                        <p className="text-sm text-gray-500">Total Working Days</p>
                        <p className="text-lg font-bold text-gray-800">
                          {payslipData.totalWorkingDays || formData.totalWorkingDays || 0}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-500">LOP Days</p>
                        <p className="text-lg font-bold text-red-600">
                          {payslipData.lopDays || formData.lopDays || 0}
                        </p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-gray-500">Days Worked</p>
                        <p className="text-lg font-bold text-green-600">
                          {payslipData.daysWorked || formData.totalWorkedDays || 0}
                        </p>
                      </div>
                    </div>

                    {/* Salary Table */}
                    <div className="mt-10 overflow-x-auto">
                      <table className="min-w-full border border-gray-300 text-sm">
                        <thead className="bg-gray-100 border-b border-gray-300">
                          <tr className="text-gray-800">
                            <th className="px-4 py-2 text-left">Earnings</th>
                            <th className="px-4 py-2 text-left">Amount</th>
                            <th className="px-4 py-2 text-left">Deductions</th>
                            <th className="px-4 py-2 text-left">Amount</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {/* Dynamic rows based on earnings and deductions */}
                          {Array.from({
                            length: Math.max(
                              payslipData.earnings?.length || 0,
                              payslipData.deductions?.length || 0
                            )
                          }).map((_, index) => (
                            <tr key={index}>
                              <td className="px-4 py-2">
                                {payslipData.earnings?.[index]?.key || ''}
                              </td>
                              <td className="px-4 py-2">
                                {payslipData.earnings?.[index] ? formatCurrency(payslipData.earnings[index].value) : ''}
                              </td>
                              <td className="px-4 py-2">
                                {payslipData.deductions?.[index]?.key || ''}
                              </td>
                              <td className="px-4 py-2">
                                {payslipData.deductions?.[index] ? formatCurrency(payslipData.deductions[index].value) : ''}
                              </td>
                            </tr>
                          ))}

                          <tr className="bg-gray-50 font-semibold">
                            <td className="px-4 py-2">Gross Earnings</td>
                            <td className="px-4 py-2">{formatCurrency(payslipData.totalEarnings)}</td>
                            <td className="px-4 py-2">Total Deductions</td>
                            <td className="px-4 py-2">{formatCurrency(payslipData.totalDeductions)}</td>
                          </tr>

                          <tr className="font-semibold">
                            <td className="px-4 py-2">Total Net Payable</td>
                            <td className="px-4 py-2 text-green-600">{formatCurrency(payslipData.netPay)}</td>
                            <td className="px-4 py-2"></td>
                            <td className="px-4 py-2"></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>

                    {/* Footer */}
                    <div className="grid md:grid-cols-2 gap-6 mt-10 text-sm">
                      <div className="text-gray-500">
                        <p>
                          For any inquiries, please contact us at +(91) 0123 456 7890 or
                          email at metromindz@gmail.com
                        </p>
                        <p className="mt-2">Best Regards,</p>
                        <p>Metromindz Private Limited</p>
                      </div>

                      <div className="flex flex-col items-center md:items-end">
                        <p className="h-12 mt-2">No digitalized signature is available for display.</p>
                        <h6 className="text-gray-800 font-semibold text-sm">Authorized Sign</h6>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-10">
                <p className="text-gray-600">No preview data available. Please check your inputs.</p>
              </div>
            )}
          </div>

          {/* Modal Footer */}
          <div className="sticky bottom-0 border-t bg-white p-4 rounded-b-xl flex justify-between">
            <div className="text-sm text-gray-500">
              Note: This is a preview. Click "Generate" to save the payslip.
            </div>
            <div className="flex gap-3">
              <button
                onClick={onClose}
                className="h-10 px-6 text-[10px] font-black uppercase tracking-widest border border-default-200 text-default-700 hover:bg-default-100 rounded-xl transition-all active:scale-95"
              >
                Close
              </button>
              <button
                onClick={() => {
                  generatePayslip();
                  // onClose();
                  // You can add generate functionality here if needed
                }}
                className="h-10 px-6 text-[10px] font-black uppercase tracking-widest bg-primary text-white rounded-xl transition-all active:scale-95"
              >
                Generate Payslip
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PreviewPayslipModal;
