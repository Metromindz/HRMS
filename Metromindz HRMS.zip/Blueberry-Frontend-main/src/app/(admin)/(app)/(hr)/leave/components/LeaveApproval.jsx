import { LuCheck, LuX } from 'react-icons/lu';

const LeaveApproval = ({ leaveRequests, loading, message, handleApproval, canStatus }) => {
  const displayRequests = canStatus ? leaveRequests.filter(request => request.status === 'pending') : leaveRequests;

  return (
    <div className="card">
      <div className="card-header">
        <h6 className="card-title">Leave Approval</h6>
      </div>
      <div className="card-body">
        {message && (
          <div
            className={`mb-4 p-3 rounded ${message.includes('success') ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}
          >
            {message}
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3">Employee</th>
                <th className="text-left py-3">Leave Type</th>
                <th className="text-left py-3">From Date</th>
                <th className="text-left py-3">To Date</th>
                <th className="text-left py-3">Days</th>
                <th className="text-left py-3">Reason</th>
                <th className="text-left py-3">Status</th>
                <th className="text-left py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {displayRequests.length === 0 ? (
                <tr>
                  <td colSpan="8" className="text-center py-4">
                    {loading ? 'Loading...' : 'No leave requests'}
                  </td>
                </tr>
              ) : (
                displayRequests.map((request, index) => (
                  <tr key={index} className="border-b">
                    <td className="py-3">{request.employeeName}</td>
                    <td className="py-3">{request.leaveName}</td>
                    <td className="py-3">{new Date(request.fromDate).toLocaleDateString()}</td>
                    <td className="py-3">{new Date(request.toDate).toLocaleDateString()}</td>
                    <td className="py-3">{request.numberOfDays}</td>
                    <td className="py-3 max-w-xs truncate">{request.reason}</td>
                    <td className="py-3">
                      <span
                        className={`px-2 py-1 rounded text-xs ${
                          request.status === 'pending'
                            ? 'bg-yellow-100 text-yellow-800'
                            : request.status === 'approved'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {request.status}
                      </span>
                    </td>
                    <td className="py-3">
                      {canStatus && request.status === 'pending' && (
                        <div className="flex gap-2">
                          <button
                            className="btn btn-sm bg-green-500 text-white"
                            onClick={() =>
                              handleApproval(
                                request.employeeId,
                                request.leaveId,
                                request.fromDate,
                                request.toDate,
                                'approved'
                              )
                            }
                            disabled={loading}
                          >
                            <LuCheck className="size-4" />
                          </button>
                          <button
                            className="btn btn-sm bg-red-500 text-white"
                            onClick={() =>
                              handleApproval(
                                request.employeeId,
                                request.leaveId,
                                request.fromDate,
                                request.toDate,
                                'rejected'
                              )
                            }
                            disabled={loading}
                          >
                            <LuX className="size-4" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default LeaveApproval;
