import { useState, useEffect } from 'react';
import { LuX, LuPlus, LuTrash2 } from 'react-icons/lu';

const EditGradeSalary = ({ isOpen, onClose, onSave, grade }) => {
  const [formData, setFormData] = useState({
    grade: '',
    basic: '',
    basicUnit: '',
    hra: '',
    hraUnit: '',
    pfEnabled: false,
    pfPercent: '',
    esiEnabled: false,
    esiPercent: '',
    medical: '',
    pt: '',
    tds: '',
    specialAllowance: '',
    conveyance: '',
    extraAllowances: []
  });

  useEffect(() => {
    if (grade) {
      setFormData({
        id: grade._id || grade.id,
        grade: grade.grade || '',
        basic: grade.basic?.value || '',
        basicUnit: grade.basic?.unit || '',
        hra: grade.hra?.value || '',
        hraUnit: grade.hra?.unit || '',
        pfEnabled: grade.pfEnabled || false,
        pfPercent: grade.pfPercent || '',
        esiEnabled: grade.esiEnabled || false,
        esiPercent: grade.esiPercent || '',
        medical: grade.medical || '',
        pt: grade.pt || '',
        tds: grade.tds || '',
        specialAllowance: grade.specialAllowance || '',
        conveyance: grade.conveyanceAllowance || '',
        extraAllowances: grade.extraAllowances || []
      });
    }
  }, [grade]);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
    
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({ 
      ...formData, 
      [name]: type === 'checkbox' ? checked : value 
    });
  };

  const addExtraAllowance = () => {
    setFormData({
      ...formData,
      extraAllowances: [...formData.extraAllowances, { name: '', amount: '' }]
    });
  };

  const updateExtraAllowance = (index, field, value) => {
    const updated = [...formData.extraAllowances];
    updated[index][field] = value;
    setFormData({ ...formData, extraAllowances: updated });
  };

  const removeExtraAllowance = (index) => {
    const updated = formData.extraAllowances.filter((_, i) => i !== index);
    setFormData({ ...formData, extraAllowances: updated });
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-default-900/60 backdrop-blur-sm transition-all duration-300 animate-in fade-in">
      <div className="relative bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-default-100 animate-in zoom-in-95 duration-300">
        <form onSubmit={handleSubmit} className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-default-100 bg-white/80 sticky top-0 z-20 backdrop-blur-md">
            <div className="flex flex-col gap-1">
              <h3 className="text-xl font-black text-default-900 uppercase tracking-tight">Edit Grade Structure</h3>
              <p className="text-[10px] font-bold text-default-500 uppercase tracking-widest px-1">Update salary components for this grade</p>
            </div>
            <button 
              type="button" 
              className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-90" 
              onClick={onClose}
            >
              <LuX className="size-5" />
            </button>
          </div>

          <div className="p-8 overflow-y-auto custom-scrollbar flex-1 space-y-8">
            {/* Basic Info Section */}
            <div className="space-y-6">
              <div className="flex items-center gap-2 mb-2 px-1">
                <div className="h-4 w-1 bg-primary rounded-full" />
                <h4 className="text-[10px] font-black text-default-900 uppercase tracking-[0.2em]">Basic Information</h4>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <label htmlFor="grade" className="text-[10px] font-black text-default-500 uppercase tracking-widest px-1">
                    Grade <span className="text-danger">*</span>
                  </label>
                  <input 
                    type="text" 
                    id="grade" 
                    name="grade"
                    value={formData.grade}
                    onChange={handleChange}
                    className="h-12 w-full bg-default-50 border border-default-200 rounded-xl px-4 text-sm font-bold text-default-700 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all placeholder:text-default-400 placeholder:font-normal" 
                    placeholder="e.g., G1" 
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="basic" className="text-[10px] font-black text-default-500 uppercase tracking-widest px-1">
                    Basic Pay <span className="text-danger">*</span>
                  </label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      id="basic" 
                      name="basic"
                      value={formData.basic}
                      onChange={handleChange}
                      className="h-12 flex-1 bg-default-50 border border-default-200 rounded-xl px-4 text-sm font-bold text-default-700 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all placeholder:text-default-400 placeholder:font-normal" 
                      placeholder="Amount" 
                      required
                    />
                    <select 
                      name="basicUnit"
                      value={formData.basicUnit}
                      onChange={handleChange}
                      className="h-12 w-24 bg-default-50 border border-default-200 rounded-xl px-3 text-sm font-bold text-default-700 focus:outline-none focus:border-primary transition-all"
                      required
                    >
                      <option value="amount">Fixed</option>
                      <option value="percent">%</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="hra" className="text-[10px] font-black text-default-500 uppercase tracking-widest px-1">
                    HRA
                  </label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      id="hra" 
                      name="hra"
                      value={formData.hra}
                      onChange={handleChange}
                      className="h-12 flex-1 bg-default-50 border border-default-200 rounded-xl px-4 text-sm font-bold text-default-700 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all placeholder:text-default-400 placeholder:font-normal" 
                      placeholder="Amount" 
                    />
                    <select 
                      name="hraUnit"
                      value={formData.hraUnit}
                      onChange={handleChange}
                      className="h-12 w-24 bg-default-50 border border-default-200 rounded-xl px-3 text-sm font-bold text-default-700 focus:outline-none focus:border-primary transition-all"
                    >
                      <option value="amount">Fixed</option>
                      <option value="percent">%</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Statutory Benefits Section */}
            <div className="space-y-6">
              <div className="flex items-center gap-2 mb-2 px-1">
                <div className="h-4 w-1 bg-primary rounded-full" />
                <h4 className="text-[10px] font-black text-default-900 uppercase tracking-[0.2em]">Statutory Benefits</h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <div className="relative flex items-center">
                      <input 
                        type="checkbox" 
                        name="pfEnabled"
                        checked={formData.pfEnabled}
                        onChange={handleChange}
                        className="peer sr-only" 
                      />
                      <div className="size-6 bg-default-100 border-2 border-default-200 rounded-lg peer-checked:bg-primary peer-checked:border-primary transition-all group-hover:border-primary/50" />
                      <LuPlus className="absolute size-4 text-white opacity-0 peer-checked:opacity-100 transition-opacity left-1" />
                    </div>
                    <span className="text-sm font-black text-default-700 uppercase tracking-widest">Provident Fund (PF)</span>
                  </label>
                  
                  {formData.pfEnabled && (
                    <div className="space-y-2 animate-in slide-in-from-top-2 duration-300">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest px-1">
                        PF Percentage (%)
                      </label>
                      <input 
                        type="text" 
                        name="pfPercent"
                        value={formData.pfPercent}
                        onChange={handleChange}
                        className="h-12 w-full bg-default-50 border border-default-200 rounded-xl px-4 text-sm font-bold text-default-700 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all" 
                        placeholder="e.g. 12" 
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <div className="relative flex items-center">
                      <input 
                        type="checkbox" 
                        name="esiEnabled"
                        checked={formData.esiEnabled}
                        onChange={handleChange}
                        className="sr-only peer"
                      />
                      <div className="size-6 bg-default-100 border-2 border-default-200 rounded-lg peer-checked:bg-primary peer-checked:border-primary transition-all group-hover:border-primary/50" />
                      <LuPlus className="absolute size-4 text-white opacity-0 peer-checked:opacity-100 transition-opacity left-1" />
                    </div>
                    <span className="text-sm font-black text-default-700 uppercase tracking-widest">ESI Status</span>
                  </label>
                  
                  {formData.esiEnabled && (
                    <div className="space-y-2 animate-in slide-in-from-top-2 duration-300">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest px-1">
                        ESI Percentage (%)
                      </label>
                      <input 
                        type="text" 
                        name="esiPercent"
                        value={formData.esiPercent}
                        onChange={handleChange}
                        className="h-12 w-full bg-default-50 border border-default-200 rounded-xl px-4 text-sm font-bold text-default-700 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all" 
                        placeholder="e.g. 1.75" 
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Allowances Section */}
            <div className="space-y-6">
              <div className="flex items-center gap-2 mb-2 px-1">
                <div className="h-4 w-1 bg-primary rounded-full" />
                <h4 className="text-[10px] font-black text-default-900 uppercase tracking-[0.2em]">Fixed Allowances & Taxes</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  { id: 'medical', label: 'Medical Allowance', placeholder: 'Amount' },
                  { id: 'pt', label: 'Professional Tax (PT)', placeholder: 'Amount' },
                  { id: 'tds', label: 'TDS', placeholder: 'Amount' },
                  { id: 'specialAllowance', label: 'Special Allowance', placeholder: 'Amount' },
                  { id: 'conveyance', label: 'Conveyance Allowance', placeholder: 'Amount' }
                ].map(field => (
                  <div key={field.id} className="space-y-2">
                    <label htmlFor={field.id} className="text-[10px] font-black text-default-500 uppercase tracking-widest px-1">
                      {field.label}
                    </label>
                    <input 
                      type="text" 
                      id={field.id} 
                      name={field.id}
                      value={formData[field.id]}
                      onChange={handleChange}
                      className="h-12 w-full bg-default-50 border border-default-200 rounded-xl px-4 text-sm font-bold text-default-700 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all placeholder:text-default-400" 
                      placeholder={field.placeholder} 
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Custom Allowances Section */}
            <div className="space-y-6">
              <div className="flex justify-between items-center px-1">
                <div className="flex items-center gap-2">
                  <div className="h-4 w-1 bg-primary rounded-full" />
                  <h4 className="text-[10px] font-black text-default-900 uppercase tracking-[0.2em]">Extra Allowances</h4>
                </div>
                <button 
                  type="button"
                  onClick={addExtraAllowance}
                  className="h-10 px-4 bg-success/10 text-success rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-success hover:text-white transition-all flex items-center gap-2 active:scale-95"
                >
                  <LuPlus className="size-3.5" /> Add Allowance
                </button>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {formData.extraAllowances.length === 0 ? (
                  <div className="py-8 text-center bg-default-50 rounded-2xl border-2 border-dashed border-default-200">
                    <p className="text-[10px] font-black text-default-400 uppercase tracking-widest">No extra allowances added</p>
                  </div>
                ) : (
                  formData.extraAllowances.map((allowance, index) => (
                    <div key={index} className="group flex flex-col md:flex-row gap-4 p-4 bg-default-50 border border-default-200 rounded-2xl transition-all hover:border-primary/30 animate-in slide-in-from-left-4 duration-300">
                      <div className="flex-1 space-y-2">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest px-1">Allowance Name</label>
                        <input 
                          type="text" 
                          value={allowance.name}
                          onChange={(e) => updateExtraAllowance(index, 'name', e.target.value)}
                          className="h-11 w-full bg-white border border-default-200 rounded-xl px-4 text-sm font-bold text-default-700 focus:outline-none focus:border-primary transition-all" 
                          placeholder="e.g. Travel Allowance" 
                        />
                      </div>
                      <div className="flex-1 space-y-2">
                        <label className="text-[10px] font-black text-default-500 uppercase tracking-widest px-1">Amount</label>
                        <div className="flex gap-2">
                          <input 
                            type="text" 
                            value={allowance.amount}
                            onChange={(e) => updateExtraAllowance(index, 'amount', e.target.value)}
                            className="h-11 w-full bg-white border border-default-200 rounded-xl px-4 text-sm font-bold text-default-700 focus:outline-none focus:border-primary transition-all" 
                            placeholder="0.00" 
                          />
                          <button 
                            type="button"
                            onClick={() => removeExtraAllowance(index)}
                            className="size-10 flex items-center justify-center rounded-xl bg-danger/10 text-danger hover:bg-danger hover:text-white transition-all active:scale-90"
                            title="Remove"
                          >
                            <LuTrash2 className="size-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="flex justify-end items-center gap-3 p-6 border-t border-default-100 bg-white/80 sticky bottom-0 z-20 backdrop-blur-md">
            <button 
              type="button"
              onClick={onClose}
              className="h-10 px-6 text-[10px] font-black text-default-500 uppercase tracking-widest hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="h-10 px-8 text-[10px] font-black text-white bg-primary hover:bg-primary-600 rounded-xl transition-all flex items-center gap-2 active:scale-95"
            >
              Update Structure
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditGradeSalary;