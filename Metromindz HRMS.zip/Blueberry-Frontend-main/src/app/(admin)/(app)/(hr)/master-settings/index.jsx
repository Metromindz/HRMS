import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import { LuTreePalm, LuNetwork, LuShieldCheck, LuGraduationCap, LuSettings } from 'react-icons/lu';

// Import Tab Components
import HolidaysTab from './components/HolidaysTab';
import DepartmentsTab from './components/DepartmentsTab';
import DesignationsTab from './components/DesignationsTab';
import Payrolls from '../payroll-setting/components/Payrolls';
import LeaveSettings from '../leave-setting/components/LeaveSettings';

const MasterSettings = () => {
  const { hasPermission } = useAuth();
  
  // Permission checks for tabs
  const canViewHolidays = hasPermission('holiday.view');
  const canViewDepartments = hasPermission('department.view');
  const canViewDesignations = hasPermission('designation.view');
  const canViewGrade = hasPermission('grade.view');
  const canViewCommonSettings = hasPermission('leave.view') || hasPermission('commonleave.view') || hasPermission('shift.view');

  const tabs = useMemo(() => {
    const availableTabs = [];
    if (canViewHolidays) availableTabs.push({ id: 'holidays', label: 'Holidays', icon: LuTreePalm });
    if (canViewDepartments) availableTabs.push({ id: 'departments', label: 'Departments', icon: LuNetwork });
    if (canViewDesignations) availableTabs.push({ id: 'designations', label: 'Designations', icon: LuShieldCheck });
    if (canViewGrade) availableTabs.push({ id: 'grade', label: 'Grade', icon: LuGraduationCap });
    if (canViewCommonSettings) availableTabs.push({ id: 'common-settings', label: 'Common Settings', icon: LuSettings });
    return availableTabs;
  }, [canViewHolidays, canViewDepartments, canViewDesignations, canViewGrade, canViewCommonSettings]);

  const [activeTab, setActiveTab] = useState('');

  useEffect(() => {
    if (tabs.length > 0 && !activeTab) {
      setActiveTab(tabs[0].id);
    }
  }, [tabs, activeTab]);

  const renderTabContent = () => {
    switch (activeTab) {
      case 'holidays':
        return <HolidaysTab />;
      case 'departments':
        return <DepartmentsTab />;
      case 'designations':
        return <DesignationsTab />;
      case 'grade':
        return <Payrolls />;
      case 'common-settings':
        return <LeaveSettings />;
      default:
        return null;
    }
  };

  if (tabs.length === 0) {
    return (
      <div className="p-4">
        <p className="text-red-500">You do not have permission to view any master settings.</p>
      </div>
    );
  }

  return (
    <>
      <PageMeta title="Master Settings" />
      <main>
        <PageBreadcrumb title="Master Settings" subtitle="HR" />
        
        <div className="flex flex-col gap-6">
          {/* Tab Navigation */}
          <div className="flex flex-wrap gap-2 border-b border-default-200 dark:border-default-100">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-all relative ${
                    activeTab === tab.id
                      ? 'text-primary'
                      : 'text-default-500 hover:text-default-700 dark:hover:text-default-300'
                  }`}
                >
                  <Icon size={18} />
                  {tab.label}
                  {activeTab === tab.id && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary rounded-t-full" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Tab Content */}
          <div className="min-h-[400px]">
            {renderTabContent()}
          </div>
        </div>
      </main>
    </>
  );
};

export default MasterSettings;
