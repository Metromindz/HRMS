import { useEffect, useState } from 'react';
import Flatpickr from 'react-flatpickr';
import { LuArrowBigLeft, LuPlus } from 'react-icons/lu';
import { Link, useNavigate } from 'react-router';
import api from '../../../../../../config/api.js';
import { useAuth } from '../../../../../../context/AuthContext.jsx';

const CreateLeave = () => {
  const { user, hasPermission } = useAuth();
  const [employees, setEmployees] = useState([]);
  const [leaveTypes, setLeaveTypes] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [employeeIdInput, setEmployeeIdInput] = useState('');
  const [leaveBalance, setLeaveBalance] = useState(null);
  const [formData, setFormData] = useState({
    leaveId: '',
    fromDate: '',
    toDate: '',
    numberOfDays: 0,
    reason: ''
  });
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const isSelfService = user && user.role !== 'superadmin' && !hasPermission('employee.view');

  const fetchEmployees = async () => {
    if (isSelfService) {
      if (user) {
        setEmployees([user]);
        setSelectedEmployee(user._id);
        setEmployeeIdInput(user.employeeId);
      }
      return;
    }
    try {
      const response = await api.get('/hr/employees');
      if (response.status === 200) {
        setEmployees(response.data.employees || []);
      }
    } catch (error) {
      console.error('Error fetching employees:', error);
    }
  };

  const fetchLeaveTypes = async () => {
    try {
      const response = await api.get('/leaves');
      if (response.status === 200) {
        setLeaveTypes(response.data || []);
      }
    } catch (error) {
      console.error('Error fetching leave types:', error);
    }
  };

  const fetchLeaveBalance = async employeeId => {
    try {
      const response = await api.get(`/leave-balance/${employeeId}`);
      if (response.status === 200) {
        setLeaveBalance(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching leave balance:', error);
    }
  };

  const calculateDays = (fromDate, toDate) => {
    if (fromDate && toDate) {
      const start = new Date(fromDate);
      const end = new Date(toDate);
      const diffTime = Math.abs(end - start);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
      setFormData(prev => ({ ...prev, numberOfDays: diffDays }));
    }
  };

  const handleEmployeeChange = (e) => {
    const selectedId = e.target.value;
    setSelectedEmployee(selectedId);
    const employee = employees.find(emp => emp._id === selectedId);
    if (employee) {
      setEmployeeIdInput(employee.employeeId);
    } else {
      setEmployeeIdInput('');
    }
  };

  const handleEmployeeIdChange = (e) => {
    const id = e.target.value;
    setEmployeeIdInput(id);
    const employee = employees.find(emp => emp.employeeId === id);
    if (employee) {
      setSelectedEmployee(employee._id);
    } else {
      setSelectedEmployee('');
    }
  };

  const handleSubmit = async () => {
    if (!selectedEmployee || !formData.leaveId || !formData.fromDate || !formData.toDate || !formData.reason) {
      setMessage('Please fill all required fields');
      return;
    }

    const employee = employees.find(emp => emp._id === selectedEmployee);
    if (!employee) return;

    setLoading(true);
    setMessage('');

    try {
      const response = await api.post('/leave-requests', {
        empId: employee.employeeId,
        employeeName: employee.name,
        leaveId: formData.leaveId,
        fromDate: formData.fromDate,
        toDate: formData.toDate,
        reason: formData.reason
      });

      if (response.status === 200 || response.status === 201) {
        setMessage('Leave request submitted successfully and is pending approval.');
        setFormData({ leaveId: '', fromDate: '', toDate: '', numberOfDays: 0, reason: '' });
        setSelectedEmployee('');
        setEmployeeIdInput('');
        setLeaveBalance(null);
        setTimeout(() => {
          navigate('/leave');
        }, 3000);
      }
    } catch (error) {
      console.error('Error submitting leave request:', error);
      setMessage(error.response?.data?.error || 'Error submitting leave request');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
    fetchLeaveTypes();
  }, [user]);

  useEffect(() => {
    if (selectedEmployee) {
      const employee = employees.find(emp => emp._id === selectedEmployee);
      if (employee) {
        fetchLeaveBalance(employee.employeeId);
      }
    }
  }, [selectedEmployee, employees]);

  return (
    <div className="grid lg:grid-cols-4 grid-cols-1 gap-6">
      <div className="lg:col-span-3 col-span-1">
        <div className="bg-white border border-default-200  rounded-xl overflow-hidden  ">
          <div className="px-8 py-6 border-b border-default-200 bg-white flex items-center justify-between">
            <div className="flex flex-col">
              <h4 className="text-xl font-black text-default-900 uppercase tracking-tight">
                Add Leave
              </h4>
              <p className="text-[10px] font-black text-default-400 uppercase tracking-widest mt-1">
                {isSelfService ? "Apply Leave" : "Apply leave on behalf of employees"}
              </p>
            </div>
            <Link
              to="/leave"
              className="size-11 flex items-center justify-center  rounded-xl bg-default-50 text-default-600 hover:bg-primary hover:text-white transition-all border border-default-200 hover:border-primary active:scale-95"
            >
              <LuArrowBigLeft className="size-6" />
            </Link>
          </div>

          <div className="p-8">
            <div className="grid md:grid-cols-2 grid-cols-1 gap-6 mb-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  Employee *
                </label>
                <select
                  className={`w-full border-default-200  rounded-xl px-5 py-3.5 text-sm font-bold text-default-900 focus:border-primary transition-all border-2 focus:ring-0 appearance-none cursor-pointer ${isSelfService ? 'bg-default-50 cursor-not-allowed' : 'bg-white'}`}
                  value={selectedEmployee}
                  onChange={handleEmployeeChange}
                  disabled={isSelfService}
                >
                  <option disabled value="">
                    Select Employee
                  </option>
                  {employees.map(employee => (
                    <option key={employee._id} value={employee._id}>
                      {employee.name} ({employee.employeeId})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  Employee ID *
                </label>
                <input
                  type="text"
                  className={`w-full border-default-200  rounded-xl px-5 py-3.5 text-sm font-bold text-default-600 border-2 focus:ring-0 ${isSelfService ? 'bg-default-50 cursor-not-allowed' : 'bg-white'}`}
                  value={employeeIdInput}
                  onChange={handleEmployeeIdChange}
                  placeholder="Enter Employee ID"
                  disabled={isSelfService}
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  Leave Type *
                </label>
                <select
                  className="w-full bg-white border-default-200  rounded-xl px-5 py-3.5 text-sm font-bold text-default-900 focus:border-primary transition-all border-2 focus:ring-0 appearance-none cursor-pointer"
                  value={formData.leaveId}
                  onChange={e => setFormData({ ...formData, leaveId: e.target.value })}
                >
                  <option disabled value="">
                    Select Leave Type
                  </option>
                  {leaveTypes.map(leave => (
                    <option key={leave._id} value={leave._id}>
                      {leave.leaveName}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  Number of Days
                </label>
                <input
                  type="number"
                  className="w-full bg-default-50 border-default-200  rounded-xl px-5 py-3.5 text-sm font-bold text-default-600 cursor-not-allowed border-2 focus:ring-0"
                  value={formData.numberOfDays}
                  readOnly
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  From *
                </label>
                <div className="relative group">
                  <Flatpickr
                    className="w-full bg-white border-default-200  rounded-xl px-5 py-3.5 text-sm font-bold text-default-900 focus:border-primary transition-all border-2 focus:ring-0 group-hover:border-default-300"
                    placeholder="DD-MM-YYYY"
                    options={{
                      dateFormat: 'Y-m-d',
                      minDate: 'today'
                    }}
                    value={formData.fromDate}
                    onChange={([date]) => {
                      const formattedDate = date?.toISOString().split('T')[0];
                      if (!formattedDate) return;
                      setFormData(prev => ({ ...prev, fromDate: formattedDate }));
                      calculateDays(formattedDate, formData.toDate);
                    }}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                  To *
                </label>
                <div className="relative group">
                  <Flatpickr
                    className="w-full bg-white border-default-200  rounded-xl px-5 py-3.5 text-sm font-bold text-default-900 focus:border-primary transition-all border-2 focus:ring-0 group-hover:border-default-300"
                    placeholder="DD-MM-YYYY"
                    options={{
                      dateFormat: 'Y-m-d',
                      minDate: formData.fromDate || 'today'
                    }}
                    value={formData.toDate}
                    onChange={([date]) => {
                      const formattedDate = date?.toISOString().split('T')[0];
                      if (!formattedDate) return;
                      setFormData(prev => ({ ...prev, toDate: formattedDate }));
                      calculateDays(formData.fromDate, formattedDate);
                    }}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2 mb-8">
              <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ps-1">
                Reason *
              </label>
              <textarea
                className="w-full bg-white border-default-200  rounded-xl px-5 py-4 text-sm font-bold text-default-900 focus:border-primary transition-all border-2 focus:ring-0 min-h-[120px] resize-none"
                rows="3"
                placeholder="Enter detailed reason here..."
                value={formData.reason}
                onChange={e => setFormData({ ...formData, reason: e.target.value })}
              ></textarea>
            </div>

            {message && (
              <div
                className={`mb-6 p-5  rounded-xl flex items-center gap-4 border ${
                  message.toLowerCase().includes('success')
                    ? 'bg-success/5 border-success/20 text-success'
                    : 'bg-danger/5 border-danger/20 text-danger'
                }`}
              >
                <div
                  className={`size-10 rounded-xl flex items-center justify-center shrink-0 ${
                    message.toLowerCase().includes('success') ? 'bg-success/10' : 'bg-danger/10'
                  }`}
                >
                  {message.toLowerCase().includes('success') ? (
                    <LuPlus className="size-5" />
                  ) : (
                    <LuPlus className="size-5 rotate-45" />
                  )}
                </div>
                <p className="text-sm font-bold tracking-tight">{message}</p>
              </div>
            )}

            <div className="flex justify-end gap-4">
              <button
                type="button"
                onClick={() => navigate('/leave')}
                className="h-12 px-8  rounded-xl border-2 border-default-200 text-[10px] font-black uppercase tracking-widest text-default-600 hover:bg-default-50 transition-all active:scale-95"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSubmit}
                disabled={loading}
                className="h-12 px-10  rounded-xl bg-primary text-white text-[10px] font-black uppercase tracking-widest hover:bg-primary-600 shadow-lg shadow-primary/25 transition-all disabled:opacity-50 active:scale-95 flex items-center gap-2"
              >
                {loading ? (
                  <div className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <LuPlus className="size-4" />
                )}
                {loading ? 'Processing...' : 'Apply & Process'}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="lg:col-span-1 col-span-1 space-y-6">
        <div className="bg-white border border-default-200  rounded-xl overflow-hidden  ">
          <div className="px-8 py-6 border-b border-default-200 bg-white">
            <h4 className="text-sm font-black text-default-900 uppercase tracking-widest">
              Leave Information (2025)
            </h4>
          </div>
          <div className="p-8 space-y-4">
            {leaveBalance?.leaveBalances?.length ? (
              leaveBalance.leaveBalances
                .filter(balance => balance.leaveName?.toLowerCase() !== 'work from home')
                .map(balance => (
                  <div
                    key={balance._id}
                    className="group p-5  rounded-xl bg-default-50 border border-default-200 hover:border-primary/30 transition-all"
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">
                        {balance.leaveName}
                      </span>
                      <span className="text-sm font-black text-primary">
                        {balance.yearlyRemaining}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-default-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full transition-all duration-1000"
                        style={{
                          width: `${
                            (balance.yearlyRemaining /
                              (balance.yearlyRemaining + balance.yearlyRemaining * 0.5 || 1)) *
                            100
                          }%`
                        }}
                      />
                    </div>
                    <div className="mt-2 flex justify-between text-[9px] font-bold text-default-400 uppercase tracking-widest">
                      <span>Available</span>
                      <span>Days</span>
                    </div>
                  </div>
                ))
            ) : (
              <div className="py-12 text-center opacity-40">
                <LuPlus className="size-8 mx-auto mb-3 text-default-300" />
                <p className="text-[10px] font-black text-default-400 uppercase tracking-widest">
                  {selectedEmployee ? 'No balance data' : 'Select an employee'}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default CreateLeave;
