import { LuUser, LuCalendar, LuClock, LuTrendingUp } from "react-icons/lu";

const PunchDetails = ({ employee, summary, month, year, onMonthYearChange }) => {
  // Handler for month change
  const handleMonthChange = (e) => {
    const newMonth = e.target.value;
    if (onMonthYearChange) {
      onMonthYearChange(newMonth, year);
    }
  };

  // Handler for year change
  const handleYearChange = (e) => {
    const newYear = e.target.value;
    if (onMonthYearChange) {
      onMonthYearChange(month, newYear);
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5">
        {/* Employee Info Card */}
        <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
              <LuUser className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Employee ID</div>
              <div className="text-xl font-black text-default-900 leading-none">{employee?.employeeId || 'N/A'}</div>
            </div>
          </div>
        </div>

        {/* Total Hours Card */}
        <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-success/10 flex items-center justify-center text-success group-hover:scale-110 transition-transform duration-300">
              <LuClock className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Hours Worked</div>
              <div className="text-xl font-black text-default-900 leading-none">{summary?.totalWorkingHours || 0} <span className="text-sm font-bold text-default-400 uppercase">Hrs</span></div>
            </div>
          </div>
        </div>

        {/* Overtime Card */}
        <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-warning/10 flex items-center justify-center text-warning group-hover:scale-110 transition-transform duration-300">
              <LuTrendingUp className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Overtime</div>
              <div className="text-xl font-black text-default-900 leading-none">{summary?.totalOvertimeHours || 0} <span className="text-sm font-bold text-default-400 uppercase">Hrs</span></div>
            </div>
          </div>
        </div>

        {/* Joining Date Card */}
        <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
          <div className="flex items-center gap-4">
            <div className="size-12 rounded-xl bg-info/10 flex items-center justify-center text-info group-hover:scale-110 transition-transform duration-300">
              <LuCalendar className="size-6" />
            </div>
            <div>
              <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Joining Date</div>
              <div className="text-sm font-bold text-default-900 leading-none">
                {employee?.employmentDetails?.dateOfJoining
                  ? new Date(employee.employmentDetails.dateOfJoining).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
                  : "N/A"}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="card">
        <div className="p-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-col">
              <h4 className="text-base font-bold text-default-900">Attendance Period</h4>
              <p className="text-[10px] font-black text-default-400 uppercase tracking-[0.3em]">Select month and year to view records</p>
            </div>
            
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-default-500 uppercase tracking-wider">Month:</span>
                <select
                  className="form-input rounded-xl h-11 border-default-200 focus:border-primary focus:ring-primary/20 min-w-[140px]"
                  value={month || ""}
                  onChange={handleMonthChange}
                >
                  <option value="1">January</option>
                  <option value="2">February</option>
                  <option value="3">March</option>
                  <option value="4">April</option>
                  <option value="5">May</option>
                  <option value="6">June</option>
                  <option value="7">July</option>
                  <option value="8">August</option>
                  <option value="9">September</option>
                  <option value="10">October</option>
                  <option value="11">November</option>
                  <option value="12">December</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-default-500 uppercase tracking-wider">Year:</span>
                <select
                  className="form-input rounded-xl h-11 border-default-200 focus:border-primary focus:ring-primary/20 min-w-[120px]"
                  value={year || ""}
                  onChange={handleYearChange}
                >
                  <option value="2025">2025</option>
                  <option value="2026">2026</option>
                  <option value="2027">2027</option>
                  <option value="2028">2028</option>
                  <option value="2029">2029</option>
                  <option value="2030">2030</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PunchDetails;