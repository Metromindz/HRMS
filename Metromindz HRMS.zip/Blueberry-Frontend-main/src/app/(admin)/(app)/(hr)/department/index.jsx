import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '@/context/AuthContext';
import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import AddDepartment from './components/AddDepartment';
import DeleteModal from './components/DeleteModal';
import Departments from './components/Departments';
import EditDepartment from './components/EditDepartment';
import api from '../../../../../config/api';
import { LuBuilding2, LuCircleCheck, LuUsers, LuUserMinus } from 'react-icons/lu';

const Index = () => {
  const { hasPermission } = useAuth();
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDepartment, setSelectedDepartment] = useState(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  // 🔹 Pagination State
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 1
  });

  // Permission checks
  const canCreate = hasPermission('department.create');
  const canEdit = hasPermission('department.edit');
  const canDelete = hasPermission('department.delete');




  // Clear message after 3 seconds
  useEffect(() => {
    if (message.text) {
      const timer = setTimeout(() => setMessage({ type: '', text: '' }), 3000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  // Fetch departments on component mount
  useEffect(() => {
    fetchDepartments(pagination.page);
  }, [pagination.page]);

  const fetchDepartments = async (page = pagination.page) => {
    try {
      setLoading(true);
      const response = await api.get(`/department?page=${page}&limit=${pagination.limit}`);
      const data = response.data;

      setDepartments(data.departments || []);
      setPagination((prev) => ({
        ...prev,
        total: data.pagination?.total || 0,
        totalPages: data.pagination?.totalPages || 1,
        page: data.pagination?.page || page
      }));
    } catch (error) {
      console.error('Failed to fetch departments:', error);
      setMessage({ type: 'error', text: 'Failed to fetch departments' });
    } finally {
      setLoading(false);
    }
  };

  const handleAddDepartment = async departmentData => {
    try {
      const response = await api.post('/department/create', departmentData);

      if (response.status === 200 || response.status === 201) {
        await fetchDepartments(1);
        setIsAddModalOpen(false);
        setMessage({ type: 'success', text: 'Department added successfully!' });
      }
    } catch (error) {
      console.error('Failed to add department:', error);
      setMessage({ type: 'error', text: 'Failed to add department' });
    }
  };

  const handleEditDepartment = async departmentData => {
    try {

      const response = await api.put(`/department/edit/${departmentData.id}`, departmentData);

      if (response.status === 200) {
        await fetchDepartments(pagination.page);
        setIsEditModalOpen(false);
        setSelectedDepartment(null);
        setMessage({ type: 'success', text: 'Department updated successfully!' });
      }
    } catch (error) {
      console.error('Failed to edit department:', error);
      setMessage({ type: 'error', text: 'Failed to update department' });
    }
  };

  const handleDeleteDepartment = async id => {
    try {

      const response = await api.delete(`/department/${id}`);

      if (response.status === 200) {
        await fetchDepartments(pagination.page);
        setIsDeleteModalOpen(false);
        setSelectedDepartment(null);
        setMessage({ type: 'success', text: 'Department deleted successfully!' });
      }
    } catch (error) {
      console.error('Failed to delete department:', error);
      setMessage({ type: 'error', text: 'Failed to delete department' });
    }
  };

  // 🔹 Pagination change handler
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= pagination.totalPages) {
      setPagination((prev) => ({ ...prev, page: newPage }));
    }
  };

  const stats = useMemo(() => {
    const total = pagination.total || 0;
    const active = departments.filter(d => d.status === 'Active').length;
    const totalEmployees = departments.reduce((acc, d) => acc + (d.userCount || 0), 0);
    const emptyDepartments = departments.filter(d => (d.userCount || 0) === 0).length;
    return { total, active, totalEmployees, emptyDepartments };
  }, [departments, pagination.total]);

  return (
    <>
      <PageMeta title="Departments" />
      <main>
        <PageBreadcrumb title="Departments List" subtitle="Menu" />

        <div className="grid md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-5 mb-6">
          <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-300">
                <LuBuilding2 className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Total Departments</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.total}</div>
              </div>
            </div>
          </div>

          <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-success/10 flex items-center justify-center text-success group-hover:scale-110 transition-transform duration-300">
                <LuCircleCheck className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Active</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.active}</div>
              </div>
            </div>
          </div>

          <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-warning/10 flex items-center justify-center text-warning group-hover:scale-110 transition-transform duration-300">
                <LuUsers className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Total Employees</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.totalEmployees}</div>
              </div>
            </div>
          </div>

          <div className="group bg-white rounded-xl p-5 border border-default-200 transition-all duration-300">
            <div className="flex items-center gap-4">
              <div className="size-12 rounded-xl bg-danger/10 flex items-center justify-center text-danger group-hover:scale-110 transition-transform duration-300">
                <LuUserMinus className="size-6" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-default-400 uppercase tracking-widest mb-0.5">Empty Depts</div>
                <div className="text-2xl font-black text-default-900 leading-none">{stats.emptyDepartments}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Success/Error Messages */}
        {message.text && (
          <div className={`mb-4 p-4 rounded-md ${message.type === 'success'
              ? 'bg-green-100 border border-green-400 text-green-700'
              : 'bg-red-100 border border-red-400 text-red-700'
            }`}>
            {message.text}
          </div>
        )}

        <Departments
          departments={departments}
          loading={loading}
          canCreate={canCreate}
          canEdit={canEdit}
          canDelete={canDelete}
          onAdd={() => setIsAddModalOpen(true)}
          onEdit={department => {

            setSelectedDepartment(department);
            setIsEditModalOpen(true);
          }}
          onDelete={department => {

            setSelectedDepartment(department);
            setIsDeleteModalOpen(true);

          }}
          pagination={pagination}
          onPageChange={handlePageChange}
        />
      </main>

      {canCreate && (
        <AddDepartment
          isOpen={isAddModalOpen}
          onClose={() => setIsAddModalOpen(false)}
          onSave={handleAddDepartment}
        />
      )}

      {canEdit && (
        <EditDepartment
          isOpen={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            setSelectedDepartment(null);
          }}
          onSave={handleEditDepartment}
          department={selectedDepartment}
        />
      )}

      {canDelete && (
        <DeleteModal
          isOpen={isDeleteModalOpen}
          onClose={() => {
            setIsDeleteModalOpen(false);
            setSelectedDepartment(null);
          }}
          onConfirm={() => selectedDepartment && handleDeleteDepartment(selectedDepartment._id)}
          department={selectedDepartment}
        />
      )}
    </>
  );
};

export default Index;