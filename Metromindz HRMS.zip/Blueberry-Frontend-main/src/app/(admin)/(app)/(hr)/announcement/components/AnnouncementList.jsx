import { LuCalendar, LuTag, LuUser, LuArrowRight, LuMegaphone } from 'react-icons/lu';
import { format } from 'date-fns';

/**
 * AnnouncementList Component
 * 
 * Displays a grid of announcement cards.
 * 
 * Features:
 * - Empty State: Shows a placeholder if no announcements are found.
 * - Card View: Displays title, priority badge, category, date, and truncated description.
 * - Visual Indicators: Color-coded priority badges (Red=High, Yellow=Medium, Green=Low).
 * 
 * @param {Array} announcements - List of announcement objects to display
 * @param {Boolean} loading - Loading state
 * @param {Function} onView - Callback when "Read More" is clicked
 */
const AnnouncementList = ({ announcements, loading, onView }) => {
  if (loading) {
    return (
      <div className="flex justify-center items-center p-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!announcements || announcements.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center bg-default-50 rounded-2xl border-2 border-dashed border-default-200">
        <div className="size-16 rounded-2xl bg-default-100 flex items-center justify-center text-default-400 mb-4">
          <LuMegaphone className="size-8" />
        </div>
        <h3 className="text-lg font-bold text-default-700">No Announcements Yet</h3>
        <p className="text-default-500 text-sm mt-1">Stay tuned for important updates and news.</p>
      </div>
    );
  }

  // Helper to determine badge color based on priority
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'High': return 'bg-danger/10 text-danger border-danger/20';
      case 'Medium': return 'bg-warning/10 text-warning border-warning/20';
      case 'Low': return 'bg-success/10 text-success border-success/20';
      default: return 'bg-default-100 text-default-600 border-default-200';
    }
  };

  const getCategoryIcon = () => {
    return <LuTag className="size-3.5" />;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
      {announcements.map((announcement) => (
        <div
          key={announcement._id}
          className="group relative bg-white rounded-3xl border border-default-200 hover:border-primary/30 hover:shadow-2xl hover:shadow-primary/10 transition-all duration-300 overflow-hidden flex flex-col mt-2"
        >
          {/* Top highlight bar */}
          <div className={`absolute top-0 left-0 right-0 h-1.5 transition-colors duration-300 ${announcement.priority === 'High' ? 'bg-danger' :
            announcement.priority === 'Medium' ? 'bg-warning' : 'bg-success'
            }`}></div>

          {/* Card Header */}
          <div className="p-6 pb-4">
            <div className="flex justify-between items-start gap-4 mb-4">
              <div className="flex gap-2.5">
                <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border ${getPriorityColor(announcement.priority)}`}>
                  {announcement.priority}
                </span>
                <span className="px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest bg-default-100 text-default-600 border border-default-200 flex items-center gap-1.5">
                  {getCategoryIcon()}
                  {announcement.category}
                </span>
              </div>
              <div className="size-10 rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/10 flex items-center justify-center text-primary shrink-0 group-hover:scale-110 group-hover:bg-primary group-hover:text-white transition-all duration-300  ">
                <LuMegaphone className="size-5" />
              </div>
            </div>

            <h4 className="text-xl font-black text-default-900 line-clamp-2 leading-snug group-hover:text-primary transition-colors duration-300">
              {announcement.title}
            </h4>
          </div>

          {/* Card Body */}
          <div className="px-6 flex-grow">
            <div
              className="text-sm font-medium text-default-500 line-clamp-3 leading-relaxed mb-6"
              dangerouslySetInnerHTML={{ __html: announcement.description }}
            />
          </div>

          {/* Card Meta & Footer overlay */}
          <div className="mt-auto px-6 py-5 bg-gradient-to-t from-default-50/80 to-transparent border-t border-default-100 flex items-center justify-between">
            <div className="flex flex-col gap-1.5 text-[11px] font-bold text-default-400 uppercase tracking-widest">
              <div className="flex items-center gap-1.5">
                <LuCalendar className="size-3.5 text-primary/70" />
                <span>{format(new Date(announcement.publishDate), 'MMM dd, yyyy')}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <LuUser className="size-3.5 text-primary/70" />
                <span>{announcement.createdBy?.name || 'Admin'}</span>
              </div>
            </div>

            <button
              onClick={() => onView(announcement)}
              className="size-10 flex items-center justify-center rounded-2xl bg-white border border-default-200 text-default-400 group-hover:bg-primary group-hover:text-white group-hover:border-primary transition-all duration-300   hover:scale-105 active:scale-95"
              title="Read More"
            >
              <LuArrowRight className="size-4" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default AnnouncementList;
