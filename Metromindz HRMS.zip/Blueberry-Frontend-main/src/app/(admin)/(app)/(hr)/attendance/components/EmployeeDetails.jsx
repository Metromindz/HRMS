const EmployeeDetails = ({ employee, summary, month, year, onMonthYearChange }) => {

  // Handler for month change
  const handleMonthChange = (e) => {
    const newMonth = e.target.value;
    if (onMonthYearChange) {
      onMonthYearChange(newMonth, year);
    }
  };

  // Handler for year change
  const handleYearChange = (e) => {
    const newYear = e.target.value;
    if (onMonthYearChange) {
      onMonthYearChange(month, newYear);
    }
  };

  return (
    <div className="bg-white border border-default-200 rounded-2xl overflow-hidden p-6">
      <div className="flex flex-wrap items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="size-14 rounded-xl bg-primary/10 text-primary flex items-center justify-center text-xl font-black">
            {employee?.name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || 'EM'}
          </div>
          <div>
            <h4 className="text-lg font-black text-default-900 leading-none mb-1">{employee?.name}</h4>
            <p className="text-[10px] font-black text-default-500 uppercase tracking-widest">Employee Profile</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-x-8 gap-y-4">
          <div className="flex flex-col">
            <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Employee ID</span>
            <span className="text-sm font-bold text-default-900">{employee?.employeeId}</span>
          </div>

          <div className="flex flex-col">
            <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Joining Date</span>
            <span className="text-sm font-bold text-default-900">
              {employee?.employmentDetails?.dateOfJoining
                ? new Date(employee.employmentDetails.dateOfJoining).toLocaleDateString('en-GB')
                : "N/A"}
            </span>
          </div>

          <div className="flex flex-col">
            <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Total Hours</span>
            <span className="text-sm font-bold text-default-900">{summary?.totalWorkingHours || 0} Hrs</span>
          </div>

          <div className="flex flex-col">
            <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1">Overtime</span>
            <span className="text-sm font-bold text-default-900">{summary?.totalOvertimeHours || 0} Hrs</span>
          </div>

          <div className="flex items-center bg-default-50 border border-default-200 rounded-xl p-1">
            <select
              className="bg-transparent border-none h-9 text-xs font-bold uppercase tracking-widest focus:ring-0 px-3 cursor-pointer"
              value={month || ""}
              onChange={handleMonthChange}
            >
              <option value="1">January</option>
              <option value="2">February</option>
              <option value="3">March</option>
              <option value="4">April</option>
              <option value="5">May</option>
              <option value="6">June</option>
              <option value="7">July</option>
              <option value="8">August</option>
              <option value="9">September</option>
              <option value="10">October</option>
              <option value="11">November</option>
              <option value="12">December</option>
            </select>
            <div className="w-px h-4 bg-default-200 mx-1" />
            <select
              className="bg-transparent border-none h-9 text-xs font-bold uppercase tracking-widest focus:ring-0 px-3 cursor-pointer"
              value={year || ""}
              onChange={handleYearChange}
            >
              <option value="2025">2025</option>
              <option value="2026">2026</option>
              <option value="2027">2027</option>
              <option value="2028">2028</option>
              <option value="2029">2029</option>
              <option value="2030">2030</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeDetails;
