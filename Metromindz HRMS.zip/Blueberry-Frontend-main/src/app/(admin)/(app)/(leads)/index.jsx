import { useEffect, useMemo, useState } from 'react';
import PageMeta from '@/components/PageMeta';
import PageBreadcrumb from '@/components/PageBreadcrumb';
import api from '@/config/api';
import { useAuth } from '@/context/AuthContext';
import { LuDownload, LuPencil, LuPlus, LuSearch, LuTrash2, LuEye, LuList, LuLayoutGrid, LuUpload, LuUserCheck, LuFileSpreadsheet, LuUserPlus, LuTarget, LuTrophy, LuX } from 'react-icons/lu';
import { toast } from 'react-hot-toast';

const debounce = (fn, delay = 400) => {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), delay);
  };
};

const statuses = [
  { value: 'new', label: 'New' },
  { value: 'contacted', label: 'Contacted' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'qualified', label: 'Qualified' },
  { value: 'proposal_sent', label: 'Proposal Sent' },
  { value: 'negotiation', label: 'Negotiation' },
  { value: 'won', label: 'Won' },
  { value: 'lost', label: 'Lost' },
  { value: 'on_hold', label: 'On Hold' },
];

const projectTypes = ['Digital Marketing', 'Web Application', 'Design', 'Mobile App', 'SEO'];
const leadSources = ['Website', 'Referral', 'LinkedIn', 'Instagram', 'Facebook', 'WhatsApp', 'Cold Call', 'Other'];

const statusPillClass = (s) => {
  const map = {
    new: 'bg-gray-200 text-gray-700',
    contacted: 'bg-blue-100 text-blue-700',
    in_progress: 'bg-blue-600 text-white',
    qualified: 'bg-emerald-100 text-emerald-700',
    proposal_sent: 'bg-indigo-100 text-indigo-700',
    negotiation: 'bg-orange-100 text-orange-700',
    won: 'bg-green-100 text-green-700',
    lost: 'bg-red-100 text-red-700',
    on_hold: 'bg-yellow-100 text-yellow-700',
  };
  return `px-2 py-1 rounded-2xl text-xs ${map[s] || 'bg-default-200 text-default-700'}`;
};

const companyPillClass = (t) => {
  const key = (t || '').toLowerCase();
  const map = {
    company: 'bg-violet-100 text-violet-700',
    individual: 'bg-slate-200 text-slate-700',
  };
  return `px-2 py-0.5 rounded-2xl text-xs ${map[key] || 'bg-default-200 text-default-700'}`;
};

const Index = () => {
  const { hasPermission } = useAuth();
  const canView = hasPermission('lead.view');
  const canCreate = hasPermission('lead.create');
  const canEdit = hasPermission('lead.edit');
  const canDelete = hasPermission('lead.delete');
  const canAssign = hasPermission('lead.assign');
  const canImport = hasPermission('lead.import');
  const canExport = hasPermission('lead.export');

  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [assignedTo, setAssignedTo] = useState('');
  const [followUpFilter, setFollowUpFilter] = useState('');
  const [loading, setLoading] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editItem, setEditItem] = useState(null);
  const [developers, setDevelopers] = useState([]);
  const [viewMode, setViewMode] = useState('list');
  const [viewOpen, setViewOpen] = useState(false);
  const [selectedLead, setSelectedLead] = useState(null);
  const [selectedIds, setSelectedIds] = useState([]);
  const [assignOpen, setAssignOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [statusMenuOpen, setStatusMenuOpen] = useState(null);
  const [followUpModalOpen, setFollowUpModalOpen] = useState(false);
  const [pendingStatus, setPendingStatus] = useState(null);
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [dateFilterType, setDateFilterType] = useState('createdAt');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [leadFormErrors, setLeadFormErrors] = useState({});
  const [leadFormSubmitError, setLeadFormSubmitError] = useState('');

  const debouncedSearch = useMemo(
    () =>
      debounce((val) => {
        setPage(1);
        fetchLeads({ search: val });
      }, 500),
    [page, limit, status, assignedTo, followUpFilter, startDate, endDate, dateFilterType]
  );

  const fetchLeads = async (params = {}) => {
    setLoading(true);
    try {
      const resp = await api.get('/leads', {
        params: { page, limit, search, status, assignedTo, followUpFilter, dateFilterType, startDate, endDate, ...params },
      });
      if (resp.data.success) {
        setItems(resp.data.items);
        setTotal(resp.data.total);
      }
    } finally {
      setLoading(false);
    }
  };

  const loadDevelopers = async () => {
    const resp = await api.get('/hr/employees', { params: { page: 1, limit: 200 } });
    setDevelopers(resp.data.employees || []);
  };

  useEffect(() => {
    if (canView) fetchLeads();
  }, [page, limit, status, assignedTo, followUpFilter, startDate, endDate, dateFilterType, canView]);

  useEffect(() => {
    loadDevelopers();
  }, []);

  const exportData = async (format) => {
    const resp = await api.get('/leads/export', {
      params: { format, search, status, assignedTo },
      responseType: 'blob',
    });
    const url = URL.createObjectURL(resp.data);
    const a = document.createElement('a');
    a.href = url;
    a.download = format === 'xlsx' ? 'leads.xlsx' : 'leads.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleUpdateStatus = async (id, newStatus) => {
    // If opening details modal, we want to set pending status and open follow-up modal
    if (viewOpen && selectedLead && selectedLead._id === id) {
        setPendingStatus(newStatus);
        setFollowUpModalOpen(true);
    } else {
        // Quick update from list view without modal
        try {
            const res = await api.patch(`/leads/${id}/status`, { status: newStatus });
            if (res.data.success) {
                fetchLeads();
            }
        } catch (e) {
            console.error(e);
        }
    }
  };

  const confirmStatusUpdate = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    const formData = new FormData(e.currentTarget);
    const notes = formData.get('notes');
    const nextFollowUp = formData.get('nextFollowUp');
    const subStatus = formData.get('subStatus');
    const id = selectedLead._id;

    const statusToUse = pendingStatus || selectedLead?.status;

    if (!statusToUse) {
        alert("Error: Status is missing. Please try again.");
        return;
    }

    try {
      const payload = {
        status: statusToUse,
        notes,
        nextFollowUp,
        subStatus
      };
      console.log('Submitting status update:', payload);

      const res = await api.patch(`/leads/${id}/status`, payload);
      if (res.data.success) {
         setSelectedLead(res.data.lead);
         fetchLeads();
         setFollowUpModalOpen(false);
         setPendingStatus(null);
         setIsAddingNote(false);
      }
    } catch (e) {
      console.error(e);
      alert(e.response?.data?.message || "Failed to update status");
    }
  };

  const openLeadView = (lead) => {
    setSelectedLead(lead);
    setViewOpen(true);
  };

  const clearLeadFormState = () => {
    setLeadFormErrors({});
    setLeadFormSubmitError('');
  };

  const clearFieldError = (field) => {
    setLeadFormErrors((prev) => {
      if (!prev[field]) return prev;
      const next = { ...prev };
      delete next[field];
      return next;
    });
    if (leadFormSubmitError) setLeadFormSubmitError('');
  };

  const validateLeadForm = (values) => {
    const errors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const mobileDigits = String(values.mobile || '').replace(/\D/g, '');
    const validStatus = statuses.some((s) => s.value === values.status);
    const validCompanyType = ['Company', 'Individual'].includes(values.companyType);
    const validWebsiteType = projectTypes.includes(values.websiteType);
    const validAssignee = !values.assignedTo || developers.some((d) => d._id === values.assignedTo);

    if (!values.name) {
      errors.name = 'Full name is required';
    } else if (values.name.length < 2) {
      errors.name = 'Full name must be at least 2 characters';
    } else if (values.name.length > 80) {
      errors.name = 'Full name must be 80 characters or fewer';
    }

    if (!values.mobile) {
      errors.mobile = 'Mobile number is required';
    } else if (mobileDigits.length < 10 || mobileDigits.length > 15) {
      errors.mobile = 'Enter a valid mobile number (10 to 15 digits)';
    }

    if (!values.email) {
      errors.email = 'Email address is required';
    } else if (!emailRegex.test(values.email)) {
      errors.email = 'Enter a valid email address';
    }

    if (!values.companyName) {
      errors.companyName = 'Company name is required';
    } else if (values.companyName.length > 120) {
      errors.companyName = 'Company name must be 120 characters or fewer';
    }

    if (!values.estimatedPriceRaw) {
      errors.estimatedPrice = 'Estimated price is required';
    } else if (!Number.isFinite(values.estimatedPrice) || values.estimatedPrice < 0) {
      errors.estimatedPrice = 'Estimated price must be 0 or more';
    }

    if (!values.websiteType) {
      errors.websiteType = 'Lead type is required';
    } else if (!validWebsiteType) {
      errors.websiteType = 'Select a valid lead type';
    }

    if (!values.status) {
      errors.status = 'Status is required';
    } else if (!validStatus) {
      errors.status = 'Select a valid status';
    }

    if (!values.source) {
      errors.source = 'Lead source is required';
    } else if (values.source.length > 80) {
      errors.source = 'Lead source must be 80 characters or fewer';
    }

    if (!values.companyType) {
      errors.companyType = 'Entity type is required';
    } else if (!validCompanyType) {
      errors.companyType = 'Select a valid entity type';
    }

    if (!validAssignee) {
      errors.assignedTo = 'Select a valid team member';
    }

    if (!values.message) {
      errors.message = 'Requirement details/message is required';
    } else if (values.message.length < 3) {
      errors.message = 'Requirement details must be at least 3 characters';
    } else if (values.message.length > 2000) {
      errors.message = 'Requirement details must be 2000 characters or fewer';
    }

    return errors;
  };

  const onSubmitLead = async (e) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const estimatedPriceRaw = form.get('estimatedPrice')?.toString().trim() || '';
    const payload = {
      name: form.get('name')?.trim(),
      mobile: form.get('mobile')?.trim(),
      email: form.get('email')?.trim() || '',
      websiteType: form.get('websiteType') || '',
      source: form.get('source') || '',
      status: form.get('status') || 'new',
      message: form.get('message')?.trim() || '',
      companyType: form.get('companyType') || 'Individual',
      assignedTo: form.get('assignedTo') || '',
      companyName: form.get('companyName')?.trim() || '',
      estimatedPrice: Number(estimatedPriceRaw || 0),
    };

    const errors = validateLeadForm({ ...payload, estimatedPriceRaw });
    if (Object.keys(errors).length > 0) {
      setLeadFormErrors(errors);
      toast.error('Please fix the highlighted form errors');
      return;
    }

    setLeadFormErrors({});
    setLeadFormSubmitError('');

    try {
      if (editItem) {
        await api.put(`/leads/${editItem._id}`, payload);
      } else {
        await api.post('/leads', payload);
      }
      toast.success(editItem ? 'Lead updated successfully' : 'Lead created successfully');
      setModalOpen(false);
      setEditItem(null);
      clearLeadFormState();
      fetchLeads();
    } catch (err) {
      const message = err?.response?.data?.message || 'Failed to save lead';
      setLeadFormSubmitError(message);
      toast.error(message);
    }
  };

  const confirmDelete = async (id) => {
    if (!canDelete) return;
    if (window.confirm('Delete this lead?')) {
      await api.delete(`/leads/${id}`);
      fetchLeads();
    }
  };

  const changeLeadStatus = async (id, newStatus) => {
    if (!canEdit) return;
    try {
      await api.patch(`/leads/${id}/status`, { status: newStatus });
      setItems(prev => prev.map(item => item._id === id ? { ...item, status: newStatus } : item));
    } catch (e) {
      console.error('Failed to update status', e);
    }
  };

  const toggleSelect = (id, checked) => {
    setSelectedIds((prev) => {
      const set = new Set(prev);
      if (checked) set.add(id);
      else set.delete(id);
      return Array.from(set);
    });
  };

  const bulkAssign = async (e) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const assignedToVal = form.get('assignedTo');
    if (!assignedToVal || selectedIds.length === 0) return;
    await api.post('/leads/bulk-assign', { leadIds: selectedIds, assignedTo: assignedToVal });
    setAssignOpen(false);
    setSelectedIds([]);
    fetchLeads();
  };

  const onImportLeads = async (e) => {
    e.preventDefault();
    const file = e.currentTarget.file?.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append('file', file);
    await api.post('/leads/import', form, { headers: { 'Content-Type': 'multipart/form-data' } });
    setImportOpen(false);
    fetchLeads();
  };

  const downloadTemplate = async () => {
    const resp = await api.get('/leads/template', { responseType: 'blob' });
    const url = URL.createObjectURL(resp.data);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'leads_template.xlsx';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!canView) {
    return (
      <>
        <PageMeta title="Leads" />
        <main>
          <PageBreadcrumb title="Leads" subtitle="Leads Management" />
          <div className="card">
            <div className="card-body">
              <p className="text-default-500">You do not have permission to view this page.</p>
            </div>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <PageMeta title="Leads" />
      <main>
        <PageBreadcrumb title="Leads" subtitle="Leads Management" />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            { label: 'Total Leads', value: total, icon: LuList, color: 'bg-primary' },
            { label: 'New Leads', value: items.filter(i => i.status === 'new').length, icon: LuUserPlus, color: 'bg-blue-500' },
            { label: 'Qualified', value: items.filter(i => i.status === 'qualified').length, icon: LuTarget, color: 'bg-emerald-500' },
            { label: 'Won Leads', value: items.filter(i => i.status === 'won').length, icon: LuTrophy, color: 'bg-green-500' },
          ].map((stat, idx) => (
            <div 
              key={idx} 
              className="group bg-white border border-default-200 rounded-2xl p-5 transition-all duration-300 animate-in fade-in slide-in-from-top-4"
              style={{ animationDelay: `${idx * 100}ms` }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-black text-default-500 uppercase tracking-[0.2em] mb-1">{stat.label}</p>
                  <h4 className="text-2xl font-black text-default-900 tabular-nums leading-none tracking-tight">{stat.value}</h4>
                </div>
                <div className={`size-12 rounded-2xl ${stat.color} text-white flex items-center justify-center group-hover:scale-110 transition-transform duration-500`}>
                  <stat.icon className="size-6" />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white border border-default-200 rounded-2xl mb-8 overflow-hidden animate-in fade-in slide-in-from-top-4 duration-500 delay-300">
          <div className="p-5 flex flex-col gap-4 bg-default-50/50">
            {/* Row 1: Search, Status, Assignee and Add Lead */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                    <div className="relative group flex-1 md:flex-none md:w-72">
                        <LuSearch className="absolute left-3.5 top-1/2 -translate-y-1/2 size-4 text-default-400 group-focus-within:text-primary transition-colors" />
                        <input
                        type="text"
                        className="w-full pl-10 pr-4 h-11 bg-white border border-default-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all placeholder:text-default-400"
                        placeholder="Search name, mobile, email..."
                        onChange={(e) => {
                            setSearch(e.target.value);
                            debouncedSearch(e.target.value);
                        }}
                        />
                    </div>
                    <select
                        className="h-11 pl-4 pr-10 bg-white border border-default-200 rounded-2xl text-sm font-bold text-default-700 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all appearance-none cursor-pointer hover:border-default-300"
                        value={status}
                        onChange={(e) => {
                        setStatus(e.target.value);
                        setPage(1);
                        }}
                    >
                        <option value="">ALL STATUS</option>
                        {statuses.map((s) => (
                        <option key={s.value} value={s.value}>
                            {s.label.toUpperCase()}
                        </option>
                        ))}
                    </select>
                    <select
                        className="h-11 pl-4 pr-10 bg-white border border-default-200 rounded-2xl text-sm font-bold text-default-700 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all appearance-none cursor-pointer hover:border-default-300"
                        value={assignedTo}
                        onChange={(e) => {
                        setAssignedTo(e.target.value);
                        setPage(1);
                        }}
                    >
                        <option value="">ALL ASSIGNEES</option>
                        {developers.map((d) => (
                        <option key={d._id} value={d._id}>
                            {d.name.toUpperCase()}
                        </option>
                        ))}
                    </select>
                    <select
                        className="h-11 pl-4 pr-10 bg-white border border-default-200 rounded-2xl text-sm font-bold text-default-700 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all appearance-none cursor-pointer hover:border-default-300"
                        value={followUpFilter}
                        onChange={(e) => {
                        setFollowUpFilter(e.target.value);
                        setPage(1);
                        }}
                    >
                        <option value="">ALL FOLLOW-UPS</option>
                        <option value="today">TODAY FOLLOW-UPS</option>
                    </select>
                </div>

                <div className="flex items-center gap-2 w-full md:w-auto justify-end">
                    {canCreate && (
                        <button
                        type="button"
                        className="h-11 px-6 flex items-center justify-center gap-2 rounded-xl bg-primary text-white font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 active:scale-95 transition-all w-auto"
                        onClick={() => {
                            setEditItem(null);
                            clearLeadFormState();
                            setModalOpen(true);
                        }}
                        >
                        <LuPlus className="size-5" />
                        <span>Add Lead</span>
                        </button>
                    )}
                </div>
            </div>

            {/* Row 2: Date Filters and Secondary Actions */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
                    <select
                    className="h-11 pl-4 pr-8 bg-white border border-default-200 rounded-2xl text-sm font-bold text-default-700 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all appearance-none cursor-pointer hover:border-default-300"
                    value={dateFilterType}
                    onChange={(e) => {
                        setDateFilterType(e.target.value);
                        setPage(1);
                    }}
                    >
                    <option value="createdAt">Created</option>
                    <option value="updatedAt">Updated</option>
                    </select>
                    <input
                        type="date"
                        className="h-11 px-4 bg-white border border-default-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-default-600"
                        value={startDate}
                        onChange={(e) => {
                        setStartDate(e.target.value);
                        setPage(1);
                        }}
                    />
                    <span className="text-default-400 font-bold">-</span>
                    <input
                        type="date"
                        className="h-11 px-4 bg-white border border-default-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-default-600"
                        value={endDate}
                        onChange={(e) => {
                        setEndDate(e.target.value);
                        setPage(1);
                        }}
                    />
                    {(startDate || endDate) && (
                    <button
                        type="button"
                        onClick={() => {
                        setStartDate('');
                        setEndDate('');
                        setPage(1);
                        }}
                        className="h-11 w-11 flex items-center justify-center hover:bg-red-50 text-red-500 rounded-xl transition-colors"
                        title="Clear Date Filter"
                    >
                        <LuX className="size-4" />
                    </button>
                    )}
                </div>

                <div className="flex items-center gap-3 w-full md:w-auto justify-end flex-wrap">
                    {canAssign && (
                        <button 
                        type="button" 
                        className="h-11 px-4 flex items-center justify-center gap-2 rounded-xl border border-default-200 bg-white font-black text-[10px] uppercase tracking-widest text-default-600 hover:bg-primary hover:text-white hover:border-primary active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed transition-all w-auto"
                        disabled={selectedIds.length === 0}
                        onClick={() => setAssignOpen(true)}
                        >
                        <LuUserCheck className="size-4" />
                        <span className="hidden sm:inline">Assign ({selectedIds.length})</span>
                        </button>
                    )}

                    <div className="flex items-center bg-white border border-default-200 rounded-2xl p-1">
                        <button
                        type="button"
                        className={`h-9 w-9 flex items-center justify-center rounded-xl transition-all ${viewMode === 'list' ? 'bg-primary text-white' : 'text-default-500 hover:bg-default-50'}`}
                        onClick={() => setViewMode('list')}
                        >
                        <LuList className="size-5" />
                        </button>
                        <button
                        type="button"
                        className={`h-9 w-9 flex items-center justify-center rounded-xl transition-all ${viewMode === 'grid' ? 'bg-primary text-white' : 'text-default-500 hover:bg-default-50'}`}
                        onClick={() => setViewMode('grid')}
                        >
                        <LuLayoutGrid className="size-5" />
                        </button>
                    </div>

                    <div className="h-8 w-px bg-default-200 mx-1 hidden md:block" />

                    <div className="flex items-center gap-2">
                        {canExport && (
                        <button 
                            type="button" 
                            className="h-11 px-4 flex items-center justify-center gap-2 rounded-xl border border-default-200 bg-white font-black text-[10px] uppercase tracking-widest text-default-600 hover:bg-primary hover:text-white hover:border-primary active:scale-95 transition-all w-auto"
                            onClick={() => exportData('xlsx')}
                        >
                            <LuDownload className="size-4" />
                            <span className="hidden sm:inline">Export</span>
                        </button>
                        )}
                        {canImport && (
                        <>
                            <button 
                            type="button" 
                            className="h-11 px-4 flex items-center justify-center gap-2 rounded-xl border border-default-200 bg-white font-black text-[10px] uppercase tracking-widest text-default-600 hover:bg-primary hover:text-white hover:border-primary active:scale-95 transition-all w-auto"
                            onClick={downloadTemplate}
                            >
                            <LuFileSpreadsheet className="size-4" />
                            <span className="hidden sm:inline">Template</span>
                            </button>
                            <button 
                            type="button" 
                            className="h-11 px-4 flex items-center justify-center gap-2 rounded-xl border border-default-200 bg-white font-black text-[10px] uppercase tracking-widest text-default-600 hover:bg-primary hover:text-white hover:border-primary active:scale-95 transition-all w-auto"
                            onClick={() => setImportOpen(true)}
                            >
                            <LuUpload className="size-4" />
                            <span className="hidden sm:inline">Import</span>
                            </button>
                        </>
                        )}
                    </div>
                </div>
            </div>
          </div>
        </div>

        <div className="bg-white border border-default-200 rounded-2xl overflow-hidden    animate-in fade-in slide-in-from-top-4 duration-500 delay-500">
          <div className="p-0">
            {viewMode === 'list' ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-default-200">
                  <thead className="bg-default-50/50">
                    <tr>
                      <th className="px-6 py-4 text-left">
                        <div className="flex items-center">
                          <input 
                            type="checkbox" 
                            className="size-4 rounded border-default-300 text-primary focus:ring-primary/20 cursor-pointer"
                            onChange={(e) => {
                              if (e.target.checked) setSelectedIds(items.map(i => i._id));
                              else setSelectedIds([]);
                            }} 
                          />
                        </div>
                      </th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">S.No</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Timestamp</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Name</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Mobile No.</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Lead Type</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Status</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Assigned To</th>
                      <th className="px-6 py-4 text-left text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Business</th>
                      <th className="px-6 py-4 text-right text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-default-100 bg-white">
                    {loading ? (
                      [...Array(limit)].map((_, i) => (
                        <tr key={i} className="animate-pulse">
                          <td className="px-6 py-4" colSpan={10}>
                            <div className="h-10 bg-default-100 rounded-lg w-full" />
                          </td>
                        </tr>
                      ))
                    ) : items.length === 0 ? (
                      <tr>
                        <td className="px-6 py-20 text-center" colSpan={10}>
                          <div className="flex flex-col items-center justify-center">
                            <div className="size-16 rounded-2xl bg-default-50 flex items-center justify-center mb-4">
                              <LuList className="size-8 text-default-200" />
                            </div>
                            <h4 className="text-sm font-black text-default-900 uppercase tracking-widest mb-1">No leads found</h4>
                            <p className="text-[11px] font-bold text-default-400 uppercase tracking-widest">Try adjusting your filters or search</p>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      items.map((l, idx) => (
                        <tr key={l._id} className="hover:bg-default-50/50 transition-colors group">
                          <td className="px-6 py-4">
                            <input 
                              type="checkbox" 
                              className="size-4 rounded border-default-300 text-primary focus:ring-primary/20 cursor-pointer"
                              checked={selectedIds.includes(l._id)} 
                              onChange={(e) => toggleSelect(l._id, e.target.checked)} 
                            />
                          </td>
                          <td className="px-6 py-4 text-xs font-bold text-default-600">{(page - 1) * limit + idx + 1}</td>
                          <td className="px-6 py-4">
                            <div className="text-[11px] font-bold text-default-900">{new Date(l.createdAt).toLocaleDateString()}</div>
                            <div className="text-[10px] font-bold text-default-400 uppercase tracking-widest">{new Date(l.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-sm font-black text-default-900 leading-none mb-1 uppercase tracking-tight">{l.name}</div>
                            <div className="text-[11px] font-bold text-default-500">{l.email || 'No email provided'}</div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-xs font-black text-default-700 uppercase tracking-widest">{l.mobile}</div>
                          </td>
                          <td className="px-6 py-4">
                            <span className="px-2.5 py-1 rounded-lg bg-default-100 text-[10px] font-black text-default-600 uppercase tracking-widest">
                              {l.websiteType || 'General'}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="relative inline-block">
                              <button
                                type="button"
                                className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${statusPillClass(l.status)}`}
                                onClick={() => canEdit && setStatusMenuOpen(statusMenuOpen === l._id ? null : l._id)}
                              >
                                {statuses.find(s => s.value === l.status)?.label || l.status}
                              </button>
                              {canEdit && statusMenuOpen === l._id && (
                                <div className="absolute left-0 top-full mt-2 z-50 w-48 bg-white border border-default-200 rounded-xl p-1.5 animate-in zoom-in-95 duration-200">
                                  {statuses.map((s) => (
                                    <button
                                      key={s.value}
                                      type="button"
                                      className={`w-full text-left px-3 py-2 rounded-lg text-[11px] font-black uppercase tracking-widest transition-all ${l.status === s.value ? 'bg-primary text-white' : 'text-default-600 hover:bg-default-50'}`}
                                      onClick={async () => {
                                        await changeLeadStatus(l._id, s.value);
                                        setStatusMenuOpen(null);
                                      }}
                                    >
                                      {s.label}
                                    </button>
                                  ))}
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            {l.assignedTo ? (
                              <div className="flex items-center gap-2">
                                <div className="size-7 rounded-lg bg-primary/10 text-primary flex items-center justify-center text-[10px] font-black">
                                  {l.assignedTo.name.charAt(0).toUpperCase()}
                                </div>
                                <span className="text-[11px] font-bold text-default-700 uppercase tracking-widest">{l.assignedTo.name}</span>
                              </div>
                            ) : (
                              <span className="text-[10px] font-bold text-default-400 uppercase tracking-widest italic">Unassigned</span>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-widest ${companyPillClass(l.companyType)}`}>
                              {l.companyType || '-'}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-1 opacity-100 transition-opacity">
                              <button 
                                type="button" 
                                className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                                onClick={() => openLeadView(l)}
                              >
                                <LuEye className="size-4" />
                              </button>
                              {canEdit && (
                                <button 
                                  type="button" 
                                  className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                                  onClick={() => {
                                    setEditItem(l);
                                    clearLeadFormState();
                                    setModalOpen(true);
                                  }}
                                >
                                  <LuPencil className="size-4" />
                                </button>
                              )}
                              {canDelete && (
                                <button 
                                  type="button" 
                                  className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-danger hover:text-white hover:border-danger transition-all active:scale-90"
                                  onClick={() => confirmDelete(l._id)}
                                >
                                  <LuTrash2 className="size-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {loading ? (
                    [...Array(limit)].map((_, i) => (
                      <div key={i} className="h-64 bg-default-50 rounded-2xl animate-pulse border border-default-200" />
                    ))
                  ) : items.length === 0 ? (
                    <div className="col-span-full py-20 text-center">
                      <div className="size-16 rounded-2xl bg-default-50 flex items-center justify-center mx-auto mb-4">
                        <LuList className="size-8 text-default-200" />
                      </div>
                      <h4 className="text-sm font-black text-default-900 uppercase tracking-widest mb-1">No leads found</h4>
                      <p className="text-[11px] font-bold text-default-400 uppercase tracking-widest">Try adjusting your filters or search</p>
                    </div>
                  ) : (
                    items.map((l, idx) => (
                      <div 
                        key={l._id} 
                        className="group bg-white border border-default-200 rounded-2xl p-5 transition-all duration-300 relative animate-in fade-in zoom-in-95"
                        style={{ animationDelay: `${idx * 50}ms` }}
                      >
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <div className="size-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center text-lg font-black    group-hover:scale-110 transition-transform">
                              {l.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <h4 className="text-sm font-black text-default-900 leading-none mb-1 uppercase tracking-tight group-hover:text-primary transition-colors">{l.name}</h4>
                              <span className={`px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-widest ${companyPillClass(l.companyType)}`}>
                                {l.companyType}
                              </span>
                            </div>
                          </div>
                          <div className="relative">
                            <button
                              type="button"
                              className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${statusPillClass(l.status)}`}
                              onClick={() => canEdit && setStatusMenuOpen(statusMenuOpen === l._id ? null : l._id)}
                            >
                              {statuses.find(s => s.value === l.status)?.label || l.status}
                            </button>
                            {canEdit && statusMenuOpen === l._id && (
                              <div className="absolute right-0 top-full mt-2 z-50 w-40 bg-white border border-default-200 rounded-xl p-1.5 animate-in zoom-in-95 duration-200">
                                {statuses.map((s) => (
                                  <button
                                    key={s.value}
                                    type="button"
                                    className={`w-full text-left px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${l.status === s.value ? 'bg-primary text-white' : 'text-default-600 hover:bg-default-50'}`}
                                    onClick={async () => {
                                      await changeLeadStatus(l._id, s.value);
                                      setStatusMenuOpen(null);
                                    }}
                                  >
                                    {s.label}
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="space-y-3 mb-6">
                          <div className="flex items-center gap-3">
                            <div className="size-8 rounded-lg bg-default-50 border border-default-100 flex items-center justify-center text-default-400 group-hover:text-primary transition-colors">
                              <LuUserPlus className="size-4" />
                            </div>
                            <div className="flex flex-col">
                              <span className="text-[10px] font-black text-default-400 uppercase tracking-widest leading-none mb-1">Mobile</span>
                              <span className="text-xs font-bold text-default-700 uppercase tracking-widest leading-none">{l.mobile}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="size-8 rounded-lg bg-default-50 border border-default-100 flex items-center justify-center text-default-400 group-hover:text-primary transition-colors">
                              <LuTarget className="size-4" />
                            </div>
                            <div className="flex flex-col">
                              <span className="text-[10px] font-black text-default-400 uppercase tracking-widest leading-none mb-1">Type</span>
                              <span className="text-xs font-bold text-default-700 uppercase tracking-widest leading-none">{l.websiteType || 'General'}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="size-8 rounded-lg bg-default-50 border border-default-100 flex items-center justify-center text-default-400 group-hover:text-primary transition-colors">
                              <LuUserCheck className="size-4" />
                            </div>
                            <div className="flex flex-col">
                              <span className="text-[10px] font-black text-default-400 uppercase tracking-widest leading-none mb-1">Assignee</span>
                              <span className="text-xs font-bold text-default-700 uppercase tracking-widest leading-none">{l.assignedTo?.name || 'Unassigned'}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t border-default-100">
                          <span className="text-[10px] font-black text-default-400 uppercase tracking-[0.1em]">{new Date(l.createdAt).toLocaleDateString()}</span>
                          <div className="flex items-center gap-2">
                            <button 
                              type="button" 
                              className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                              onClick={() => openLeadView(l)}
                            >
                              <LuEye className="size-4" />
                            </button>
                            {canEdit && (
                              <button 
                                type="button" 
                                className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-primary hover:text-white hover:border-primary transition-all active:scale-90"
                                onClick={() => {
                                  setEditItem(l);
                                  clearLeadFormState();
                                  setModalOpen(true);
                                }}
                              >
                                <LuPencil className="size-4" />
                              </button>
                            )}
                            {canDelete && (
                              <button 
                                type="button" 
                                className="size-10 flex items-center justify-center rounded-xl bg-white border border-default-200 text-default-600 hover:bg-danger hover:text-white hover:border-danger transition-all active:scale-90"
                                onClick={() => confirmDelete(l._id)}
                              >
                                <LuTrash2 className="size-4" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            <div className="p-4 border-t border-default-100 bg-default-50/50 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">
                Showing <span className="text-default-900">{((page - 1) * limit) + 1}</span> to <span className="text-default-900">{Math.min(page * limit, total)}</span> of <span className="text-default-900">{total}</span> Results
              </div>
              
              <div className="flex items-center gap-4">
                <select
                  className="h-9 pl-3 pr-8 bg-white border border-default-200 rounded-lg text-[10px] font-black text-default-600 uppercase tracking-widest focus:outline-none focus:ring-2 focus:ring-primary/20 appearance-none cursor-pointer hover:border-default-300 transition-all   "
                  value={limit}
                  onChange={(e) => {
                    setLimit(parseInt(e.target.value));
                    setPage(1);
                  }}
                >
                  {[10, 20, 50, 100].map(v => (
                    <option key={v} value={v}>{v} PER PAGE</option>
                  ))}
                </select>

                <div className="flex items-center bg-white border border-default-200 rounded-xl p-1   ">
                  <button 
                    type="button" 
                    className="h-8 px-4 flex items-center justify-center rounded-lg font-black text-[10px] uppercase tracking-widest transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600" 
                    disabled={page === 1} 
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                  >
                    Prev
                  </button>
                  <div className="w-px h-3 bg-default-200 mx-1" />
                  <button 
                    type="button" 
                    className="h-8 px-4 flex items-center justify-center rounded-lg font-black text-[10px] uppercase tracking-widest transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-default-50 text-default-600" 
                    disabled={page * limit >= total} 
                    onClick={() => setPage(p => p + 1)}
                  >
                    Next
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {viewOpen && selectedLead && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 p-4 overflow-y-auto transition-all animate-in fade-in duration-300">
            <div className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300 border border-default-200">
              <div className="px-8 py-6 border-b border-default-100 flex items-center justify-between bg-white">
                <div className="flex items-center gap-4">
                  <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                    <LuEye className="size-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">Lead Details</h3>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Viewing information for {selectedLead.name}</p>
                  </div>
                </div>
                <button 
                  type="button" 
                  className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                  onClick={() => setViewOpen(false)}
                >
                  <LuX className="size-5" />
                </button>
              </div>
              <div className="p-8 max-h-[70vh] overflow-y-auto custom-scrollbar">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div>
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] block mb-2">Basic Information</span>
                      <div className="bg-default-50 rounded-2xl p-4 border border-default-100">
                        <div className="flex items-center gap-4 mb-4">
                          <div className="size-12 rounded-xl bg-primary text-white flex items-center justify-center text-xl font-black">
                            {selectedLead.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <h3 className="text-base font-black text-default-900 leading-none mb-1 uppercase tracking-tight">{selectedLead.name}</h3>
                            <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest ${companyPillClass(selectedLead.companyType)}`}>
                              {selectedLead.companyType}
                            </span>
                          </div>
                        </div>
                        <div className="space-y-3">
                          <div className="flex flex-col">
                            <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-0.5">Company Name</span>
                            <span className="text-sm font-bold text-default-700">{selectedLead.companyName || 'N/A'}</span>
                          </div>
                          <div className="flex flex-col">
                            <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-0.5">Email Address</span>
                            <span className="text-sm font-bold text-default-700">{selectedLead.email || 'N/A'}</span>
                          </div>
                          <div className="flex flex-col">
                            <span className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-0.5">Phone Number</span>
                            <span className="text-sm font-bold text-default-700 uppercase tracking-widest">{selectedLead.mobile}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <span className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] block mb-2">Status & Assignment</span>
                      <div className="bg-default-50 rounded-2xl p-4 border border-default-100 space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-black text-default-500 uppercase tracking-widest">Current Status</span>
                          <select
                            value={selectedLead.status}
                            onChange={(e) => handleUpdateStatus(selectedLead._id, e.target.value)}
                            className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border-none outline-none cursor-pointer appearance-none ${statusPillClass(selectedLead.status)}`}
                          >
                            {statuses.map((s) => (
                              <option key={s.value} value={s.value} className="bg-white text-default-900">
                                {s.label.toUpperCase()}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-black text-default-500 uppercase tracking-widest">Lead Type</span>
                          <span className="px-2.5 py-1 rounded-lg bg-white border border-default-200 text-[10px] font-black text-default-700 uppercase tracking-widest">
                            {selectedLead.websiteType || 'General'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-black text-default-500 uppercase tracking-widest">Lead Source</span>
                          <span className="px-2.5 py-1 rounded-lg bg-white border border-default-200 text-[10px] font-black text-default-700 uppercase tracking-widest">
                            {selectedLead.source || 'N/A'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-black text-default-500 uppercase tracking-widest">Estimated Price</span>
                          <span className="px-2.5 py-1 rounded-lg bg-white border border-default-200 text-[10px] font-black text-default-700 uppercase tracking-widest">
                            {selectedLead.estimatedPrice ? `$${selectedLead.estimatedPrice}` : 'N/A'}
                          </span>
                        </div>
                        <div className="pt-3 border-t border-default-200">
                          <span className="text-[10px] font-black text-default-400 uppercase tracking-widest block mb-2">Assigned To</span>
                          {selectedLead.assignedTo ? (
                            <div className="flex items-center gap-3 bg-white p-2 rounded-xl border border-default-200">
                              <div className="size-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center text-xs font-black">
                                {selectedLead.assignedTo.name.charAt(0).toUpperCase()}
                              </div>
                              <span className="text-xs font-bold text-default-700 uppercase tracking-widest">{selectedLead.assignedTo.name}</span>
                            </div>
                          ) : (
                            <div className="text-xs font-bold text-default-400 uppercase tracking-widest italic">Not assigned yet</div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="col-span-full">
                    <span className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] block mb-2">Requirement / Message</span>
                    <div className="bg-default-50 rounded-2xl p-5 border border-default-100 min-h-[100px]">
                      <p className="text-sm font-bold text-default-600 leading-relaxed whitespace-pre-wrap">
                        {selectedLead.message || 'No additional message provided.'}
                      </p>
                    </div>
                  </div>

                  <div className="col-span-full">
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-black text-default-400 uppercase tracking-[0.2em] block">Follow-Up History</span>
                        <button
                            type="button"
                            className="h-8 px-4 flex items-center gap-2 rounded-lg bg-primary/10 text-primary font-bold text-[10px] uppercase tracking-widest hover:bg-primary/20 transition-all active:scale-95"
                            onClick={() => {
                                setIsAddingNote(true);
                                setPendingStatus(selectedLead.status || 'new');
                                setFollowUpModalOpen(true);
                            }}
                        >
                            <LuPlus className="size-3" />
                            Add Note
                        </button>
                    </div>
                    <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                      {selectedLead.followUps && selectedLead.followUps.length > 0 ? (
                        [...selectedLead.followUps].reverse().map((fu, idx) => (
                          <div key={idx} className="bg-default-50 rounded-2xl p-4 border border-default-100 relative group hover:border-primary/20 transition-all">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center gap-3">
                                <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest ${statusPillClass(fu.stage)}`}>
                                  {statuses.find(s => s.value === fu.stage)?.label || fu.stage}
                                </span>
                                {fu.status && (
                                  <span className="px-2 py-0.5 rounded-lg bg-white border border-default-200 text-[9px] font-black text-default-600 uppercase tracking-widest">
                                    {fu.status}
                                  </span>
                                )}
                              </div>
                              <div className="flex flex-col items-end">
                                <span className="text-[10px] font-bold text-default-400 uppercase tracking-widest">
                                  {new Date(fu.date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
                                </span>
                                {fu.updatedBy && (
                                  <span className="text-[9px] font-black text-default-300 uppercase tracking-widest mt-0.5">
                                    By {fu.updatedBy.name || 'Unknown'}
                                  </span>
                                )}
                              </div>
                            </div>
                            
                            {fu.notes && (
                              <div className="bg-white rounded-xl p-3 border border-default-100 mb-3">
                                <p className="text-xs font-bold text-default-600 whitespace-pre-wrap leading-relaxed">{fu.notes}</p>
                              </div>
                            )}

                            {fu.nextFollowUp && (
                              <div className="flex items-center gap-2 pt-2 border-t border-default-200/50">
                                <span className="text-[10px] font-black text-default-400 uppercase tracking-widest">Next Follow-Up:</span>
                                <span className="text-[10px] font-bold text-primary uppercase tracking-widest bg-primary/5 px-2 py-0.5 rounded-md">
                                  {new Date(fu.nextFollowUp).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
                                </span>
                              </div>
                            )}
                          </div>
                        ))
                      ) : (
                        <div className="bg-default-50 rounded-2xl p-12 border border-default-100 flex flex-col items-center justify-center text-center border-dashed">
                          <div className="size-12 rounded-2xl bg-default-100 flex items-center justify-center text-default-400 mb-4">
                            <LuList className="size-6" />
                          </div>
                          <p className="text-xs font-bold text-default-900 uppercase tracking-widest mb-1">No History</p>
                          <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Follow-up activities will appear here</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-6 border-t border-default-200 bg-default-50/50 flex justify-end">
                <button 
                  type="button" 
                  className="h-11 px-8 rounded-xl bg-default-900 text-white font-black text-[10px] uppercase tracking-[0.2em] hover:bg-default-800 transition-all active:scale-95"
                  onClick={() => setViewOpen(false)}
                >
                  Close View
                </button>
              </div>
            </div>
          </div>
        )}

        {modalOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 p-4 overflow-y-auto transition-all animate-in fade-in duration-300">
            <div className="bg-white rounded-3xl w-full max-w-4xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300 border border-default-200">
              <div className="px-8 py-6 border-b border-default-100 flex items-center justify-between bg-white sticky top-0 z-10">
                <div className="flex items-center gap-4">
                  <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                    {editItem ? <LuPencil className="size-6" /> : <LuPlus className="size-6" />}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">{editItem ? 'Edit Lead' : 'Add New Lead'}</h3>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">{editItem ? 'Update existing lead details' : 'Register a new potential client'}</p>
                  </div>
                </div>
                <button 
                  type="button" 
                  className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                  onClick={() => { setModalOpen(false); setEditItem(null); clearLeadFormState(); }}
                >
                  <LuX className="size-5" />
                </button>
              </div>
              <form onSubmit={onSubmitLead}>
                <div className="p-8 max-h-[70vh] overflow-y-auto custom-scrollbar">
                  {leadFormSubmitError && (
                    <div className="mb-5 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-xs font-bold text-danger">
                      {leadFormSubmitError}
                    </div>
                  )}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Full Name</label>
                      <input 
                        name="name" 
                        className={`w-full h-12 px-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all uppercase placeholder:text-default-400 ${leadFormErrors.name ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.name || ''} 
                        placeholder="ENTER NAME"
                        onChange={() => clearFieldError('name')}
                      />
                      {leadFormErrors.name && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.name}</p>}
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Mobile Number</label>
                      <input 
                        name="mobile" 
                        className={`w-full h-12 px-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all uppercase placeholder:text-default-400 tabular-nums ${leadFormErrors.mobile ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.mobile || ''} 
                        placeholder="ENTER MOBILE"
                        onChange={() => clearFieldError('mobile')}
                      />
                      {leadFormErrors.mobile && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.mobile}</p>}
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Email Address</label>
                      <input 
                        name="email" 
                        type="email" 
                        className={`w-full h-12 px-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all placeholder:text-default-400 ${leadFormErrors.email ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.email || ''} 
                        placeholder="email@example.com"
                        onChange={() => clearFieldError('email')}
                      />
                      {leadFormErrors.email && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.email}</p>}
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Company Name</label>
                      <input 
                        name="companyName" 
                        className={`w-full h-12 px-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all placeholder:text-default-400 ${leadFormErrors.companyName ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.companyName || ''} 
                        placeholder="ENTER COMPANY NAME"
                        onChange={() => clearFieldError('companyName')}
                      />
                      {leadFormErrors.companyName && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.companyName}</p>}
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Estimated Price</label>
                      <input 
                        name="estimatedPrice" 
                        type="number"
                        className={`w-full h-12 px-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all placeholder:text-default-400 ${leadFormErrors.estimatedPrice ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.estimatedPrice || ''} 
                        placeholder="0.00"
                        onChange={() => clearFieldError('estimatedPrice')}
                      />
                      {leadFormErrors.estimatedPrice && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.estimatedPrice}</p>}
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Lead Type</label>
                      <select 
                        name="websiteType" 
                        className={`w-full h-12 px-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all cursor-pointer appearance-none uppercase ${leadFormErrors.websiteType ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.websiteType || ''} 
                        onChange={() => clearFieldError('websiteType')}
                      >
                        <option value="">SELECT LEAD TYPE</option>
                        {projectTypes.map((t) => (
                          <option key={t} value={t}>{t.toUpperCase()}</option>
                        ))}
                      </select>
                      {leadFormErrors.websiteType && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.websiteType}</p>}
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Status</label>
                      <select 
                        name="status" 
                        className={`w-full h-12 px-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all cursor-pointer appearance-none uppercase ${leadFormErrors.status ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.status || 'new'}
                        onChange={() => clearFieldError('status')}
                      >
                        {statuses.map((s) => (
                          <option key={s.value} value={s.value}>{s.label.toUpperCase()}</option>
                        ))}
                      </select>
                      {leadFormErrors.status && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.status}</p>}
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Lead Source</label>
                      <input
                        name="source"
                        list="lead-source-options"
                        className={`w-full h-12 px-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all cursor-pointer appearance-none uppercase ${leadFormErrors.source ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.source || ''}
                        placeholder="ENTER OR SELECT LEAD SOURCE"
                        onChange={() => clearFieldError('source')}
                      />
                      <datalist id="lead-source-options">
                        {leadSources.map((s) => (
                          <option key={s} value={s} />
                        ))}
                      </datalist>
                      {leadFormErrors.source && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.source}</p>}
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Entity Type</label>
                      <select 
                        name="companyType" 
                        className={`w-full h-12 px-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all cursor-pointer appearance-none uppercase ${leadFormErrors.companyType ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.companyType || 'Individual'}
                        onChange={() => clearFieldError('companyType')}
                      >
                        <option value="Company">COMPANY</option>
                        <option value="Individual">INDIVIDUAL</option>
                      </select>
                      {leadFormErrors.companyType && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.companyType}</p>}
                    </div>
                    <div className="col-span-2 space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Assign To Team Member</label>
                      <select 
                        name="assignedTo" 
                        className={`w-full h-12 px-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all cursor-pointer appearance-none uppercase ${leadFormErrors.assignedTo ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.assignedTo?._id || ''}
                        onChange={() => clearFieldError('assignedTo')}
                      >
                        <option value="">SELECT ASSIGNEE (UNASSIGNED)</option>
                        {developers.map((d) => (
                          <option key={d._id} value={d._id}>{d.name.toUpperCase()}</option>
                        ))}
                      </select>
                      {leadFormErrors.assignedTo && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.assignedTo}</p>}
                    </div>
                    <div className="col-span-2 space-y-1.5">
                      <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Requirement Details / Message</label>
                      <textarea 
                        name="message" 
                        rows={4}
                        className={`w-full p-4 bg-default-50 border rounded-xl text-sm font-bold focus:outline-none focus:ring-2 transition-all uppercase placeholder:text-default-400 resize-none ${leadFormErrors.message ? 'border-danger focus:ring-danger/20 focus:border-danger' : 'border-default-200 focus:ring-primary/20 focus:border-primary'}`}
                        defaultValue={editItem?.message || ''} 
                        placeholder="ENTER LEAD REQUIREMENTS OR NOTES..."
                        onChange={() => clearFieldError('message')}
                      />
                      {leadFormErrors.message && <p className="text-[11px] font-bold text-danger ml-1">{leadFormErrors.message}</p>}
                    </div>
                  </div>
                </div>
                <div className="p-6 border-t border-default-200 bg-default-50/50 flex justify-end gap-3">
                  <button
                    type="button"
                    className="h-11 px-6 rounded-xl border border-default-200 bg-white text-default-600 font-black text-[10px] uppercase tracking-widest hover:bg-default-50 transition-all active:scale-95"
                    onClick={() => { setModalOpen(false); setEditItem(null); clearLeadFormState(); }}
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="h-11 px-10 rounded-xl bg-primary text-white font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all active:scale-95"
                  >
                    {editItem ? 'Update Lead' : 'Create Lead'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {followUpModalOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-[60] p-4 overflow-y-auto transition-all animate-in fade-in duration-300">
            <div className="bg-white rounded-3xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300 border border-default-200">
              <div className="px-8 py-6 border-b border-default-100 flex items-center justify-between bg-white sticky top-0 z-10">
                <div className="flex items-center gap-4">
                  <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                    {isAddingNote ? <LuPencil className="size-6" /> : <LuTarget className="size-6" />}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">{isAddingNote ? 'Add Follow-Up Note' : 'Update Status'}</h3>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">
                      {isAddingNote ? (
                        <span>Adding note for <span className={statusPillClass(pendingStatus)}>{statuses.find(s => s.value === pendingStatus)?.label}</span> stage</span>
                      ) : (
                        <>Move to <span className={statusPillClass(pendingStatus)}>{statuses.find(s => s.value === pendingStatus)?.label}</span></>
                      )}
                    </p>
                  </div>
                </div>
                <button 
                  type="button" 
                  className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                  onClick={() => { setFollowUpModalOpen(false); setPendingStatus(null); setIsAddingNote(false); }}
                >
                  <LuX className="size-5" />
                </button>
              </div>
              <form onSubmit={confirmStatusUpdate}>
                <div className="p-8 space-y-6">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Sub Status (Optional)</label>
                    <select 
                      name="subStatus" 
                      className="w-full h-12 px-4 bg-default-50 border border-default-200 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all cursor-pointer appearance-none uppercase"
                    >
                      <option value="">SELECT SUB-STATUS</option>
                      <option value="Interested">INTERESTED</option>
                      <option value="Not Interested">NOT INTERESTED</option>
                      <option value="Call Back Later">CALL BACK LATER</option>
                      <option value="No Answer">NO ANSWER</option>
                      <option value="Voicemail">VOICEMAIL</option>
                    </select>
                  </div>
                  
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Next Follow-Up Date</label>
                    <input 
                      name="nextFollowUp" 
                      type="datetime-local"
                      className="w-full h-12 px-4 bg-default-50 border border-default-200 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all uppercase placeholder:text-default-400"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Notes / Remarks</label>
                    <textarea 
                      name="notes" 
                      rows={4}
                      className="w-full p-4 bg-default-50 border border-default-200 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all uppercase placeholder:text-default-400 resize-none"
                      placeholder="ENTER NOTES..."
                    />
                  </div>
                </div>
                <div className="p-6 border-t border-default-200 bg-default-50/50 flex justify-end gap-3">
                  <button
                    type="button"
                    className="h-11 px-6 rounded-xl border border-default-200 bg-white text-default-600 font-black text-[10px] uppercase tracking-widest hover:bg-default-50 transition-all active:scale-95"
                    onClick={() => { setFollowUpModalOpen(false); setPendingStatus(null); setIsAddingNote(false); }}
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="h-11 px-10 rounded-xl bg-primary text-white font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all active:scale-95"
                  >
                    {isAddingNote ? 'Add Note' : 'Confirm Update'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {assignOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 p-4 overflow-y-auto transition-all animate-in fade-in duration-300">
            <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300 border border-default-200">
              <div className="px-8 py-6 border-b border-default-100 flex items-center justify-between bg-white">
                <div className="flex items-center gap-4">
                  <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                    <LuUserCheck className="size-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">Bulk Assign</h3>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Assign {selectedIds.length} leads at once</p>
                  </div>
                </div>
                <button 
                  type="button" 
                  className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                  onClick={() => setAssignOpen(false)}
                >
                  <LuX className="size-5" />
                </button>
              </div>
              <form onSubmit={bulkAssign}>
                <div className="p-8">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1 text-center block">Select Team Member</label>
                    <select 
                      name="assignedTo" 
                      className="w-full h-12 px-4 bg-default-50 border border-default-200 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all cursor-pointer appearance-none uppercase text-center"
                      required
                    >
                      <option value="">CHOOSE ASSIGNEE</option>
                      {developers.map((d) => (
                        <option key={d._id} value={d._id}>{d.name.toUpperCase()}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="p-6 border-t border-default-200 bg-default-50/50 flex justify-end gap-3">
                  <button type="button" className="h-11 px-6 rounded-xl bg-white border border-default-200 text-default-600 font-black text-[10px] uppercase tracking-widest hover:bg-default-50 transition-all" onClick={() => setAssignOpen(false)}>Cancel</button>
                  <button type="submit" className="h-11 px-8 rounded-xl bg-primary text-white font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all">Assign Now</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {importOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 p-4 overflow-y-auto transition-all animate-in fade-in duration-300">
            <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-300 border border-default-200">
              <div className="px-8 py-6 border-b border-default-100 flex items-center justify-between bg-white">
                <div className="flex items-center gap-4">
                  <div className="size-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary ring-8 ring-primary/5">
                    <LuUpload className="size-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-default-900 uppercase tracking-tight">Import Leads</h3>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Bulk upload from CSV/Excel</p>
                  </div>
                </div>
                <button 
                  type="button" 
                  className="size-10 flex items-center justify-center bg-default-50 text-default-400 hover:text-danger hover:bg-danger/10 rounded-xl transition-all active:scale-95"
                  onClick={() => setImportOpen(false)}
                >
                  <LuX className="size-5" />
                </button>
              </div>
              <form onSubmit={onImportLeads}>
                <div className="p-8">
                  <div className="p-6 border-2 border-dashed border-default-200 rounded-2xl bg-default-50/50 flex flex-col items-center justify-center text-center group hover:border-primary/50 transition-colors">
                    <LuUpload className="size-10 text-default-300 mb-4 group-hover:text-primary transition-colors" />
                    <p className="text-xs font-bold text-default-600 uppercase tracking-widest mb-1">Click or drag file here</p>
                    <p className="text-[10px] font-bold text-default-400 uppercase tracking-widest">Supports .xlsx, .xls, .csv</p>
                    <input type="file" name="file" accept=".xlsx,.xls,.csv" className="absolute inset-0 opacity-0 cursor-pointer" />
                  </div>
                  <p className="mt-4 text-[10px] font-black text-default-500 uppercase tracking-widest text-center">
                    Note: Use our template for consistent headers.
                  </p>
                </div>
                <div className="p-6 border-t border-default-200 bg-default-50/50 flex justify-end gap-3">
                  <button type="button" className="h-11 px-6 rounded-xl bg-white border border-default-200 text-default-600 font-black text-[10px] uppercase tracking-widest hover:bg-default-50 transition-all" onClick={() => setImportOpen(false)}>Cancel</button>
                  <button type="submit" className="h-11 px-8 rounded-xl bg-primary text-white font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all">Start Import</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </>
  );
};

export default Index;
