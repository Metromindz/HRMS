import { LuFileText, LuShieldCheck, LuCreditCard, LuUser, LuExternalLink, LuFingerprint } from 'react-icons/lu';

const StatutoryCompliance = ({ data }) => {
  const statutory = data?.statutoryCompliance || {};

  const fieldConfig = [
    { key: 'pfNumber', label: 'PF Number', icon: LuFingerprint },
    { key: 'esiNumber', label: 'ESIC Number', icon: LuShieldCheck },
    { key: 'panNumber', label: 'PAN Number', icon: LuCreditCard },
    { key: 'aadhaarNumber', label: 'AADHAR Number', icon: LuUser },
    { key: 'previousEmployment', label: 'Previous Employment', icon: LuFileText },
    { key: 'incomeTaxDeclaration', label: 'Income Tax Declaration', icon: LuFileText, type: 'document' },
  ];

  const renderField = (config) => {
    const { key, label, icon: Icon, type } = config;
    const value = statutory[key];

    return (
      <div key={key} className="space-y-2">
        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-default-400">
          <Icon className="size-3" />
          {label}
        </label>
        {type === 'document' && value ? (
          <a
            href={value}
            target="_blank"
            rel="noopener noreferrer"
            className="h-11 flex items-center gap-2 px-4 rounded-xl bg-primary/5 text-primary hover:bg-primary/10 transition-all text-sm font-bold group"
          >
            <span>View Document</span>
            <LuExternalLink className="size-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
        ) : (
          <div className="min-h-[44px] flex items-center px-4 rounded-xl bg-default-50/50 border border-transparent text-sm font-medium text-default-700">
            {value || '-'}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="animate-in fade-in duration-500">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-default-900">Statutory Compliance</h2>
        <p className="text-sm text-default-500">Manage your regulatory documents and compliance numbers</p>
      </div>

      <div className="bg-white rounded-3xl border border-default-200 p-6 md:p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {fieldConfig.map(renderField)}
        </div>
      </div>
    </div>
  );
};

export default StatutoryCompliance;

