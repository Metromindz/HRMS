import { useState, useEffect } from 'react';
import api from '../../../../../config/api';
import { LuUser, LuMail, LuCalendar, LuUsers, LuHeart, LuMapPin, LuSmartphone, LuShieldAlert, LuEye, LuEyeOff } from 'react-icons/lu';
import { toast } from 'react-hot-toast';

const PersonalInfo = ({ data }) => {
  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState(data.employeePersonal);
  const [loading, setLoading] = useState(false);
  const [visibleFields, setVisibleFields] = useState({});

  const toggleVisibility = (key) => {
    setVisibleFields(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const maskValue = (value, type) => {
    if (!value) return '-';
    if (type === 'phone') return 'XXXXXX' + value.slice(-4);
    if (type === 'email') {
      const [local, domain] = value.split('@');
      return local.length > 2 ? local.slice(0, 2) + '****@' + domain : value;
    }
    return value;
  };

  useEffect(() => {
    setForm(data.employeePersonal);
  }, [data]);


  const handleChange = e => {
    const { name, value } = e.target;
    if (name === 'fullName' || name === 'fatherOrSpouseName' || name === 'gender' || name === 'maritalStatus' || name === 'emergencyContact.name') {
      const lettersOnly = value.replace(/[^a-zA-Z\s.\-']/g, '');
      if (name.includes('emergencyContact.')) {
        const field = name.split('.')[1];
        setForm({ ...form, emergencyContact: { ...form.emergencyContact, [field]: lettersOnly } });
      } else {
        setForm({ ...form, [name]: lettersOnly });
      }
    } else if (name === 'contactNumber' || name === 'emergencyContact.number') {
      const numbersOnly = value.replace(/[^0-9]/g, '');
      if (numbersOnly === '' || (/^[6-9]/.test(numbersOnly) && numbersOnly.length <= 10)) {
        if (name.includes('emergencyContact.')) {
          const field = name.split('.')[1];
          setForm({ ...form, emergencyContact: { ...form.emergencyContact, [field]: numbersOnly } });
        } else {
          setForm({ ...form, [name]: numbersOnly });
        }
      }
    } else {
      if (name.includes('emergencyContact.')) {
        const field = name.split('.')[1];
        setForm({ ...form, emergencyContact: { ...form.emergencyContact, [field]: value } });
      } else {
        setForm({ ...form, [name]: value });
      }
    }
  };

  const handleSave = async () => {
    try {
      setLoading(true);
      const token = sessionStorage.getItem('token');
      const userId = data._id;

      const response = await api.put(
        `/hr/employees/my-profile/${userId}`,
        { employeePersonal: form },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      if (response.status === 200) {
        toast.success('Personal info updated successfully');
        setEditMode(false);
      } else {
        throw new Error(response.data.error || 'Failed to update personal info');
      }
    } catch (err) {
      console.error('Error updating personal info:', err);
      toast.error(err.response?.data?.error || err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  const renderField = (config) => {
    const { key, label, icon: Icon, type, options, sensitive, maskType } = config;
    const value = form?.[key];
    const displayValue = type === 'date' && value ? value.split('T')[0] : (value || '-');
    const isVisible = visibleFields[key];

    return (
      <div key={key} className={`space-y-2 ${type === 'textarea' ? 'md:col-span-2' : ''}`}>
        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-default-400">
          <Icon className="size-3" />
          {label}
        </label>
        {editMode ? (
          type === 'select' ? (
            <select
              name={key}
              value={value || ''}
              onChange={handleChange}
              className="w-full h-11 px-4 rounded-xl border border-default-200 bg-default-50 focus:bg-white focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm outline-none"
            >
              <option value="">Select {label}</option>
              {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
          ) : type === 'textarea' ? (
            <textarea
              name={key}
              value={value || ''}
              onChange={handleChange}
              rows={3}
              className="w-full px-4 py-3 rounded-xl border border-default-200 bg-default-50 focus:bg-white focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm outline-none resize-none"
            />
          ) : (
            <input
              type={type}
              name={key}
              value={value || ''}
              onChange={handleChange}
              className="w-full h-11 px-4 rounded-xl border border-default-200 bg-default-50 focus:bg-white focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm outline-none"
            />
          )
        ) : (
          <div className="min-h-[44px] flex items-center justify-between px-4 rounded-xl bg-default-50/50 border border-transparent text-sm font-medium text-default-700">
            <span>{sensitive && !isVisible ? maskValue(displayValue, maskType) : displayValue}</span>
            {sensitive && value && (
              <button 
                onClick={() => toggleVisibility(key)}
                className="text-default-400 hover:text-primary transition-colors"
              >
                {isVisible ? <LuEyeOff className="size-4" /> : <LuEye className="size-4" />}
              </button>
            )}
          </div>
        )}
      </div>
    );
  };

  const fieldConfig = [
    { key: 'fullName', label: 'Full Name', icon: LuUser, type: 'text' },
    { key: 'dateOfBirth', label: 'Date of Birth', icon: LuCalendar, type: 'date', sensitive: true, maskType: 'date' },
    { key: 'gender', label: 'Gender', icon: LuUsers, type: 'select', options: ['Male', 'Female', 'Other'] },
    { key: 'maritalStatus', label: 'Marital Status', icon: LuHeart, type: 'select', options: ['Single', 'Married', 'Divorced'] },
    { key: 'fatherOrSpouseName', label: 'Father/Spouse Name', icon: LuUser, type: 'text' },
    { key: 'contactNumber', label: 'Contact Number', icon: LuSmartphone, type: 'tel', sensitive: true, maskType: 'phone' },
    { key: 'emailAddress', label: 'Email Address', icon: LuMail, type: 'email', sensitive: true, maskType: 'email' },
    { key: 'currentAddress', label: 'Current Address', icon: LuMapPin, type: 'textarea' },
    { key: 'permanentAddress', label: 'Permanent Address', icon: LuMapPin, type: 'textarea' },
  ];

  return (
    <div className="animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <div>
          <h2 className="text-xl font-bold text-default-900">Personal Information</h2>
          <p className="text-sm text-default-500">Manage your personal details and contact information</p>
        </div>
        <div className="flex items-center gap-3">
          {editMode ? (
            <>
              <button
                onClick={() => setEditMode(false)}
                className="h-11 px-6 rounded-xl border border-default-200 text-default-600 hover:bg-default-50 transition-all active:scale-95 font-black uppercase tracking-widest text-[10px]"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={loading}
                className="h-11 px-6 rounded-xl bg-primary text-white shadow-lg shadow-primary/20 hover:opacity-90 transition-all active:scale-95 font-black uppercase tracking-widest text-[10px] flex items-center gap-2"
              >
                {loading ? (
                  <div className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : 'Save Changes'}
              </button>
            </>
          ) : (
            <button
              onClick={() => setEditMode(true)}
              className="h-11 px-8 rounded-xl bg-primary text-white shadow-lg shadow-primary/20 hover:opacity-90 transition-all active:scale-95 font-black uppercase tracking-widest text-[10px]"
            >
              Edit Profile
            </button>
          )}
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-default-200 p-6 md:p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {fieldConfig.map(renderField)}

          <div className="space-y-2">
            <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-default-400">
              <LuShieldAlert className="size-3" />
              Emergency Contact Name
            </label>
            {editMode ? (
              <input
                type="text"
                name="emergencyContact.name"
                value={form?.emergencyContact?.name || ''}
                onChange={handleChange}
                className="w-full h-11 px-4 rounded-xl border border-default-200 bg-default-50 focus:bg-white focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm outline-none"
              />
            ) : (
              <div className="min-h-[44px] flex items-center px-4 rounded-xl bg-default-50/50 border border-transparent text-sm font-medium text-default-700">
                {form?.emergencyContact?.name || '-'}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-default-400">
              <LuSmartphone className="size-3" />
              Emergency Contact Number
            </label>
            {editMode ? (
              <input
                type="text"
                name="emergencyContact.number"
                value={form?.emergencyContact?.number || ''}
                onChange={handleChange}
                className="w-full h-11 px-4 rounded-xl border border-default-200 bg-default-50 focus:bg-white focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-sm outline-none"
              />
            ) : (
              <div className="min-h-[44px] flex items-center px-4 rounded-xl bg-default-50/50 border border-transparent text-sm font-medium text-default-700">
                {form?.emergencyContact?.number || '-'}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PersonalInfo;
