import { useState } from 'react';
import { LuBanknote, LuUser, LuCreditCard, LuHash, LuMapPin, LuEye, LuEyeOff } from 'react-icons/lu';

const BankDetails = ({ data }) => {
  const bank = data?.bankDetails || {};
  const [visibleFields, setVisibleFields] = useState({});

  const toggleVisibility = (key) => {
    setVisibleFields(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const maskValue = (value, type) => {
    if (!value) return '-';
    if (type === 'account') return 'X'.repeat(Math.max(0, value.length - 4)) + value.slice(-4);
    return value;
  };

  const fieldConfig = [
    { key: 'bankName', label: 'Bank Name', icon: LuBanknote },
    { key: 'accountHolderName', label: 'Account Holder Name', icon: LuUser },
    { key: 'accountNumber', label: 'Account Number', icon: LuCreditCard, sensitive: true, type: 'account' },
    { key: 'ifscCode', label: 'IFSC Code', icon: LuHash },
    { key: 'branchName', label: 'Branch Name', icon: LuMapPin },
  ];

  const renderField = (config) => {
    const { key, label, icon: Icon, sensitive, type } = config;
    const value = bank[key];
    const isVisible = visibleFields[key];

    return (
      <div key={key} className="space-y-2">
        <label className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-default-400">
          <Icon className="size-3" />
          {label}
        </label>
        <div className="min-h-[44px] flex items-center justify-between px-4 rounded-xl bg-default-50/50 border border-transparent text-sm font-medium text-default-700">
          <span>{sensitive && !isVisible ? maskValue(value, type) : (value || '-')}</span>
          {sensitive && value && (
            <button 
              onClick={() => toggleVisibility(key)}
              className="text-default-400 hover:text-primary transition-colors"
            >
              {isVisible ? <LuEyeOff className="size-4" /> : <LuEye className="size-4" />}
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="animate-in fade-in duration-500">
      <div className="mb-8">
        <h2 className="text-xl font-bold text-default-900">Bank Details</h2>
        <p className="text-sm text-default-500">View your salary disbursement account information</p>
      </div>

      <div className="bg-white rounded-3xl border border-default-200 p-6 md:p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {fieldConfig.map(renderField)}
        </div>
      </div>
    </div>
  );
};

export default BankDetails;

