import { useEffect, useState } from 'react';
import { toast } from 'react-hot-toast';
import { useParams, Link } from 'react-router-dom';
import PageMeta from '@/components/PageMeta';
import api from '@/config/api';
import { useAuth } from '@/context/AuthContext';
import {
    LuUsers, // Was LuBuilding
    LuMail,
    LuPhone,
    LuFileSpreadsheet, // Was LuBriefcase & LuClipboardList
    LuClock,
    LuInfo, // Was LuDollarSign & LuMapPin
    LuChevronLeft, // Was LuArrowLeft
    LuSquarePen, // Was LuPencil
    LuPlus,
    LuFilter
} from 'react-icons/lu';

const CompanyDetailView = () => {
    const { id } = useParams();
    const { hasPermission, user } = useAuth();
    const canView = hasPermission('company.overview');
    const canViewValue = hasPermission('project.value') || user?.role === 'superadmin';
    const canViewDocs = hasPermission('project.documents') || user?.role === 'superadmin';

    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [modalOpen, setModalOpen] = useState(false);
    const [editItem, setEditItem] = useState(null);
    const [projectTypeFilter, setProjectTypeFilter] = useState('All');

    const fetchOverview = async () => {
        setLoading(true);
        try {
            const resp = await api.get(`/company/${id}/overview`);
            if (resp.data.success) {
                setData(resp.data);
            } else {
                setError('Failed to load company data');
            }
        } catch (err) {
            setError(err?.response?.data?.message || 'Server error');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (canView) {
            fetchOverview();
        }
    }, [id, canView]);

    const [updatingStatus, setUpdatingStatus] = useState(null);

    const handleStatusUpdate = async (projectId, newStatus) => {
        try {
            setUpdatingStatus(projectId);
            await api.patch(`/projects/${projectId}/status`, { status: newStatus });
            setData(prev => ({
                ...prev,
                recentProjects: prev.recentProjects.map(p =>
                    p._id === projectId ? { ...p, status: newStatus } : p
                )
            }));
            toast.success("Project status updated");
        } catch (error) {
            console.error(error);
            toast.error("Failed to update status");
        } finally {
            setUpdatingStatus(null);
        }
    };

    const onSubmitCompany = async (e) => {
        e.preventDefault();
        const form = new FormData(e.currentTarget);
        const payload = {
            name: form.get('name')?.trim(),
            companyType: form.get('companyType'),
            industry: form.get('industry')?.trim(),
            email: form.get('email')?.trim(),
            phone: form.get('phone')?.trim(),
            alternatePhone: form.get('alternatePhone')?.trim(),
            website: form.get('website')?.trim(),
            addressLine1: form.get('addressLine1')?.trim(),
            addressLine2: form.get('addressLine2')?.trim(),
            city: form.get('city')?.trim(),
            state: form.get('state')?.trim(),
            country: form.get('country')?.trim(),
            pincode: form.get('pincode')?.trim(),
            gstNumber: form.get('gstNumber')?.trim(),
            panNumber: form.get('panNumber')?.trim(),
            contactPersonName: form.get('contactPersonName')?.trim(),
            designation: form.get('designation')?.trim(),
            contactPersonEmail: form.get('contactPersonEmail')?.trim(),
            contactPersonPhone: form.get('contactPersonPhone')?.trim(),
        };

        if (
            !payload.name ||
            !payload.email ||
            !payload.phone ||
            !payload.companyType ||
            !payload.addressLine1 ||
            !payload.city ||
            !payload.state ||
            !payload.country ||
            !payload.pincode ||
            !payload.contactPersonName ||
            !payload.contactPersonEmail ||
            !payload.contactPersonPhone
        ) {
            alert("Please fill in all mandatory fields.");
            return;
        }

        try {
            if (editItem) {
                await api.put(`/company/${editItem._id}`, payload);
            } else {
                await api.post('/company', payload);
            }
            setModalOpen(false);
            setEditItem(null);
            fetchOverview();
        } catch (err) {
            console.error('Failed to save company:', err);
        }
    };

    if (!canView) {
        return (
            <div className="card">
                <div className="card-body">
                    <p className="text-default-500">You do not have permission to view this page.</p>
                </div>
            </div>
        );
    }

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
                <div className="size-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                <p className="text-xs font-bold text-default-400 uppercase tracking-widest">Loading Overview...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4">
                <div className="size-16 bg-danger/10 text-danger rounded-xl flex items-center justify-center mb-2">
                    <LuUsers className="size-8" />
                </div>
                <h3 className="text-lg font-black text-default-900 uppercase tracking-widest">Error Loading Data</h3>
                <p className="text-sm text-default-500">{error}</p>
                <Link to="/company" className="btn btn-primary mt-4">
                    Back to Companies
                </Link>
            </div>
        );
    }

    const { company, metrics, recentProjects } = data || {};

    const uniqueProjectTypes = ['All', ...new Set(recentProjects?.map(p => p.projectType).filter(Boolean) || [])];

    const filteredProjects = recentProjects?.filter(p =>
        projectTypeFilter === 'All' || p.projectType === projectTypeFilter
    );

    return (
        <>
            <PageMeta title={`${company?.name || 'Company'} - Overview`} />
            <main>
                <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-4">
                        <Link to="/company" className="inline-flex items-center justify-center size-10 rounded-xl bg-white border border-default-200 text-default-500 hover:text-primary hover:border-primary transition-colors  ">
                            <LuChevronLeft className="size-5" />
                        </Link>
                        <div>
                            <h4 className="text-xs font-black text-default-400 uppercase tracking-widest mb-1">Company Overview</h4>
                            <h1 className="text-xl font-black text-default-900 leading-none">Detail Dashboard</h1>
                        </div>
                    </div>
                </div>

                {/* Header Section */}
                <div className="bg-white border border-default-200 rounded-xl p-6 lg:p-8 mb-8  ">
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                        <div className="flex items-center gap-6">
                            <div className="size-20 lg:size-24 rounded-xl shadow-inner relative overflow-hidden group border border-default-200 bg-white">
                                {company?.logo ? (
                                    <img
                                        src={`${api.defaults.baseURL?.replace('/api', '')}/${company.logo}`}
                                        alt={company.name}
                                        className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-110"
                                    />
                                ) : (
                                    <div className="w-full h-full bg-primary/10 text-primary flex items-center justify-center font-black text-3xl">
                                        {company?.name?.charAt(0).toUpperCase()}
                                    </div>
                                )}
                            </div>
                            <div>
                                <h1 className="text-2xl lg:text-3xl font-black text-default-900 mb-1 flex items-center gap-3">
                                    {company?.name}
                                    <span className="px-2.5 py-0.5 rounded-md bg-primary/10 text-primary text-[10px] font-black uppercase tracking-widest">
                                        Company
                                    </span>
                                </h1>
                                <div className="flex flex-wrap items-center gap-4 text-sm font-medium text-default-500">
                                    <a href={`mailto:${company?.email}`} className="hover:text-primary transition-colors flex items-center gap-1.5">
                                        <LuMail className="size-3.5" />
                                        {company?.email}
                                    </a>
                                    <span className="size-1 rounded-full bg-default-300" />
                                    <a href={`tel:${company?.phone}`} className="hover:text-primary transition-colors flex items-center gap-1.5">
                                        <LuPhone className="size-3.5" />
                                        {company?.phone}
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div className="flex items-center gap-3 w-full md:w-auto">
                            <button
                                onClick={() => {
                                    setEditItem(company);
                                    setModalOpen(true);
                                }}
                                className="btn btn-outline border-default-200 hover:bg-default-50 text-default-600 font-bold gap-2 flex-1 md:flex-none justify-center">
                                <LuSquarePen className="size-4" />
                                Edit Company
                            </button>
                            <Link to={`/projects?add=true&companyId=${company?._id}`} className="btn btn-primary font-bold gap-2 flex-1 md:flex-none justify-center shadow-lg shadow-primary/20">
                                <LuPlus className="size-4" />
                                New Project
                            </Link>
                        </div>
                    </div>
                </div>

                {/* KPI Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
                    <KPICard
                        icon={LuFileSpreadsheet}
                        label="Projects Done"
                        value={metrics?.completedProjects}
                        subValue={`of ${metrics?.totalProjects} Total`}
                        color="indigo"
                    />
                    <KPICard
                        icon={LuClock}
                        label="Total Time Taken"
                        value={metrics?.totalTime}
                        subValue="Across all tasks"
                        color="orange"
                    />
                    <KPICard
                        icon={LuFileSpreadsheet}
                        label="Tasks Completed"
                        value={metrics?.completedTasks}
                        subValue={`of ${metrics?.totalTasks} Total`}
                        color="emerald"
                    />
                    <KPICard
                        icon={LuInfo}
                        label="Revenue Generated"
                        value={`₹${(metrics?.revenue || 0).toLocaleString()}`}
                        subValue="Total Revenue"
                        color="teal"
                    />
                </div>

                <div className="grid lg:grid-cols-3 gap-8">
                    {/* About Company - Left Column */}
                    <div className="lg:col-span-1 space-y-6">
                        <div className="bg-white border border-default-200 rounded-xl p-6  ">
                            <div className="flex items-center gap-3 mb-6">
                                <LuInfo className="size-5 text-primary" />
                                <h3 className="text-base font-black text-default-900">About Company</h3>
                            </div>

                            <div className="space-y-8">
                                {/* Basic Information */}
                                <div>
                                    <h4 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2 mb-3">Basic Information</h4>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 block">Company Type</label>
                                            <p className="text-sm font-bold text-default-900">{company?.companyType || 'Company'}</p>
                                        </div>
                                        <div>
                                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 block">Industry</label>
                                            <p className="text-sm font-bold text-default-900">{company?.industry || '-'}</p>
                                        </div>
                                    </div>
                                </div>

                                {/* Contact Details */}
                                <div>
                                    <h4 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2 mb-3">Contact Details</h4>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 block">Website</label>
                                            <p className="text-sm font-medium text-default-600">{company?.website || '-'}</p>
                                        </div>
                                        <div>
                                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 block">Alternate Phone</label>
                                            <p className="text-sm font-medium text-default-600">{company?.alternatePhone || '-'}</p>
                                        </div>
                                    </div>
                                </div>

                                {/* Address Details */}
                                <div>
                                    <h4 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2 mb-3">Address Details</h4>
                                    <div className="space-y-3">
                                        <div>
                                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 block">Address</label>
                                            <p className="text-sm font-medium text-default-600 leading-relaxed">
                                                {company?.addressLine1}{company?.addressLine2 ? `, ${company.addressLine2}` : ''}<br />
                                                {company?.city}, {company?.state} - {company?.pincode}<br />
                                                {company?.country}
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                {/* Business Information */}
                                <div>
                                    <h4 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2 mb-3">Business Information</h4>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 block">GST Number</label>
                                            <p className="text-sm font-medium text-default-600">{company?.gstNumber || '-'}</p>
                                        </div>
                                        <div>
                                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 block">PAN Number</label>
                                            <p className="text-sm font-medium text-default-600">{company?.panNumber || '-'}</p>
                                        </div>
                                    </div>
                                </div>

                                {/* Contact Person Details */}
                                <div>
                                    <h4 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2 mb-3">Contact Person</h4>
                                    <div className="space-y-3">
                                        <div>
                                            <label className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 block">Name & Designation</label>
                                            <p className="text-sm font-bold text-default-900">{company?.contactPersonName}</p>
                                            <p className="text-xs text-default-500">{company?.designation}</p>
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div>
                                                <label className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 block">Email</label>
                                                <p className="text-sm font-medium text-default-600">{company?.contactPersonEmail}</p>
                                            </div>
                                            <div>
                                                <label className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 block">Phone</label>
                                                <p className="text-sm font-medium text-default-600">{company?.contactPersonPhone}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="mt-8 pt-6 border-t border-default-100 flex items-center justify-between">
                                <Link to="#" className="text-xs font-bold text-primary hover:text-primary-600 transition-colors">
                                    View All Invoices
                                </Link>
                                <Link to="#" className="text-xs font-bold text-primary hover:text-primary-600 transition-colors">
                                    Client Portal
                                </Link>
                            </div>
                        </div>
                    </div>

                    {/* Associated Projects - Right Column */}
                    <div className="lg:col-span-2">
                        <div className="bg-white border border-default-200 rounded-xl overflow-hidden  ">
                            <div className="p-6 border-b border-default-100 flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <LuFileSpreadsheet className="size-5 text-primary" />
                                    <h3 className="text-base font-black text-default-900">Associated Projects</h3>
                                </div>
                                <div className="flex items-center gap-3">
                                    {uniqueProjectTypes.length > 1 && (
                                        <div className="relative">
                                            <LuFilter className="absolute left-3 top-1/2 -translate-y-1/2 size-3.5 text-default-400 pointer-events-none" />
                                            <select
                                                value={projectTypeFilter}
                                                onChange={(e) => setProjectTypeFilter(e.target.value)}
                                                className="pl-9 pr-8 py-1.5 rounded-lg bg-default-50 border border-default-200 text-xs font-bold text-default-600 focus:border-primary focus:ring-primary/20 outline-none appearance-none cursor-pointer hover:border-default-300 transition-colors"
                                            >
                                                {uniqueProjectTypes.map(type => (
                                                    <option key={type} value={type}>{type}</option>
                                                ))}
                                            </select>
                                            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                                                <svg className="size-3 text-default-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                                </svg>
                                            </div>
                                        </div>
                                    )}
                                    <span className="px-2.5 py-1.5 rounded-lg bg-primary/10 text-primary text-xs font-bold border border-primary/20">
                                        {metrics?.totalProjects} Projects
                                    </span>
                                </div>
                            </div>

                            <div className="divide-y divide-default-100">
                                {recentProjects && recentProjects.length > 0 ? (
                                    <>
                                        <div className={`hidden md:grid gap-4 px-5 py-3 bg-default-50 border-b border-default-100 text-[10px] font-black text-default-400 uppercase tracking-widest ${canViewValue && canViewDocs ? 'grid-cols-[2fr_1fr_1fr_1fr_1fr]' : canViewValue || canViewDocs ? 'grid-cols-[2fr_1fr_1fr_1fr]' : 'grid-cols-[2fr_1fr_1fr]'}`}>
                                            <span>Project Name</span>
                                            <span>Project Type</span>
                                            {canViewValue && <span>Project Value</span>}
                                            {canViewDocs && <span>Documents</span>}
                                            <span className="text-right">Project Status</span>
                                        </div>
                                        {filteredProjects.length > 0 ? (
                                            filteredProjects.map((project) => (
                                                <div key={project._id} className="p-5 hover:bg-default-50 transition-colors group">
                                                    <div className={`grid grid-cols-1 md:gap-4 items-center ${canViewValue && canViewDocs ? 'md:grid-cols-[2fr_1fr_1fr_1fr_1fr]' : canViewValue || canViewDocs ? 'md:grid-cols-[2fr_1fr_1fr_1fr]' : 'md:grid-cols-[2fr_1fr_1fr]'}`}>
                                                        <div className="flex items-center gap-4">
                                                            <div className="size-10 rounded-xl bg-default-100 text-default-500 flex items-center justify-center font-black text-sm uppercase">
                                                                {project.name.charAt(0)}
                                                            </div>
                                                            <div>
                                                                <h4 className="text-sm font-bold text-default-900 mb-0.5 group-hover:text-primary transition-colors">
                                                                    {project.name}
                                                                </h4>
                                                                <p className="text-xs text-default-400">
                                                                    Lead: {project.developers?.[0]?.name || 'Unassigned'}
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div className="text-sm font-bold text-default-600">
                                                            {project.projectType}
                                                        </div>
                                                        {canViewValue && (
                                                            <div className="text-sm font-bold text-default-900">
                                                                ₹{(project.projectValue || 0).toLocaleString()}
                                                            </div>
                                                        )}
                                                        {canViewDocs && (
                                                            <div className="flex flex-wrap gap-2 items-center">
                                                                {project.documents && project.documents.length > 0 ? (
                                                                    project.documents.map((doc, idx) => {
                                                                        const baseUrl = import.meta.env.VITE_API_BASE_URL ? import.meta.env.VITE_API_BASE_URL.replace(/\/api.*$/, '') : '';
                                                                        const fileUrl = doc.url.startsWith('http') ? doc.url : `${baseUrl}${doc.url}`;
                                                                        return (
                                                                            <a key={idx} href={fileUrl} target="_blank" rel="noreferrer" className="flex items-center justify-center p-1.5 bg-default-100/50 hover:bg-primary/10 text-default-600 hover:text-primary rounded-lg border border-default-200 transition-all" title={doc.name}>
                                                                                <LuFileSpreadsheet className="size-4" />
                                                                            </a>
                                                                        );
                                                                    })
                                                                ) : (
                                                                    <span className="text-xs text-default-400 font-medium italic">None</span>
                                                                )}
                                                            </div>
                                                        )}
                                                        <div className="text-right">
                                                            <select
                                                                value={project.status}
                                                                disabled={updatingStatus === project._id}
                                                                onChange={(e) => handleStatusUpdate(project._id, e.target.value)}
                                                                className={`inline-block px-2.5 py-1 rounded text-xs font-bold uppercase tracking-wider mb-1 border cursor-pointer outline-none appearance-none ${project.status === 'completed'
                                                                    ? 'bg-success/10 text-success border-success/20'
                                                                    : project.status === 'in_progress'
                                                                        ? 'bg-primary/10 text-primary border-primary/20'
                                                                        : project.status === 'on_hold'
                                                                            ? 'bg-warning/10 text-warning border-warning/20'
                                                                            : 'bg-default-100 text-default-500 border-default-200'
                                                                    }`}
                                                            >
                                                                <option value="pending" className="bg-white text-default-600">Pending</option>
                                                                <option value="in_progress" className="bg-white text-primary">In Progress</option>
                                                                <option value="completed" className="bg-white text-success">Completed</option>
                                                                <option value="on_hold" className="bg-white text-warning">On Hold</option>
                                                            </select>
                                                            <p className="text-[10px] font-bold text-default-400 uppercase tracking-wide">
                                                                Deadline: {new Date(project.deadlineDate).toLocaleDateString()}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))
                                        ) : (
                                            <div className="p-8 text-center">
                                                <p className="text-sm text-default-400 font-medium">No projects match the selected filter.</p>
                                            </div>
                                        )}
                                    </>
                                ) : (
                                    <div className="p-8 text-center">
                                        <p className="text-sm text-default-400 font-medium">No projects associated with this company yet.</p>
                                        <Link to={`/projects?add=true&companyId=${company?._id}`} className="inline-block mt-3 text-xs font-bold text-primary hover:underline">
                                            + Create First Project
                                        </Link>
                                    </div>
                                )}
                            </div>

                            {recentProjects && recentProjects.length > 0 && (
                                <div className="p-4 bg-default-50 border-t border-default-100 text-center">
                                    <Link to="/projects" className="text-xs font-bold text-default-500 hover:text-default-900 transition-colors">
                                        View All Project History
                                    </Link>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </main>

            {modalOpen && (
                <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-300 p-4">
                    <div className="bg-white w-full max-w-lg rounded-xl overflow-hidden animate-in zoom-in-95 duration-300">
                        <div className="p-6 border-b border-default-200 flex items-center justify-between bg-white">
                            <div>
                                <h4 className="text-lg font-black text-default-900 leading-none mb-1 uppercase tracking-widest">
                                    {editItem ? 'Edit Company' : 'Add New Company'}
                                </h4>
                                <p className="text-[10px] font-black text-default-500 uppercase tracking-[0.2em]">
                                    {editItem ? 'Update company details' : 'Register a new company'}
                                </p>
                            </div>
                            <button
                                type="button"
                                className="size-10 flex items-center justify-center rounded-xl bg-default-100 text-default-600 hover:bg-danger hover:text-white transition-all active:scale-90"
                                onClick={() => {
                                    setModalOpen(false);
                                    setEditItem(null);
                                }}
                            >
                                <LuPlus className="size-6 rotate-45" />
                            </button>
                        </div>
                        <form onSubmit={onSubmitCompany}>
                            <div className="p-6 space-y-8 overflow-y-auto max-h-[65vh]">
                                {/* 1. Basic Information */}
                                <div className="space-y-4">
                                    <h5 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2">1. Basic Information</h5>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Company Name *</label>
                                            <input
                                                name="name"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="ENTER COMPANY NAME"
                                                defaultValue={editItem?.name || ''}
                                                required
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Company Type *</label>
                                            <select
                                                name="companyType"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                defaultValue={editItem?.companyType || 'Company'}
                                                required
                                            >
                                                <option value="Company">Company</option>
                                                <option value="Individual">Individual</option>
                                            </select>
                                        </div>
                                        <div className="space-y-1.5 md:col-span-2">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Industry</label>
                                            <input
                                                name="industry"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="ENTER INDUSTRY"
                                                defaultValue={editItem?.industry || ''}
                                            />
                                        </div>
                                    </div>
                                </div>

                                {/* 2. Contact Details */}
                                <div className="space-y-4">
                                    <h5 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2">2. Contact Details (Company)</h5>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Company Email *</label>
                                            <input
                                                type="email"
                                                name="email"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="EMAIL@COMPANY.COM"
                                                defaultValue={editItem?.email || ''}
                                                required
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Company Phone *</label>
                                            <input
                                                name="phone"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="+1 (234) 567-890"
                                                defaultValue={editItem?.phone || ''}
                                                required
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Alternate Phone</label>
                                            <input
                                                name="alternatePhone"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="ALTERNATE PHONE"
                                                defaultValue={editItem?.alternatePhone || ''}
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Website</label>
                                            <input
                                                name="website"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="WWW.WEBSITE.COM"
                                                defaultValue={editItem?.website || ''}
                                            />
                                        </div>
                                    </div>
                                </div>

                                {/* 3. Address Details */}
                                <div className="space-y-4">
                                    <h5 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2">3. Address Details</h5>
                                    <div className="space-y-4">
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Address Line 1 *</label>
                                            <input
                                                name="addressLine1"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="STREET ADDRESS"
                                                defaultValue={editItem?.addressLine1 || ''}
                                                required
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Address Line 2</label>
                                            <input
                                                name="addressLine2"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="APARTMENT, SUITE, ETC."
                                                defaultValue={editItem?.addressLine2 || ''}
                                            />
                                        </div>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div className="space-y-1.5">
                                                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">City *</label>
                                                <input
                                                    name="city"
                                                    className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                    placeholder="CITY"
                                                    defaultValue={editItem?.city || ''}
                                                    required
                                                />
                                            </div>
                                            <div className="space-y-1.5">
                                                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">State *</label>
                                                <input
                                                    name="state"
                                                    className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                    placeholder="STATE"
                                                    defaultValue={editItem?.state || ''}
                                                    required
                                                />
                                            </div>
                                            <div className="space-y-1.5">
                                                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Country *</label>
                                                <input
                                                    name="country"
                                                    className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                    placeholder="COUNTRY"
                                                    defaultValue={editItem?.country || ''}
                                                    required
                                                />
                                            </div>
                                            <div className="space-y-1.5">
                                                <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Pincode *</label>
                                                <input
                                                    name="pincode"
                                                    className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                    placeholder="PINCODE"
                                                    defaultValue={editItem?.pincode || ''}
                                                    required
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* 4. Business Information */}
                                <div className="space-y-4">
                                    <h5 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2">4. Business Information</h5>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">GST Number</label>
                                            <input
                                                name="gstNumber"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="GST NUMBER"
                                                defaultValue={editItem?.gstNumber || ''}
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">PAN Number</label>
                                            <input
                                                name="panNumber"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="PAN NUMBER"
                                                defaultValue={editItem?.panNumber || ''}
                                            />
                                        </div>
                                    </div>
                                </div>

                                {/* 5. Contact Person Details */}
                                <div className="space-y-4">
                                    <h5 className="text-xs font-black text-primary uppercase tracking-widest border-b border-default-200 pb-2">5. Contact Person Details (Primary)</h5>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Contact Person Name *</label>
                                            <input
                                                name="contactPersonName"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="FULL NAME"
                                                defaultValue={editItem?.contactPersonName || ''}
                                                required
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Designation</label>
                                            <input
                                                name="designation"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="DESIGNATION"
                                                defaultValue={editItem?.designation || ''}
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Email Address *</label>
                                            <input
                                                type="email"
                                                name="contactPersonEmail"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="EMAIL"
                                                defaultValue={editItem?.contactPersonEmail || ''}
                                                required
                                            />
                                        </div>
                                        <div className="space-y-1.5">
                                            <label className="text-[10px] font-black text-default-500 uppercase tracking-widest ml-1">Phone Number *</label>
                                            <input
                                                name="contactPersonPhone"
                                                className="w-full bg-white border-default-200 rounded-xl h-12 px-4 text-sm font-bold focus:ring-primary/20 focus:border-primary transition-all"
                                                placeholder="PHONE"
                                                defaultValue={editItem?.contactPersonPhone || ''}
                                                required
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="p-6 border-t border-default-200 bg-white flex justify-end gap-3">
                                <button
                                    type="button"
                                    className="h-12 px-6 flex items-center justify-center rounded-xl font-black text-[10px] uppercase tracking-widest text-default-600 hover:bg-default-100 transition-all"
                                    onClick={() => {
                                        setModalOpen(false);
                                        setEditItem(null);
                                    }}
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    className="h-12 px-8 flex items-center justify-center bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary-600 transition-all active:scale-95"
                                >
                                    {editItem ? 'Update Company' : 'Register Company'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </>
    );
};

const KPICard = ({ icon: Icon, label, value, subValue, color }) => {
    const colorStyles = {
        indigo: 'bg-indigo-50 text-indigo-600',
        orange: 'bg-orange-50 text-orange-600',
        emerald: 'bg-emerald-50 text-emerald-600',
        blue: 'bg-blue-50 text-blue-600',
        teal: 'bg-teal-50 text-teal-600'
    };

    const iconColor = colorStyles[color] || 'bg-default-100 text-default-600';

    return (
        <div className="bg-white border border-default-200 rounded-xl p-5   hover:shadow-md transition-shadow">
            <div className="flex justify-between items-start mb-4">
                <div className={`size-10 rounded-xl flex items-center justify-center ${iconColor}`}>
                    <Icon className="size-5" />
                </div>
                <div className="size-8 rounded-full bg-default-50 flex items-center justify-center text-default-300">
                    <Icon className="size-4 opacity-50" />
                </div>
            </div>
            <div>
                <p className="text-[10px] font-black text-default-400 uppercase tracking-widest mb-1 line-clamp-1">{label}</p>
                <h4 className="text-xl lg:text-2xl font-black text-default-900 mb-1">{value}</h4>
                {subValue && (
                    <p className="text-xs font-medium text-default-400">{subValue}</p>
                )}
            </div>
        </div>
    );
};


export default CompanyDetailView;
