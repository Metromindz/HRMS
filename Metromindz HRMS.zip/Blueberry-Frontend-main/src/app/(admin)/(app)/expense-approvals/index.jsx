import PageBreadcrumb from '@/components/PageBreadcrumb';
import PageMeta from '@/components/PageMeta';
import ApprovalList from './components/ApprovalList';

const ExpenseApprovals = () => {
  return (
    <>
      <PageMeta title="Expense Approvals" />
      <main>
        <PageBreadcrumb title="Expense Approvals" subtitle="Admin" />
        <ApprovalList />
      </main>
    </>
  );
};

export default ExpenseApprovals;
