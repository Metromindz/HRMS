import api from '../../../../../config/api';
import ApexChartClient from '@/components/client-wrapper/ApexChartClient';
import { useEffect, useState } from 'react';

const ApplicationReceived = () => {
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchCount = async () => {
    try {
      const res = await api.get('/statistics/counts');
      const data = res.data.data;
      
      const chartData = {
        totalEmployees: data.totalEmployees,
        totalActive: data.totalActive,
        totalInactive: data.totalInactive,
        totalProbation: data.totalProbation,
        totalPermanent: data.totalPermanent,
        totalContract: data.totalContract,
        totalResigned: data.totalResigned,
        totalTerminated: data.totalTerminated,
        totalNotice: data.totalNotice
      };
      
      setStatistics(chartData);
    } catch (error) {
      console.error("Fetching error", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCount();
  }, []);

  // Get pie chart options and series
  const getPieChartData = () => {
    if (!statistics) {
      return {
        options: {},
        series: []
      };
    }

    const labels = [
      'Active Employees',
      'Inactive Employees',
      'Probation',
      'Permanent',
      'Contract',
      'Resigned',
      'Terminated',
      'On Notice'
    ];

    const series = [
      statistics.totalActive,
      statistics.totalInactive,
      statistics.totalProbation,
      statistics.totalPermanent,
      statistics.totalContract,
      statistics.totalResigned,
      statistics.totalTerminated,
      statistics.totalNotice
    ];

    return {
      options: {
        chart: {
          type: 'pie',
          width: '100%',
          events: {
            // Disable click events to prevent highlighting
            dataPointSelection: () => false,
            click: () => false
          }
        },
        labels: labels,
        responsive: [{
          breakpoint: 768,
          options: {
            chart: {
              width: '100%'
            }
          }
        }],
        legend: {
          show: false
        },
        colors: [
          '#4CAF50', // Green - Active
          '#FF5722', // Deep Orange - Inactive
          '#FFC107', // Amber - Probation
          '#2196F3', // Blue - Permanent
          '#9C27B0', // Purple - Contract
          '#F44336', // Red - Resigned
          '#607D8B', // Blue Grey - Terminated
          '#FF9800'  // Orange - Notice
        ],
        tooltip: {
          y: {
            formatter: function(val) {
              return val + " employees";
            }
          }
        },
        // Disable hover and active states
        states: {
          hover: {
            filter: {
              type: 'none'
            }
          },
          active: {
            filter: {
              type: 'none'
            }
          }
        },
        // Disable data labels on hover
        dataLabels: {
          enabled: false
        }
      },
      series: series
    };
  };

  // Data for the legend/statistics list
  const getStatItems = () => {
    if (!statistics) return [];
    
    return [
      { 
        label: 'Active Employees', 
        value: statistics.totalActive, 
        color: '#4CAF50',
        key: 'active'
      },
      { 
        label: 'Inactive Employees', 
        value: statistics.totalInactive, 
        color: '#FF5722',
        key: 'inactive'
      },
      { 
        label: 'Probation', 
        value: statistics.totalProbation, 
        color: '#FFC107',
        key: 'probation'
      },
      { 
        label: 'Permanent', 
        value: statistics.totalPermanent, 
        color: '#2196F3',
        key: 'permanent'
      },
      { 
        label: 'Contract', 
        value: statistics.totalContract, 
        color: '#9C27B0',
        key: 'contract'
      },
      { 
        label: 'Resigned', 
        value: statistics.totalResigned, 
        color: '#F44336',
        key: 'resigned'
      },
      { 
        label: 'Terminated', 
        value: statistics.totalTerminated, 
        color: '#607D8B',
        key: 'terminated'
      },
      { 
        label: 'On Notice', 
        value: statistics.totalNotice, 
        color: '#FF9800',
        key: 'notice'
      }
    ];
  };

  if (loading) {
    return (
      <div className="col-span-1">
        <div className="card">
          <div className="card-body">
            <div className="flex justify-between">
              <h6 className="card-title">Workforce Overview</h6>
            </div>
            <div className="flex items-center justify-center h-44">
              <div className="text-gray-500">Loading statistics...</div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="col-span-1">
      <div className="card">
        <div className="card-body">
          {/* Header with total count */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-2">
            <h6 className="card-title text-lg mb-0">Workforce Overview</h6>
            <div className="flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-lg">
              <div className="text-base font-bold text-primary">
                Total: {statistics?.totalEmployees || 0}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Left side - Pie chart */}
            <div className="flex items-center justify-center">
              {statistics && (
                <ApexChartClient
                  getOptions={() => getPieChartData().options}
                  series={getPieChartData().series}
                  type="pie"
                  height={220}
                />
              )}
            </div>

            {/* Right side - Legend with counts - Reduced gaps */}
            <div>
              <h3 className="text-sm font-semibold text-gray-700 mb-2">Employee Distribution</h3>
              
              <div className="space-y-0.5"> {/* Reduced from space-y-2 */}
                {getStatItems().map((item) => (
                  <div 
                    key={item.key} 
                    className="flex items-center gap-5 p-1.5 hover:bg-gray-50 rounded transition-colors" // Reduced from p-2
                  >
                    <div className="flex items-center gap-3"> {/* Reduced from gap-3 */}
                      <div 
                        className="w-2.5 h-2.5 rounded-full flex-shrink-0" // Slightly smaller
                        style={{ backgroundColor: item.color }}
                      ></div>
                      <span className="text-sm text-gray-700 truncate">{item.label}:</span>
                    </div>
                    <div className="flex items-center gap-1"> {/* Reduced from gap-2 */}
                      <span className="font-bold text-gray-900 text-sm">{item.value}</span>
                      <span className="text-xs text-gray-500">emp</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicationReceived;
