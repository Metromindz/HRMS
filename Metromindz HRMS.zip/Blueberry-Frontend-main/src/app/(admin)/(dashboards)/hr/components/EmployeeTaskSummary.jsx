import { LuUserCheck, LuChartPie, LuListTodo, LuFileX } from 'react-icons/lu';

const EmployeeTaskSummary = ({ stats, loading }) => {
    // Use generic or specific stats mapping
    const data = [
        {
            label: 'Task Completed',
            value: loading ? '—' : (stats?.completedTasks || 0) + ' Completed',
            icon: LuUserCheck,
            colorClass: 'text-green-500 bg-green-50',
        },
        {
            label: 'In Progress',
            value: loading ? '—' : (stats?.inProgressTasks || 0) + ' Tasks',
            icon: LuChartPie,
            colorClass: 'text-violet-500 bg-violet-50',
        },
        {
            label: 'Task ToDo',
            value: loading ? '—' : (stats?.todoTasks || 0) + ' Tasks',
            icon: LuListTodo,
            colorClass: 'text-amber-500 bg-amber-50',
        },
        {
            label: 'Incomplete Task',
            value: loading ? '—' : (stats?.incompleteTasks || 0) + ' Tasks',
            icon: LuFileX,
            colorClass: 'text-red-500 bg-red-50',
        }
    ];

    return (
        <div className="w-full">
            <h3 className="text-xl font-bold text-default-900 mb-6">Summary</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {data.map((item, index) => (
                    <div key={index} className="flex items-center gap-4">
                        <div className={`size-16 rounded-2xl flex items-center justify-center shrink-0 ${item.colorClass}`}>
                            <item.icon className="size-8" />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-default-400 mb-1">{item.label}</p>
                            <h4 className="text-xl font-bold text-default-900">{item.value}</h4>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default EmployeeTaskSummary;
