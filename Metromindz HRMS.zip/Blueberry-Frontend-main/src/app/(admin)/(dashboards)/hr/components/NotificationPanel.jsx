import { useNotifications } from '@/context/NotificationContext';
import { useAuth } from '@/context/AuthContext';
import {
  Bell,
  CheckCheck,
  Clock,
  Check,
  Settings,
  ArrowRight,
  Sparkles,
  AlertCircle,
  Info,
  CheckCircle2
} from 'lucide-react';
import { Link } from 'react-router';
import { useState } from 'react';

const NotificationPanel = () => {
  const { notifications, unreadCount, markAsRead } = useNotifications();
  const { user } = useAuth();
  const [hoveredId, setHoveredId] = useState(null);

  // Show only recent 5
  const recentNotifications = notifications.slice(0, 5);

  const isRead = (notification) => {
    if (!user || !notification.isRead) return false;
    return notification.isRead.some(r => r.userId === user._id);
  };

  // Get icon based on notification type or title
  const getNotificationIcon = (notif) => {
    const title = notif.title?.toLowerCase() || '';
    if (title.includes('alert') || title.includes('warning')) return AlertCircle;
    if (title.includes('success') || title.includes('complete')) return CheckCircle2;
    if (title.includes('info')) return Info;
    return Bell;
  };

  // Get color based on read status and type
  const getNotificationStyles = (notif, read) => {
    if (read) return 'bg-slate-50/50 border-slate-100';

    const title = notif.title?.toLowerCase() || '';
    if (title.includes('urgent') || title.includes('alert')) {
      return 'bg-rose-50/80 border-rose-100 shadow-sm shadow-rose-100/50';
    }
    if (title.includes('success')) {
      return 'bg-emerald-50/80 border-emerald-100 shadow-sm shadow-emerald-100/50';
    }
    return 'bg-blue-50/80 border-blue-100 shadow-sm shadow-blue-100/50';
  };

  const formatTime = (date) => {
    const now = new Date();
    const notifDate = new Date(date);
    const diff = now - notifDate;

    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return notifDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="relative w-full h-full">
      {/* Ambient glow effect */}
      <div className="absolute -inset-0.5 bg-gradient-to-br from-blue-100 via-purple-50 to-slate-100 rounded-2xl blur opacity-40" />

      <div className="relative h-full bg-white/90 backdrop-blur-xl rounded-2xl shadow-xl shadow-slate-200/50 border border-white/50 overflow-hidden flex flex-col">

        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-white to-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-500/20">
                <Bell className="w-5 h-5 text-white" />
              </div>
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white animate-pulse">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 tracking-tight">Notifications</h3>
              <p className="text-[11px] text-slate-500 font-medium">
                {unreadCount > 0 ? `${unreadCount} unread message${unreadCount > 1 ? 's' : ''}` : 'All caught up!'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {unreadCount > 0 && (
              <button
                onClick={() => recentNotifications.filter(n => !isRead(n)).forEach(n => markAsRead(n._id))}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-500 hover:text-blue-600"
                title="Mark all as read"
              >
                <CheckCheck className="w-4 h-4" />
              </button>
            )}
            <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-400 hover:text-slate-600">
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Notification List */}
        <div className="flex-1 overflow-y-auto max-h-[480px] custom-scrollbar">
          {recentNotifications.length > 0 ? (
            <div className="divide-y divide-slate-100/50">
              {recentNotifications.map((notif) => {
                const read = isRead(notif);
                const NotifIcon = getNotificationIcon(notif);
                const styles = getNotificationStyles(notif, read);

                return (
                  <div
                    key={notif._id}
                    className={`relative p-4 transition-all duration-300 border-l-4 ${styles} ${read ? 'border-l-transparent' : 'border-l-blue-500'} ${hoveredId === notif._id ? 'translate-x-1' : ''}`}
                    onMouseEnter={() => setHoveredId(notif._id)}
                    onMouseLeave={() => setHoveredId(null)}
                  >
                    <div className="flex gap-3">
                      {/* Icon */}
                      <div className={`shrink-0 w-9 h-9 rounded-lg flex items-center justify-center ${read ? 'bg-slate-100 text-slate-400' : 'bg-white/80 text-blue-600 shadow-sm'}`}>
                        <NotifIcon className="w-4 h-4" />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <h4 className={`text-sm leading-tight ${read ? 'font-medium text-slate-600' : 'font-bold text-slate-900'}`}>
                            {notif.title}
                          </h4>

                          {!read && (
                            <button
                              onClick={() => markAsRead(notif._id)}
                              className="shrink-0 p-1.5 hover:bg-white rounded-lg transition-all text-slate-400 hover:text-emerald-600 hover:shadow-sm"
                              title="Mark as read"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        <p className={`text-xs mt-1 leading-relaxed line-clamp-2 ${read ? 'text-slate-500' : 'text-slate-600'}`}>
                          {notif.message}
                        </p>

                        <div className="flex items-center gap-3 mt-2">
                          <div className="flex items-center gap-1 text-[10px] text-slate-400 font-medium">
                            <Clock className="w-3 h-3" />
                            {formatTime(notif.createdAt)}
                          </div>

                          {notif.link && (
                            <Link
                              to={notif.link}
                              className="text-[10px] font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-0.5 hover:underline"
                            >
                              View details
                              <ArrowRight className="w-3 h-3" />
                            </Link>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Unread indicator dot */}
                    {!read && (
                      <div className="absolute top-4 right-4 w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                    )}
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-64 px-6 text-center">
              <div className="relative mb-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-slate-100 to-slate-50 flex items-center justify-center">
                  <Bell className="w-7 h-7 text-slate-300" />
                </div>
                <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
                </div>
              </div>
              <h5 className="text-sm font-bold text-slate-700 mb-1">All caught up!</h5>
              <p className="text-xs text-slate-400 max-w-[200px] leading-relaxed">
                You have no new notifications. We'll notify you when something important happens.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
          <span className="text-[11px] text-slate-400 font-medium">
            {notifications.length > 5 ? `+${notifications.length - 5} more` : 'Showing all'}
          </span>
          <Link
            to="/notifications"
            className="group flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 transition-colors"
          >
            View all
            <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default NotificationPanel;
