import { useState, useEffect } from 'react';
import { LuX, LuSave, LuLoader } from 'react-icons/lu';
import api from '@/config/api';
import toast from 'react-hot-toast';

const EditProfileModal = ({ isOpen, onClose, user, onUpdateSuccess }) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    contactNumber: '',
    currentAddress: '',
    permanentAddress: '',
    bloodGroup: '',
    emergencyContactName: '',
    emergencyContactNumber: '',
  });

  useEffect(() => {
    if (user && user.employeePersonal) {
      setFormData({
        contactNumber: user.employeePersonal.contactNumber || '',
        currentAddress: user.employeePersonal.currentAddress || '',
        permanentAddress: user.employeePersonal.permanentAddress || '',
        bloodGroup: user.employeePersonal.bloodGroup || '',
        emergencyContactName: user.employeePersonal.emergencyContact?.name || '',
        emergencyContactNumber: user.employeePersonal.emergencyContact?.number || '',
      });
    }
  }, [user, isOpen]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const payload = {
        employeePersonal: {
          contactNumber: formData.contactNumber,
          currentAddress: formData.currentAddress,
          permanentAddress: formData.permanentAddress,
          bloodGroup: formData.bloodGroup,
          emergencyContact: {
            name: formData.emergencyContactName,
            number: formData.emergencyContactNumber,
          }
        }
      };

      const response = await api.put('/auth/profile', payload);
      
      if (response.data.success) {
        toast.success('Profile updated successfully');
        if (onUpdateSuccess) onUpdateSuccess(response.data.user);
        onClose();
      }
    } catch (error) {
      console.error('Update error:', error);
      toast.error(error.response?.data?.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex justify-between items-center p-4 border-b border-default-200">
          <h3 className="text-lg font-semibold text-default-900">Edit Profile</h3>
          <button 
            onClick={onClose}
            className="text-default-500 hover:text-default-700 hover:bg-default-100 p-2 rounded-full transition-colors"
          >
            <LuX size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          
          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-primary uppercase tracking-wider">Contact Information</h4>
            
            <div>
              <label className="block text-sm font-medium text-default-700 mb-1">Phone Number</label>
              <input
                type="text"
                name="contactNumber"
                value={formData.contactNumber}
                onChange={handleChange}
                className="w-full rounded-lg border border-default-200 px-3 py-2 text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none"
                placeholder="+1 234 567 890"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-default-700 mb-1">Current Address</label>
              <textarea
                name="currentAddress"
                value={formData.currentAddress}
                onChange={handleChange}
                rows="2"
                className="w-full rounded-lg border border-default-200 px-3 py-2 text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none"
                placeholder="123 Main St, City, Country"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-default-700 mb-1">Permanent Address</label>
              <textarea
                name="permanentAddress"
                value={formData.permanentAddress}
                onChange={handleChange}
                rows="2"
                className="w-full rounded-lg border border-default-200 px-3 py-2 text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none"
                placeholder="Same as current address"
              />
            </div>
          </div>

          <hr className="border-default-200" />

          {/* Emergency Contact */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-primary uppercase tracking-wider">Emergency Contact</h4>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-default-700 mb-1">Name</label>
                <input
                  type="text"
                  name="emergencyContactName"
                  value={formData.emergencyContactName}
                  onChange={handleChange}
                  className="w-full rounded-lg border border-default-200 px-3 py-2 text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none"
                  placeholder="Relative Name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-default-700 mb-1">Phone</label>
                <input
                  type="text"
                  name="emergencyContactNumber"
                  value={formData.emergencyContactNumber}
                  onChange={handleChange}
                  className="w-full rounded-lg border border-default-200 px-3 py-2 text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none"
                  placeholder="Emergency Phone"
                />
              </div>
            </div>
          </div>
          
          <hr className="border-default-200" />

           {/* Personal Details */}
           <div className="space-y-4">
            <h4 className="text-sm font-semibold text-primary uppercase tracking-wider">Other Details</h4>
            
            <div>
                <label className="block text-sm font-medium text-default-700 mb-1">Blood Group</label>
                <select
                  name="bloodGroup"
                  value={formData.bloodGroup}
                  onChange={handleChange}
                  className="w-full rounded-lg border border-default-200 px-3 py-2 text-sm focus:border-primary focus:ring-1 focus:ring-primary outline-none bg-white"
                >
                  <option value="">Select Blood Group</option>
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                </select>
            </div>
          </div>

          <div className="pt-4 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-default-700 bg-default-100 hover:bg-default-200 rounded-lg transition-colors"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-600 rounded-lg shadow-sm transition-all flex items-center gap-2"
            >
              {loading ? <LuLoader className="animate-spin" /> : <LuSave />}
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditProfileModal;
