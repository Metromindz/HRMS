const Activities = () => {
  return <div className="grid lg:grid-cols-4 grid-cols-1 mb-5 gap-5">
      {/* <div className="lg:col-span-2">
        <h5 className="mb-2 text-xl text-default-800 font-semibold">Welcome Neha Reddy</h5>
      </div> */}

      {/* <div className="lg:col-start-6">
        <div className="card">
          <div className="card-body">
            <div className="grid grid-cols-4">
              <div className="px-4 text-center border-e border-default-200 text-sm">
                <h6 className="mb-1 font-bold">
                  <span className="counter-value text-default-800" data-target="36">
                    15
                  </span>
                </h6>
                <p className="text-default-500">Absent</p>
              </div>

              <div className="px-4 text-center border-e border-default-200 text-sm">
                <h6 className="mb-1 font-bold">
                  <span className="counter-value text-default-800" data-target="465">
                    150
                  </span>
                </h6>
                <p className="text-default-500">Present</p>
              </div>

              <div className="px-4 text-center border-e border-default-200 text-sm">
                <h6 className="mb-1 font-bold">
                  <span className="counter-value text-default-800" data-target="50">
                    50
                  </span>
                </h6>
                <p className="text-default-500">Late</p>
              </div>

               <div className="px-4 text-center text-sm">
                <h6 className="mb-1 font-bold">
                  <span className="counter-value text-default-800" data-target="50">
                    5
                  </span>
                </h6>
                <p className="text-default-500">Leave</p>
              </div>
            </div>
          </div>
        </div>
      </div> */}
    </div>;
};
export default Activities;
