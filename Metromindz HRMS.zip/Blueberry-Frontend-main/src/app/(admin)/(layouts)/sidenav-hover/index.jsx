import PageMeta from '@/components/PageMeta';
import SidenavHover from './components/SidenavHover';
const Index = () => {
  return <>
      <PageMeta title="Hover View Sidenav" />
      <main>
        <SidenavHover />
      </main>
    </>;
};
export default Index;