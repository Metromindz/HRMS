import PageMeta from '@/components/PageMeta';
import SideCompact from './components/SideCompact';
const Index = () => {
  return <>
      <PageMeta title="Compact Sidenav" />
      <main>
        <SideCompact />
      </main>
    </>;
};
export default Index;