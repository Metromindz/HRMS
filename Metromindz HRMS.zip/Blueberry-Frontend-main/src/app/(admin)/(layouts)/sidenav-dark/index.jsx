import PageMeta from '@/components/PageMeta';
import SideDark from './components/SideDark';
const Index = () => {
  return <>
      <PageMeta title="Sidenav Dark" />
      <main>
        <SideDark />
      </main>
    </>;
};
export default Index;