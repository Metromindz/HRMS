import { createContext, useContext, useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';
import api from '@/config/api';
import toast from 'react-hot-toast';

const NotificationContext = createContext();

export const useNotifications = () => useContext(NotificationContext);

export const NotificationProvider = ({ children }) => {
  const { user } = useAuth();
  const [socket, setSocket] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);

  // Initialize Socket
  useEffect(() => {
    if (user) {
        // Extract base URL from API config
        // If VITE_API_BASE_URL is "http://localhost:5000/api", we want "http://localhost:5000"
        const apiUrl = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';
        let socketUrl;
        try {
          socketUrl = new URL(apiUrl).origin;
        } catch {
          socketUrl = 'http://localhost:5000';
        }

        const token = localStorage.getItem('token') || sessionStorage.getItem('token');
        const newSocket = io(socketUrl, {
          auth: { token }
        });

        setSocket(newSocket);

        newSocket.on('connect', () => {
            console.log('Socket connected');
        });

        newSocket.on('new-notification', (notification) => {
             // Check if this notification is for me
             if (notification.recipientId === user._id) {
                 setNotifications(prev => [notification, ...prev]);
                 setUnreadCount(prev => prev + 1);
                 
                 // Show toast
                 toast(notification.title, {
                    icon: '🔔',
                    duration: 4000,
                 });
             }
        });

        return () => {
            newSocket.disconnect();
        };
    }
  }, [user]);

  // Fetch initial notifications
  useEffect(() => {
      if (user) {
          fetchNotifications();
          fetchUnreadCount();
      }
  }, [user]);

  const fetchNotifications = async () => {
      try {
          const res = await api.get('/notifications');
          if (res.data && res.data.notifications) {
            setNotifications(res.data.notifications);
          }
      } catch (err) {
          console.error("Error fetching notifications", err);
      }
  };

  const fetchUnreadCount = async () => {
      try {
          const res = await api.get('/notifications/unread-count');
          if (res.data) {
            setUnreadCount(res.data.unreadCount);
          }
      } catch (err) {
           console.error("Error fetching unread count", err);
      }
  };

  const markAsRead = async (notificationId) => {
      try {
          await api.patch(`/notifications/read?notificationId=${notificationId}`);
          
          setNotifications(prev => prev.map(n => {
              if (n._id === notificationId) {
                  // Check if user already read it to avoid duplicate entries if logic was different
                  const alreadyRead = n.isRead?.some(r => r.userId === user._id);
                  if (!alreadyRead) {
                      return { 
                          ...n, 
                          isRead: [...(n.isRead || []), { userId: user._id, readAt: new Date() }] 
                      };
                  }
              }
              return n;
          }));
          
          // Refresh count
          fetchUnreadCount();
      } catch (err) {
          console.error("Error marking as read", err);
      }
  };

  return (
    <NotificationContext.Provider value={{ socket, notifications, unreadCount, markAsRead, fetchNotifications }}>
      {children}
    </NotificationContext.Provider>
  );
};
