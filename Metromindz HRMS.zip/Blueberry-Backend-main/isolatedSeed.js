import mongoose from "mongoose";
import dotenv from "dotenv";

dotenv.config();

const widgetSchema = new mongoose.Schema({
    key: { type: String, required: true, unique: true },
    label: { type: String, required: true },
    description: { type: String },
    module: { type: String },
    icon: { type: String },
    roles: { type: [String], default: ["superadmin", "admin"] },
    status: { type: String, enum: ["active", "inactive"], default: "active" },
    order: { type: Number, default: 0 },
    config: { type: mongoose.Schema.Types.Mixed, default: {} }
}, { timestamps: true });

const Widget = mongoose.model("Widget", widgetSchema);

const seed = async () => {
    try {
        if (!process.env.MONGO_URI) {
            console.error("MONGO_URI not found in .env");
            process.exit(1);
        }
        await mongoose.connect(process.env.MONGO_URI);
        console.log("Connected to MongoDB for isolated seeding...");

        const initialWidgets = [
            { key: "profile_card", label: "Employee Profile", module: "HR", roles: ["superadmin", "admin", "employee"], order: 1, icon: "LuUser" },
            { key: "attendance_widget", label: "Attendance Control", module: "HR", roles: ["superadmin", "admin", "employee"], order: 2, icon: "LuClock" },
            { key: "notifications_panel", label: "Notifications", module: "Dashboard", roles: ["superadmin", "admin", "employee"], order: 3, icon: "LuBell" },
            { key: "announcements_widget", label: "Announcements Widget", module: "HR", roles: ["superadmin", "admin", "employee"], order: 4, icon: "LuMegaphone" },
            { key: "task_board_widget", label: "Task Board", module: "Task", roles: ["superadmin", "admin", "employee"], order: 5, icon: "LuLayout" },
            { key: "today_priorities_widget", label: "Today Priorities", module: "Task", roles: ["superadmin", "admin", "employee"], order: 6, icon: "LuListTodo" },
            { key: "employee_task_summary", label: "Employee Task Summary", module: "Task", roles: ["superadmin", "admin", "employee"], order: 7, icon: "LuCheckCircle" },
            { key: "employee_performance", label: "Employee Performance", module: "HR", roles: ["superadmin", "admin", "employee"], order: 8, icon: "LuTrendingUp" },
            { key: "activity_logs", label: "Activity Logs", module: "Dashboard", roles: ["superadmin", "admin"], order: 9, icon: "LuListChecks" },
            { key: "upcoming_birthdays", label: "Upcoming Birthdays", module: "HR", roles: ["superadmin", "admin"], order: 10, icon: "LuCalendar" },
            { key: "task_status_overview", label: "Task Status Distribution", module: "Task", roles: ["superadmin", "admin"], order: 11, icon: "LuBarChart2" },
            { key: "task_completion_trend", label: "Task Completion Trend", module: "Task", roles: ["superadmin", "admin"], order: 12, icon: "LuAreaChart" },
            { key: "leads_overview", label: "Leads Overview Chart", module: "Lead", roles: ["superadmin", "admin"], order: 13, icon: "LuTrendingUp" },
            { key: "project_status", label: "Project Status Chart", module: "Project", roles: ["superadmin", "admin"], order: 14, icon: "LuBriefcase" },
            { key: "workforce_overview", label: "Workforce Overview", module: "HR", roles: ["superadmin", "admin"], order: 15, icon: "LuUsers" }
        ];

        for (const w of initialWidgets) {
            await Widget.findOneAndUpdate({ key: w.key }, w, { upsert: true, new: true });
        }

        console.log("Isolated seeding complete!");
        process.exit(0);
    } catch (error) {
        console.error("Isolated seeding failed:", error);
        process.exit(1);
    }
};

seed();
