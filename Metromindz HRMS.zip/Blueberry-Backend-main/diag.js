import mongoose from "mongoose";
import dotenv from "dotenv";

dotenv.config();

const widgetSchema = new mongoose.Schema({
    key: String,
    label: String,
    roles: [String],
    status: String
}, { strict: false });

const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    role: String
}, { strict: false });

const Widget = mongoose.model("Widget", widgetSchema);
const User = mongoose.model("User", userSchema);

const dump = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log("Connected to MongoDB...");

        const widgets = await Widget.find({ status: "active" });
        console.log("\n--- Active Widgets ---");
        widgets.forEach(w => {
            console.log(`Key: ${w.key}, Roles: [${w.roles.join(", ")}], Status: ${w.status}`);
        });

        const users = await User.find().limit(10);
        console.log("\n--- Users (First 10) ---");
        users.forEach(u => {
            console.log(`Email: ${u.email}, Role: "${u.role}"`);
        });

        process.exit(0);
    } catch (error) {
        console.error("Dump failed:", error);
        process.exit(1);
    }
};

dump();
