import cookieParser from "cookie-parser";
import cors from "cors";
import dotenv from "dotenv";
import express from "express";
import http from "http";
import path from "path";
import { Server } from "socket.io";
import { fileURLToPath } from "url";
import mongoose from "mongoose";
import jwt from "jsonwebtoken";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import connectDB from "./src/config/db.js";
import hrRoutes from "./src/routes/hrRoutes.js";
import authRoutes from "./src/routes/authRoutes.js";
import permissionRoutes from "./src/routes/permissionRoutes.js";
import notificationRoutes from "./src/routes/notificationRoutes.js";
import departmentRoutes from "./src/routes/departmentRoutes.js";
import designationRoutes from "./src/routes/designationRoutes.js";
import holidayRoutes from "./src/routes/holidayRoutes.js";
import activityLogRoutes from "./src/routes/activityLogRoutes.js";
import gradeRoutes from "./src/routes/gradeRoutes.js";
import leaveRoutes from "./src/routes/leaveMasterRoutes.js";
import shiftRoutes from "./src/routes/shiftRoutes.js";
import attendanceRoutes from "./src/routes/attendanceRoutes.js";
import paySlipRoutes from "./src/routes/paySlipRoutes.js";
import leaveBalanceRoutes from "./src/routes/leaveBalanceRoutes.js";
import leaveRequestsRoutes from "./src/routes/leaveRequestsRoutes.js";
import leaveReportsRoutes from "./src/routes/leaveReportsRoutes.js";
import dashboardRoutes from "./src/routes/dashboardRoutes.js";
import staticRoutes from "./src/routes/staticRoutes.js";
import companyRoutes from "./src/routes/companyRoutes.js";
import rolePermissionRoutes from "./src/routes/rolePermissionRoutes.js";
import projectRoutes from "./src/routes/projectRoutes.js";
import taskRoutes from "./src/routes/taskRoutes.js";
import leadRoutes from "./src/routes/leadRoutes.js";
import expenseRoutes from "./src/routes/expenseRoutes.js";
import announcementRoutes from "./src/routes/announcementRoutes.js";
import widgetRoutes from "./src/routes/widgetRoutes.js";
import Widget from "./src/models/Widget.js";
import { startCleanupJob } from "./src/jobs/cleanupActivityLogs.js";
import { startLeadFollowUpReminderJob } from "./src/jobs/leadFollowUpReminders.js";
import { startNotificationCleanupJob } from "./src/jobs/cleanupNotifications.js";

dotenv.config();
// Connect to MongoDB
connectDB();

const ensureDefaultWidgets = async () => {
  const defaults = [
    {
      key: "today_priorities_widget",
      label: "Today Priorities",
      description: "Today priorities widget",
      module: "Dashboard",
      order: 70,
      status: "active",
    },
    {
      key: "task_board_widget",
      label: "Task Board",
      description: "Task board widget",
      module: "Dashboard",
      order: 71,
      status: "active",
    },
    {
      key: "employee_task_summary",
      label: "Employee Task Summary",
      description: "Summary of employee tasks",
      module: "Dashboard",
      order: 72,
      status: "active",
    },
    {
      key: "task_status_chart_widget",
      label: "Task Status Distribution",
      description: "Pie chart visualization of task statuses",
      module: "Dashboard",
      order: 73,
      status: "active",
    },
  ];

  for (const widget of defaults) {
    const exists = await Widget.findOne({ key: widget.key }).select("_id");
    if (!exists) {
      await Widget.create(widget);
    }
  }
};

mongoose.connection.once("open", () => {
  ensureDefaultWidgets().catch((e) => {
    console.error("Failed to ensure default widgets:", e?.message || e);
  });
});

// Start scheduled jobs
startCleanupJob();
startNotificationCleanupJob();

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(helmet({
  crossOriginResourcePolicy: false,
}));

// ✅ CORS for frontend + credentials
const allowedCorsOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',').map(o => o.trim())
  : [
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost:5175",
    "http://localhost:5176",
    "http://127.0.0.1:5173",
    "http://127.0.0.1:5174",
    "http://127.0.0.1:5175",
    "http://127.0.0.1:5176"
  ];

app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin || allowedCorsOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    },
    credentials: true,
  })
);

// Disable caching for API responses to ensure fresh data
app.use("/api", (req, res, next) => {
  res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  next();
});

// Middleware
app.use(cookieParser());
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
});
app.use("/api/auth/login", loginLimiter);

// Get __dirname equivalent
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Serve static files from ONE "uploads" folder
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Socket.io Server
const server = http.createServer(app);
const allowedSocketOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(',').map(o => o.trim())
  : [
    process.env.FRONTEND_URL,
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:5174",
    "http://127.0.0.1:5174",
  ].filter(Boolean);

const io = new Server(server, {
  cors: {
    origin: allowedSocketOrigins,
    credentials: true,
  },
});
// Authenticate sockets with JWT
io.use((socket, next) => {
  try {
    const authToken =
      socket.handshake.auth?.token ||
      socket.handshake.headers?.authorization?.split(" ")[1];
    if (!authToken) return next(new Error("unauthorized"));
    const decoded = jwt.verify(authToken, process.env.JWT_SECRET);
    socket.user = { id: decoded.id, role: decoded.role };
    return next();
  } catch (e) {
    return next(new Error("unauthorized"));
  }
});

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

app.set("io", io); // expose it to use in controllers
startLeadFollowUpReminderJob(io);

app.use("/api/hr", hrRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/permissions", permissionRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/department", departmentRoutes);
app.use("/api/designation", designationRoutes);
app.use("/api/holiday", holidayRoutes);
app.use("/api/activity-logs", activityLogRoutes);
app.use("/api/grades", gradeRoutes);
app.use("/api/leaves", leaveRoutes);
app.use("/api/shifts", shiftRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/payslip", paySlipRoutes);
app.use("/api/leave-balance", leaveBalanceRoutes);
app.use("/api/leave-requests", leaveRequestsRoutes);
app.use("/api/leave-reports", leaveReportsRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/statistics/", staticRoutes);
app.use("/api/company", companyRoutes);
app.use("/api/role-permissions", rolePermissionRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/tasks", taskRoutes);
app.use("/api/leads", leadRoutes);
app.use("/api/expenses", expenseRoutes);
app.use("/api/announcements", announcementRoutes);
app.use("/api/widgets", widgetRoutes);

// Sample route
app.get("/", (req, res) => {
  res.send("Backend Server running!");
});

const port = process.env.PORT || 5001;
server.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
