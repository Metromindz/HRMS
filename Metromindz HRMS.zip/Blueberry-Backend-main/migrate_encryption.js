import mongoose from "mongoose";
import dotenv from "dotenv";
import User from "./src/models/User.js";
import Company from "./src/models/Company.js";
import { encrypt } from "./src/utils/encryption.js";

dotenv.config();

const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/blueberry";

const runMigration = async () => {
  try {
    await mongoose.connect(MONGO_URI);
    console.log("Connected to DB for migration...");

    // 1. Encrypt Users
    const users = await User.find({});
    console.log(`Found ${users.length} users to check/encrypt.`);

    for (const user of users) {
      let modified = false;

      // Helper to encrypt plaintext fields only if they don't look like AES (starts with U2Fsd...)
      // Simple heuristic: AES output from crypto-js usually starts with 'U2Fsd' (Salted__)
      const encryptIfPlain = (val) => {
        if (val && typeof val === "string" && !val.startsWith("U2Fsd")) {
          return encrypt(val);
        }
        return val;
      };

      // Personal
      if (user.employeePersonal) {
        user.employeePersonal.contactNumber = encryptIfPlain(user.employeePersonal.contactNumber);
        user.employeePersonal.emailAddress = encryptIfPlain(user.employeePersonal.emailAddress);
        user.employeePersonal.permanentAddress = encryptIfPlain(user.employeePersonal.permanentAddress);
        user.employeePersonal.currentAddress = encryptIfPlain(user.employeePersonal.currentAddress);
        if (user.employeePersonal.emergencyContact?.number) {
            user.employeePersonal.emergencyContact.number = encryptIfPlain(user.employeePersonal.emergencyContact.number);
        }
        modified = true;
      }

      // Salary
      if (user.salaryDetails && user.salaryDetails.ctc) {
          // CTC is number in schema but encrypted as string. 
          // Note: If schema changed to string, we can store string. If it's Number, mongoose might cast fail.
          // In our updated schema, CTC is Number with set/get. 
          // Mongoose set/get runs on save. If we just save, it should encrypt automatically if we mark modified?
          // Actually, since we updated the schema with set: encrypt, calling user.save() will re-encrypt unless we are careful.
          // BUT: 'set' runs when setting a value. If value is already loaded, 'set' might not run unless modified.
          // To trigger re-encryption of plaintext, we need to explicitly set them.
          
          // Strategy: Read lean, encrypt manually, updateOne to avoid double encryption loops or schema type conflicts during migration.
      }
      
      // Since we attached 'set' getters to the schema, simple .save() might be tricky if data is already in DB.
      // Better approach for migration: Update directly using bulkWrite or atomic updates to avoid mongoose lifecycle confusion for this one-time script.
    }

    // Migration Strategy 2: Direct update using bulkOps for maximum safety/control
    // We will fetch documents as plain objects (lean), encrypt fields, and write back.
    
    const userOps = [];
    for (const user of await User.find({}).lean()) {
        const update = {};
        const set = {};

        const encryptVal = (val) => {
            if (val && typeof val === "string" && !val.startsWith("U2Fsd")) {
                return encrypt(val);
            }
            return val;
        };

        if (user.employeePersonal) {
            set["employeePersonal.contactNumber"] = encryptVal(user.employeePersonal.contactNumber);
            set["employeePersonal.emailAddress"] = encryptVal(user.employeePersonal.emailAddress);
            set["employeePersonal.permanentAddress"] = encryptVal(user.employeePersonal.permanentAddress);
            set["employeePersonal.currentAddress"] = encryptVal(user.employeePersonal.currentAddress);
            if(user.employeePersonal.emergencyContact) {
                set["employeePersonal.emergencyContact.number"] = encryptVal(user.employeePersonal.emergencyContact.number);
            }
        }

        if (user.salaryDetails) {
            // CTC is defined as Number in schema but we want to encrypt it? 
            // Wait, if we encrypt it, it becomes a string.
            // If the schema says { type: Number, set: encrypt }, mongoose expects a number input, encrypts it to string, and tries to save.
            // BUT underlying mongo field must be string to hold ciphertext.
            // Check User.js: ctc: { type: Number, ... set: encrypt } -> This will FAIL if encryption returns a non-numeric string and mongo expects double.
            // **Correction**: We need to change schema type to String for encrypted fields if they were Numbers!
            // Let's verify User.js again.
        }
        
        if (user.bankDetails) {
            set["bankDetails.accountNumber"] = encryptVal(user.bankDetails.accountNumber);
            set["bankDetails.ifscCode"] = encryptVal(user.bankDetails.ifscCode);
        }

        if (user.statutoryCompliance) {
            set["statutoryCompliance.pfNumber"] = encryptVal(user.statutoryCompliance.pfNumber);
            set["statutoryCompliance.esiNumber"] = encryptVal(user.statutoryCompliance.esiNumber);
            set["statutoryCompliance.panNumber"] = encryptVal(user.statutoryCompliance.panNumber);
            set["statutoryCompliance.aadhaarNumber"] = encryptVal(user.statutoryCompliance.aadhaarNumber);
        }

        if (Object.keys(set).length > 0) {
            userOps.push({
                updateOne: {
                    filter: { _id: user._id },
                    update: { $set: set }
                }
            });
        }
    }

    if (userOps.length > 0) {
        console.log(`Migrating ${userOps.length} users...`);
        await User.bulkWrite(userOps);
        console.log("Users migrated.");
    } else {
        console.log("No users needed migration.");
    }

    // 2. Encrypt Companies
    const companies = await Company.find({}).lean();
    const companyOps = [];
    
    for (const comp of companies) {
        const set = {};
        const encryptVal = (val) => {
             if (val && typeof val === "string" && !val.startsWith("U2Fsd")) {
                return encrypt(val);
            }
            return val;
        };

        set["gstNumber"] = encryptVal(comp.gstNumber);
        set["panNumber"] = encryptVal(comp.panNumber);
        set["contactPersonEmail"] = encryptVal(comp.contactPersonEmail);
        set["contactPersonPhone"] = encryptVal(comp.contactPersonPhone);

        if (Object.keys(set).length > 0) {
            companyOps.push({
                updateOne: {
                    filter: { _id: comp._id },
                    update: { $set: set }
                }
            });
        }
    }

    if (companyOps.length > 0) {
        console.log(`Migrating ${companyOps.length} companies...`);
        await Company.bulkWrite(companyOps);
        console.log("Companies migrated.");
    }

    console.log("Migration complete.");
    process.exit(0);

  } catch (error) {
    console.error("Migration failed:", error);
    process.exit(1);
  }
};

runMigration();
