import dotenv from "dotenv";
import connectDB from "../src/config/db.js";
import Permission from "../src/models/Permission.js";

dotenv.config();

const permissions = [
  //Dashbaord
  // {module: "Dashbaord", label: "View", key: "dashboard.view", description: "View dashboard"},

  // 🔹 Employee
  { module: "Employee", label: "Create", key: "employee.create", description: "Create new employee" },
  { module: "Employee", label: "Edit", key: "employee.edit", description: "Edit employee details" },
  { module: "Employee", label: "Delete", key: "employee.delete", description: "Delete an employee" },
  { module: "Employee", label: "View All", key: "employee.view", description: "View all employees" },
  { module: "Employee", label: "View One", key: "employee.view_one", description: "View single employee details" },
  { module: "Employee", label: "Status", key: "employee.status", description: "Changing the status of emp" },

  { module: "Employee", label: "Import", key: "employee.import", description: "Import employee details" },
  // { module: "Employee", label: "Export", key: "employee.export", description: "Export employee details" },

  // Leave
  { module: "Leave", label: "Create", key: "leave.create", description: "Create new leave" },
  // {module: "Leave", label: "Edit", key: "leave.edit", description: "Edit leave"},
  { module: "Leave", label: "View", key: "leave.view", description: "View all leave" },
  // {module: "Leave", label: "Delete", key: "leave.delete", description: "Delete a leave"},
  { module: "Leave", label: "Status", key: "leave.status", description: "Change a status" },
  // {module: "Leave", label: "Export", key: "leave.export", description: "Export leave report"},

  //Attendance
  { module: "Attendance", label: "Punch View", key: 'attendance.punch.view', description: "View all attendance" },
  { module: "Attendance", label: "View", key: 'attendance.calendar.view', description: "View all callender" },
  { module: "Attendance", label: "Import", key: 'attendance.import', description: "Export attendance report" },

  //Payroll
  { module: 'Payroll', label: "Employee salary", key: 'payroll.salary.view', description: "View all employee salary" },
  { module: 'Payroll', label: "Generate", key: 'payroll.generate.view', description: "Generating employee salary" },

  // Company
  { module: "Company", label: "Create", key: "company.create", description: "Create company" },
  { module: "Company", label: "Edit", key: "company.edit", description: "Edit company" },
  { module: "Company", label: "Delete", key: "company.delete", description: "Delete company" },
  { module: "Company", label: "View", key: "company.view", description: "View companies" },

  // Project
  { module: "Project", label: "Create", key: "project.create", description: "Create project" },
  { module: "Project", label: "Edit", key: "project.edit", description: "Edit project" },
  { module: "Project", label: "Delete", key: "project.delete", description: "Delete project" },
  { module: "Project", label: "View", key: "project.view", description: "View projects" },
  { module: "Project", label: "Export", key: "project.export", description: "Export projects" },
  { module: "Project", label: "Assign Developers", key: "project.assign", description: "Assign developers to projects" },


  //Master Setting
  { module: "Holidays", label: "View", key: "holidays.view", description: "View holidays setting" },
  { module: "Holidays", label: "Create", key: "holidays.create", description: "Create holidays setting" },
  { module: "Holidays", label: "Edit", key: "holidays.edit", description: "Edit holidays setting" },
  { module: "Holidays", label: "Delete", key: "holidays.delete", description: "Delete holidays setting" },
  // {module: "Holidays", label: "Export", key: "holidays.export", description: "Export holidays setting"},

  // Department
  { module: "Department", label: "Create", key: "department.create", description: "Create new department" },
  { module: "Department", label: "Edit", key: "department.edit", description: "Edit department" },
  { module: "Department", label: "View", key: "department.view", description: "View all department" },
  { module: "Department", label: "Delete", key: "department.delete", description: "Delete a department" },

  // Designation
  { module: "Designation", label: "Create", key: "designation.create", description: "Create new designation" },
  { module: "Designation", label: "Edit", key: "designation.edit", description: "Edit designation" },
  { module: "Designation", label: "View", key: "designation.view", description: "View all designation" },
  { module: "Designation", label: "Delete", key: "designation.delete", description: "Delete a designation" },

  //Grade
  { module: "Grade", label: "Create", key: "grade.create", description: "Create Grade setting" },
  { module: "Grade", label: "Edit", key: "grade.edit", description: "Edit Grade setting" },
  { module: "Grade", label: "View", key: "grade.view", description: "View Grade setting" },
  { module: "Grade", label: "Delete", key: "grade.delete", description: "Delete Grade setting" },

  //Grade
  { module: "Shift", label: "Create", key: "shift.create", description: "Create Shift setting" },
  { module: "Shift", label: "Edit", key: "shift.edit", description: "Edit Shift setting" },
  { module: "Shift", label: "View", key: "shift.view", description: "View Shift setting" },
  { module: "Shift", label: "Delete", key: "shift.delete", description: "Delete Shift setting" },

  // common setting leave
  { module: "Commonleave", label: "Create", key: "commonleave.create", description: "Create Shift setting" },
  { module: "Commonleave", label: "Edit", key: "commonleave.edit", description: "Edit Shift setting" },
  { module: "Commonleave", label: "View", key: "commonleave.view", description: "View Shift setting" },
  { module: "Commonleave", label: "Delete", key: "commonleave.delete", description: "Delete Shift setting" },

  // Task
  { module: "Task", label: "Create", key: "task.create", description: "Create task" },
  { module: "Task", label: "Edit", key: "task.edit", description: "Edit task" },
  { module: "Task", label: "Delete", key: "task.delete", description: "Delete task" },
  { module: "Task", label: "View", key: "task.view", description: "View tasks" },
  { module: "Task", label: "Export", key: "task.export", description: "Export tasks" },
  { module: "Task", label: "Assign", key: "task.assign", description: "Assign tasks" },

  // Expense
  { module: "Expense", label: "Submit", key: "expense.submit", description: "Submit an expense" },
  { module: "Expense", label: "View My", key: "expense.view_my", description: "View own expenses" },
  { module: "Expense", label: "View All", key: "expense.view_all", description: "View all expenses (Admin/HR)" },
  { module: "Expense", label: "Approve", key: "expense.approve", description: "Approve/Reject expenses" },

  // Announcement
  { module: "Announcement", label: "View", key: "announcement.view", description: "View announcements" },
  { module: "Announcement", label: "Create", key: "announcement.create", description: "Create announcements" },
  { module: "Announcement", label: "Delete", key: "announcement.delete", description: "Delete announcements" },
];

const seedPermissions = async () => {
  try {
    await connectDB();
    console.log("🌱 Connected to MongoDB");

    await Permission.deleteMany(); // clear old data
    await Permission.insertMany(permissions);

    console.log(`✅ Inserted ${permissions.length} permissions successfully`);
    process.exit();
  } catch (error) {
    console.error("❌ Seeding failed:", error);
    process.exit(1);
  }
};

seedPermissions();
