import dotenv from "dotenv";
import mongoose from "mongoose";

dotenv.config();

const run = async () => {
  try {
    const uri = process.env.MONGO_URI;
    await mongoose.connect(uri, {});
    const db = mongoose.connection.db;
    const superAdmins = await db.collection("users").find({ role: "superadmin" }).toArray();
    if (superAdmins.length > 0) {
      console.log("SuperAdmins found:", superAdmins.map(u => u.email));
    } else {
      console.log("No superadmin found.");
    }
  } catch (e) {
    console.error("Error:", e);
  } finally {
    await mongoose.disconnect();
  }
};

run();
