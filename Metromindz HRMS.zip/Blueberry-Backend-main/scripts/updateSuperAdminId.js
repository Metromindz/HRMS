import dotenv from "dotenv";
import mongoose from "mongoose";

dotenv.config();

const run = async () => {
  try {
    const uri = process.env.MONGO_URI;
    await mongoose.connect(uri, {});
    const db = mongoose.connection.db;

    const email = "admin@admin.com";
    const employeeId = "SA-001";

    const result = await db.collection("users").updateOne(
      { email: email },
      { 
        $set: { 
          employeeId: employeeId,
          "employmentDetails.employeeId": employeeId 
        } 
      }
    );

    if (result.matchedCount > 0) {
      console.log(`Successfully updated SuperAdmin (${email}) with employeeId: ${employeeId}`);
    } else {
      console.log("SuperAdmin not found with email:", email);
    }

  } catch (e) {
    console.error("Error:", e);
  } finally {
    await mongoose.disconnect();
  }
};

run();
