import dotenv from "dotenv";
import mongoose from "mongoose";
import User from "../src/models/User.js";
import connectDB from "../src/config/db.js";

dotenv.config();

const run = async () => {
    try {
        await connectDB();
        console.log("✅ Connected to MongoDB");

        const email = "employee@company.com";
        const password = "Employee@123";
        const baseEmployeeId = "EMP_TEST_";
        const employeeId = baseEmployeeId + Date.now();

        let user = await User.findOne({ email });

        if (user) {
            console.log("User exists. Updating password...");
            user.password = password;
            user.role = "Employee";
            user.status = "active";
            await user.save();
            console.log("✅ User updated successfully");
        } else {
            console.log("Creating new user...");
            user = new User({
                name: "Test Employee",
                email,
                employeeId,
                password,
                role: "Employee",
                status: "active",
                employeePersonal: {
                    fullName: "Test Employee",
                    emailAddress: email,
                    contactNumber: "9876543210",
                },
                employmentDetails: {
                    department: { name: "IT" },
                    designation: { name: "Developer" },
                    joiningDate: new Date(),
                }
            });
            await user.save();
            console.log(`✅ User created successfully with ID: ${employeeId}`);
        }

        process.exit(0);
    } catch (error) {
        console.error("Error:", error);
        process.exit(1);
    }
};

run();
