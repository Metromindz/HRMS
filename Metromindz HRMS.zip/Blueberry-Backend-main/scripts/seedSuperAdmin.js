import dotenv from "dotenv";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";

dotenv.config();

const run = async () => {
  try {
    const uri = process.env.MONGO_URI;
    if (!uri) {
      console.error("MONGO_URI is not set");
      process.exit(1);
    }

    await mongoose.connect(uri, {});
    const db = mongoose.connection.db;

    // Check if superadmin already exists
    const existingSuperAdmin = await db.collection("users").findOne({ role: "superadmin" });
    if (existingSuperAdmin) {
      console.log("Superadmin already exists:", existingSuperAdmin.email);
      process.exit(0);
    }

    const email = "superadmin@company.com";
    const password = "Admin@123";
    const name = "Super Admin";
    const role = "superadmin";

    const hash = await bcrypt.hash(password, 10);

    await db.collection("users").insertOne({
      name,
      email,
      password: hash,
      role,
      permissions: [], // Superadmin usually has access to all by role check
      status: "active",
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    console.log("Superadmin created successfully!");
    console.log("Email:", email);
    console.log("Password:", password);

  } catch (e) {
    console.error("Error:", e?.message || e);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
  }
};

run();
