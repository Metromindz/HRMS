import dotenv from "dotenv";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";

dotenv.config();

const run = async () => {
  try {
    const uri = process.env.MONGO_URI;
    if (!uri) {
      console.error("MONGO_URI is not set");
      process.exit(1);
    }

    await mongoose.connect(uri, {});
    const db = mongoose.connection.db;

    const superAdmin = await db.collection("users").findOne({ email: "superadmin@company.com" });
    if (!superAdmin) {
      console.error("No superadmin found with email superadmin@company.com");
      process.exit(1);
    }

    const newPassword = "Admin@123";
    const hash = await bcrypt.hash(newPassword, 10);

    await db
      .collection("users")
      .updateOne({ _id: superAdmin._id }, { $set: { password: hash } });

    console.log(
      JSON.stringify({
        updated: true,
        email: superAdmin.email,
        name: superAdmin.name,
        password: newPassword,
      })
    );
  } catch (e) {
    console.error("Error:", e?.message || e);
    process.exit(1);
  } finally {
    try {
      await mongoose.disconnect();
    } catch { }
  }
};

run();
