import Expense from "../models/Expense.js";
import User from "../models/User.js";
import { createActivityLog } from "./activityLogController.js";
import { createNotification } from "./notificationController.js";

/**
 * @desc Create new expense submission
 * @route POST /api/expenses
 * @access Private (Employee)
 */
export const createExpense = async (req, res) => {
  try {
    const { title, category, amount, date, description } = req.body;
    const employeeId = req.user?.id || req.user?._id;
    const user = employeeId ? await User.findById(employeeId) : null;

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    if (!user.employeeId) {
      return res.status(400).json({ success: false, message: "Employee ID not set for this user" });
    }

    const expense = new Expense({
      employee: employeeId,
      employeeId: user.employeeId,
      title,
      category,
      amount,
      date,
      description,
      receiptUrl: req.file ? `/uploads/documents/${req.file.filename}` : null,
    });

    await expense.save();
    
    await createActivityLog(
      employeeId,
      "Expense Submitted",
      `Submitted an expense for ${category}: ${title} (Amount: ${amount})`
    );

    res.status(201).json({ success: true, data: expense });
  } catch (error) {
    console.error("Create Expense Error:", error);
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc Create expense for an employee (Admin/HR)
 * @route POST /api/expenses/admin
 * @access Private (Admin/HR)
 */
export const createExpenseForEmployee = async (req, res) => {
  try {
    const { employeeUserId, title, category, amount, date, description } = req.body;
    if (!employeeUserId) {
      return res.status(400).json({ success: false, message: "Employee is required" });
    }

    const employeeUser = await User.findById(employeeUserId).select("_id name employeeId role");
    if (!employeeUser) {
      return res.status(404).json({ success: false, message: "Employee not found" });
    }
    if (!employeeUser.employeeId) {
      return res.status(400).json({ success: false, message: "Selected employee has no employeeId" });
    }
    if (employeeUser.role === "superadmin") {
      return res.status(400).json({ success: false, message: "Cannot create expense for superadmin" });
    }

    const expense = new Expense({
      employee: employeeUser._id,
      employeeId: employeeUser.employeeId,
      title,
      category,
      amount,
      date,
      description,
      receiptUrl: req.file ? `/uploads/documents/${req.file.filename}` : null,
    });

    await expense.save();

    const adminId = req.user?.id || req.user?._id;
    if (adminId) {
      await createActivityLog(
        adminId,
        "Expense Generated",
        `Generated an expense for ${employeeUser.employeeId}: ${title} (Amount: ${amount})`
      );
    }

    await createNotification({
      recipient: employeeUser._id,
      title: "Expense Created",
      message: `An expense "${title}" has been created for you.`,
      type: "info",
    });

    const populated = await Expense.findById(expense._id).populate("employee", "name email employeeId");
    res.status(201).json({ success: true, data: populated });
  } catch (error) {
    console.error("Create Expense For Employee Error:", error);
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc Get expenses for logged-in employee
 * @route GET /api/expenses/my
 * @access Private (Employee)
 */
export const getMyExpenses = async (req, res) => {
  try {
    const expenses = await Expense.find({ employee: req.user.id }).sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: expenses });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc Get all expenses for admin/HR
 * @route GET /api/expenses
 * @access Private (Admin/HR)
 */
export const getAllExpenses = async (req, res) => {
  try {
    const expenses = await Expense.find()
      .populate("employee", "name email employeeId")
      .sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: expenses });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc Update expense status (Approve/Reject)
 * @route PATCH /api/expenses/:id/status
 * @access Private (Admin/HR)
 */
export const updateExpenseStatus = async (req, res) => {
  try {
    const { status, rejectionReason } = req.body;
    const { id } = req.params;

    const expense = await Expense.findById(id);
    if (!expense) {
      return res.status(404).json({ success: false, message: "Expense not found" });
    }

    expense.status = status;
    if (status === "Approved") {
      expense.approvedBy = req.user.id;
      expense.approvedAt = new Date();
    } else if (status === "Rejected") {
      expense.rejectionReason = rejectionReason;
    }

    await expense.save();

    // Notify employee
    await createNotification({
      recipient: expense.employee,
      title: `Expense ${status}`,
      message: `Your expense for ${expense.title} has been ${status.toLowerCase()}.`,
      type: status === "Approved" ? "success" : "error",
    });

    await createActivityLog(
      req.user.id,
      `Expense ${status}`,
      `${status} expense for ${expense.employeeId}: ${expense.title}`
    );

    res.status(200).json({ success: true, data: expense });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc Update expense (Only if Pending)
 * @route PUT /api/expenses/:id
 * @access Private (Employee)
 */
export const updateExpense = async (req, res) => {
  try {
    const { title, category, amount, date, description } = req.body;
    const expense = await Expense.findById(req.params.id);

    if (!expense) {
      return res.status(404).json({ success: false, message: "Expense not found" });
    }

    if (expense.employee.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: "Unauthorized" });
    }

    if (expense.status !== "Pending") {
      return res.status(400).json({ success: false, message: "Cannot edit approved/rejected expense" });
    }

    expense.title = title || expense.title;
    expense.category = category || expense.category;
    expense.amount = amount || expense.amount;
    expense.date = date || expense.date;
    expense.description = description || expense.description;

    if (req.file) {
      expense.receiptUrl = `/uploads/documents/${req.file.filename}`;
    }

    await expense.save();
    res.status(200).json({ success: true, data: expense });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

/**
 * @desc Delete expense (Only if Pending)
 * @route DELETE /api/expenses/:id
 * @access Private (Employee)
 */
export const deleteExpense = async (req, res) => {
  try {
    const expense = await Expense.findById(req.params.id);

    if (!expense) {
      return res.status(404).json({ success: false, message: "Expense not found" });
    }

    if (expense.employee.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: "Unauthorized" });
    }

    if (expense.status !== "Pending") {
      return res.status(400).json({ success: false, message: "Cannot delete approved/rejected expense" });
    }

    await expense.deleteOne();
    res.status(200).json({ success: true, message: "Expense deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
