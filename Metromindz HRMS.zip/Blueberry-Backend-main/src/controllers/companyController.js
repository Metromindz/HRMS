import mongoose from "mongoose";
import Company from "../models/Company.js";
import Project from "../models/Project.js";
import xlsx from "xlsx";

export const createCompany = async (req, res) => {
  try {
    const { 
      companyId, 
      name, 
      companyType, 
      industry, 
      email, 
      phone, 
      alternatePhone, 
      website, 
      addressLine1, 
      addressLine2, 
      city, 
      state, 
      country, 
      pincode, 
      gstNumber, 
      panNumber, 
      contactPersonName, 
      designation, 
      contactPersonEmail, 
      contactPersonPhone, 
      projects = 0, 
      totalCost = 0 
    } = req.body;

    let logo = null;
    if (req.file) {
      logo = `uploads/documents/${req.file.filename}`;
    }

    // Validate required fields
    if (
      !name || 
      !email || 
      !phone || 
      !companyType || 
      !addressLine1 || 
      !city || 
      !state || 
      !country || 
      !pincode || 
      !contactPersonName || 
      !contactPersonEmail || 
      !contactPersonPhone
    ) {
      return res.status(400).json({ message: "All mandatory fields are required." });
    }

    // Ensure email unique
    const emailExists = await Company.findOne({ email });
    if (emailExists) return res.status(400).json({ message: "Company email already exists" });

    // Generate companyId if not provided
    let finalCompanyId = companyId?.trim();
    if (!finalCompanyId) {
      // Find max numeric suffix among existing IDs with CMP-###
      const latest = await Company.findOne({ companyId: { $regex: /^CMP-\d+$/ } })
        .sort({ createdAt: -1 })
        .select("companyId");
      let nextNum = 1;
      if (latest?.companyId) {
        const match = latest.companyId.match(/^CMP-(\d+)$/);
        if (match) nextNum = parseInt(match[1], 10) + 1;
      } else {
        // Fallback: check all to get max, in case createdAt sorting isn't numeric order
        const allIds = await Company.find({ companyId: { $regex: /^CMP-\d+$/ } }).select("companyId");
        const maxNum = allIds.reduce((max, c) => {
          const m = c.companyId.match(/^CMP-(\d+)$/);
          const n = m ? parseInt(m[1], 10) : 0;
          return Math.max(max, n);
        }, 0);
        nextNum = maxNum + 1;
      }
      finalCompanyId = `CMP-${String(nextNum).padStart(3, "0")}`;
    } else {
      // If provided, ensure not duplicated
      const idExists = await Company.findOne({ companyId: finalCompanyId });
      if (idExists) return res.status(400).json({ message: "Company ID already exists" });
    }

    const company = await Company.create({
      companyId: finalCompanyId,
      logo,
      name,
      companyType,
      industry,
      email,
      phone,
      alternatePhone,
      website,
      addressLine1,
      addressLine2,
      city,
      state,
      country,
      pincode,
      gstNumber,
      panNumber,
      contactPersonName,
      designation,
      contactPersonEmail,
      contactPersonPhone,
      projects,
      totalCost,
    });
    res.status(201).json({ success: true, company });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const listCompanies = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = "" } = req.query;
    const p = Math.max(parseInt(page), 1);
    const l = Math.max(parseInt(limit), 1);
    const skip = (p - 1) * l;
    const q = search
      ? {
        $or: [
          { name: { $regex: search, $options: "i" } },
          { companyId: { $regex: search, $options: "i" } },
          { email: { $regex: search, $options: "i" } },
        ],
      }
      : {};
    const [companies, total, companyIds] = await Promise.all([
      Company.find(q).sort({ createdAt: -1 }).skip(skip).limit(l).lean(),
      Company.countDocuments(q),
      Company.distinct("_id", q),
    ]);

    const items = await Promise.all(companies.map(async (c) => {
      const stats = await Project.aggregate([
        { $match: { company: c._id } },
        { 
          $group: { 
            _id: null, 
            count: { $sum: 1 }, 
            totalValue: { $sum: "$projectValue" } 
          } 
        }
      ]);
      const { count = 0, totalValue = 0 } = stats[0] || {};
      return { ...c, projectCount: count, totalCost: totalValue };
    }));

    let totalRevenue = 0;
    if (companyIds.length) {
      const revenueAgg = await Project.aggregate([
        { $match: { company: { $in: companyIds } } },
        { $group: { _id: null, totalRevenue: { $sum: "$projectValue" } } },
      ]);
      totalRevenue = revenueAgg[0]?.totalRevenue || 0;
    }
    
    res.json({ success: true, items, total, totalRevenue, page: p, limit: l });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const updateCompany = async (req, res) => {
  try {
    const { id } = req.params;
    const update = req.body;
    
    if (req.file) {
      update.logo = `uploads/documents/${req.file.filename}`;
    }

    const company = await Company.findByIdAndUpdate(id, update, { new: true });
    if (!company) return res.status(404).json({ message: "Company not found" });
    res.json({ success: true, company });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const deleteCompany = async (req, res) => {
  try {
    const { id } = req.params;
    const company = await Company.findByIdAndDelete(id);
    if (!company) return res.status(404).json({ message: "Company not found" });
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const exportCompanies = async (req, res) => {
  try {
    const { format = "csv", search = "" } = req.query;
    const q = search
      ? {
        $or: [
          { name: { $regex: search, $options: "i" } },
          { companyId: { $regex: search, $options: "i" } },
          { email: { $regex: search, $options: "i" } },
        ],
      }
      : {};
    const items = await Company.find(q).sort({ createdAt: -1 }).lean();
    const rows = await Promise.all(items.map(async (c, i) => {
      const stats = await Project.aggregate([
        { $match: { company: c._id } },
        { 
          $group: { 
            _id: null, 
            count: { $sum: 1 }, 
            totalValue: { $sum: "$projectValue" } 
          } 
        }
      ]);
      const { count = 0, totalValue = 0 } = stats[0] || {};
      return {
      SlNo: i + 1,
      CompanyID: c.companyId,
      CompanyName: c.name,
      CompanyEmail: c.email,
      CompanyPhone: c.phone,
      Projects: count,
      TotalRevenue: totalValue,
    }}));
    const ws = xlsx.utils.json_to_sheet(rows);
    const wb = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, "Companies");
    if (format === "xlsx") {
      const buf = xlsx.write(wb, { type: "buffer", bookType: "xlsx" });
      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.setHeader("Content-Disposition", "attachment; filename=companies.xlsx");
      return res.send(buf);
    } else {
      const csv = xlsx.utils.sheet_to_csv(ws);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=companies.csv");
      return res.send(csv);
    }
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const getCompanyProjects = async (req, res) => {
  try {
    const { id } = req.params;
    const { page = 1, limit = 10 } = req.query;
    const p = Math.max(parseInt(page), 1);
    const l = Math.max(parseInt(limit), 1);
    const skip = (p - 1) * l;
    const company = await Company.findById(id).select("name email phone companyId");
    if (!company) return res.status(404).json({ message: "Company not found" });
    const baseQuery = { company: id };
    const q = { ...baseQuery };
    if (req.user?.role === "employee" && req.user?._id) {
      q.developers = new mongoose.Types.ObjectId(req.user._id);
    }
    const [items, total] = await Promise.all([
      Project.find(q)
        .populate("developers", "name")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(l),
      Project.countDocuments(q),
    ]);
    res.json({ success: true, company, items, total, page: p, limit: l });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const getCompanyOverview = async (req, res) => {
  try {
    const { id } = req.params;
    const company = await Company.findById(id);
    if (!company) return res.status(404).json({ message: "Company not found" });

    // 1. Projects Analysis
    const projects = await Project.find({ company: id });
    const totalProjects = projects.length;
    const completedProjects = projects.filter(p => p.status === 'completed').length;

    // 2. Tasks Analysis
    // Find all tasks linked to these projects
    const projectIds = projects.map(p => p._id);
    const tasks = await mongoose.model("Task").find({ project: { $in: projectIds } });

    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.status === 'done').length;
    const totalTimeSeconds = tasks.reduce((sum, t) => sum + (t.timeSpentSeconds || 0), 0);

    // Convert seconds to Days + Hours (assuming 8h workday for "business days" or just 24h for raw time? 
    // Requirement says "Days + Hours". Let's do raw time: 1 day = 24h for simplicity, or standard working days.
    // Usually "Time Taken" implies effort. Let's use 8h = 1d if it's effort, but standard duration is 24h.
    // Let's stick to raw duration: 
    const totalHours = Math.floor(totalTimeSeconds / 3600);
    const days = Math.floor(totalHours / 24);
    const hours = totalHours % 24;
    const timeString = `${days}d ${hours}h`;

    // 3. Financials
    const projectRevenue = projects.reduce((sum, p) => sum + (p.projectValue || 0), 0);
    const totalOrderValue = projectRevenue;
    const revenue = totalOrderValue; // Consolidated into revenue as per request

    // 4. Recent Projects (Limit 5, sorted by latest)
    const recentProjects = await Project.find({ company: id })
      .sort({ createdAt: -1 })
      .limit(5)
      .populate('developers', 'name email profilePicture'); // Populate developers for "Lead" info

    const overview = {
      company,
      metrics: {
        totalProjects,
        completedProjects,
        totalTasks,
        completedTasks,
        totalTime: timeString,
        totalOrderValue,
        revenue
      },
      recentProjects // Add to response
    };

    res.json({ success: true, ...overview });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Server error", error: e.message });
  }
};
