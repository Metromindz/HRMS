import jwt from "jsonwebtoken";
import User from "../models/User.js";
import { createActivityLog } from "./activityLogController.js";
import bcrypt from "bcryptjs";

const generateToken = (id, role, rememberMe) => {
  const expiresIn = rememberMe ? "30d" : "1d"; // longer expiry if checked
  return jwt.sign({ id, role }, process.env.JWT_SECRET, { expiresIn });
};

// Register Superadmin (only for initial setup)
export const registerSuperAdmin = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if superadmin already exists
    const existingSuperAdmin = await User.findOne({ role: "superadmin" });
    if (existingSuperAdmin) {
      return res.status(400).json({ message: "Superadmin already exists" });
    }

    const existing = await User.findOne({ email });
    if (existing)
      return res.status(400).json({ message: "Email already registered" });

    const admin = await User.create({
      name,
      email,
      password,
      employeeId: `SA-${Date.now()}`, // Add employeeId for superadmin
      role: "superadmin",
      permissions: [], // Superadmin has all permissions by default
    });

    const { password: _, ...adminData } = admin.toObject();
    res
      .status(201)
      .json({ message: "Superadmin created successfully", user: adminData });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Login for all users
// export const login = async (req, res) => {
//   try {
//     const { email, employeeId, password, rememberMe } = req.body;
//     let user;

//     // Superadmin login with email
//     if (email) {
//       user = await User.findOne({ email, role: "superadmin" });
//       if (!user)
//         return res.status(404).json({ message: "Superadmin not found" });
//     }
//     // Other users login with employeeId
//     else if (employeeId) {
//       user = await User.findOne({ employeeId, role: { $ne: "superadmin" } });
//       if (!user) return res.status(404).json({ message: "Employee not found" });
//     } else {
//       return res.status(400).json({
//         message:
//           "Email (for superadmin) or employeeId (for employees) is required",
//       });
//     }

//     const isMatch = await user.comparePassword(password);
//     if (!isMatch)
//       return res.status(401).json({ message: "Invalid credentials" });

//     const token = generateToken(user._id, user.role, rememberMe);

//     // ✅ Optionally store token in secure httpOnly cookie
//     res.cookie("authToken", token, {
//       httpOnly: true,
//       sameSite: "lax",
//       maxAge: rememberMe ? 30 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000, // 30d or 1d
//     });
//     // Log login activity
//     await createActivityLog(
//       user._id,
//       "login",
//       `${user.name} logged in`,
//       req,
//       { loginMethod: email ? 'email' : 'employeeId' }
//     );

//     const { password: _, ...userData } = user.toObject();
//     res.json({ message: "Login successful", token, user: userData });
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// };

export const login = async (req, res) => {
  try {
    const { email, employeeId, password, rememberMe } = req.body;

    let user;

    // 1️⃣ Validate input
    if (!password) {
      return res.status(400).json({ message: "Password is required" });
    }

    // 2️⃣ Superadmin login (EMAIL)
    if (email) {
      user = await User.findOne({ email, role: "superadmin" });
      if (!user) {
        return res.status(404).json({ message: "Superadmin not found" });
      }
    }

    // 3️⃣ Employee login (EMPLOYEE ID)
    else if (employeeId) {
      user = await User.findOne({
        employeeId,
        role: { $ne: "superadmin" }
      });

      if (!user) {
        return res.status(404).json({ message: "Employee not found" });
      }

      // 🔒 Block login if password not set yet
      if (user.passwordSetToken) {
        return res.status(403).json({
          message: "Please set your password using the link sent to your email"
        });
      }
    }

    else {
      return res.status(400).json({
        message: "Email (superadmin) or Employee ID (employee) is required"
      });
    }

    // 4️⃣ Compare password
    const isMatch = await user.comparePassword(password);

    if (!isMatch) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // 5️⃣ Generate JWT
    const token = generateToken(user._id, user.role, rememberMe);

    // 6️⃣ Set secure cookie
    res.cookie("authToken", token, {
      httpOnly: true,
      sameSite: "lax",
      secure: false, // set true in production with HTTPS
      maxAge: rememberMe
        ? 30 * 24 * 60 * 60 * 1000 // 30 days
        : 24 * 60 * 60 * 1000     // 1 day
    });

    // 7️⃣ Log activity
    await createActivityLog(
      user._id,
      "login",
      `${user.name} logged in`,
      req,
      { loginMethod: email ? "email" : "employeeId" }
    );

    // 8️⃣ Remove password from response
    const { password: _, ...userData } = user.toObject();

    return res.json({
      success: true,
      message: "Login successful",
      token,
      user: userData
    });

  } catch (error) {
    console.error("Login error:", error);
    return res.status(500).json({ message: "Server error" });
  }
};


// Get user profile
export const getProfile = async (req, res) => {
  try {
    const userId = req.user._id || req.user.id;
    if (!userId) {
      return res.status(400).json({ message: "User ID not found in request" });
    }
    const user = await User.findById(userId).select("-password");
    if (!user) return res.status(404).json({ message: "User not found" });

    res.json({ user });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Update user profile
export const updateProfile = async (req, res) => {
  try {
    const userId = req.user._id || req.user.id;
    const updates = req.body;

    // Fields that cannot be updated by the user directly
    const restrictedFields = [
      'role', 
      'permissions', 
      'salaryDetails', 
      'employmentDetails', // Includes designation, department, joining date etc.
      'employeeId',
      'email', // Changing email might require verification, skipping for now
      'password' // Password update should be a separate endpoint
    ];

    restrictedFields.forEach(field => delete updates[field]);

    // Update specific nested fields if provided
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found" });

    // Merge employeePersonal details carefully
    if (updates.employeePersonal) {
      user.employeePersonal = { ...user.employeePersonal, ...updates.employeePersonal };
    }

    // Merge bankDetails carefully
    if (updates.bankDetails) {
        user.bankDetails = { ...user.bankDetails, ...updates.bankDetails };
    }

    // Save the user
    await user.save();

    // Log activity
    await createActivityLog(
      userId,
      "update_profile",
      `${user.name} updated their profile`,
      req
    );

    const { password: _, ...userData } = user.toObject();
    res.json({ success: true, message: "Profile updated successfully", user: userData });

  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
