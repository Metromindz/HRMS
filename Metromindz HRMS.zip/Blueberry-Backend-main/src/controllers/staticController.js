import User from '../models/User.js';
import Designation from '../models/Designation.js';
import Department from '../models/Department.js';
import Holiday from '../models/Holiday.js';
import LeaveRequests from '../models/LeaveRequests.js';

export const getDashboardCounts = async (req, res) => {
  try {
    const employeesCount = await User.countDocuments();
        const employeesActive = await User.countDocuments({status:"active"});
    const employeesInactive = await User.countDocuments({status:"inactive"});
    const employeesProbation = await User.countDocuments({status:"probation"});
    const employeesPermanent = await User.countDocuments({status:"permanent"});
    const employeesContract = await User.countDocuments({status:"contract"});
    const employeesNotice = await User.countDocuments({status:"notice period"});
    const employeesResigned = await User.countDocuments({status:"resigned"});
        const employeesTerminated = await User.countDocuments({status:"terminated"});


    const designationsCount = await Designation.countDocuments();
    const departmentsCount = await Department.countDocuments();
    const holidaysCount = await Holiday.countDocuments();

    res.status(200).json({
      success: true,
      data: {
        totalEmployees: employeesCount,
        totalDesignations: designationsCount,
        totalDepartments: departmentsCount,
        totalHolidays: holidaysCount,
        totalActive: employeesActive,
        totalInactive: employeesInactive,
        totalProbation: employeesProbation,
        totalPermanent: employeesPermanent,
        totalContract: employeesContract,
        totalResigned: employeesResigned,
        totalTerminated: employeesTerminated,
        totalNotice: employeesNotice,
      },
      message: 'Dashboard counts retrieved successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error retrieving dashboard counts',
      error: error.message
    });
  }
};

export const getLeaveCounts = async (req, res) => {
  try {
    // Using aggregation to count applications in leaveRequests array
    const result = await LeaveRequests.aggregate([
      // Unwind the leaveRequests array first
      { $unwind: "$leaveRequests" },
      // Then unwind the applications array inside leaveRequests
      { $unwind: "$leaveRequests.applications" },
      // Group by status to get counts
      {
        $group: {
          _id: "$leaveRequests.applications.status",
          count: { $sum: 1 }
        }
      }
    ]);

    // Convert array to object for easier access
    const statusCounts = {};
    let totalApplications = 0;
    
    result.forEach(item => {      
      statusCounts[item._id] = item.count;
      totalApplications += item.count;
    });

    // Get total leave requests documents count
    const totalLeaveRequests = await LeaveRequests.countDocuments();

    const response = {
      totalLeaveRequests: totalLeaveRequests,
      totalApplications: totalApplications,
      approved: statusCounts.approved || 0,
      rejected: statusCounts.rejected || 0,
      pending: statusCounts.pending || 0,
      // Include any other statuses that might exist
      otherStatuses: statusCounts
    };

    res.status(200).json({
      success: true,
      message: "Leave counts fetched successfully",
      data: response
    });

  } catch (error) {
    console.error("Error fetching leave counts:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching leave counts",
      error: error.message
    });
  }
};