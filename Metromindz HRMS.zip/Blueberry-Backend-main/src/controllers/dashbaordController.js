// controllers/birthdayController.js
import mongoose from "mongoose";
import User from "../models/User.js";
import Company from "../models/Company.js";
import Project from "../models/Project.js";
import Task from "../models/Task.js";
import Lead from "../models/Lead.js";

export const getTaskCompletionTrend = async (req, res) => {
  try {
    const { range = 30 } = req.query;
    const days = Number(range) || 30;
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - days + 1);

    const match = { status: "done", updatedAt: { $gte: start, $lte: end } };
    if (req.user?.role?.toLowerCase() === "employee") {
      if (!req.user?.permissions?.includes("task.view")) {
        return res.json({ success: true, data: { labels: [], series: [] } });
      }
      match.assignees = new mongoose.Types.ObjectId(req.user._id);
    }

    const result = await Task.aggregate([
      { $match: match },
      {
        $group: {
          _id: {
            y: { $year: "$updatedAt" },
            m: { $month: "$updatedAt" },
            d: { $dayOfMonth: "$updatedAt" },
          },
          count: { $sum: 1 },
        },
      },
      { $sort: { "_id.y": 1, "_id.m": 1, "_id.d": 1 } },
    ]);

    const series = [];
    const labels = [];
    const cursor = new Date(start);
    const map = new Map(result.map(r => [new Date(r._id.y, r._id.m - 1, r._id.d).toDateString(), r.count]));
    while (cursor <= end) {
      const key = cursor.toDateString();
      labels.push(new Date(cursor));
      series.push(map.get(key) || 0);
      cursor.setDate(cursor.getDate() + 1);
    }

    return res.json({ success: true, data: { labels, series } });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error fetching task completion trend", error: error.message });
  }
};
export const getUpcomingBirthdays = async (req, res) => {
  try {
    const today = new Date();
    const next7 = new Date();
    next7.setDate(today.getDate() + 7);

    const users = await User.find({
      "employeePersonal.dateOfBirth": { $exists: true, $ne: "" },
    }).select(
      "employeePersonal.fullName employeePersonal.emailAddress employeePersonal.profilePhoto employeePersonal.dateOfBirth"
    );

    const upcoming = [];

    users.forEach((user) => {
      const dobString = user.employeePersonal?.dateOfBirth;
      if (!dobString) return;

      const dob = new Date(dobString);
      if (isNaN(dob)) return;

      // Birthday date for the CURRENT YEAR
      let birthdayThisYear = new Date(
        today.getFullYear(),
        dob.getMonth(),
        dob.getDate()
      );

      // If birthday already passed, shift to next year
      if (birthdayThisYear < today) {
        birthdayThisYear.setFullYear(today.getFullYear() + 1);
      }

      // Check if inside next 7 days
      if (birthdayThisYear >= today && birthdayThisYear <= next7) {
        upcoming.push({
          fullName: user.employeePersonal.fullName,
          email: user.employeePersonal.emailAddress,
          profilePhoto: user.employeePersonal.profilePhoto,
          birthday: birthdayThisYear,
        });
      }
    });

    // Sort by nearest
    upcoming.sort((a, b) => new Date(a.birthday) - new Date(b.birthday));

    return res.status(200).json({
      success: true,
      message: "Upcoming birthdays fetched successfully",
      data: upcoming,
    });
  } catch (error) {
    console.error("Error fetching upcoming birthdays:", error);
    return res.status(500).json({
      success: false,
      message: "Server error while fetching birthdays",
    });
  }
};

export const getDashboardSummary = async (req, res) => {
  try {
    const user = req.user;
    if (user?.role === "superadmin") {
      const [companies, projects, tasks, leads, activeProjects, completedTasks] = await Promise.all([
        Company.countDocuments(),
        Project.countDocuments(),
        Task.countDocuments(),
        Lead.countDocuments(),
        Project.countDocuments({ status: "in_progress" }),
        Task.countDocuments({ status: "done" }),
      ]);
      return res.json({ success: true, data: { companies, projects, tasks, leads, activeProjects, completedTasks } });
    }

    const canCompany = user?.permissions?.includes("company.view");
    const canProject = user?.permissions?.includes("project.view");
    const canTask = user?.permissions?.includes("task.view");
    const canLead = user?.permissions?.includes("lead.view");

    let companies = 0;
    let projects = 0;
    let tasks = 0;
    let leads = 0;
    let activeProjects = 0;
    let completedTasks = 0;
    let inProgressTasks = 0;
    let todoTasks = 0;
    let incompleteTasks = 0;

    if (canProject) {
      const filter = user?.role?.toLowerCase() === "employee" ? { developers: user._id } : {};
      projects = await Project.countDocuments(filter);
      activeProjects = await Project.countDocuments({ ...filter, status: "in_progress" });
    }

    if (canTask) {
      const tFilter = user?.role?.toLowerCase() === "employee" ? { assignees: user._id } : {};
      tasks = await Task.countDocuments(tFilter);
      completedTasks = await Task.countDocuments({ ...tFilter, status: "done" });
      inProgressTasks = await Task.countDocuments({ ...tFilter, status: "in_progress" });
      todoTasks = await Task.countDocuments({ ...tFilter, status: "todo" });
      incompleteTasks = await Task.countDocuments({ ...tFilter, status: { $in: ["paused", "blocked"] } });
    }

    if (canLead) {
      const lFilter = user?.role?.toLowerCase() === "employee" ? { assignedTo: user._id } : {};
      leads = await Lead.countDocuments(lFilter);
    }

    if (canCompany) {
      if (user?.role?.toLowerCase() === "employee") {
        const companyIds = await Project.distinct("company", { developers: user._id });
        companies = companyIds.length;
      } else {
        companies = await Company.countDocuments();
      }
    }

    return res.json({ success: true, data: { companies, projects, tasks, leads, activeProjects, completedTasks, inProgressTasks, todoTasks, incompleteTasks } });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error fetching dashboard summary", error: error.message });
  }
};

export const getLeadsTrend = async (req, res) => {
  try {
    const { range = 30 } = req.query;
    const days = Number(range) || 30;
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - days + 1);

    const match = { createdAt: { $gte: start, $lte: end } };
    if (req.user?.role?.toLowerCase() === "employee" && req.user?.permissions?.includes("lead.view")) {
      match.assignedTo = new mongoose.Types.ObjectId(req.user._id);
    } else if (req.user?.role?.toLowerCase() === "employee") {
      // No permission to view leads; return empty series
      return res.json({ success: true, data: { labels: [], series: [] } });
    }

    const result = await Lead.aggregate([
      { $match: match },
      {
        $group: {
          _id: {
            y: { $year: "$createdAt" },
            m: { $month: "$createdAt" },
            d: { $dayOfMonth: "$createdAt" },
          },
          count: { $sum: 1 },
        },
      },
      { $sort: { "_id.y": 1, "_id.m": 1, "_id.d": 1 } },
    ]);

    const series = [];
    const labels = [];
    const cursor = new Date(start);
    const map = new Map(result.map(r => [new Date(r._id.y, r._id.m - 1, r._id.d).toDateString(), r.count]));
    while (cursor <= end) {
      const key = cursor.toDateString();
      labels.push(new Date(cursor));
      series.push(map.get(key) || 0);
      cursor.setDate(cursor.getDate() + 1);
    }

    return res.json({ success: true, data: { labels, series } });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error fetching leads trend", error: error.message });
  }
};

export const getProjectStatus = async (req, res) => {
  try {
    const match = {};
    if (req.user?.role?.toLowerCase() === "employee") {
      if (!req.user?.permissions?.includes("project.view")) {
        return res.json({ success: true, data: { in_progress: 0, completed: 0, pending: 0, on_hold: 0 } });
      }
      match.developers = new mongoose.Types.ObjectId(req.user._id);
    }
    const agg = await Project.aggregate([{ $match: match }, { $group: { _id: "$status", count: { $sum: 1 } } }]);
    const data = {
      in_progress: 0,
      completed: 0,
      pending: 0,
      on_hold: 0,
    };
    agg.forEach(a => data[a._id] = a.count);
    return res.json({ success: true, data });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error fetching project status", error: error.message });
  }
};

export const getTaskStatus = async (req, res) => {
  try {
    const match = {};
    if (req.user?.role?.toLowerCase() === "employee") {
      if (!req.user?.permissions?.includes("task.view")) {
        return res.json({ success: true, data: { todo: 0, in_progress: 0, paused: 0, blocked: 0, done: 0 } });
      }
      match.assignees = new mongoose.Types.ObjectId(req.user._id);
    }
    // Aggregation for mutually exclusive statuses including Overdue
    const now = new Date();

    const stats = await Task.aggregate([
      { $match: match },
      {
        $project: {
          statusCategory: {
            $switch: {
              branches: [
                { case: { $eq: ["$status", "done"] }, then: "completed" },
                { case: { $eq: ["$status", "todo"] }, then: "todo" },
                {
                  case: {
                    $and: [
                      { $ne: ["$status", "done"] },
                      { $lt: ["$dueDate", now] },
                      { $ne: ["$dueDate", null] }
                    ]
                  },
                  then: "overdue"
                },
                { case: { $eq: ["$status", "in_progress"] }, then: "in_progress" },
              ],
              default: "pending" // Map blocked/paused/etc to pending if not overdue
            }
          }
        }
      },
      {
        $group: {
          _id: "$statusCategory",
          count: { $sum: 1 }
        }
      }
    ]);

    const data = {
      completed: 0,
      overdue: 0,
      in_progress: 0,
      pending: 0,
      todo: 0
    };

    stats.forEach(s => {
      if (data[s._id] !== undefined) {
        data[s._id] = s.count;
      }
    });

    return res.json({ success: true, data });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error fetching task status", error: error.message });
  }
};

export const getLeadsBySource = async (req, res) => {
  try {
    const match = {};
    if (req.user?.role?.toLowerCase() === "employee") {
      if (!req.user?.permissions?.includes("lead.view")) {
        return res.json({ success: true, data: { bySource: [], byWebsiteType: [] } });
      }
      match.assignedTo = new mongoose.Types.ObjectId(req.user._id);
    }
    const bySource = await Lead.aggregate([{ $match: match }, { $group: { _id: "$source", count: { $sum: 1 } } }, { $sort: { count: -1 } }]);
    const byWebsiteType = await Lead.aggregate([{ $match: match }, { $group: { _id: "$websiteType", count: { $sum: 1 } } }, { $sort: { count: -1 } }]);
    return res.json({ success: true, data: { bySource, byWebsiteType } });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error fetching leads sources", error: error.message });
  }
};

export const getRecentActivities = async (req, res) => {
  try {
    const u = req.user;
    const leadMatch = {};
    const projectMatch = {};
    const taskMatch = {};
    if (u?.role?.toLowerCase() === "employee") {
      if (u?.permissions?.includes("lead.view")) leadMatch.assignedTo = u._id;
      else leadMatch._id = null; // Ensure no leads are returned if no permission

      if (u?.permissions?.includes("project.view")) projectMatch.developers = u._id;
      else projectMatch._id = null; // Ensure no projects are returned if no permission

      if (u?.permissions?.includes("task.view")) taskMatch.assignees = u._id;
      else taskMatch._id = null; // Ensure no tasks are returned if no permission
    }
    const [leads, projects, tasks] = await Promise.all([
      Lead.find(leadMatch).sort({ createdAt: -1 }).limit(10).select("name status createdAt"),
      Project.find(projectMatch).sort({ createdAt: -1 }).limit(10).select("name status createdAt"),
      Task.find(taskMatch).sort({ updatedAt: -1 }).limit(10).select("title status updatedAt"),
    ]);
    return res.json({
      success: true,
      data: {
        leads,
        projects,
        tasks,
      },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error fetching recent activities", error: error.message });
  }
};

// Temporary stable summary to avoid runtime errors while advanced summary is being refactored
export const getDashboardSummary2 = async (req, res) => {
  try {
    const user = req.user;
    // Superadmin totals
    if (user?.role === "superadmin") {
      const [companies, projects, tasks, leads, activeProjects, completedTasks] = await Promise.all([
        Company.countDocuments(),
        Project.countDocuments(),
        Task.countDocuments(),
        Lead.countDocuments(),
        Project.countDocuments({ status: "in_progress" }),
        Task.countDocuments({ status: "done" }),
      ]);
      return res.json({
        success: true,
        data: { companies, projects, tasks, leads, activeProjects, completedTasks },
      });
    }

    const canCompany = user?.permissions?.includes("company.view");
    const canProject = user?.permissions?.includes("project.view");
    const canTask = user?.permissions?.includes("task.view");
    const canLead = user?.permissions?.includes("lead.view");

    let companies = 0;
    let projects = 0;
    let tasks = 0;
    let leads = 0;
    let activeProjects = 0;
    let completedTasks = 0;
    let inProgressTasks = 0;
    let todoTasks = 0;
    let incompleteTasks = 0;

    if (canProject) {
      const filter = user?.role?.toLowerCase() === "employee" ? { developers: user._id } : {};
      projects = await Project.countDocuments(filter);
      activeProjects = await Project.countDocuments({ ...filter, status: "in_progress" });
    }

    if (canTask) {
      const tFilter = user?.role?.toLowerCase() === "employee" ? { assignees: user._id } : {};
      tasks = await Task.countDocuments(tFilter);
      completedTasks = await Task.countDocuments({ ...tFilter, status: "done" });
      inProgressTasks = await Task.countDocuments({ ...tFilter, status: "in_progress" });
      todoTasks = await Task.countDocuments({ ...tFilter, status: "todo" });
      incompleteTasks = await Task.countDocuments({ ...tFilter, status: { $in: ["paused", "blocked"] } });
    }

    if (canLead) {
      const lFilter = user?.role?.toLowerCase() === "employee" ? { assignedTo: user._id } : {};
      leads = await Lead.countDocuments(lFilter);
    }

    if (canCompany) {
      if (user?.role?.toLowerCase() === "employee") {
        const companyIds = await Project.distinct("company", { developers: user._id });
        companies = companyIds.length;
      } else {
        companies = await Company.countDocuments();
      }
    }

    return res.json({
      success: true,
      data: {
        companies,
        projects,
        tasks,
        leads,
        activeProjects,
        completedTasks,
        inProgressTasks,
        todoTasks,
        incompleteTasks,
      },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: "Error fetching dashboard summary", error: error.message });
  }
};
