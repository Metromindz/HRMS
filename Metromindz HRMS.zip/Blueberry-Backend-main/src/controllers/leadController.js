import xlsx from "xlsx";
import Lead from "../models/Lead.js";
import User from "../models/User.js";
import Company from "../models/Company.js";
import mongoose from "mongoose";
import { createNotification } from "./notificationController.js";

export const listLeads = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search = "",
      status = "",
      assignedTo = "",
      dateFilterType = "createdAt",
      startDate,
      endDate,
      followUpFilter = "",
    } = req.query;
    const p = Math.max(parseInt(page), 1);
    const l = Math.max(parseInt(limit), 1);
    const skip = (p - 1) * l;
    const filter = {};
    if (status) filter.status = status;
    if (assignedTo) {
      filter.assignedTo = assignedTo;
    } else if (req.user?.role?.toLowerCase() === "employee" && req.user?._id) {
      // Employee-specific scoping: only see leads assigned to them
      filter.assignedTo = req.user._id;
    }

    if (followUpFilter === "today") {
      const start = new Date();
      start.setHours(0, 0, 0, 0);
      const end = new Date();
      end.setHours(23, 59, 59, 999);
      filter.followUps = { $elemMatch: { nextFollowUp: { $gte: start, $lte: end } } };
    }

    if (startDate || endDate) {
      const dateQuery = {};
      if (startDate) dateQuery.$gte = new Date(startDate);
      if (endDate) {
        // Set end date to end of day if it's just a date string, or use as provided
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        dateQuery.$lte = end;
      }

      if (dateFilterType === 'updatedAt') {
        filter.updatedAt = dateQuery;
      } else {
        filter.createdAt = dateQuery;
      }
    }

    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: "i" } },
        { mobile: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
      ];
    }
    const [items, total] = await Promise.all([
      Lead.find(filter)
        .populate("assignedTo", "name")
        .populate("followUps.updatedBy", "name")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(l),
      Lead.countDocuments(filter),
    ]);
    res.json({ success: true, items, total, page: p, limit: l });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

const findDup = async (mobile, email, excludeId = null) => {
  const filter = {
    $or: [],
  };
  if (mobile) filter.$or.push({ mobile });
  if (email) filter.$or.push({ email: new RegExp(`^${email}$`, "i") });
  if (excludeId) filter._id = { $ne: excludeId };
  if (filter.$or.length === 0) return null;
  return Lead.findOne(filter);
};

export const createLead = async (req, res) => {
  try {
    const { name, mobile, email = "", websiteType = "", source = "", status = "new", message = "", assignedTo = "", companyType = "Individual", companyName = "", estimatedPrice = 0 } =
      req.body;
    if (!name || !mobile) return res.status(400).json({ message: "Name and Mobile are required" });
    const dup = await findDup(mobile.trim(), email.trim());
    if (dup) return res.status(400).json({ message: "Duplicate lead (phone/email) detected" });
    const assigned =
      assignedTo && mongoose.Types.ObjectId.isValid(assignedTo) ? assignedTo : null;
    const doc = await Lead.create({
      name,
      mobile: mobile.trim(),
      email: email.trim(),
      websiteType,
      source,
      status,
      message,
      assignedTo: assigned,
      companyType,
      companyName,
      estimatedPrice,
    });

    if (assigned) {
      await createNotification(
        req,
        "Lead Assigned",
        `You have been assigned to lead: ${name}`,
        "lead",
        [assigned],
        req.user?._id,
        { leadId: doc._id }
      );
    }

    res.status(201).json({ success: true, lead: doc });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const updateLead = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, mobile, email, websiteType, source, status, message, assignedTo, companyType, companyName, estimatedPrice } = req.body;
    if (!name || !mobile) return res.status(400).json({ message: "Name and Mobile are required" });
    const dup = await findDup((mobile || "").trim(), (email || "").trim(), id);
    if (dup) return res.status(400).json({ message: "Duplicate lead (phone/email) detected" });
    const updateBody = {
      name,
      mobile: mobile?.trim(),
      email: email?.trim() || "",
      websiteType,
      source: source || "",
      status,
      message,
      companyType,
      companyName,
      estimatedPrice,
    };
    if (assignedTo !== undefined) {
      if (!assignedTo) {
        // Do not overwrite if empty string; keep existing assignedTo
      } else if (mongoose.Types.ObjectId.isValid(assignedTo)) {
        updateBody.assignedTo = assignedTo;
      } else {
        updateBody.assignedTo = null;
      }
    }

    const oldLead = await Lead.findById(id).select("assignedTo");

    let doc = await Lead.findByIdAndUpdate(id, updateBody, { new: true });
    if (!doc) return res.status(404).json({ message: "Lead not found" });

    if (doc.assignedTo && (!oldLead?.assignedTo || doc.assignedTo.toString() !== oldLead.assignedTo.toString())) {
      await createNotification(
        req,
        "Lead Assigned",
        `You have been assigned to lead: ${doc.name}`,
        "lead",
        [doc.assignedTo],
        req.user?._id,
        { leadId: doc._id }
      );
    }

    if (status === "won") {
      if (!doc.convertedCompany) {
        const existingCompany =
          (doc.email && (await Company.findOne({ email: doc.email }))) ||
          (await Company.findOne({ phone: doc.mobile }));
        let company = existingCompany;
        if (!company) {
          let nextNum = 1;
          const latest = await Company.findOne({ companyId: { $regex: /^CMP-\d+$/ } })
            .sort({ createdAt: -1 })
            .select("companyId");
          if (latest?.companyId) {
            const m = latest.companyId.match(/^CMP-(\d+)$/);
            if (m) nextNum = parseInt(m[1], 10) + 1;
          } else {
            const allIds = await Company.find({ companyId: { $regex: /^CMP-\d+$/ } }).select("companyId");
            const maxNum = allIds.reduce((max, c) => {
              const m = c.companyId.match(/^CMP-(\d+)$/);
              const n = m ? parseInt(m[1], 10) : 0;
              return Math.max(max, n);
            }, 0);
            nextNum = maxNum + 1;
          }
          const finalCompanyId = `CMP-${String(nextNum).padStart(3, "0")}`;
          const emailOut = doc.email && doc.email.trim() ? doc.email.trim() : `lead-${doc._id}@noemail.local`;
          company = await Company.create({
            companyId: finalCompanyId,
            name: doc.companyName || doc.name,
            email: emailOut,
            phone: doc.mobile,
            companyType: doc.companyType || 'Individual',
            addressLine1: "N/A",
            city: "N/A",
            state: "N/A",
            country: "N/A",
            pincode: "N/A",
            contactPersonName: doc.name,
            contactPersonEmail: emailOut,
            contactPersonPhone: doc.mobile,
            projects: 0,
            totalCost: 0,
          });
        }
        doc.convertedCompany = company._id;
        doc.convertedAt = new Date();
        await doc.save();
      }
    }
    res.json({ success: true, lead: doc });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const updateStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, notes, nextFollowUp, subStatus } = req.body;
    const allowed = ["new", "contacted", "in_progress", "qualified", "proposal_sent", "negotiation", "won", "lost", "on_hold"];
    if (!allowed.includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    const updateData = { status };
    if (notes !== undefined || nextFollowUp !== undefined || subStatus !== undefined || status) {
      updateData.$push = {
        followUps: {
          stage: status,
          status: subStatus || "",
          notes: notes || "",
          nextFollowUp: nextFollowUp ? new Date(nextFollowUp) : null,
          updatedBy: req.user?._id || null,
          date: new Date()
        }
      };
    }

    let doc = await Lead.findByIdAndUpdate(id, updateData, { new: true }).populate("followUps.updatedBy", "name");
    if (!doc) return res.status(404).json({ message: "Lead not found" });

    if (status === "won") {
      if (!doc.convertedCompany) {
        // Check existing company by email or phone to avoid duplicates
        const existingCompany =
          (doc.email && (await Company.findOne({ email: doc.email }))) ||
          (await Company.findOne({ phone: doc.mobile }));

        let company = existingCompany;
        if (!company) {
          // Generate companyId CMP-###
          let finalCompanyId = null;
          const latest = await Company.findOne({ companyId: { $regex: /^CMP-\d+$/ } })
            .sort({ createdAt: -1 })
            .select("companyId");
          let nextNum = 1;
          if (latest?.companyId) {
            const match = latest.companyId.match(/^CMP-(\d+)$/);
            if (match) nextNum = parseInt(match[1], 10) + 1;
          } else {
            const allIds = await Company.find({ companyId: { $regex: /^CMP-\d+$/ } }).select("companyId");
            const maxNum = allIds.reduce((max, c) => {
              const m = c.companyId.match(/^CMP-(\d+)$/);
              const n = m ? parseInt(m[1], 10) : 0;
              return Math.max(max, n);
            }, 0);
            nextNum = maxNum + 1;
          }
          finalCompanyId = `CMP-${String(nextNum).padStart(3, "0")}`;

          const email = doc.email && doc.email.trim() ? doc.email.trim() : `lead-${doc._id}@noemail.local`;
          company = await Company.create({
            companyId: finalCompanyId,
            name: doc.companyName || doc.name,
            email,
            phone: doc.mobile,
            companyType: doc.companyType || 'Individual',
            addressLine1: "N/A",
            city: "N/A",
            state: "N/A",
            country: "N/A",
            pincode: "N/A",
            contactPersonName: doc.name,
            contactPersonEmail: email,
            contactPersonPhone: doc.mobile,
            projects: 0,
            totalCost: 0,
          });
        }

        // Mark lead as converted and reference company
        doc.convertedCompany = company._id;
        doc.convertedAt = new Date();
        await doc.save();
      }
    }

    res.json({ success: true, lead: doc });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const deleteLead = async (req, res) => {
  try {
    const { id } = req.params;
    await Lead.findByIdAndDelete(id);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const bulkAssign = async (req, res) => {
  try {
    const { leadIds = [], assignedTo } = req.body;
    if (!Array.isArray(leadIds) || leadIds.length === 0 || !assignedTo) {
      return res.status(400).json({ message: "leadIds and assignedTo are required" });
    }
    await Lead.updateMany({ _id: { $in: leadIds } }, { $set: { assignedTo } });

    await createNotification(
      req,
      "Leads Assigned",
      `You have been assigned to ${leadIds.length} leads.`,
      "lead",
      [assignedTo],
      req.user?._id,
      { count: leadIds.length }
    );

    res.json({ success: true, count: leadIds.length });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const importLeads = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No file uploaded" });
    const workbook = xlsx.readFile(req.file.path);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = xlsx.utils.sheet_to_json(sheet);

    const NAME_KEYS = ["Name", "Full Name"];
    const MOBILE_KEYS = ["Mobile", "Mobile No.", "Phone"];
    const EMAIL_KEYS = ["Email", "Email ID"];
    const WEBSITE_KEYS = ["Website Type", "Website"];
    const STATUS_KEYS = ["Status"];
    const MESSAGE_KEYS = ["Message", "Notes"];
    const ASSIGNED_KEYS = ["Assigned To", "Assignee", "Owner"];
    const COMPANY_KEYS = ["Company/Individual", "Type"];
    const COMPANY_NAME_KEYS = ["Company Name", "Business Name"];
    const ESTIMATED_PRICE_KEYS = ["Estimated Price", "Price", "Value"];
    const SOURCE_KEYS = ["Lead Source", "Source"];

    const getValue = (row, keys) => keys.reduce((a, b) => (a !== undefined ? a : row[b]), undefined);

    const users = await User.find({}, "_id name");
    const nameToId = new Map(users.map((u) => [u.name.toLowerCase(), u._id]));

    const docs = [];
    const failed = [];
    const existing = await Lead.find({}, "mobile email");
    const existingKey = new Set([
      ...existing.map((l) => `m:${(l.mobile || "").trim()}`),
      ...existing.map((l) => `e:${(l.email || "").toLowerCase().trim()}`),
    ]);

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const name = getValue(row, NAME_KEYS);
      const mobile = String(getValue(row, MOBILE_KEYS) || "").trim();
      const email = String(getValue(row, EMAIL_KEYS) || "").trim();
      const websiteType = getValue(row, WEBSITE_KEYS) || "";
      const status = getValue(row, STATUS_KEYS) || "new";
      const message = getValue(row, MESSAGE_KEYS) || "";
      const assignedName = (getValue(row, ASSIGNED_KEYS) || "").toString().toLowerCase().trim();
      const companyType = getValue(row, COMPANY_KEYS) || "Individual";
      const companyName = getValue(row, COMPANY_NAME_KEYS) || "";
      const estimatedPrice = getValue(row, ESTIMATED_PRICE_KEYS) || 0;
      const source = getValue(row, SOURCE_KEYS) || "";

      if (!name || !mobile) {
        failed.push({ row: i + 2, reason: "Missing required fields (Name/Mobile)" });
        continue;
      }
      if (existingKey.has(`m:${mobile}`) || (email && existingKey.has(`e:${email.toLowerCase()}`))) {
        failed.push({ row: i + 2, reason: "Duplicate (mobile/email)" });
        continue;
      }
      const assignedTo = nameToId.get(assignedName) || null;
      docs.push({ name, mobile, email, websiteType, source, status, message, assignedTo, companyType, companyName, estimatedPrice });
    }

    if (docs.length) await Lead.insertMany(docs, { ordered: false });
    res.json({ success: true, uploaded: docs.length, failed: failed.length, failedRecords: failed });
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const downloadTemplate = async (req, res) => {
  try {
    const template = [
      {
        "Name": "John Doe",
        "Mobile No.": "9876543210",
        "Email ID": "john@example.com",
        "Website Type": "Web Application",
        "Lead Source": "Referral",
        "Status": "new",
        "Message": "Looking for website redesign",
        "Assigned To": "Jane Smith",
        "Company/Individual": "Company",
        "Company Name": "Acme Corp",
        "Estimated Price": 5000,
      },
    ];
    const workbook = xlsx.utils.book_new();
    const ws = xlsx.utils.json_to_sheet(template);
    xlsx.utils.book_append_sheet(workbook, ws, "Leads Template");
    const buffer = xlsx.write(workbook, { type: "buffer", bookType: "xlsx" });
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", "attachment; filename=leads_template.xlsx");
    res.send(buffer);
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};

export const exportLeads = async (req, res) => {
  try {
    const { format = "csv", search = "", status = "", assignedTo = "" } = req.query;
    const match = {};
    // Employee-specific scoping: only export leads assigned to them
    if (req.user?.role?.toLowerCase() === "employee" && req.user?._id) {
      match.assignedTo = new mongoose.Types.ObjectId(req.user._id);
    }
    if (status) match.status = status;
    if (assignedTo) match.assignedTo = assignedTo;
    if (search) {
      match.$or = [
        { name: { $regex: search, $options: "i" } },
        { mobile: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
      ];
    }
    const rows = await Lead.aggregate([
      { $match: match },
      {
        $lookup: {
          from: "users",
          localField: "assignedTo",
          foreignField: "_id",
          as: "assignedTo",
        },
      },
      { $unwind: { path: "$assignedTo", preserveNullAndEmptyArrays: true } },
      { $sort: { createdAt: -1 } },
    ]);
    const data = rows.map((l, i) => ({
      SlNo: i + 1,
      Timestamp: l.createdAt,
      Name: l.name,
      Mobile: l.mobile,
      Email: l.email || "",
      WebsiteType: l.websiteType || "",
      LeadSource: l.source || "",
      Status: l.status,
      Message: l.message || "",
      AssignedTo: l.assignedTo?.name || "",
      CompanyOrIndividual: l.companyType || "",
      CompanyName: l.companyName || "",
      EstimatedPrice: l.estimatedPrice || 0,
    }));
    if (format === "xlsx") {
      const wb = xlsx.utils.book_new();
      const ws = xlsx.utils.json_to_sheet(data);
      xlsx.utils.book_append_sheet(wb, ws, "Leads");
      const buffer = xlsx.write(wb, { type: "buffer", bookType: "xlsx" });
      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.setHeader("Content-Disposition", "attachment; filename=leads.xlsx");
      return res.send(buffer);
    }
    const wb = xlsx.utils.book_new();
    const ws = xlsx.utils.json_to_sheet(data);
    const csv = xlsx.utils.sheet_to_csv(ws);
    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", "attachment; filename=leads.csv");
    res.send(csv);
  } catch (e) {
    res.status(500).json({ message: "Server error", error: e.message });
  }
};
