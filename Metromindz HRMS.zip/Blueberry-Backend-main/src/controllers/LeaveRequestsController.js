import LeaveRequest from "../models/LeaveRequests.js";
import LeaveMaster from "../models/LeaveMaster.js";
import User from "../models/User.js";
import Holiday from "../models/Holiday.js";
import {processLeaveApplication}  from "./LeaveBalanceController.js";
import { createActivityLog } from "./activityLogController.js";
import { createNotification } from "./notificationController.js";
import e from "express";

// Helper function to calculate working days excluding weekends and holidays
const calculateWorkingDays = async (
  fromDate,
  toDate,
  employeeWeekOffs = []
) => {
  const start = new Date(fromDate);
  const end = new Date(toDate);
  let workingDays = 0;
  let totalDays = 0;

  // Get holidays in the date range
  const holidays = await Holiday.find({
    date: { $gte: start, $lte: end },
  });
  const holidayDates = holidays.map((h) => h.date.toDateString());

  // Iterate through each date
  for (
    let date = new Date(start);
    date <= end;
    date.setDate(date.getDate() + 1)
  ) {
    totalDays++;
    const dayName = date.toLocaleDateString("en-US", { weekday: "long" });
    const dateString = date.toDateString();

    // Skip if it's employee's weekly off or holiday
    if (
      !employeeWeekOffs.includes(dayName) &&
      !holidayDates.includes(dateString)
    ) {
      workingDays++;
    }
  }

  return { workingDays, totalDays, excludedDays: totalDays - workingDays };
};

const notifyLeaveApprovers = async ({
  req,
  employee,
  empId,
  employeeName,
  leaveName,
  fromDate,
  toDate,
  status = "pending",
}) => {
  const managerId = employee?.employmentDetails?.reportingManager?.id;

  const hrUsers = await User.find({
    role: { $regex: /^(superadmin|hr)$/i },
    status: "active",
  }).select("_id");

  const recipients = [
    ...(managerId ? [managerId] : []),
    ...hrUsers.map((u) => u._id),
  ]
    .map((id) => String(id))
    .filter(Boolean);

  const uniqueRecipients = [...new Set(recipients)];
  if (uniqueRecipients.length === 0) return;

  await createNotification(
    req,
    "Leave Approval Required",
    `${employeeName} (${empId}) requested ${leaveName} from ${new Date(fromDate).toLocaleDateString()} to ${new Date(toDate).toLocaleDateString()} (${status})`,
    "leave_status",
    uniqueRecipients,
    req.user?._id || req.user?.id,
    { employeeId: empId, employeeName, leaveName, fromDate, toDate, status }
  );
};

export const leaveRequests = async (req, res) => {
  try {
    const { empId, employeeName, leaveId, fromDate, toDate, reason } = req.body;

    if (!empId) {
       return res.status(400).json({ message: "Employee ID (empId) is required" });
    }

    if (!leaveId) {
       return res.status(400).json({ message: "Leave Type ID (leaveId) is required" });
    }

    // 🟢 Step 1: Validate leaveId
    const leaveType = await LeaveMaster.findById(leaveId);
    if (!leaveType) {
      return res.status(404).json({ message: "Invalid leave type ID" });
    }

    // 🟢 Step 2: Validate employee ID and get employee details
    const employee = await User.findOne({ employeeId: empId }).select(
      "_id name employeeId employmentDetails.weekOff employmentDetails.reportingManager"
    );
    if (!employee) {
      return res.status(404).json({ message: `Employee not found with ID: ${empId}` });
    }

    // Use employee name from database if not provided
    const finalEmployeeName = employeeName || employee.name;

    // 🟢 Step 2.5: Validate dates
    const startDate = new Date(fromDate);
    const endDate = new Date(toDate);

    if (startDate > endDate) {
      return res
        .status(400)
        .json({ message: "From date cannot be after to date" });
    }

    if (startDate < new Date().setHours(0, 0, 0, 0)) {
      return res.status(400).json({ message: "Cannot apply for past dates" });
    }

    // 🟢 Step 2.7: Check for overlapping leave requests
    const existingLeaveRequest = await LeaveRequest.findOne({
      employeeId: empId,
    });
    if (existingLeaveRequest) {
      for (const leaveTypeRecord of existingLeaveRequest.leaveRequests) {
        for (const app of leaveTypeRecord.applications) {
          if (app.status === "pending" || app.status === "approved") {
            const existingStart = new Date(app.fromDate);
            const existingEnd = new Date(app.toDate);

            // Check for date overlap
            if (startDate <= existingEnd && endDate >= existingStart) {
              return res.status(400).json({
                message: `Leave request overlaps with existing ${
                  app.status
                } leave from ${existingStart.toDateString()} to ${existingEnd.toDateString()}`,
              });
            }
          }
        }
      }
    }

    // 🟢 Step 2.6: Calculate working days dynamically
    const employeeWeekOffs = employee.employmentDetails?.weekOff || [];
    const { workingDays, totalDays, excludedDays } = await calculateWorkingDays(
      fromDate,
      toDate,
      employeeWeekOffs
    );

    if (workingDays === 0) {
      return res.status(400).json({
        message:
          "No working days in selected date range (all days are weekoffs/holidays)",
      });
    }

    // 🟢 Step 3: Check if LeaveRequest record exists for this employee
    let leaveRequestDoc = await LeaveRequest.findOne({ employeeId: empId });

    // 🟢 Step 4: If not found → create a new LeaveRequest record
    if (!leaveRequestDoc) {
      const newLeaveRequest = new LeaveRequest({
        employee: employee._id,
        employeeId: empId,
        employeeName: finalEmployeeName,
        leaveRequests: [
          {
            leaveId: leaveType._id,
            leaveName: leaveType.leaveName,
            applications: [
              {
                fromDate,
                toDate,
                numberOfDays: workingDays,
                totalDays,
                excludedDays,
                reason,
                status: "pending",
              },
            ],
          },
        ],
      });

       await createActivityLog(
                        req.user?.id,
                     "emp_leaveCreate",
       `Employee  ${employeeName} (${empId}) applied for leave from ${new Date(fromDate).toLocaleDateString()} to ${new Date(toDate).toLocaleDateString()}.`,
                        req,
                        { employeeId: empId, employeeName:employeeName
                         }
                      );

      await newLeaveRequest.save();

      await notifyLeaveApprovers({
        req,
        employee,
        empId,
        employeeName: finalEmployeeName,
        leaveName: leaveType.leaveName,
        fromDate,
        toDate,
        status: "pending",
      });

      const populatedRecord = await LeaveRequest.findById(
        newLeaveRequest._id
      ).populate(
        "leaveRequests.leaveId",
        "leaveName yearlyCount monthlyLimit carryForward"
      );

      return res.status(201).json({
        message: "Leave request submitted successfully.",
        data: populatedRecord,
      });
    }

    // 🟢 Step 5: Record exists — check for the specific leave type
    const leaveTypeRecord = leaveRequestDoc.leaveRequests.find(
      (lr) => lr.leaveId.toString() === leaveId.toString()
    );

    if (!leaveTypeRecord) {
      // Add new leave type entry for this employee
      leaveRequestDoc.leaveRequests.push({
        leaveId: leaveType._id,
        leaveName: leaveType.leaveName,
        applications: [
          {
            fromDate,
            toDate,
            numberOfDays: workingDays,
            totalDays,
            excludedDays,
            reason,
            status: "pending",
          },
        ],
      });
    } else {
      // 🟢 Step 6: Add new application to existing leave type
      leaveTypeRecord.applications.push({
        fromDate,
        toDate,
        numberOfDays: workingDays,
        totalDays,
        excludedDays,
        reason,
        status: "pending",
      });
    }

    // Update the timestamp
    leaveRequestDoc.updatedAt = new Date();

     await createActivityLog(
                        req.user?.id,
                     "emp_leaveCreate",
       `Employee  ${employeeName} (${empId}) applied for leave from ${new Date(fromDate).toLocaleDateString()} to ${new Date(toDate).toLocaleDateString()}.`,
                        req,
                        { employeeId: empId, employeeName:employeeName
                         }
                      );

    await leaveRequestDoc.save();

    await notifyLeaveApprovers({
      req,
      employee,
      empId,
      employeeName: finalEmployeeName,
      leaveName: leaveType.leaveName,
      fromDate,
      toDate,
      status: "pending",
    });

    // 🟢 Step 7: Populate and return
    const updated = await LeaveRequest.findById(leaveRequestDoc._id).populate(
      "leaveRequests.leaveId",
      "leaveName yearlyCount monthlyLimit carryForward"
    );

    res.status(200).json({
      message: "Leave request submitted successfully.",
      data: updated,
    });
  } catch (error) {
    console.error("❌ Error submitting leave request:", error);
    res.status(500).json({
      message: "Server error",
      error: error.message || error,
    });
  }
};

export const getEmployeeLeaveRequests = async (req, res) => {
  try {    
    const empId = req.user.employeeId; 

    if (!empId) {
      return res.status(400).json({ 
        message: "Employee ID not found in user data"
      });
    }

    // Get pagination parameters from query
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    // Get filter parameters
    const status = req.query.status; // Filter by status: pending, approved, rejected

    // Find the employee's leave request document
    const leaveRequestsDoc = await LeaveRequest.findOne({
      employeeId: empId,
    }).populate(
      "leaveRequests.leaveId",
      "leaveName yearlyCount monthlyLimit carryForward"
    ).sort({createdAt:-1});

    if (!leaveRequestsDoc) {
      return res.status(200).json({ 
        message: `No leave requests found for employee ID: ${empId}`,
        data: {
          employeeId: empId,
          employeeName: '',
          applications: [],
          leaveTypes: []
        },
        pagination: {
          total: 0,
          page: page,
          limit: limit,
          totalPages: 0,
          hasNextPage: false,
          hasPrevPage: false
        }
      });
    }

    // Flatten all applications from all leave types
    let allApplications = [];
    
    if (leaveRequestsDoc.leaveRequests && leaveRequestsDoc.leaveRequests.length > 0) {
      leaveRequestsDoc.leaveRequests.forEach(leaveType => {
        if (leaveType.applications && leaveType.applications.length > 0) {
          leaveType.applications.forEach(app => {
            // Apply status filter if provided
            const shouldInclude = !status || app.status === status;
            
            if (shouldInclude) {
              allApplications.push({
                _id: app._id,
                leaveId: leaveType.leaveId?._id,
                leaveName: leaveType.leaveId?.leaveName || leaveType.leaveName,
                fromDate: app.fromDate,
                toDate: app.toDate,
                numberOfDays: app.numberOfDays,
                reason: app.reason,
                status: app.status,
                approvedDays: app.approvedDays,
                lopDays: app.lopDays,
                createdAt: app.createdAt,
                updatedAt: app.updatedAt,
              });
            }
          });
        }
      });
    }

    // ALWAYS SORT BY createdAt IN DESCENDING ORDER (newest first)
 allApplications.sort((a, b) => {
  // Convert to strings for consistent comparison
  const idA = a._id.toString();
  const idB = b._id.toString();
  
  // Compare ObjectIds - newer ObjectIds come first
  if (idA < idB) return 1;
  if (idA > idB) return -1;
  return 0;
});

    // Apply pagination to the flattened array
    const total = allApplications.length;
    const totalPages = Math.ceil(total / limit);
    const paginatedApplications = allApplications.slice(skip, skip + limit);

    // Format the response
    const responseData = {
      employeeId: leaveRequestsDoc.employeeId,
      employeeName: leaveRequestsDoc.employeeName,
      applications: paginatedApplications,
      leaveTypes: leaveRequestsDoc.leaveRequests.map(lt => ({
        leaveId: lt.leaveId?._id,
        leaveName: lt.leaveId?.leaveName || lt.leaveName,
        yearlyCount: lt.leaveId?.yearlyCount || lt.yearlyCount,
        monthlyLimit: lt.leaveId?.monthlyLimit || lt.monthlyLimit,
        carryForward: lt.leaveId?.carryForward || lt.carryForward,
      }))
    };

    res.status(200).json({
      message: "Leave requests retrieved successfully.",
      data: responseData,
      pagination: {
        total: total,
        page: page,
        limit: limit,
        totalPages: totalPages,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      }
    });
  } catch (error) {
    console.error("❌ Error retrieving leave requests:", error);
    res.status(500).json({
      message: "Server error",
      error: error.message || error,
    });
  }
};

// 🟢 Get all leave requests (for admin approval)
// export const getAllLeaveRequests = async (req, res) => {
//   try {
//     const { 
//       status, 
//       searchByEmployee, 
//       page = 1, 
//       limit = 10,
//       sortBy = 'createdAt',
//       sortOrder = 'desc' 
//     } = req.query;

//     // Parse pagination parameters
//     const pageNum = parseInt(page);
//     const limitNum = parseInt(limit);
//     const skip = (pageNum - 1) * limitNum;
    
//     // Sort order
//     const sort = {};
//     sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

//     // Base query to get all employee leave requests
//     const query = {};
    
//     // You might need to adjust this based on your schema
//     // If you want to filter at the database level for employee name
//     // you might need a different approach
    
//     const leaveRequests = await LeaveRequest.find(query)
//       .sort(sort)
//       .populate(
//         "leaveRequests.leaveId",
//         "leaveName yearlyCount monthlyLimit carryForward"
//       )
//       .populate("employee", "name employeeId");

//     // Flatten all applications
//     const flattenedRequests = [];

//     leaveRequests.forEach((empRequest) => {
//       empRequest.leaveRequests.forEach((leaveType) => {
//         leaveType.applications.forEach((app) => {
//           // Check if the request matches both status and employee name filters
//           const matchesStatus = !status || app.status === status;
//           const matchesEmployeeName = !searchByEmployee || 
//             empRequest.employeeName?.toLowerCase().includes(searchByEmployee.toLowerCase()) ||
//             empRequest.employee?.name?.toLowerCase().includes(searchByEmployee.toLowerCase());

//           // Include if matches both filters (or if filter is not provided)
//           if (matchesStatus && matchesEmployeeName) {
//             flattenedRequests.push({
//               _id: app._id,
//               employeeId: empRequest.employeeId,
//               employeeName: empRequest.employeeName || empRequest.employee?.name || 'N/A',
//               leaveId: leaveType.leaveId?._id,
//               leaveName: leaveType.leaveId?.leaveName || leaveType.leaveName,
//               fromDate: app.fromDate,
//               toDate: app.toDate,
//               numberOfDays: app.numberOfDays,
//               reason: app.reason,
//               status: app.status,
//               approvedDays: app.approvedDays,
//               lopDays: app.lopDays,
//               createdAt: empRequest.createdAt,
//             });
//           }
//         });
//       });
//     });

//     // Apply sorting to flattened array if needed
//     flattenedRequests.sort((a, b) => {
//       if (sortOrder === 'desc') {
//         return new Date(b[sortBy]) - new Date(a[sortBy]);
//       } else {
//         return new Date(a[sortBy]) - new Date(b[sortBy]);
//       }
//     });

//     // Apply pagination
//     const total = flattenedRequests.length;
//     const totalPages = Math.ceil(total / limitNum);
//     const paginatedResults = flattenedRequests.slice(skip, skip + limitNum);

//     res.status(200).json({
//       message: "All leave requests retrieved successfully.",
//       data: paginatedResults,
//       count: paginatedResults.length,
//       pagination: {
//         total,
//         page: pageNum,
//         limit: limitNum,
//         totalPages,
//         hasNextPage: pageNum < totalPages,
//         hasPrevPage: pageNum > 1,
//       }
//     });
//   } catch (error) {
//     console.error("❌ Error retrieving all leave requests:", error);
//     res.status(500).json({
//       message: "Server error",
//       error: error.message || error,
//     });
//   }
// };
export const getAllLeaveRequests = async (req, res) => {
  try {
    const { 
      status, 
      searchByEmployee, 
      page = 1, 
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc' 
    } = req.query;

    // Parse pagination parameters
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    // Get all leave requests sorted by document creation date (newest first)
    const leaveRequests = await LeaveRequest.find({})
      .sort({ createdAt: -1 }) // Get newest documents first
      .populate(
        "leaveRequests.leaveId",
        "leaveName yearlyCount monthlyLimit carryForward"
      )
      .populate("employee", "name employeeId employmentDetails.reportingManager");      
      

    // Flatten all applications with index tracking
    const flattenedRequests = [];

    leaveRequests.forEach((empRequest) => {
      empRequest.leaveRequests.forEach((leaveType) => {
        // Get applications in reverse order (newest first)
        const applications = [...leaveType.applications];
        
        // Reverse to get newest applications first (since they're pushed to the end)
        applications.reverse().forEach((app, index) => {
          // Check if the request matches both status and employee name filters
          const matchesStatus = !status || app.status === status;
          const matchesEmployeeName = !searchByEmployee || 
            empRequest.employeeName?.toLowerCase().includes(searchByEmployee.toLowerCase()) ||
            empRequest.employee?.name?.toLowerCase().includes(searchByEmployee.toLowerCase());

          // Include if matches both filters (or if filter is not provided)
          if (matchesStatus && matchesEmployeeName) {
            flattenedRequests.push({
              _id: app._id,
              employeeId: empRequest.employeeId,
              employeeName: empRequest.employeeName || empRequest.employee?.name || 'N/A',
              leaveId: leaveType.leaveId?._id,
              leaveName: leaveType.leaveId?.leaveName || leaveType.leaveName,
              fromDate: app.fromDate,
              toDate: app.toDate,
              numberOfDays: app.numberOfDays,
              reason: app.reason,
               reportingManagerName: empRequest.employee?.employmentDetails?.reportingManager?.name || "N/A",
               reportingManagerId: empRequest.employee?.employmentDetails?.reportingManager?.id || null,
              status: app.status,
              approvedDays: app.approvedDays,
              lopDays: app.lopDays,
              parentCreatedAt: empRequest.createdAt,
              // Add a synthetic timestamp for sorting
              sortTimestamp: new Date(empRequest.createdAt).getTime() - index,
            });
          }
        });
      });
    });

    // Sort by the synthetic timestamp (newest first)
    flattenedRequests.sort((a, b) => b.sortTimestamp - a.sortTimestamp);

    const requesterRole = String(req.user?.role || "").toLowerCase();
    const requesterId = String(req.user?.id || req.user?._id || "");
    const roleFiltered =
      requesterRole === "manager" || requesterRole === "team manager"
        ? flattenedRequests.filter(
            (r) => r.reportingManagerId && String(r.reportingManagerId) === requesterId
          )
        : flattenedRequests;

    // Apply pagination
    const total = roleFiltered.length;
    const totalPages = Math.ceil(total / limitNum);
    const paginatedResults = roleFiltered.slice(skip, skip + limitNum);

    res.status(200).json({
      message: "All leave requests retrieved successfully.",
      data: paginatedResults,
      count: paginatedResults.length,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages,
        hasNextPage: pageNum < totalPages,
        hasPrevPage: pageNum > 1,
      }
    });
  } catch (error) {
    console.error("❌ Error retrieving all leave requests:", error);
    res.status(500).json({
      message: "Server error",
      error: error.message || error,
    });
  }
};

// 🟢 Integrated function to submit and process leave request
export const submitAndProcessLeave = async (req, res) => {
  return leaveRequests(req, res);
};

// 🟢 Helper function to submit leave request (extracted from main function)
const submitLeaveRequest = async (
  req,
  empId,
  employeeName,
  leaveId,
  fromDate,
  toDate,
  reason
) => {
  const leaveType = await LeaveMaster.findById(leaveId);
  if (!leaveType) throw new Error("Invalid leave type ID");

  const employee = await User.findOne({ employeeId: empId }).select(
    "_id name employeeId employmentDetails.weekOff"
  );
  if (!employee) throw new Error("Employee not found");

  const finalEmployeeName = employeeName || employee.name;

  // Validate dates and check for overlaps
  const startDate = new Date(fromDate);
  const endDate = new Date(toDate);

  const existingLeaveRequest = await LeaveRequest.findOne({
    employeeId: empId,
  });
  if (existingLeaveRequest) {
    for (const leaveTypeRecord of existingLeaveRequest.leaveRequests) {
      for (const app of leaveTypeRecord.applications) {
        if (app.status === "pending" || app.status === "approved") {
          const existingStart = new Date(app.fromDate);
          const existingEnd = new Date(app.toDate);

          if (startDate <= existingEnd && endDate >= existingStart) {
            throw new Error(
              `Leave request overlaps with existing ${
                app.status
              } leave from ${existingStart.toDateString()} to ${existingEnd.toDateString()}`
            );
          }
        }
      }
    }
  }

  // Calculate working days
  const employeeWeekOffs = employee.employmentDetails?.weekOff || [];
  const { workingDays, totalDays, excludedDays } = await calculateWorkingDays(
    fromDate,
    toDate,
    employeeWeekOffs
  );

  let leaveRequestDoc = await LeaveRequest.findOne({ employeeId: empId });

  if (!leaveRequestDoc) {
    const newLeaveRequest = new LeaveRequest({
      employee: employee._id,
      employeeId: empId,
      employeeName: finalEmployeeName,
      leaveRequests: [
        {
          leaveId: leaveType._id,
          leaveName: leaveType.leaveName,
          applications: [
            {
              fromDate,
              toDate,
              numberOfDays: workingDays,
              totalDays,
              excludedDays,
              reason,
              status: "pending",
           
            },
          ],
        },
      ],
    });

           await createActivityLog(
      req.user?.id,
      "leave_created",
      `New Leave ${leaveType.leaveName} created`,
      req,
      { leaveName: leaveType.leaveName }
    );
    await newLeaveRequest.save();
  } else {
    const leaveTypeRecord = leaveRequestDoc.leaveRequests.find(
      (lr) => lr.leaveId.toString() === leaveId.toString()
    );

    if (!leaveTypeRecord) {
      leaveRequestDoc.leaveRequests.push({
        leaveId: leaveType._id,
        leaveName: leaveType.leaveName,
        applications: [
          {
            fromDate,
            toDate,
            numberOfDays: workingDays,
            totalDays,
            excludedDays,
            reason,
            status: "pending",
          },
        ],
      });
    } else {
      leaveTypeRecord.applications.push({
        fromDate,
        toDate,
        numberOfDays: workingDays,
        totalDays,
        excludedDays,
        reason,
        status: "pending",
      });
    }

    leaveRequestDoc.updatedAt = new Date();
    await leaveRequestDoc.save();
  }

  return workingDays;
};

// 🟢 Function to approve/reject leave with balance processing
export const approveLeaveRequest = async (req, res) => {
  try {
    const { empId, leaveId, fromDate, toDate, status } = req.body;
        const empObjId = await User.findOne({employeeId : empId})

    if (!empObjId) {
        return res.status(404).json({ message: "Employee not found." });
    }
    
    // Permission check for managers
    const approverRole = req.user.role?.toLowerCase();
    if (approverRole === 'manager' || approverRole === 'team manager') {
        const reportingManagerId = empObjId.employmentDetails?.reportingManager?.id;
        if (!reportingManagerId || String(reportingManagerId) !== String(req.user.id)) {
             return res.status(403).json({ message: "You are not authorized to approve this leave request." });
        }
    }
    
    if (!["approved", "rejected"].includes(status)) {
      return res
        .status(400)
        .json({ message: "Status must be 'approved' or 'rejected'" });
    }

    const leaveRequest = await LeaveRequest.findOne({ employeeId: empId });
    if (!leaveRequest) {
      return res.status(404).json({ message: "Leave request not found" });
    }

    const leaveTypeRecord = leaveRequest.leaveRequests.find(
      (lr) => lr.leaveId.toString() === leaveId.toString()
    );

    if (!leaveTypeRecord) {
      return res.status(404).json({ message: "Leave type not found" });
    }

    // Find application by date match
    const application = leaveTypeRecord.applications.find(
      (app) =>
        app.fromDate.getTime() === new Date(fromDate).getTime() &&
        app.toDate.getTime() === new Date(toDate).getTime()
    );

    if (!application) {
      return res.status(404).json({ message: "Leave application not found" });
    }

    if (application.status !== "pending") {
      return res.status(400).json({ message: "Leave already processed" });
    }

    if (status === "rejected") {
      application.status = "rejected";
      leaveRequest.updatedAt = new Date(); 
      
        const io = req.app.get('io');
      await createNotification(
        "Leave Status Updated",
       `Leave request from ${new Date(fromDate).toLocaleDateString()} to ${new Date(toDate).toLocaleDateString()} has been ${status}.`,
        "leave_status",
     empObjId._id ,
        req.user?._id,
        { employeeId: empId, employeeName: empObjId.name },
        io
      );

       await createActivityLog(
                        req.user?.id,
                     "emp_leaveStatus_update",
                        `Employee ${empObjId.name} (${empId}) leave status has been ${status}`,
                        req,
                        { employeeId: empId, employeeName: empObjId.name
                         }
                      );


            await leaveRequest.save();
      return res.status(200).json({
        message: "Leave request rejected successfully.",
        data: leaveRequest,
      });
    } 

    
    // If approved, process through balance controller
    req.body.numberOfDays = application.numberOfDays;
    req.body.reason = application.reason;
    req.body.status = "approved";


    // Process leave application for balance calculation
    await processLeaveApplication(req, res);
  } catch (error) {
    console.error("❌ Error approving leave request:", error);
    res.status(500).json({
      message: "Server error",
      error: error.message || error,
    });
  }
};

// 🟢 Function to update leave request status (manual override)
export const updateLeaveRequestStatus = async (req, res) => {
  try {
    const { empId, leaveId, fromDate, toDate, status } = req.body;

    if (
      !["pending", "approved", "rejected", "partially_approved"].includes(
        status
      )
    ) {
      return res.status(400).json({
        message:
          "Invalid status. Must be: pending, approved, rejected, partially_approved",
      });
    }

    const leaveRequest = await LeaveRequest.findOne({ employeeId: empId });
    if (!leaveRequest) {
      return res.status(404).json({ message: "Leave request not found" });
    }

    const leaveTypeRecord = leaveRequest.leaveRequests.find(
      (lr) => lr.leaveId.toString() === leaveId.toString()
    );

    if (!leaveTypeRecord) {
      return res.status(404).json({ message: "Leave type not found" });
    }

    // Find application by date match
    const application = leaveTypeRecord.applications.find(
      (app) =>
        app.fromDate.getTime() === new Date(fromDate).getTime() &&
        app.toDate.getTime() === new Date(toDate).getTime()
    );

    if (!application) {
      return res.status(404).json({ message: "Leave application not found" });
    }

    // For approved status, process through balance controller
    if (status === "approved" && application.status === "pending") {
      const mockReq = {
        body: {
          empId,
          leaveId,
          fromDate,
          toDate,
          numberOfDays: application.numberOfDays,
          reason: application.reason,
        },
      };

      // Process through balance controller for automatic calculation
      return await processLeaveApplication(mockReq, res);
    }

    // For other statuses, just update directly
    application.status = status;

    // Reset approval fields for non-approved statuses
    if (status !== "approved" && status !== "partially_approved") {
      application.approvedDays = 0;
      application.lopDays = 0;
    }

    leaveRequest.updatedAt = new Date();
    await leaveRequest.save();

    const updated = await LeaveRequest.findById(leaveRequest._id).populate(
      "leaveRequests.leaveId",
      "leaveName yearlyCount monthlyLimit carryForward"
    );

    res.status(200).json({
      message: `Leave request ${status} successfully.`,
      data: updated,
    });
  } catch (error) {
    console.error("❌ Error updating leave request status:", error);
    res.status(500).json({
      message: "Server error",
      error: error.message || error,
    });
  }
};

// 🟢 Function for manual balance override (admin only)
export const manualBalanceUpdate = async (req, res) => {
  try {
    const { empId, leaveId, fromDate, toDate, status, approvedDays, lopDays } =
      req.body;

    // Validate required fields for manual update
    if (!approvedDays && approvedDays !== 0) {
      return res
        .status(400)
        .json({ message: "approvedDays is required for manual update" });
    }
    if (!lopDays && lopDays !== 0) {
      return res
        .status(400)
        .json({ message: "lopDays is required for manual update" });
    }

    const leaveRequest = await LeaveRequest.findOne({ employeeId: empId });
    if (!leaveRequest) {
      return res.status(404).json({ message: "Leave request not found" });
    }

    const leaveTypeRecord = leaveRequest.leaveRequests.find(
      (lr) => lr.leaveId.toString() === leaveId.toString()
    );

    if (!leaveTypeRecord) {
      return res.status(404).json({ message: "Leave type not found" });
    }

    const application = leaveTypeRecord.applications.find(
      (app) =>
        app.fromDate.getTime() === new Date(fromDate).getTime() &&
        app.toDate.getTime() === new Date(toDate).getTime()
    );

    if (!application) {
      return res.status(404).json({ message: "Leave application not found" });
    }

    // Manual override - update all fields
    application.status = status;
    application.approvedDays = approvedDays;
    application.lopDays = lopDays;

    leaveRequest.updatedAt = new Date();
    await leaveRequest.save();

    const updated = await LeaveRequest.findById(leaveRequest._id).populate(
      "leaveRequests.leaveId",
      "leaveName yearlyCount monthlyLimit carryForward"
    );

    res.status(200).json({
      message: "Leave request manually updated successfully.",
      data: updated,
    });
  } catch (error) {
    console.error("❌ Error in manual balance update:", error);
    res.status(500).json({
      message: "Server error",
      error: error.message || error,
    });
  }
};
