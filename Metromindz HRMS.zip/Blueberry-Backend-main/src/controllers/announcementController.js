import Announcement from '../models/Announcement.js';
import User from '../models/User.js';
import { createNotification } from './notificationController.js';

/**
 * Create Announcement
 * 
 * Logic:
 * 1. Receives announcement details from admin/HR.
 * 2. Creates the announcement record.
 * 3. Identifies the target audience (All, Department-specific, or Role-specific).
 * 4. (Optional) Triggers notifications for the targeted users.
 * 
 * @param {Object} req - Request object containing body with announcement data
 * @param {Object} res - Response object
 */
export const createAnnouncement = async (req, res) => {
  try {
    const {
      title,
      description,
      category,
      priority,
      targetAudience,
      publishDate,
      expiryDate,
      attachments
    } = req.body;

    const announcement = new Announcement({
      title,
      description,
      category,
      priority,
      targetAudience,
      publishDate: publishDate || new Date(),
      expiryDate,
      attachments,
      createdBy: req.user._id
    });

    await announcement.save();

    // Notification Logic: Determine recipients based on target audience configuration
    let recipients = [];
    if (targetAudience.type === 'All') {
      recipients = await User.find({ status: 'active' }).select('_id');
    } else if (targetAudience.type === 'Department') {
      recipients = await User.find({ department: targetAudience.department, status: 'active' }).select('_id');
    } else if (targetAudience.type === 'Role') {
      recipients = await User.find({ role: targetAudience.role, status: 'active' }).select('_id');
    }

    // Note: In a production environment with many users, notifications should be processed asynchronously via a job queue (e.g., BullMQ).
    
    res.status(201).json({
      success: true,
      message: 'Announcement created successfully',
      data: announcement
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error creating announcement',
      error: error.message
    });
  }
};

/**
 * Get Announcements (Personalized Feed)
 * 
 * Logic:
 * 1. Filters announcements based on the requesting user's context (Role, Department).
 * 2. Logic: Show announcements where:
 *    - Audience is 'All' OR
 *    - Audience is 'Department' AND matches user's department OR
 *    - Audience is 'Role' AND matches user's role.
 * 3. Also filters by publishDate (must be published) and expiryDate (must not be expired).
 * 4. Supports pagination and filtering by category/priority.
 * 
 * @param {Object} req - Request object containing user context and query params
 * @param {Object} res - Response object
 */
export const getAnnouncements = async (req, res) => {
  try {
    const { page = 1, limit = 10, category, priority } = req.query;
    const user = req.user;

    // Core Filtering Logic for Targeted Announcements
    const query = {
      $or: [
        { 'targetAudience.type': 'All' },
        { 
          'targetAudience.type': 'Department',
          'targetAudience.department': user.department
        },
        {
          'targetAudience.type': 'Role',
          'targetAudience.role': user.role
        }
      ],
      // Only show announcements that are published (publishDate <= now)
      publishDate: { $lte: new Date() }
    };

    // Expiry Logic: Show if no expiry date exists OR expiry date is in the future
    query.$or.push({ expiryDate: { $exists: false } });
    query.$or.push({ expiryDate: { $gt: new Date() } });
    
    // Additional filters from frontend
    if (category) query.category = category;
    if (priority) query.priority = priority;

    const announcements = await Announcement.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .populate('createdBy', 'name avatar');

    const total = await Announcement.countDocuments(query);

    res.status(200).json({
      success: true,
      data: announcements,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching announcements',
      error: error.message
    });
  }
};

// Get All Announcements (Admin/HR Management)
export const getAllAnnouncements = async (req, res) => {
  try {
    const { page = 1, limit = 10, search } = req.query;
    
    const query = {};
    if (search) {
      query.title = { $regex: search, $options: 'i' };
    }

    const announcements = await Announcement.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .populate('createdBy', 'name');

    const total = await Announcement.countDocuments(query);

    res.status(200).json({
      success: true,
      data: announcements,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching announcements',
      error: error.message
    });
  }
};

// Delete Announcement
export const deleteAnnouncement = async (req, res) => {
  try {
    const { id } = req.params;
    const announcement = await Announcement.findByIdAndDelete(id);

    if (!announcement) {
      return res.status(404).json({
        success: false,
        message: 'Announcement not found'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Announcement deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error deleting announcement',
      error: error.message
    });
  }
};

// Acknowledge Announcement
export const acknowledgeAnnouncement = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user._id;

    const announcement = await Announcement.findById(id);
    if (!announcement) {
      return res.status(404).json({ success: false, message: 'Announcement not found' });
    }

    // Check if already acknowledged
    const alreadyAcknowledged = announcement.acknowledgments.find(
      ack => ack.user.toString() === userId.toString()
    );

    if (alreadyAcknowledged) {
      return res.status(400).json({ success: false, message: 'Already acknowledged' });
    }

    announcement.acknowledgments.push({ user: userId });
    await announcement.save();

    res.status(200).json({ success: true, message: 'Announcement acknowledged' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error acknowledging announcement', error: error.message });
  }
};
