import mongoose from "mongoose";
import xlsx from "xlsx";
import Task from "../models/Task.js";
import Project from "../models/Project.js";
import User from "../models/User.js";
import RolePermission from "../models/RolePermission.js";
import { createNotification } from "./notificationController.js";

const emitTaskChanged = (req, payload) => {
  const io = req?.app?.get?.("io");
  if (!io || typeof io.emit !== "function") return;
  io.emit("task-changed", payload);
};

const uniqStrings = (arr) =>
  [...new Set((arr || []).map((x) => (x == null ? "" : String(x))).filter(Boolean))];

const canAssignTasks = async (req) => {
  if (req.user?.role === "superadmin") return true;
  const user = await User.findById(req.user?._id).select("role permissions");
  if (!user) return false;
  if (user.permissions?.includes("task.assign")) return true;
  const rolePerm = await RolePermission.findOne({ role: user.role }).select("permissions");
  return !!(rolePerm && rolePerm.permissions?.includes("task.assign"));
};

export const listTasks = async (req, res) => {
  try {
    const { page = 1, limit = 10, search = "", priority = "", status = "", projectId = "" } = req.query;
    const query = {};
    if (search) query.$or = [{ title: { $regex: search, $options: "i" } }, { description: { $regex: search, $options: "i" } }];
    if (priority) query.priority = priority;
    if (status) query.status = status;
    if (projectId && mongoose.Types.ObjectId.isValid(projectId)) query.project = projectId;

    // Role-based filtering: Employees see tasks assigned to them or created by them
    if (req.user?.role?.toLowerCase() === "employee" && req.user?._id) {
      const roleFilter = { $or: [{ assignees: req.user._id }, { reporter: req.user._id }] };
      if (query.$or) {
        query.$and = [{ $or: query.$or }, roleFilter];
        delete query.$or;
      } else {
        query.$or = roleFilter.$or;
      }
    }

    const total = await Task.countDocuments(query);
    const items = await Task.find(query)
      .populate("project", "name")
      .populate("assignees", "name documents employeePersonal")
      .populate("reporter", "name")
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));
    res.json({ success: true, items, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (e) {
    res.status(500).json({ message: "Error fetching tasks", error: e.message });
  }
};

export const listTasksCalendar = async (req, res) => {
  try {
    const { from, to, status = "", projectId = "" } = req.query;

    const query = {};

    if (status) query.status = status;
    if (projectId && mongoose.Types.ObjectId.isValid(projectId)) query.project = projectId;

    if (req.user?.role?.toLowerCase() === "employee" && req.user?._id) {
      const roleFilter = { $or: [{ assignees: req.user._id }, { reporter: req.user._id }] };
      if (query.$or) {
        query.$and = [{ $or: query.$or }, roleFilter];
        delete query.$or;
      } else {
        query.$or = roleFilter.$or;
      }
    }

    if (from || to) {
      const rangeFilter = {};
      if (from) rangeFilter.$gte = new Date(from);
      if (to) rangeFilter.$lte = new Date(to);

      query.$or = [
        { startDate: rangeFilter },
        { dueDate: rangeFilter },
      ];
    }

    const items = await Task.find(query)
      .populate("project", "name")
      .select("title startDate dueDate status project");

    res.json({ success: true, items });
  } catch (e) {
    res.status(500).json({ message: "Error fetching calendar tasks", error: e.message });
  }
};

export const createTask = async (req, res) => {
  try {
    const {
      projectId,
      title,
      description = "",
      projectType,
      technology = "",
      priority,
      status = "todo",
      assignees = [],
      reporterId,
      startDate,
      dueDate,
      dueHours = 0,
      estimatedHours = 0,
      tags = [],
    } = req.body;
    if (!projectId || !mongoose.Types.ObjectId.isValid(projectId)) {
      return res.status(400).json({ message: "Invalid project" });
    }
    const project = await Project.findById(projectId).select("_id developers projectType");
    if (!project) return res.status(404).json({ message: "Project not found" });

    // Check if user is authorized to create task in this project
    // Only superadmin or assigned developers can create tasks
    if (req.user?.role?.toLowerCase() === "employee") {
      const isDeveloper = project.developers?.some(devId => devId.toString() === req.user._id.toString());
      if (!isDeveloper) {
        return res.status(403).json({ message: "You are not a member of this project and cannot create tasks." });
      }
    }

    const assignOk = await canAssignTasks(req);
    let parsedAssignees = assignees;
    if (typeof assignees === "string") {
      try { parsedAssignees = JSON.parse(assignees); }
      catch (e) { parsedAssignees = [assignees]; }
    }
    let assigneeIds = Array.isArray(parsedAssignees) ? parsedAssignees : [];
    assigneeIds = assigneeIds.filter((id) => mongoose.Types.ObjectId.isValid(id));
    if (!assignOk) {
      assigneeIds = [];
    } else {
      // Validate that all assignees are members of the project
      const validDevelopers = project.developers?.map(d => d.toString()) || [];
      const invalidAssignees = assigneeIds.filter(id => !validDevelopers.includes(id.toString()));

      if (invalidAssignees.length > 0) {
        return res.status(400).json({ message: "One or more assignees are not members of this project." });
      }
    }
    const reporter = reporterId && mongoose.Types.ObjectId.isValid(reporterId) ? reporterId : req.user?._id;
    if (startDate && dueDate) {
      if (new Date(dueDate) < new Date(startDate)) return res.status(400).json({ message: "Due date must be after start date" });
    }
    const finalProjectType = projectType || (project?.projectType || "");
    let parsedTags = tags;
    if (typeof tags === "string") {
      try { parsedTags = JSON.parse(tags); }
      catch (e) { parsedTags = [tags]; }
    }

    const documents = [];
    if (req.files && req.files.length > 0) {
      for (const file of req.files) {
        documents.push({
          name: file.originalname,
          url: `/uploads/documents/${file.filename}`
        });
      }
    }

    const doc = await Task.create({
      project: projectId,
      title: String(title || "").trim(),
      description: String(description || "").trim(),
      projectType: finalProjectType,
      technology,
      priority,
      status,
      assignees: assigneeIds,
      reporter,
      startDate: startDate || null,
      dueDate: dueDate || null,
      dueHours: Number(dueHours || 0),
      estimatedHours: Number(estimatedHours || 0),
      tags: Array.isArray(parsedTags) ? parsedTags : [],
      documents
    });
    const populated = await Task.findById(doc._id)
      .populate("project", "name")
      .populate("assignees", "name documents employeePersonal")
      .populate("reporter", "name");

    if (assigneeIds.length > 0) {
      await createNotification(
        req,
        "Task Assigned",
        `You have been assigned to task: ${doc.title}`,
        "task",
        assigneeIds,
        req.user?._id,
        { taskId: doc._id, projectId }
      );
    }

    emitTaskChanged(req, {
      action: "created",
      taskId: populated?._id,
      projectId: populated?.project?._id || projectId || null,
      affectedUserIds: uniqStrings([
        ...(assigneeIds || []),
        populated?.reporter?._id,
      ]),
    });

    res.json({ success: true, task: populated });
  } catch (e) {
    res.status(500).json({ message: "Error creating task", error: e.message });
  }
};

export const updateTask = async (req, res) => {
  try {
    const { id } = req.params;
    const update = { ...req.body };
    if (typeof update.projectType === "string") update.projectType = update.projectType.trim();
    if (typeof update.technology === "string") update.technology = update.technology.trim();
    if (update.projectId) {
      if (!mongoose.Types.ObjectId.isValid(update.projectId)) return res.status(400).json({ message: "Invalid project" });
      update.project = update.projectId;
      delete update.projectId;
      const proj = await Project.findById(update.project).select("projectType");
      if (proj && !update.projectType) {
        update.projectType = proj.projectType;
      }
    }
    if (update.assignees) {
      const assignOk = await canAssignTasks(req);
      if (!assignOk) {
        delete update.assignees;
      } else {
        let parsedUpdateAssignees = update.assignees;
        if (typeof update.assignees === "string") {
          try { parsedUpdateAssignees = JSON.parse(update.assignees); }
          catch (e) { parsedUpdateAssignees = [update.assignees]; }
        }
        update.assignees = (Array.isArray(parsedUpdateAssignees) ? parsedUpdateAssignees : []).filter((id) =>
          mongoose.Types.ObjectId.isValid(id)
        );

        // Validate assignees against project members
        const task = await Task.findById(id);
        const projectId = update.project || task.project;
        const project = await Project.findById(projectId).select("developers");

        if (project) {
          const validDevelopers = project.developers?.map(d => d.toString()) || [];
          const invalidAssignees = update.assignees.filter(id => !validDevelopers.includes(id.toString()));

          if (invalidAssignees.length > 0) {
            return res.status(400).json({ message: "One or more assignees are not members of this project." });
          }
        }
      }
    }
    if (update.startDate && update.dueDate) {
      if (new Date(update.dueDate) < new Date(update.startDate)) return res.status(400).json({ message: "Due date must be after start date" });
    }

    const oldTask = await Task.findById(id).select("assignees reporter project");
    if (update.tags) {
      let parsedUpdateTags = update.tags;
      if (typeof update.tags === "string") {
        try { parsedUpdateTags = JSON.parse(update.tags); }
        catch (e) { parsedUpdateTags = [update.tags]; }
      }
      update.tags = Array.isArray(parsedUpdateTags) ? parsedUpdateTags : [];
    }

    const newDocs = [];
    if (req.files && req.files.length > 0) {
      for (const file of req.files) {
        newDocs.push({
          name: file.originalname,
          url: `/uploads/documents/${file.filename}`
        });
      }
    }
    if (newDocs.length > 0) {
      update.$push = { documents: { $each: newDocs } };
    }

    const doc = await Task.findByIdAndUpdate(id, update, { new: true });
    if (!doc) return res.status(404).json({ message: "Task not found" });
    const populated = await Task.findById(id)
      .populate("project", "name")
      .populate("assignees", "name documents employeePersonal")
      .populate("reporter", "name");

    // Send notifications for newly assigned members
    if (update.assignees && oldTask) {
      const oldAssignees = oldTask.assignees.map(d => d.toString());
      const newAssignees = populated.assignees.map(d => d._id.toString());

      const addedAssignees = newAssignees.filter(d => !oldAssignees.includes(d));

      if (addedAssignees.length > 0) {
        await createNotification(
          req,
          "Task Assigned",
          `You have been assigned to task: ${doc.title}`,
          "task",
          addedAssignees,
          req.user?._id,
          { taskId: doc._id, projectId: doc.project }
        );
      }
    }

    emitTaskChanged(req, {
      action: "updated",
      taskId: populated?._id,
      projectId: populated?.project?._id || doc?.project || null,
      affectedUserIds: uniqStrings([
        ...(oldTask?.assignees || []),
        ...(populated?.assignees || []).map((a) => a?._id),
        oldTask?.reporter,
        populated?.reporter?._id,
      ]),
    });

    res.json({ success: true, task: populated });
  } catch (e) {
    res.status(500).json({ message: "Error updating task", error: e.message });
  }
};

export const deleteTask = async (req, res) => {
  try {
    const { id } = req.params;
    const existing = await Task.findById(id).select("assignees reporter project");
    const doc = await Task.findByIdAndDelete(id);
    if (!doc) return res.status(404).json({ message: "Task not found" });

    emitTaskChanged(req, {
      action: "deleted",
      taskId: id,
      projectId: existing?.project || null,
      affectedUserIds: uniqStrings([
        ...(existing?.assignees || []),
        existing?.reporter,
      ]),
    });

    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ message: "Error deleting task", error: e.message });
  }
};

export const updateStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const doc = await Task.findByIdAndUpdate(id, { status }, { new: true });
    if (!doc) return res.status(404).json({ message: "Task not found" });

    const detail = await Task.findById(id).select("assignees reporter project");
    emitTaskChanged(req, {
      action: "status_updated",
      taskId: id,
      projectId: detail?.project || null,
      affectedUserIds: uniqStrings([
        ...(detail?.assignees || []),
        detail?.reporter,
      ]),
    });

    res.json({ success: true, status: doc.status });
  } catch (e) {
    res.status(500).json({ message: "Error updating status", error: e.message });
  }
};

const pauseActiveTimersForUser = async ({ userId, excludeTaskId = null }) => {
  const filter = {
    timerStartAt: { $ne: null },
    $or: [{ timerStartedBy: userId }, { assignees: userId }],
  };
  if (excludeTaskId) filter._id = { $ne: excludeTaskId };

  const activeTasks = await Task.find(filter);
  let pausedCount = 0;
  const pausedTaskIds = [];

  for (const task of activeTasks) {
    const elapsed = Math.floor((Date.now() - new Date(task.timerStartAt).getTime()) / 1000);
    task.timeSpentSeconds = Math.max(0, (task.timeSpentSeconds || 0)) + Math.max(0, elapsed);
    task.timerStartAt = null;
    task.timerStartedBy = null;
    if (task.status !== "done") task.status = "paused";
    await task.save();
    pausedCount++;
    pausedTaskIds.push(task._id);
  }

  return { pausedCount, pausedTaskIds };
};

export const startTimer = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user?._id;
    if (!userId) return res.status(401).json({ message: "Unauthorized" });

    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ message: "Task not found" });
    if (task.timerStartAt) {
      const startedBy = task.timerStartedBy?.toString();
      if (!startedBy || startedBy !== userId.toString()) {
        return res.status(409).json({ message: "Task timer is already running" });
      }
      const populated = await Task.findById(task._id).populate("project", "name").populate("assignees", "name documents employeePersonal").populate("reporter", "name");
      return res.json({ success: true, task: populated });
    }

    const paused = await pauseActiveTimersForUser({ userId, excludeTaskId: task._id });

    task.timerStartAt = new Date();
    task.timerStartedBy = userId;
    if (task.status !== "in_progress") task.status = "in_progress";
    await task.save();
    const populated = await Task.findById(task._id).populate("project", "name").populate("assignees", "name documents employeePersonal").populate("reporter", "name");

    if ((paused?.pausedTaskIds || []).length > 0) {
      emitTaskChanged(req, {
        action: "timer_paused_bulk",
        taskIds: paused.pausedTaskIds,
        affectedUserIds: uniqStrings([userId]),
      });
    }

    emitTaskChanged(req, {
      action: "timer_started",
      taskId: populated?._id,
      projectId: populated?.project?._id || null,
      affectedUserIds: uniqStrings([
        userId,
        ...(populated?.assignees || []).map((a) => a?._id),
        populated?.reporter?._id,
      ]),
    });

    res.json({ success: true, task: populated });
  } catch (e) {
    res.status(500).json({ message: "Error starting timer", error: e.message });
  }
};

export const pauseTimer = async (req, res) => {
  try {
    const { id } = req.params;
    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ message: "Task not found" });
    if (task.timerStartAt) {
      const elapsed = Math.floor((Date.now() - new Date(task.timerStartAt).getTime()) / 1000);
      task.timeSpentSeconds = Math.max(0, (task.timeSpentSeconds || 0)) + Math.max(0, elapsed);
      task.timerStartAt = null;
      task.timerStartedBy = null;
    } else {
      task.timerStartedBy = null;
    }
    if (task.status !== "done") task.status = "paused";
    await task.save();
    const populated = await Task.findById(task._id).populate("project", "name").populate("assignees", "name documents employeePersonal").populate("reporter", "name");

    emitTaskChanged(req, {
      action: "timer_paused",
      taskId: populated?._id,
      projectId: populated?.project?._id || null,
      affectedUserIds: uniqStrings([
        req.user?._id,
        ...(populated?.assignees || []).map((a) => a?._id),
        populated?.reporter?._id,
      ]),
    });

    res.json({ success: true, task: populated });
  } catch (e) {
    res.status(500).json({ message: "Error pausing timer", error: e.message });
  }
};

export const endTimer = async (req, res) => {
  try {
    const { id } = req.params;
    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ message: "Task not found" });
    if (task.timerStartAt) {
      const elapsed = Math.floor((Date.now() - new Date(task.timerStartAt).getTime()) / 1000);
      task.timeSpentSeconds = Math.max(0, (task.timeSpentSeconds || 0)) + Math.max(0, elapsed);
      task.timerStartAt = null;
      task.timerStartedBy = null;
    }
    task.status = "done";
    await task.save();
    const populated = await Task.findById(task._id).populate("project", "name").populate("assignees", "name documents employeePersonal").populate("reporter", "name");

    emitTaskChanged(req, {
      action: "timer_ended",
      taskId: populated?._id,
      projectId: populated?.project?._id || null,
      affectedUserIds: uniqStrings([
        req.user?._id,
        ...(populated?.assignees || []).map((a) => a?._id),
        populated?.reporter?._id,
      ]),
    });

    res.json({ success: true, task: populated });
  } catch (e) {
    res.status(500).json({ message: "Error ending timer", error: e.message });
  }
};

export const pauseAllTimersForUser = async (req, res) => {
  try {
    const userId = req.user?._id;
    if (!userId) return res.status(401).json({ message: "Unauthorized" });
    const paused = await pauseActiveTimersForUser({ userId });

    if ((paused?.pausedTaskIds || []).length > 0) {
      emitTaskChanged(req, {
        action: "timer_paused_bulk",
        taskIds: paused.pausedTaskIds,
        affectedUserIds: uniqStrings([userId]),
      });
    }
    res.json({ success: true, pausedCount: paused?.pausedCount || 0 });
  } catch (e) {
    res.status(500).json({ message: "Error pausing timers", error: e.message });
  }
};

export const exportTasks = async (req, res) => {
  try {
    const { search = "", priority = "", status = "", projectId = "", format = "csv" } = req.query;
    const query = {};
    if (search) query.$or = [{ title: { $regex: search, $options: "i" } }, { description: { $regex: search, $options: "i" } }];
    if (priority) query.priority = priority;
    if (status) query.status = status;
    if (projectId && mongoose.Types.ObjectId.isValid(projectId)) query.project = projectId;

    // Role-based filtering: Employees see only tasks assigned to them
    if (req.user?.role?.toLowerCase() === "employee" && req.user?._id) {
      query.assignees = req.user._id;
    }

    const items = await Task.find(query).populate("project", "name").populate("assignees", "name documents employeePersonal");
    const rows = items.map((t) => ({
      Project: t.project?.name || "",
      Title: t.title,
      Priority: t.priority,
      Status: t.status,
      Assignees: (t.assignees || []).map((u) => u.name).join(", "),
      StartDate: t.startDate ? new Date(t.startDate).toLocaleDateString() : "",
      DueDate: t.dueDate ? new Date(t.dueDate).toLocaleDateString() : "",
      DueHours: t.dueHours || 0,
      EstimatedHours: t.estimatedHours || 0,
      TimeSpent: t.timeSpentSeconds || 0,
      Tags: (t.tags || []).join(","),
    }));
    const ws = xlsx.utils.json_to_sheet(rows);
    const wb = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(wb, ws, "Tasks");
    const buf = format === "xlsx" ? xlsx.write(wb, { type: "buffer", bookType: "xlsx" }) : xlsx.write(wb, { type: "buffer", bookType: "csv" });
    res.setHeader("Content-Disposition", `attachment; filename=tasks.${format}`);
    res.send(buf);
  } catch (e) {
    res.status(500).json({ message: "Error exporting tasks", error: e.message });
  }
};

export const listTasksByProject = async (req, res) => {
  try {
    const { id } = req.params;
    const { page = 1, limit = 10 } = req.query;
    if (!mongoose.Types.ObjectId.isValid(id)) return res.status(400).json({ message: "Invalid project" });
    const base = { project: id };
    const q = { ...base };

    // Role-based filtering: Employees see only tasks assigned to them
    if (req.user?.role?.toLowerCase() === "employee" && req.user?._id) {
      q.assignees = req.user._id;
    }

    const total = await Task.countDocuments(q);
    const items = await Task.find(q)
      .populate("assignees", "name documents employeePersonal")
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));
    res.json({ success: true, items, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (e) {
    res.status(500).json({ message: "Error fetching project tasks", error: e.message });
  }
};
