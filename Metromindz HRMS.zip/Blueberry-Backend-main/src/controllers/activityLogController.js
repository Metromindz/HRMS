import ActivityLog from "../models/ActivityLog.js";
import User from "../models/User.js";
import xlsx from "xlsx";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Export activity logs to Excel
 */
export const exportActivityLogs = async (req, res) => {
  try {
    const { userId, action, startDate, endDate } = req.query;

    const query = {};
    if (userId) query.userId = userId;
    if (action) query.action = action;
    if (startDate && endDate) {
      query.createdAt = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }

    const logs = await ActivityLog.find(query)
      .populate('userId', 'name email employeeId')
      .sort({ createdAt: -1 });

    const formattedLogs = logs.map(log => ({
      'Log ID': log._id.toString(),
      'User': log.userId?.name || 'System',
      'Employee ID': log.userId?.employeeId || 'N/A',
      'Action': log.action,
      'Description': log.description,
      'Date': new Date(log.createdAt).toLocaleDateString(),
      'Time': new Date(log.createdAt).toLocaleTimeString(),
      'IP Address': log.ipAddress || 'N/A',
      'User Agent': log.userAgent || 'N/A'
    }));

    // Create workbook and worksheet
    const wb = xlsx.utils.book_new();
    const ws = xlsx.utils.json_to_sheet(formattedLogs);

    // Add worksheet to workbook
    xlsx.utils.book_append_sheet(wb, ws, "Activity Logs");

    // Generate buffer
    const buffer = xlsx.write(wb, { type: "buffer", bookType: "xlsx" });

    // Set headers for download
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename=activity-logs-${Date.now()}.xlsx`
    );

    res.send(buffer);
  } catch (error) {
    console.error("Error exporting activity logs:", error);
    res.status(500).json({ message: "Error exporting activity logs", error: error.message });
  }
};

/**
 * Create activity log entry
 */
export const createActivityLog = async (userId, action, description, req = null, metadata = {}) => {
  try {
    const logData = {
      userId,
      action,
      description,
      metadata,
    };

    if (req) {
      logData.ipAddress = req.ip || req.connection.remoteAddress;
      logData.userAgent = req.get('User-Agent');
    }

    const activityLog = new ActivityLog(logData);
    await activityLog.save();
    return activityLog;
  } catch (error) {
    console.error("Error creating activity log:", error);
  }
};

/**
 * Get activity logs with pagination
 */
export const getActivityLogs = async (req, res) => {
  try {
    const { page = 1, limit = 20, userId, action } = req.query;
    const skip = (page - 1) * limit;

    const query = {};
    if (userId) query.userId = userId;
    if (action) query.action = action;

    const total = await ActivityLog.countDocuments(query);
    const logs = await ActivityLog.find(query)
      .populate('userId', 'name email employeeId')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const formattedLogs = logs.map(log => ({
      id: log._id,
      day: new Date(log.createdAt).getDate().toString().padStart(2, '0'),
      month: new Date(log.createdAt).toLocaleDateString('en-US', { month: 'short' }),
     title: `${log.description} by ${log.userId?.name || 'System'}`,
      time: new Date(log.createdAt).toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      }),
      createdBy: log.userId?.name || 'System',
      action: log.action,
      createdAt: log.createdAt,
      metadata: log.metadata
    }));

    res.json({
      success: true,
      logs: formattedLogs,
      pagination: {
        total,
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / limit),
        limit: parseInt(limit),
      },
    });
  } catch (error) {
    console.error("Error fetching activity logs:", error);
    res.status(500).json({ message: "Error fetching activity logs", error: error.message });
  }
};

/**
 * Get recent activity logs (for dashboard)
 */
export const getRecentActivityLogs = async (req, res) => {
  try {
    const { limit = 10 } = req.query;

    const logs = await ActivityLog.find()
      .populate('userId', 'name email employeeId')
      .sort({ createdAt: -1 })
      .limit(parseInt(limit));

    const formattedLogs = logs.map(log => ({
      id: log._id,
      day: new Date(log.createdAt).getDate().toString().padStart(2, '0'),
      month: new Date(log.createdAt).toLocaleDateString('en-US', { month: 'short' }),
      title: log.action === 'login' 
        ? log.description 
        : `${log.description} by ${log.userId?.name || 'System'}`, 
      time: new Date(log.createdAt).toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      }),
      createdBy: log.userId?.name || 'System',
      action: log.action,
      createdAt: log.createdAt
    }));

    res.json({
      success: true,
      logs: formattedLogs,
    });
  } catch (error) {
    console.error("Error fetching recent activity logs:", error);
    res.status(500).json({ message: "Error fetching recent activity logs", error: error.message });
  }
};