import LeaveBalance from "../models/LeaveBalance.js";
import LeaveMaster from "../models/LeaveMaster.js";
import User from "../models/User.js";
import LeaveRequest from "../models/LeaveRequests.js";
import { createNotification } from "./notificationController.js";
import { createActivityLog } from "./activityLogController.js";


// 🟢 Initialize or get leave balance for an employee
export const initializeLeaveBalance = async (empId, year = new Date().getFullYear()) => {
  try {
    const employee = await User.findOne({ employeeId: empId });
    if (!employee) throw new Error("Employee not found");

    // Get all active leave types
    const leaveTypes = await LeaveMaster.find({});

    let leaveBalance = await LeaveBalance.findOne({ employeeId: empId });

    if (!leaveBalance) {
      // Create new leave balance record
      const leaveBalances = leaveTypes.map(leaveType => ({
        leaveId: leaveType._id,
        leaveName: leaveType.leaveName,
        year: year,
        yearlyAllocated: leaveType.yearlyCount,
        yearlyUsed: 0,
        yearlyRemaining: leaveType.yearlyCount,
        carryForwardFromPrevious: 0,
        monthlyUsage: Array.from({ length: 12 }, (_, i) => ({
          month: i + 1,
          year: year,
          monthlyAllocated: leaveType.monthlyLimit,
          monthlyUsed: 0,
          monthlyRemaining: leaveType.monthlyLimit,
          lopDays: 0
        })),
        applications: []
      }));

      leaveBalance = new LeaveBalance({
        employee: employee._id,
        employeeId: empId,
        employeeName: employee.name,
        leaveBalances: leaveBalances
      });

      await leaveBalance.save();
    } else {
      // Check for any new leave types that aren't in the existing balance record
      let updated = false;
      for (const leaveType of leaveTypes) {
        const hasType = leaveBalance.leaveBalances.some(
          lb => lb.leaveId.toString() === leaveType._id.toString() && lb.year === year
        );

        if (!hasType) {
          leaveBalance.leaveBalances.push({
            leaveId: leaveType._id,
            leaveName: leaveType.leaveName,
            year: year,
            yearlyAllocated: leaveType.yearlyCount,
            yearlyUsed: 0,
            yearlyRemaining: leaveType.yearlyCount,
            carryForwardFromPrevious: 0,
            monthlyUsage: Array.from({ length: 12 }, (_, i) => ({
              month: i + 1,
              year: year,
              monthlyAllocated: leaveType.monthlyLimit,
              monthlyUsed: 0,
              monthlyRemaining: leaveType.monthlyLimit,
              lopDays: 0
            })),
            applications: []
          });
          updated = true;
        }
      }

      if (updated) {
        await leaveBalance.save();
      }
    }

    return leaveBalance;
  } catch (error) {
    throw error;
  }
};

// 🟢 Process leave application and calculate balances/LOP
export const processLeaveApplication = async (req, res) => {
  try {
    const { empId, leaveId, fromDate, toDate, numberOfDays, reason } = req.body;


    // Validate inputs
    const leaveType = await LeaveMaster.findById(leaveId);
    if (!leaveType) {
      return res.status(404).json({ message: "Invalid leave type ID" });
    }

    const employee = await User.findOne({ employeeId: empId });
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    // Initialize or get leave balance(if leaveBalance not there it will creeate and save in below func)
    const leaveBalance = await initializeLeaveBalance(empId);
    const currentYear = new Date().getFullYear();
    const applicationMonth = new Date(fromDate).getMonth() + 1;

    // Find the specific leave balance record(in leaveBalance check id & year is true)
    const leaveBalanceRecord = leaveBalance.leaveBalances.find(
      lb => lb.leaveId.toString() === leaveId.toString() && lb.year === currentYear
    );

    if (!leaveBalanceRecord) {
      return res.status(404).json({ message: "Leave balance record not found" });
    }

    // Find monthly usage for the application month(check whether month is matching)
    const monthlyUsage = leaveBalanceRecord.monthlyUsage.find(
      mu => mu.month === applicationMonth
    );

    if (!monthlyUsage) {
      return res.status(404).json({ message: "Monthly balance not found" });
    }

    let approvedDays = 0;
    let lopDays = 0;
    const remainingMonthly = monthlyUsage.monthlyRemaining;
    const remainingYearly = leaveBalanceRecord.yearlyRemaining;

    // 🟢 Calculate approved days and LOP based on yearly balance first
    if (remainingYearly >= numberOfDays) {
      // Enough yearly leaves available
      approvedDays = numberOfDays;
      lopDays = 0;
    } else if (remainingYearly > 0) {
      // Partial yearly balance available
      approvedDays = remainingYearly;
      lopDays = numberOfDays - approvedDays;
    } else {
      // No yearly balance available - all LOP
      approvedDays = 0;
      lopDays = numberOfDays;
    }

    // 🟢 Update balances - update both yearly and monthly tracking
    leaveBalanceRecord.yearlyUsed += approvedDays;
    leaveBalanceRecord.yearlyRemaining = leaveBalanceRecord.yearlyAllocated - leaveBalanceRecord.yearlyUsed;

    // Update monthly usage tracking - only count what fits in monthly limit
    const monthlyUsedFromThisRequest = Math.min(numberOfDays, monthlyUsage.monthlyRemaining);
    monthlyUsage.monthlyUsed += monthlyUsedFromThisRequest;
    monthlyUsage.monthlyRemaining = monthlyUsage.monthlyAllocated - monthlyUsage.monthlyUsed;

    // LOP days are those exceeding monthly limit
    const monthlyLopDays = Math.max(0, numberOfDays - monthlyUsedFromThisRequest);
    monthlyUsage.lopDays += monthlyLopDays;

    // 🟢 Store the application in balance record
    leaveBalanceRecord.applications.push({
      fromDate,
      toDate,
      requestedDays: numberOfDays,
      approvedDays,
      lopDays,
      // status: lopDays > 0 ? 'partially_approved' : 'approved',
      status: 'approved',

      processedAt: new Date()
    });

    leaveBalance.updatedAt = new Date();


    await leaveBalance.save();
    const io = req.app.get('io');
    await createNotification(
      "Leave Status Updated",
      `Leave request from ${new Date(fromDate).toLocaleDateString()} to ${new Date(toDate).toLocaleDateString()} has been to approved.`,
      "leave_status",
      employee._id,
      req.user?._id,
      { employeeId: empId, employeeName: employee.name },
      io
    );

    await createActivityLog(
      req.user?.id,
      "emp_leaveStatus_update",
      `Employee ${employee.name} (${employee.employeeId}) leave status has been approved`,
      req,
      {
        employeeId: empId, employeeName: employee.name
      }
    );

    // 🟢 Update leave request record with processing results
    await updateLeaveRequestRecord(empId, leaveId, fromDate, toDate, numberOfDays, approvedDays, lopDays, 'approved');


    const response = {
      message: lopDays > 0 ?
        `Leave partially approved. ${approvedDays} days approved, ${lopDays} days marked as LOP` :
        "Leave approved successfully",
      data: {
        employeeId: empId,
        employeeName: employee.name,
        leaveType: leaveType.leaveName,
        requestedDays: numberOfDays,
        approvedDays,
        lopDays,
        monthlyBalance: Math.max(0, monthlyUsage.monthlyRemaining), // Show 0 if negative
        yearlyBalance: leaveBalanceRecord.yearlyRemaining,
        monthlyLOP: monthlyUsage.lopDays,
        // Additional LOP info if monthly balance went negative
        ...(monthlyUsage.monthlyRemaining < 0 && {
          monthlyOveruse: Math.abs(monthlyUsage.monthlyRemaining),
          note: `Monthly limit exceeded by ${Math.abs(monthlyUsage.monthlyRemaining)} days`
        })
      }
    };


    res.status(200).json(response);

  } catch (error) {
    console.error("❌ Error processing leave application:", error);
    res.status(500).json({
      message: "Server error",
      error: error.message || error,
    });
  }
};

// 🟢 Update existing leave request record with processing results
const updateLeaveRequestRecord = async (empId, leaveId, fromDate, toDate, requestedDays, approvedDays, lopDays, status) => {
  try {
    const leaveRequest = await LeaveRequest.findOne({ employeeId: empId });
    if (!leaveRequest) {
      throw new Error("Leave request record not found");
    }

    // Find the specific leave type and application
    const leaveTypeRecord = leaveRequest.leaveRequests.find(
      lr => lr.leaveId.toString() === leaveId.toString()
    );

    if (!leaveTypeRecord) {
      throw new Error("Leave type record not found");
    }

    // Find the most recent pending application that matches the dates
    const application = leaveTypeRecord.applications.find(
      app => app.fromDate.getTime() === new Date(fromDate).getTime() &&
        app.toDate.getTime() === new Date(toDate).getTime() &&
        app.status === 'pending'
    );

    if (!application) {
      throw new Error("Matching pending application not found");
    }

    // Update the application with processing results
    application.status = status;
    application.approvedDays = approvedDays;
    application.lopDays = lopDays;

    leaveRequest.updatedAt = new Date();
    await leaveRequest.save();
  } catch (error) {
    console.error("Error updating leave request record:", error);
    throw error;
  }
};

// 🟢 Get employee leave balance
export const getEmployeeLeaveBalance = async (req, res) => {
  try {
    const { empId } = req.params;
    const { year = new Date().getFullYear() } = req.query;

    const leaveBalance = await LeaveBalance.findOne({ employeeId: empId })
      .populate("leaveBalances.leaveId", "leaveName yearlyCount monthlyLimit carryForward");

    if (!leaveBalance) {
      // Initialize balance if not exists
      const newBalance = await initializeLeaveBalance(empId, parseInt(year));
      return res.status(200).json({
        message: "Leave balance initialized",
        data: newBalance
      });
    }

    // Filter for specific year if requested
    const filteredBalances = leaveBalance.leaveBalances.filter(lb => lb.year === parseInt(year));

    res.status(200).json({
      message: "Leave balance retrieved successfully",
      data: {
        ...leaveBalance.toObject(),
        leaveBalances: filteredBalances
      }
    });

  } catch (error) {
    console.error("❌ Error retrieving leave balance:", error);
    res.status(500).json({
      message: "Server error",
      error: error.message || error,
    });
  }
};

// 🟢 Monthly reset function (to be run via cron job)
export const resetMonthlyLeaves = async () => {
  try {
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();

    const leaveBalances = await LeaveBalance.find({});
    const leaveTypes = await LeaveMaster.find({});

    for (const balance of leaveBalances) {
      for (const leaveBalanceRecord of balance.leaveBalances) {
        if (leaveBalanceRecord.year === currentYear) {
          const monthlyUsageExists = leaveBalanceRecord.monthlyUsage.some(
            mu => mu.month === currentMonth && mu.year === currentYear
          );

          if (!monthlyUsageExists) {
            const leaveType = leaveTypes.find(lt => lt._id.toString() === leaveBalanceRecord.leaveId.toString());
            if (leaveType) {
              leaveBalanceRecord.monthlyUsage.push({
                month: currentMonth,
                year: currentYear,
                monthlyAllocated: leaveType.monthlyLimit,
                monthlyUsed: 0,
                monthlyRemaining: leaveType.monthlyLimit,
                lopDays: 0
              });
            }
          }
        }
      }
      await balance.save();
    }


  } catch (error) {
    console.error("Error resetting monthly leaves:", error);
  }
};