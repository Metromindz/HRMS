import express from "express";
import { checkPermission } from "../middleware/checkPermission.js";
import { upload } from "../middleware/upload.js";
import {
  createCompany,
  listCompanies,
  updateCompany,
  deleteCompany,
  exportCompanies,
  getCompanyProjects,
  getCompanyOverview,
} from "../controllers/companyController.js";

const router = express.Router();

router.get("/", checkPermission("company.view"), listCompanies);
router.get("/selection", checkPermission("project.create"), listCompanies);
router.post("/", checkPermission("company.create"), upload.single("logo"), createCompany);
router.put("/:id", checkPermission("company.edit"), upload.single("logo"), updateCompany);
router.delete("/:id", checkPermission("company.delete"), deleteCompany);
router.get("/export", checkPermission("company.view"), exportCompanies);
router.get("/:id/projects", checkPermission("project.view"), getCompanyProjects);
router.get("/:id/overview", checkPermission("company.overview"), getCompanyOverview);

export default router;
