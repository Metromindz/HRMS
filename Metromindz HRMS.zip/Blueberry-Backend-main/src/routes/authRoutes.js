import express from "express";
import { getProfile, login, registerSuperAdmin, updateProfile } from "../controllers/authController.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();

// Superadmin registration (one-time setup)
router.post("/register-superadmin", registerSuperAdmin);

// Universal login for all users
router.post("/login", login);

// Get user profile (requires authentication)
router.get("/profile", protect, getProfile);

// Update user profile (requires authentication)
router.put("/profile", protect, updateProfile);

export default router;
