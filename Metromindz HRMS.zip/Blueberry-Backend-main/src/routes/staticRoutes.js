import express from 'express';
import { getDashboardCounts,getLeaveCounts } from '../controllers/staticController.js';

const router = express.Router();

router.get('/counts', getDashboardCounts);
router.get('/counts/leave',getLeaveCounts);

export default router;
// or export default router; (if you want default export)