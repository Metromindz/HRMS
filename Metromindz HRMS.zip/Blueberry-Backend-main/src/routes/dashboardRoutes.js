// routes/birthdayRoutes.js
import express from "express";
import {
  getUpcomingBirthdays,
  getDashboardSummary,
  getLeadsTrend,
  getProjectStatus,
  getTaskStatus,
  getLeadsBySource,
  getRecentActivities,
  getTaskCompletionTrend,
} from "../controllers/dashbaordController.js";
import { protect } from "../middleware/auth.js";


const router = express.Router();

router.get("/upcoming-birthdays", protect, getUpcomingBirthdays);
router.get("/summary", protect, getDashboardSummary);
router.get("/leads-trend", protect, getLeadsTrend);
router.get("/project-status", protect, getProjectStatus);
router.get("/task-status", protect, getTaskStatus);
router.get("/leads-sources", protect, getLeadsBySource);
router.get("/recent-activities", protect, getRecentActivities);
router.get("/task-completion-trend", protect, getTaskCompletionTrend);

export default router;
