import express from "express";
import { checkPermission } from "../middleware/checkPermission.js";
import {
  createDepartment,
  deleteDepartment,
  editDepartment,
  getAllDepartment,
} from "../controllers/departmentController.js";

const router = express.Router();

router.post(
  "/create",
  checkPermission("department.create"),
  createDepartment
);

router.put("/edit/:id", checkPermission("department.edit"), editDepartment);
router.get("/", checkPermission("department.view"), getAllDepartment);
router.delete("/:id", checkPermission("department.delete"), deleteDepartment);

export default router;
