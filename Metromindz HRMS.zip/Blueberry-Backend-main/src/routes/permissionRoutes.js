import express from "express";
import Permission from "../models/Permission.js";
import Widget from "../models/Widget.js";
import { checkPermission } from "../middleware/checkPermission.js";

const router = express.Router();

const permissions = [
  { module: "Employee", label: "Create", key: "employee.create", description: "Create new employee" },
  { module: "Employee", label: "Edit", key: "employee.edit", description: "Edit employee details" },
  { module: "Employee", label: "Delete", key: "employee.delete", description: "Delete an employee" },
  { module: "Employee", label: "View All", key: "employee.view", description: "View all employees" },
  { module: "Employee", label: "View One", key: "employee.view_one", description: "View single employee details" },
  { module: "Employee", label: "Status", key: "employee.status", description: "Change employee status" },
  { module: "Employee", label: "Import", key: "employee.import", description: "Import employees" },
  { module: "Employee", label: "Export", key: "employee.export", description: "Export employees" },

  { module: "Leave", label: "Create", key: "leave.create", description: "Create leave" },
  { module: "Leave", label: "Edit", key: "leave.edit", description: "Edit leave" },
  { module: "Leave", label: "Delete", key: "leave.delete", description: "Delete leave" },
  { module: "Leave", label: "View", key: "leave.view", description: "View leave" },
  { module: "Leave", label: "Status", key: "leave.status", description: "Change leave status" },
  { module: "Leave", label: "Export", key: "leave.export", description: "Export leave" },

  { module: "Attendance", label: "Punch View", key: "attendance.punch.view", description: "View punch" },
  { module: "Attendance", label: "Calendar View", key: "attendance.calendar.view", description: "View calendar" },
  { module: "Attendance", label: "Import", key: "attendance.import", description: "Import attendance" },

  { module: "Payroll", label: "Employee Salary", key: "payroll.salary.view", description: "View salaries" },
  { module: "Payroll", label: "Generate", key: "payroll.generate.view", description: "Generate payroll" },

  { module: "Company", label: "Create", key: "company.create", description: "Create company" },
  { module: "Company", label: "Edit", key: "company.edit", description: "Edit company" },
  { module: "Company", label: "Delete", key: "company.delete", description: "Delete company" },
  { module: "Company", label: "View", key: "company.view", description: "View companies" },
  { module: "Company", label: "Overview", key: "company.overview", description: "View company overview dashboard" },

  { module: "Project", label: "Create", key: "project.create", description: "Create project" },
  { module: "Project", label: "Edit", key: "project.edit", description: "Edit project" },
  { module: "Project", label: "Delete", key: "project.delete", description: "Delete project" },
  { module: "Project", label: "View", key: "project.view", description: "View projects" },
  { module: "Project", label: "Export", key: "project.export", description: "Export projects" },
  { module: "Project", label: "Assign Developers", key: "project.assign", description: "Assign developers" },
  { module: "Project", label: "Manage Details", key: "project.details", description: "Manage project details" },
  { module: "Project", label: "View Value", key: "project.value", description: "View project contract value" },
  { module: "Project", label: "View Documents", key: "project.documents", description: "View project uploaded documents" },

  { module: "Holidays", label: "View", key: "holidays.view", description: "View holidays" },
  { module: "Holidays", label: "Create", key: "holidays.create", description: "Create holiday" },
  { module: "Holidays", label: "Edit", key: "holidays.edit", description: "Edit holiday" },
  { module: "Holidays", label: "Delete", key: "holidays.delete", description: "Delete holiday" },
  { module: "Holidays", label: "Export", key: "holidays.export", description: "Export holidays" },

  { module: "Department", label: "Create", key: "department.create", description: "Create department" },
  { module: "Department", label: "Edit", key: "department.edit", description: "Edit department" },
  { module: "Department", label: "View", key: "department.view", description: "View departments" },
  { module: "Department", label: "Delete", key: "department.delete", description: "Delete department" },

  { module: "Designation", label: "Create", key: "designation.create", description: "Create designation" },
  { module: "Designation", label: "Edit", key: "designation.edit", description: "Edit designation" },
  { module: "Designation", label: "View", key: "designation.view", description: "View designations" },
  { module: "Designation", label: "Delete", key: "designation.delete", description: "Delete designation" },

  { module: "Grade", label: "Create", key: "grade.create", description: "Create grade" },
  { module: "Grade", label: "Edit", key: "grade.edit", description: "Edit grade" },
  { module: "Grade", label: "View", key: "grade.view", description: "View grades" },
  { module: "Grade", label: "Delete", key: "grade.delete", description: "Delete grade" },

  { module: "Shift", label: "Create", key: "shift.create", description: "Create shift" },
  { module: "Shift", label: "Edit", key: "shift.edit", description: "Edit shift" },
  { module: "Shift", label: "View", key: "shift.view", description: "View shifts" },
  { module: "Shift", label: "Delete", key: "shift.delete", description: "Delete shift" },

  { module: "Commonleave", label: "Create", key: "commonleave.create", description: "Create leave master" },
  { module: "Commonleave", label: "Edit", key: "commonleave.edit", description: "Edit leave master" },
  { module: "Commonleave", label: "View", key: "commonleave.view", description: "View leave master" },
  { module: "Commonleave", label: "Delete", key: "commonleave.delete", description: "Delete leave master" },

  { module: "Task", label: "Create", key: "task.create", description: "Create task" },
  { module: "Task", label: "Edit", key: "task.edit", description: "Edit task" },
  { module: "Task", label: "Delete", key: "task.delete", description: "Delete task" },
  { module: "Task", label: "View", key: "task.view", description: "View tasks" },
  { module: "Task", label: "Export", key: "task.export", description: "Export tasks" },
  { module: "Task", label: "Assign", key: "task.assign", description: "Assign tasks" },

  { module: "Lead", label: "Create", key: "lead.create", description: "Create lead" },
  { module: "Lead", label: "Edit", key: "lead.edit", description: "Edit lead" },
  { module: "Lead", label: "Delete", key: "lead.delete", description: "Delete lead" },
  { module: "Lead", label: "View", key: "lead.view", description: "View leads" },
  { module: "Lead", label: "Assign", key: "lead.assign", description: "Assign leads" },
  { module: "Lead", label: "Import", key: "lead.import", description: "Import leads" },
  { module: "Lead", label: "Export", key: "lead.export", description: "Export leads" },

  { module: "Announcement", label: "Create", key: "announcement.create", description: "Create announcement" },
  { module: "Announcement", label: "Delete", key: "announcement.delete", description: "Delete announcement" },
  { module: "Announcement", label: "View", key: "announcement.view", description: "View announcements" },

  { module: "Expense", label: "Submit", key: "expense.submit", description: "Submit an expense" },
  { module: "Expense", label: "View My", key: "expense.view_my", description: "View own expenses" },
  { module: "Expense", label: "View All", key: "expense.view_all", description: "View all expenses (Admin/HR)" },

  { module: "Expense", label: "Approve", key: "expense.approve", description: "Approve/Reject expenses" },

  { module: "Dashboard", label: "View", key: "dashboard.view", description: "View dashboard" },
];

// Seed permissions (superadmin only)
router.post("/seed", async (req, res) => {
  try {
    const existingCount = await Permission.countDocuments();
    if (existingCount > 0) {
      return res.status(400).json({ message: "Permissions already seeded" });
    }

    await Permission.insertMany(permissions);
    res.json({ message: `${permissions.length} permissions seeded successfully` });
  } catch (error) {
    res.status(500).json({ message: "Error seeding permissions", error: error.message });
  }
});

// Upsert missing permissions
router.post("/seed-update", async (req, res) => {
  try {
    let created = 0;
    for (const perm of permissions) {
      const exists = await Permission.findOne({ key: perm.key });
      if (!exists) {
        await Permission.create(perm);
        created++;
      }
    }
    res.json({ message: `Upsert complete, created ${created} new permissions` });
  } catch (error) {
    res.status(500).json({ message: "Error upserting permissions", error: error.message });
  }
});

// Get all permissions
router.get("/", async (req, res) => {
  try {
    const staticPermissions = [...permissions];

    // Dynamically add widget permissions from Widget registry
    const activeWidgets = await Widget.find({ status: "active" });
    const widgetPermissions = activeWidgets.map(widget => ({
      module: "Dashboard",
      label: widget.label,
      key: `widget.${widget.key}`,
      description: `Access to ${widget.label} widget`
    }));

    const allPermissions = [...staticPermissions, ...widgetPermissions];
    res.json({ permissions: allPermissions });
  } catch (error) {
    res.status(500).json({ message: "Error fetching permissions", error: error.message });
  }
});

export default router;
