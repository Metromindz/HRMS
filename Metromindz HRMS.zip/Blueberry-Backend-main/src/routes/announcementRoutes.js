import express from 'express';
import {
  createAnnouncement,
  getAnnouncements,
  getAllAnnouncements,
  deleteAnnouncement,
  acknowledgeAnnouncement
} from '../controllers/announcementController.js';
import { protect } from '../middleware/auth.js';
import { checkPermission } from '../middleware/checkPermission.js';

const router = express.Router();

/**
 * Announcement Routes
 * 
 * Base Path: /api/announcements
 * 
 * Logic:
 * - All routes are protected by 'protect' middleware (requires valid JWT).
 * - Specific actions require specific permissions via 'checkPermission'.
 */

// Route: /
// GET: Fetch personalized announcement feed for the logged-in user.
// POST: Create a new announcement (Requires 'announcement.create' permission).
router.route('/')
  .post(protect, checkPermission('announcement.create'), createAnnouncement)
  .get(protect, getAnnouncements);

// Route: /all
// GET: Fetch ALL announcements (Admin view). Requires 'announcement.view' permission.
router.route('/all')
  .get(protect, checkPermission('announcement.view'), getAllAnnouncements);

// Route: /:id
// DELETE: Remove an announcement. Requires 'announcement.delete' permission.
router.route('/:id')
  .delete(protect, checkPermission('announcement.delete'), deleteAnnouncement);

// Route: /:id/acknowledge
// POST: Mark an announcement as read by the user.
router.route('/:id/acknowledge')
  .post(protect, acknowledgeAnnouncement);

export default router;
