import mongoose from "mongoose";

const taskSchema = new mongoose.Schema(
  {
    project: { type: mongoose.Schema.Types.ObjectId, ref: "Project", required: true },
    title: { type: String, required: true },
    description: { type: String },
    projectType: {
      type: String,
      enum: ["Digital Marketing", "Web Application", "Design", "Mobile App", "SEO"],
    },
    technology: { type: String, default: "" },
    priority: { type: String, enum: ["High", "Medium", "Low"], required: true },
    status: { type: String, enum: ["todo", "in_progress", "paused", "blocked", "done"], default: "todo" },
    assignees: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    reporter: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    startDate: { type: Date },
    dueDate: { type: Date },
    dueHours: { type: Number, default: 0 },
    estimatedHours: { type: Number, default: 0 },
    timeSpentSeconds: { type: Number, default: 0 },
    timerStartAt: { type: Date, default: null },
    timerStartedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    tags: [String],
    documents: [{
      name: String,
      url: String,
      uploadedAt: { type: Date, default: Date.now }
    }]
  },
  { timestamps: true }
);

export default mongoose.model("Task", taskSchema);
