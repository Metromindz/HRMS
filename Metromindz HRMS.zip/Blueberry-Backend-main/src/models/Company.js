import mongoose from "mongoose";
import { encrypt, decrypt } from "../utils/encryption.js";

const companySchema = new mongoose.Schema(
  {
    companyId: { type: String, required: true, unique: true },
    // 1. Basic Information
    logo: { type: String }, // Company Logo URL
    name: { type: String, required: true }, // Company Name
    companyType: { 
      type: String, 
      required: true, 
      enum: ['Company', 'Individual'],
      default: 'Company' 
    },
    industry: { type: String },

    // 2. Contact Details (Company)
    email: { type: String, required: true }, // Company Email
    phone: { type: String, required: true }, // Company Phone
    alternatePhone: { type: String },
    website: { type: String },

    // 3. Address Details
    addressLine1: { type: String, required: true },
    addressLine2: { type: String },
    city: { type: String, required: true },
    state: { type: String, required: true },
    country: { type: String, required: true },
    pincode: { type: String, required: true },

    // 4. Business Information
    gstNumber: { type: String, set: encrypt, get: decrypt },
    panNumber: { type: String, set: encrypt, get: decrypt },

    // 5. Contact Person Details (Primary)
    contactPersonName: { type: String, required: true },
    designation: { type: String },
    contactPersonEmail: { type: String, required: true, set: encrypt, get: decrypt },
    contactPersonPhone: { type: String, required: true, set: encrypt, get: decrypt },

    projects: { type: Number, default: 0 },
    totalCost: { type: Number, default: 0 },
  },
  { timestamps: true, toJSON: { getters: true }, toObject: { getters: true } }
);

export default mongoose.model("Company", companySchema);
