import mongoose from "mongoose";

const leaveRequestsSchema = new mongoose.Schema({
  // 🔗 Link to Employee (User)
  employee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  employeeId: {
    type: String,
    required: true,
    trim: true
  },
  employeeName: {
    type: String,
    required: true,
  },

  // 📋 Array of leave requests grouped by leave type
  leaveRequests: [
    {
      leaveId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "LeaveMaster",
        required: true,
      },
      leaveName: {
        type: String,
        required: true
      },
      // 📝 Array of individual leave applications for this leave type
      applications: [{
        fromDate: { 
          type: Date, 
          required: true 
        },
        toDate: { 
          type: Date, 
          required: true 
        },
        numberOfDays: { 
          type: Number, 
          required: true 
        },
        totalDays: {
          type: Number,
          required: true
        },
        excludedDays: {
          type: Number,
          default: 0
        },
        reason: { 
          type: String, 
          required: true 
        },
        status: {
          type: String,
          enum: ['pending', 'approved', 'rejected', 'partially_approved'],
          default: 'pending'
        },
        approvedDays: {
          type: Number,
          default: 0
        },
        lopDays: {
          type: Number,
          default: 0
        },
      }]
    }
  ],

  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

export default mongoose.model("LeaveRequests", leaveRequestsSchema);