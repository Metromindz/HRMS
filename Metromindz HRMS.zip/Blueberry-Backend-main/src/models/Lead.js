import mongoose from "mongoose";

const leadSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    mobile: { type: String, required: true },
    email: { type: String, default: "" },
    websiteType: { type: String, default: "" },
    status: {
      type: String,
      enum: ["new", "contacted", "in_progress", "qualified", "proposal_sent", "negotiation", "won", "lost", "on_hold"],
      default: "new",
    },
    message: { type: String, default: "" },
    assignedTo: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    companyName: { type: String, default: "" },
    estimatedPrice: { type: Number, default: 0 },
    companyType: { type: String, enum: ["Company", "Individual"], default: "Individual" },
    source: { type: String, default: "" },
    convertedCompany: { type: mongoose.Schema.Types.ObjectId, ref: "Company", default: null },
    convertedAt: { type: Date, default: null },
    followUps: [
      {
        stage: String,
        status: String, // e.g., Interested, Call Back Later
        notes: String,
        nextFollowUp: Date,
        reminderNotifiedAt: { type: Date, default: null },
        date: { type: Date, default: Date.now },
        updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      },
    ],
  },
  { timestamps: true }
);

leadSchema.index({ mobile: 1 }, { unique: false });
leadSchema.index({ email: 1 }, { unique: false });

export default mongoose.model("Lead", leadSchema);
