import nodemailer from "nodemailer";
import dotenv from "dotenv";

dotenv.config()

const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

export const sendAccountCreatedEmail = async (email, link) => {

  try {
    await transporter.sendMail({
      from: `"HR Team" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: "Your Employee Account is Created",
      html: `
      <p>Your employee account has been created successfully.</p>
      <p>Please click the link below to set your password:</p>
      <a href="${link}">${link}</a>
      <p>This link will expire in 24 hours.</p>
    `
    });


  } catch (error) {
    console.error("Error sending email", error.message);

  }
};
