import CryptoJS from "crypto-js";
import dotenv from "dotenv";

dotenv.config();

const SECRET_KEY = process.env.ENCRYPTION_KEY;

if (!SECRET_KEY) {
  console.error("⚠️ ENCRYPTION_KEY is missing in environment variables. Encryption will fail.");
}

/**
 * Encrypts a given text using AES-256.
 * @param {string} text - The plaintext to encrypt.
 * @returns {string} - The encrypted ciphertext.
 */
export const encrypt = (text) => {
  if (!text) return text;
  try {
    return CryptoJS.AES.encrypt(String(text), SECRET_KEY).toString();
  } catch (error) {
    console.error("Encryption error:", error);
    return text;
  }
};

/**
 * Decrypts a given ciphertext using AES-256.
 * @param {string} ciphertext - The encrypted text to decrypt.
 * @returns {string} - The decrypted plaintext.
 */
export const decrypt = (ciphertext) => {
  if (!ciphertext) return ciphertext;
  try {
    const bytes = CryptoJS.AES.decrypt(ciphertext, SECRET_KEY);
    const originalText = bytes.toString(CryptoJS.enc.Utf8);
    return originalText || ciphertext; // Return original if decryption results in empty string (e.g. invalid key/text)
  } catch (error) {
    console.error("Decryption error:", error);
    return ciphertext;
  }
};
