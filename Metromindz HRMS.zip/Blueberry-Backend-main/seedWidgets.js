import mongoose from "mongoose";
import dotenv from "dotenv";
import Widget from "./src/models/Widget.js";

dotenv.config();

const seed = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log("Connected to MongoDB for seeding...");

        const initialWidgets = [
            { key: "profile_card", label: "Employee Profile", module: "HR", roles: ["superadmin", "admin", "employee"], order: 1, icon: "LuUser" },
            { key: "attendance_widget", label: "Attendance Control", module: "HR", roles: ["superadmin", "admin", "employee"], order: 2, icon: "LuClock" },
            { key: "notifications_panel", label: "Notifications", module: "Dashboard", roles: ["superadmin", "admin", "employee"], order: 3, icon: "LuBell" },
            { key: "announcements_widget", label: "Announcements Widget", module: "HR", roles: ["superadmin", "admin", "employee"], order: 4, icon: "LuMegaphone" },
            { key: "task_board_widget", label: "Task Board", module: "Task", roles: ["superadmin", "admin", "employee"], order: 5, icon: "LuLayout" },
            { key: "today_priorities_widget", label: "Today Priorities", module: "Task", roles: ["superadmin", "admin", "employee"], order: 6, icon: "LuListTodo" },
            { key: "employee_task_summary_widget", label: "Employee Task Summary", module: "Task", roles: ["superadmin", "admin", "employee"], order: 7, icon: "LuCheckCircle" },
            { key: "employee_performance_widget", label: "Employee Performance", module: "HR", roles: ["superadmin", "admin", "employee"], order: 8, icon: "LuTrendingUp" },
            { key: "activity_logs", label: "Activity Logs", module: "Dashboard", roles: ["superadmin", "admin"], order: 9, icon: "LuListChecks" },
            { key: "upcoming_birthdays", label: "Upcoming Birthdays", module: "HR", roles: ["superadmin", "admin"], order: 10, icon: "LuCalendar" },
            { key: "leads_overview", label: "Leads Overview Chart", module: "Lead", roles: ["superadmin", "admin"], order: 11, icon: "LuTrendingUp" },
            { key: "project_status", label: "Project Status Chart", module: "Project", roles: ["superadmin", "admin"], order: 12, icon: "LuBriefcase" },
            { key: "workforce_overview", label: "Workforce Overview", module: "HR", roles: ["superadmin", "admin"], order: 13, icon: "LuUsers" }
        ];

        for (const w of initialWidgets) {
            await Widget.findOneAndUpdate({ key: w.key }, w, { upsert: true, new: true });
            console.log(`Seeded/Updated: ${w.label}`);
        }

        console.log("Seeding complete!");
        process.exit(0);
    } catch (error) {
        console.error("Seeding failed:", error);
        process.exit(1);
    }
};

seed();
